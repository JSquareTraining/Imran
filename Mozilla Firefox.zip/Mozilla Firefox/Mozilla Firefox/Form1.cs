﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Reflection;
using System.Resources;
using System.IO;

namespace Mozilla_Firefox
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        TabPage t;
        TabPage t1;
        TabPage t2;
        TabPage t3;
        TabPage t4;
        TabPage t5;
        TabPage t6;
        TabPage t7;
        TabPage t8;
        ToolStripComboBox to;
        ToolStripComboBox to1;
        ToolStripComboBox to2;
        ToolStripComboBox to3;
        ToolStripComboBox to4;
        WebBrowser web;
        WebBrowser web1;
        WebBrowser web2;
        WebBrowser web3;
        WebBrowser web4;
        ResourceManager rm = new ResourceManager("Mozilla_Firefox.Properties.Resources", Assembly.GetExecutingAssembly());
        private void tabPage2_Enter(object sender, EventArgs e)
        {
            TabPage tabPage3 = new TabPage();
            tabPage3.Name = "tabPage3";
            tabPage3.Text = "New Tab                ";
            ToolStrip ts = new ToolStrip();
            ts.Dock = DockStyle.Top;
            ToolStripButton tb = new ToolStripButton();
            tb.Name = "toolStripButton1";
            tb.Click +=new EventHandler(tb_Click);
            tb.Image = ((System.Drawing.Image)(rm.GetObject("back")));
            ToolStripComboBox tc = new ToolStripComboBox();
            tc.Name = "Searchbar";
            to = tc;
            tc.Size = new System.Drawing.Size(1000, 25);
            ToolStripButton tb1 = new ToolStripButton();
            tb1.Name = "toolStripButton2";
            tb1.Image = ((System.Drawing.Image)(rm.GetObject("fwd")));
            tb1.Click +=new EventHandler(tb1_Click);
            ToolStripSeparator tts = new ToolStripSeparator();
            ToolStripButton bookmark = new ToolStripButton();
            bookmark.Name = "Bookmark";
            bookmark.Image = ((System.Drawing.Image)(rm.GetObject("book")));
            bookmark.Click += new EventHandler(bookmark_Click);
            ToolStripButton showbook = new ToolStripButton();
            showbook.Name = "showBook";
            showbook.Image = ((System.Drawing.Image)(rm.GetObject("showbook")));
            showbook.Click += new EventHandler(showbook_Click);


            tabControl1.TabPages.Add(tabPage3);
            tabPage3.Controls.Add(ts);
            ts.Items.Add(tb);
            ts.Items.Add(tc);
            ts.Items.Add(tb1);
            ts.Items.Add(tts);
            ts.Items.Add(bookmark);
            ts.Items.Add(showbook);
            WebBrowser wb = new WebBrowser();
            wb.Name = "webBrowser2";
            wb.Size = new System.Drawing.Size(1354, 687);
            wb.Location = new Point(3, 28);
            web = wb;
            tabPage3.Controls.Add(wb);
           
            
            TabPage tabPage4 = new TabPage();
            tabPage4.Name = "tabPage4";
            tabPage4.Text = "+";
            tabControl1.TabPages.Add(tabPage4);
            tabControl1.TabPages.Remove(tabPage2);
            t = tabPage4;
            tabPage4.Enter  += new EventHandler(tabPage4_Enter);
           
           
        }
        private void bookmark_Click(object sender, EventArgs e)
        {
            TextWriter tw;
            tw = File.AppendText(@"C:\Firefox\Bookmarks\Bookmarks.txt");
            tw.WriteLine(to.Text);
            tw.Dispose();
            tw.Close();

        }
        private void showbook_Click(object sender, EventArgs e)
        {
            Form2 frm2 = new Form2();
            TextReader tr;
            tr = File.OpenText(@"C:\Firefox\Bookmarks\Bookmarks.txt");
            frm2.richTextBox1.Text = tr.ReadToEnd();
            frm2.Show();
            tr.Dispose();
            tr.Close();
        }
        private void tb_Click(object sender, EventArgs e)
        {
            web.GoBack();
        }
        private void tb1_Click(object sender, EventArgs e)
        {
            if (to.Text != "")
            {
                web.Navigate(to.Text); 
                TextWriter tw2;
                tw2 = File.AppendText(@"C:\Firefox\History\History.txt");
                tw2.WriteLine(to.Text);
                tw2.Dispose();
                tw2.Close();

            }
        }


        private void tabPage4_Enter(object sender, EventArgs e)
        {
            TabPage tabPage5 = new TabPage();
            tabPage5.Name = "tabPage5";
            tabPage5.Text = "New Tab               ";
            ToolStrip ts1 = new ToolStrip();
            ts1.Dock = DockStyle.Top;
            ToolStripButton tb2 = new ToolStripButton();
            tb2.Name = "toolStripButton1";
            tb2.Click +=new EventHandler(tb2_Click);
            tb2.Image = ((System.Drawing.Image)(rm.GetObject("back")));
            ToolStripComboBox tc1 = new ToolStripComboBox();
            tc1.Name = "Searchbar";
            to1 = tc1;
            tc1.Size = new System.Drawing.Size(1000, 25);
            ToolStripButton tb3 = new ToolStripButton();
            tb3.Name = "toolStripButton2";
            tb3.Image = ((System.Drawing.Image)(rm.GetObject("fwd")));
            tb3.Click +=new EventHandler(tb3_Click);
            ToolStripSeparator tts1 = new ToolStripSeparator();
            ToolStripButton bookmark1 = new ToolStripButton();
            bookmark1.Name = "Bookmark";
            bookmark1.Image = ((System.Drawing.Image)(rm.GetObject("book")));
            bookmark1.Click += new EventHandler(bookmark1_Click);
            ToolStripButton showbook = new ToolStripButton();
            showbook.Name = "showBook";
            showbook.Image = ((System.Drawing.Image)(rm.GetObject("showbook")));
            showbook.Click += new EventHandler(showbook_Click);
            tabControl1.TabPages.Add(tabPage5);
            tabPage5.Controls.Add(ts1);
            ts1.Items.Add(tb2);
            ts1.Items.Add(tc1);
            ts1.Items.Add(tb3);
            ts1.Items.Add(tts1);
            ts1.Items.Add(bookmark1);
            ts1.Items.Add(showbook);
            WebBrowser wb1 = new WebBrowser();
            wb1.Name = "webBrowser3";
            wb1.Size = new System.Drawing.Size(1354, 687);
            wb1.Location = new Point(3, 28);
            web1 = wb1;
            tabPage5.Controls.Add(wb1);

            TabPage tabPage6 = new TabPage();
            tabPage6.Name = "tabPage6";
            tabPage6.Text = "+";
            tabControl1.TabPages.Add(tabPage6);
            tabControl1.TabPages.Remove(t);
            t1 = tabPage6;
            tabPage6.Enter +=new EventHandler(tabPage6_Enter);
        }

        private void bookmark1_Click(object sender, EventArgs e)
        {
            TextWriter tw;
            tw = File.AppendText(@"C:\Firefox\Bookmarks\Bookmarks.txt");
            tw.WriteLine(to1.Text);
            tw.Dispose();
            tw.Close();

        }
        private void tb2_Click(object sender, EventArgs e)
        {
            web1.GoBack();
        }

        private void tb3_Click(object sender, EventArgs e)
        {
            if (to1.Text != "")
            {
                web1.Navigate(to1.Text);
                TextWriter tw3;
                tw3 = File.AppendText(@"C:\Firefox\History\History.txt");
                tw3.WriteLine(to1.Text);
                tw3.Dispose();
                tw3.Close();
            }
        }

        private void tabPage6_Enter(object sender, EventArgs e)
        {
            TabPage tabPage7 = new TabPage();
            tabPage7.Name = "tabPage7";
            tabPage7.Text = "New Tab               ";
            ToolStrip ts2 = new ToolStrip();
            ts2.Dock = DockStyle.Top;
            ToolStripButton tb4 = new ToolStripButton();
            tb4.Name = "toolStripButton1";
            tb4.Click += new EventHandler(tb4_Click);
            tb4.Image = ((System.Drawing.Image)(rm.GetObject("back")));
            ToolStripComboBox tc2 = new ToolStripComboBox();
            tc2.Name = "Searchbar";
            to2 = tc2;
            tc2.Size = new System.Drawing.Size(1000, 25);
            ToolStripButton tb5 = new ToolStripButton();
            tb5.Name = "toolStripButton2";
            tb5.Image = ((System.Drawing.Image)(rm.GetObject("fwd")));
            tb5.Click += new EventHandler(tb5_Click);
            ToolStripSeparator tts2 = new ToolStripSeparator();
            ToolStripButton bookmark2 = new ToolStripButton();
            bookmark2.Name = "Bookmark";
            bookmark2.Image = ((System.Drawing.Image)(rm.GetObject("book")));
            bookmark2.Click += new EventHandler(bookmark2_Click);
            ToolStripButton showbook = new ToolStripButton();
            showbook.Name = "showBook";
            showbook.Image = ((System.Drawing.Image)(rm.GetObject("showbook")));
            showbook.Click += new EventHandler(showbook_Click);
            tabControl1.TabPages.Add(tabPage7);
            tabPage7.Controls.Add(ts2);
            ts2.Items.Add(tb4);
            ts2.Items.Add(tc2);
            ts2.Items.Add(tb5);
            ts2.Items.Add(tts2);
            ts2.Items.Add(bookmark2);
            ts2.Items.Add(showbook);
            WebBrowser wb2 = new WebBrowser();
            wb2.Name = "webBrowser3";
            wb2.Size = new System.Drawing.Size(1354, 687);
            wb2.Location = new Point(3, 28);
            web2 = wb2;
            tabPage7.Controls.Add(wb2);


            TabPage tabPage8 = new TabPage();
            tabPage8.Name = "tabPage8";
            tabPage8.Text = "+";
            tabControl1.TabPages.Add(tabPage8);
            tabControl1.TabPages.Remove(t1);
            t2 = tabPage8;
            tabPage8.Enter += new EventHandler(tabPage8_Enter);

        }
        private void bookmark2_Click(object sender, EventArgs e)
        {
            TextWriter tw;
            tw = File.AppendText(@"C:\Firefox\Bookmarks\Bookmarks.txt");
            tw.WriteLine(to2.Text);
            tw.Dispose();
            tw.Close();

        }

        private void tb4_Click(object sender, EventArgs e)
        {
            web2.GoBack();
        }
        private void tb5_Click(object sender, EventArgs e)
        {
            if (to2.Text != "")
            {
                web2.Navigate(to2.Text);
                TextWriter tw4;
                tw4 = File.AppendText(@"C:\Firefox\History\History.txt");
                tw4.WriteLine(to2.Text);
                tw4.Dispose();
                tw4.Close();
            }
        }

        private void tabPage8_Enter(object sender, EventArgs e)
        {
            TabPage tabPage9 = new TabPage();
            tabPage9.Name = "tabPage9";
            tabPage9.Text = "New Tab               ";
            ToolStrip ts3 = new ToolStrip();
            ts3.Dock = DockStyle.Top;
            ToolStripButton tb6 = new ToolStripButton();
            tb6.Name = "toolStripButton1";
            tb6.Click +=new EventHandler(tb6_Click);
            tb6.Image = ((System.Drawing.Image)(rm.GetObject("back")));
            ToolStripComboBox tc3 = new ToolStripComboBox();
            tc3.Name = "Searchbar";
            to3 = tc3;
            tc3.Size = new System.Drawing.Size(1000, 25);
            ToolStripButton tb7 = new ToolStripButton();
            tb7.Name = "toolStripButton2";
            tb7.Image = ((System.Drawing.Image)(rm.GetObject("fwd")));
            tb7.Click +=new EventHandler(tb7_Click);
            ToolStripSeparator tts3 = new ToolStripSeparator();
            ToolStripButton bookmark3 = new ToolStripButton();
            bookmark3.Name = "Bookmark";
            bookmark3.Image = ((System.Drawing.Image)(rm.GetObject("book")));
            bookmark3.Click += new EventHandler(bookmark3_Click);
            ToolStripButton showbook = new ToolStripButton();
            showbook.Name = "showBook";
            showbook.Image = ((System.Drawing.Image)(rm.GetObject("showbook")));
            showbook.Click += new EventHandler(showbook_Click);
            tabControl1.TabPages.Add(tabPage9);
            tabPage9.Controls.Add(ts3);
            ts3.Items.Add(tb6);
            ts3.Items.Add(tc3);
            ts3.Items.Add(tb7);
            ts3.Items.Add(tts3);
            ts3.Items.Add(bookmark3);
            ts3.Items.Add(showbook);
            WebBrowser wb3 = new WebBrowser();
            wb3.Name = "webBrowser4";
            wb3.Size = new System.Drawing.Size(1354, 687);
            wb3.Location = new Point(3, 28);
            web3 = wb3;
            tabPage9.Controls.Add(wb3);



            TabPage tabPage10 = new TabPage();
            tabPage10.Name = "tabPage10";
            tabPage10.Text = "+";
            tabControl1.TabPages.Add(tabPage10);
            tabControl1.TabPages.Remove(t2);
            t3 = tabPage10;
            tabPage10.Enter += new EventHandler(tabPage10_Enter);
        }
        private void bookmark3_Click(object sender, EventArgs e)
        {
            TextWriter tw;
            tw = File.AppendText(@"C:\Firefox\Bookmarks\Bookmarks.txt");
            tw.WriteLine(to3.Text);
            tw.Dispose();
            tw.Close();

        }
        private void tb6_Click(object sender, EventArgs e)
        {
            web3.GoBack();
        }
        private void tb7_Click(object sender, EventArgs e)
        {
            if (to3.Text != "")
            {
                web3.Navigate(to3.Text);
                TextWriter tw5;
                tw5 = File.AppendText(@"C:\Firefox\History\History.txt");
                tw5.WriteLine(to3.Text);
                tw5.Dispose();
                tw5.Close();
            }
        }




        private void tabPage10_Enter(object sender, EventArgs e)
        {

            TabPage tabPage11 = new TabPage();
            tabPage11.Name = "tabPage11";
            tabPage11.Text = "New Tab               ";
            ToolStrip ts4 = new ToolStrip();
            ts4.Dock = DockStyle.Top;
            ToolStripButton tb8 = new ToolStripButton();
            tb8.Name = "toolStripButton1";
            tb8.Click +=new EventHandler(tb8_Click);
            tb8.Image = ((System.Drawing.Image)(rm.GetObject("back")));
            ToolStripComboBox tc4 = new ToolStripComboBox();
            tc4.Name = "Searchbar";
            to4 = tc4;
            tc4.Size = new System.Drawing.Size(1000, 25);
            ToolStripButton tb9 = new ToolStripButton();
            tb9.Name = "toolStripButton2";
            tb9.Image = ((System.Drawing.Image)(rm.GetObject("fwd")));
            tb9.Click +=new EventHandler(tb9_Click);
            ToolStripSeparator tts4 = new ToolStripSeparator();
            ToolStripButton bookmark4 = new ToolStripButton();
            bookmark4.Name = "Bookmark";
            bookmark4.Image = ((System.Drawing.Image)(rm.GetObject("book")));
            bookmark4.Click += new EventHandler(bookmark4_Click);
            ToolStripButton showbook = new ToolStripButton();
            showbook.Name = "showBook";
            showbook.Image = ((System.Drawing.Image)(rm.GetObject("showbook")));
            showbook.Click += new EventHandler(showbook_Click);
            tabControl1.TabPages.Add(tabPage11);
            tabPage11.Controls.Add(ts4);
            ts4.Items.Add(tb8);
            ts4.Items.Add(tc4);
            ts4.Items.Add(tb9);
            ts4.Items.Add(tts4);
            ts4.Items.Add(bookmark4);
            ts4.Items.Add(showbook);
            WebBrowser wb4 = new WebBrowser();
            wb4.Name = "webBrowser4";
            wb4.Size = new System.Drawing.Size(1354, 687);
            wb4.Location = new Point(3, 28);
            web4 = wb4;
            tabPage11.Controls.Add(wb4);


            TabPage tabPage12 = new TabPage();
            tabPage12.Name = "tabPage12";
            tabPage12.Text = "+";
            tabControl1.TabPages.Add(tabPage12);
            tabControl1.TabPages.Remove(t3);
            t4 = tabPage12;
            tabPage12.Enter += new EventHandler(tabPage12_Enter);
        }
        private void bookmark4_Click(object sender, EventArgs e)
        {
            TextWriter tw;
            tw = File.AppendText(@"C:\Firefox\Bookmarks\Bookmarks.txt");
            tw.WriteLine(to4.Text);
            tw.Dispose();
            tw.Close();

        }

        private void tb8_Click(object sender, EventArgs e)
        {
            web4.GoBack();
        }
        private void tb9_Click(object sender, EventArgs e)
        {
            if (to4.Text != "")
            {
                web4.Navigate(to4.Text);
                TextWriter tw5;
                tw5 = File.AppendText(@"C:\Firefox\History\History.txt");
                tw5.WriteLine(to4.Text);
                tw5.Dispose();
                tw5.Close();
            }
        }
        private void tabPage12_Enter(object sender, EventArgs e)
        {
            TabPage tabPage13 = new TabPage();
            tabPage13.Name = "tabPage13";
            tabPage13.Text = "New Tab               ";
            tabControl1.TabPages.Add(tabPage13);
            TabPage tabPage14 = new TabPage();
            tabPage14.Name = "tabPage14";
            tabPage14.Text = "+";
            tabControl1.TabPages.Add(tabPage14);
            tabControl1.TabPages.Remove(t4);
            t5 = tabPage14;
            tabPage14.Enter += new EventHandler(tabPage14_Enter);

        }
        private void tabPage14_Enter(object sender, EventArgs e)
        {
            TabPage tabPage15 = new TabPage();
            tabPage15.Name = "tabPage15";
            tabPage15.Text = "New Tab               ";
            tabControl1.TabPages.Add(tabPage15);
            TabPage tabPage16 = new TabPage();
            tabPage16.Name = "tabPage16";
            tabPage16.Text = "+";
            tabControl1.TabPages.Add(tabPage16);
            tabControl1.TabPages.Remove(t5);
            t6 = tabPage16;
            tabPage16.Enter += new EventHandler(tabPage16_Enter);
        }
        private void tabPage16_Enter(object sender, EventArgs e)
        {
            TabPage tabPage17 = new TabPage();
            tabPage17.Name = "tabPage17";
            tabPage17.Text = "New Tab               ";
            tabControl1.TabPages.Add(tabPage17);
            TabPage tabPage18 = new TabPage();
            tabPage18.Name = "tabPage18";
            tabPage18.Text = "+";
            tabControl1.TabPages.Add(tabPage18);
            tabControl1.TabPages.Remove(t6);
            t7 = tabPage18;
            tabPage18.Enter += new EventHandler(tabPage18_Enter);
        }
        private void tabPage18_Enter(object sender, EventArgs e)
        {
            TabPage tabPage19 = new TabPage();
            tabPage19.Name = "tabPage19";
            tabPage19.Text = "New Tab               ";
            tabControl1.TabPages.Add(tabPage19);
            TabPage tabPage20 = new TabPage();
            tabPage20.Name = "tabPage18";
            tabPage20.Text = "+";
            tabControl1.TabPages.Add(tabPage20);
            tabControl1.TabPages.Remove(t7);
            t8 = tabPage20;
            tabPage20.Enter += new EventHandler(tabPage20_Enter);
        }
        private void tabPage20_Enter(object sender, EventArgs e)
        {

        }

        private void toolStripButton2_Click(object sender, EventArgs e)
        {
            if (toolStripComboBox1.Text != "")
            {
                webBrowser1.Navigate(toolStripComboBox1.Text);
                TextWriter tw1;
                tw1 = File.AppendText(@"C:\Firefox\History\History.txt");
                tw1.WriteLine(toolStripComboBox1.Text);
                tw1.Dispose();
                tw1.Close();
            }
        }

        private void toolStripButton3_Click(object sender, EventArgs e)
        {
            TextWriter tw;
            tw = File.AppendText(@"C:\Firefox\Bookmarks\Bookmarks.txt");
            tw.WriteLine(toolStripComboBox1.Text);
            tw.Dispose();
            tw.Close();
        }

        private void toolStripButton4_Click(object sender, EventArgs e)
        {
            Form2 frm2 = new Form2();
            TextReader tr;
            tr = File.OpenText(@"C:\Firefox\Bookmarks\Bookmarks.txt");
            frm2.richTextBox1.Text = tr.ReadToEnd();
            frm2.Show();
            tr.Dispose();
            tr.Close();
        }

        


        
    }
}
