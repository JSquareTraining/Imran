﻿namespace Diary
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.progressBar1 = new System.Windows.Forms.ProgressBar();
            this.grpbx_Decide = new System.Windows.Forms.GroupBox();
            this.rd_Register = new System.Windows.Forms.RadioButton();
            this.rd_Login = new System.Windows.Forms.RadioButton();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.grpbx_Decide.SuspendLayout();
            this.SuspendLayout();
            // 
            // pictureBox1
            // 
            this.pictureBox1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(0, 0);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(1362, 741);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("Bickham Script Pro Semibold", 129.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Gold;
            this.label1.Location = new System.Drawing.Point(197, 345);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(1025, 304);
            this.label1.TabIndex = 1;
            this.label1.Text = "DIARY   2014\r\n";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // progressBar1
            // 
            this.progressBar1.Location = new System.Drawing.Point(504, 662);
            this.progressBar1.Name = "progressBar1";
            this.progressBar1.Size = new System.Drawing.Size(281, 23);
            this.progressBar1.Style = System.Windows.Forms.ProgressBarStyle.Continuous;
            this.progressBar1.TabIndex = 2;
            // 
            // grpbx_Decide
            // 
            this.grpbx_Decide.Controls.Add(this.rd_Register);
            this.grpbx_Decide.Controls.Add(this.rd_Login);
            this.grpbx_Decide.Location = new System.Drawing.Point(519, 219);
            this.grpbx_Decide.Name = "grpbx_Decide";
            this.grpbx_Decide.Size = new System.Drawing.Size(314, 90);
            this.grpbx_Decide.TabIndex = 3;
            this.grpbx_Decide.TabStop = false;
            // 
            // rd_Register
            // 
            this.rd_Register.AutoSize = true;
            this.rd_Register.Font = new System.Drawing.Font("Bosox Full", 20.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rd_Register.ForeColor = System.Drawing.Color.Gold;
            this.rd_Register.Location = new System.Drawing.Point(163, 33);
            this.rd_Register.Name = "rd_Register";
            this.rd_Register.Size = new System.Drawing.Size(130, 26);
            this.rd_Register.TabIndex = 1;
            this.rd_Register.TabStop = true;
            this.rd_Register.Text = "REGISTER";
            this.rd_Register.UseVisualStyleBackColor = true;
            // 
            // rd_Login
            // 
            this.rd_Login.AutoSize = true;
            this.rd_Login.Checked = true;
            this.rd_Login.Font = new System.Drawing.Font("Bosox Full", 20.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rd_Login.ForeColor = System.Drawing.Color.Gold;
            this.rd_Login.Location = new System.Drawing.Point(34, 33);
            this.rd_Login.Name = "rd_Login";
            this.rd_Login.Size = new System.Drawing.Size(88, 26);
            this.rd_Login.TabIndex = 0;
            this.rd_Login.TabStop = true;
            this.rd_Login.Text = "LOGIN";
            this.rd_Login.UseVisualStyleBackColor = true;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1362, 741);
            this.Controls.Add(this.grpbx_Decide);
            this.Controls.Add(this.progressBar1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.pictureBox1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.grpbx_Decide.ResumeLayout(false);
            this.grpbx_Decide.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.ProgressBar progressBar1;
        private System.Windows.Forms.GroupBox grpbx_Decide;
        private System.Windows.Forms.RadioButton rd_Register;
        private System.Windows.Forms.RadioButton rd_Login;
    }
}

