﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;

namespace Diary
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        Form4 frm4 = new Form4();
        private void Form2_Load(object sender, EventArgs e)
        {
            grpbx_Login.Parent = pictureBox1;
            grpbx_Login.BackColor = Color.Transparent;
        }

        private void button1_Click(object sender, EventArgs e)
        {

            if (File.Exists(@"C:\Diary\" + textBox1.Text + ".txt") == false)
            {
                MessageBox.Show("Please enter the Correct name", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                TextReader tr;

                tr = File.OpenText(@"C:\Diary\" + textBox1.Text + ".txt");

                textBox1.Text = tr.ReadLine();
                frm4.label1.Text = textBox1.Text;
                if (textBox2.Text == tr.ReadLine())
                {
                    DialogResult dr = new DialogResult();
                    dr = MessageBox.Show("Login Successfull", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    if (dr == DialogResult.OK)
                    {
                        this.Hide();

                        tr.ReadLine();
                        tr.ReadLine();

                        dateTimePicker1.Value = File.GetLastWriteTime(@"C:\Diary\" + textBox1.Text + ".txt");
                        int k = dateTimePicker1.Value.Minute;
                        frm4.dateTimePicker1.Value = DateTime.Now;
                        int k1 = frm4.dateTimePicker1.Value.Minute;
                        int k2 = k1 - k;
                        if (k2 > 0)
                        {
                            frm4.Show();
                        }
                        else
                        {
                            MessageBox.Show("Sorry u cant login now", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }


                    }
                }
                else
                {
                    MessageBox.Show("Login Failed", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                tr.Dispose();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
