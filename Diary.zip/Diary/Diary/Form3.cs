﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;

namespace Diary
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }
       
        private void button1_Click(object sender, EventArgs e)
        {

            saveFileDialog1.Filter = "Textfiles(*.txt)|*.txt|All Files(*.*)|*.*";
            saveFileDialog1.ShowDialog();

            TextWriter tw;
            tw = File.CreateText(saveFileDialog1.FileName);
            tw.WriteLine(txtbx_name.Text);
            tw.WriteLine(txtbx_password.Text);
            if (rdbtn_male.Checked == true)
            {
                tw.WriteLine(rdbtn_male.Text);
            }
            else
            {
                tw.WriteLine(rdbtn_female.Text);
            }
            tw.WriteLine(cmbbx_relation.Text);
            tw.Dispose();
            DialogResult dr = new DialogResult();
            dr = MessageBox.Show("Registered Succesfully", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
            if (dr == DialogResult.OK)
            {
                Form2 frm2 = new Form2();
                frm2.ShowDialog();
                this.Close();
            }
        }

        private void Form3_Load(object sender, EventArgs e)
        {
            groupBox1.Parent = pictureBox1;
            groupBox1.BackColor = Color.Transparent;
            lbl_Reg.Parent = pictureBox1;
            lbl_Reg.BackColor = Color.Transparent;
            lbl_Name.Parent = pictureBox1;
            lbl_Name.BackColor = Color.Transparent;
            label1.Parent = pictureBox1;
            label1.BackColor = Color.Transparent;
            label2.Parent = pictureBox1;
            label2.BackColor = Color.Transparent;
            label3.Parent = pictureBox1;
            label3.BackColor = Color.Transparent;

        }
    }
}
