﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;

namespace Diary
{
    public partial class Form4 : Form
    {
        public Form4()
        {
            InitializeComponent();
        }

        private void Form4_Load(object sender, EventArgs e)
        {
            label1.Parent = pictureBox1;
            label1.BackColor = Color.Transparent;
            panel1.Parent = pictureBox1;
            panel1.BackColor = Color.Transparent;
        }

        private void rdbtn_write_CheckedChanged(object sender, EventArgs e)
        {
            btn_save.Show();
            richTextBox1.Text = "";
        }

        private void rdbtn_read_CheckedChanged(object sender, EventArgs e)
        {
            btn_save.Hide();
            TextReader tr;
            tr = File.OpenText(@"C:\Diary\" + label1.Text + ".txt");
            tr.ReadLine();
            tr.ReadLine();
            tr.ReadLine();
            tr.ReadLine();
            richTextBox1.Text = tr.ReadToEnd();
            tr.Dispose();
            
        }

        private void btn_logout_Click(object sender, EventArgs e)
        {
            Form2 frm2 = new Form2();
            frm2.ShowDialog();
            this.Close();
        }

        private void btn_save_Click(object sender, EventArgs e)
        {
            TextWriter tw1;
            tw1 = File.AppendText(@"C:\Diary\" + label1.Text + ".txt");
            tw1.WriteLine(richTextBox1.Text);
            tw1.Dispose();
            richTextBox1.Text = "";
        }
    }
}
