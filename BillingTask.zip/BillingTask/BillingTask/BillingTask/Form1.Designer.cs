﻿namespace BillingTask
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.P1 = new System.Windows.Forms.TextBox();
            this.PQ1 = new System.Windows.Forms.TextBox();
            this.Q1 = new System.Windows.Forms.TextBox();
            this.A1 = new System.Windows.Forms.TextBox();
            this.P2 = new System.Windows.Forms.TextBox();
            this.PQ2 = new System.Windows.Forms.TextBox();
            this.Q2 = new System.Windows.Forms.TextBox();
            this.A2 = new System.Windows.Forms.TextBox();
            this.P3 = new System.Windows.Forms.TextBox();
            this.PQ3 = new System.Windows.Forms.TextBox();
            this.Q3 = new System.Windows.Forms.TextBox();
            this.A3 = new System.Windows.Forms.TextBox();
            this.P4 = new System.Windows.Forms.TextBox();
            this.PQ4 = new System.Windows.Forms.TextBox();
            this.Q4 = new System.Windows.Forms.TextBox();
            this.A4 = new System.Windows.Forms.TextBox();
            this.P5 = new System.Windows.Forms.TextBox();
            this.PQ5 = new System.Windows.Forms.TextBox();
            this.Q5 = new System.Windows.Forms.TextBox();
            this.A5 = new System.Windows.Forms.TextBox();
            this.Total = new System.Windows.Forms.TextBox();
            this.D1 = new System.Windows.Forms.TextBox();
            this.D2 = new System.Windows.Forms.TextBox();
            this.NA = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, ((System.Drawing.FontStyle)(((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic)
                            | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(25, 111);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(303, 37);
            this.label1.TabIndex = 0;
            this.label1.Text = "PRODUCT NAME";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label2
            // 
            this.label2.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, ((System.Drawing.FontStyle)(((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic)
                            | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(417, 111);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(374, 37);
            this.label2.TabIndex = 1;
            this.label2.Text = "PRODUCT/QUANTITY";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label3
            // 
            this.label3.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, ((System.Drawing.FontStyle)(((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic)
                            | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(927, 111);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(192, 37);
            this.label3.TabIndex = 2;
            this.label3.Text = "QUANTITY";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label4
            // 
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(1177, 111);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(192, 37);
            this.label4.TabIndex = 3;
            // 
            // label5
            // 
            this.label5.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, ((System.Drawing.FontStyle)(((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic)
                            | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(1298, 111);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(192, 37);
            this.label5.TabIndex = 4;
            this.label5.Text = "AMOUNT";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label6
            // 
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, ((System.Drawing.FontStyle)(((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic)
                            | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(522, 13);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(513, 45);
            this.label6.TabIndex = 5;
            this.label6.Text = " BILLING ";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // P1
            // 
            this.P1.AutoCompleteCustomSource.AddRange(new string[] {
            "Apple",
            "Banana",
            "Mosambi",
            "Mango",
            "Orange",
            "WaterMelon"});
            this.P1.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.P1.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.P1.BackColor = System.Drawing.Color.LightSalmon;
            this.P1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.P1.Location = new System.Drawing.Point(22, 180);
            this.P1.Name = "P1";
            this.P1.Size = new System.Drawing.Size(358, 31);
            this.P1.TabIndex = 6;
            this.P1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.P1.WordWrap = false;
            
            // 
            // PQ1
            // 
            this.PQ1.BackColor = System.Drawing.Color.LightSalmon;
            this.PQ1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PQ1.Location = new System.Drawing.Point(415, 180);
            this.PQ1.Name = "PQ1";
            this.PQ1.Size = new System.Drawing.Size(376, 31);
            this.PQ1.TabIndex = 7;
            this.PQ1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.PQ1.WordWrap = false;
            
            // 
            // Q1
            // 
            this.Q1.BackColor = System.Drawing.Color.LightSalmon;
            this.Q1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Q1.Location = new System.Drawing.Point(833, 180);
            this.Q1.Name = "Q1";
            this.Q1.Size = new System.Drawing.Size(376, 31);
            this.Q1.TabIndex = 8;
            this.Q1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.Q1.WordWrap = false;
            this.Q1.TextChanged += new System.EventHandler(this.Q1_TextChanged);
            // 
            // A1
            // 
            this.A1.BackColor = System.Drawing.Color.LightSalmon;
            this.A1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.A1.Location = new System.Drawing.Point(1241, 180);
            this.A1.Name = "A1";
            this.A1.Size = new System.Drawing.Size(376, 31);
            this.A1.TabIndex = 9;
            this.A1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.A1.WordWrap = false;
            
            // 
            // P2
            // 
            this.P2.AutoCompleteCustomSource.AddRange(new string[] {
            "Apple",
            "Banana",
            "Mango",
            "Mosambi",
            "Orange",
            "WaterMelon"});
            this.P2.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.P2.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.P2.BackColor = System.Drawing.Color.LightSalmon;
            this.P2.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.P2.Location = new System.Drawing.Point(22, 233);
            this.P2.Name = "P2";
            this.P2.Size = new System.Drawing.Size(358, 31);
            this.P2.TabIndex = 10;
            this.P2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.P2.WordWrap = false;
            
            // 
            // PQ2
            // 
            this.PQ2.BackColor = System.Drawing.Color.LightSalmon;
            this.PQ2.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PQ2.Location = new System.Drawing.Point(415, 233);
            this.PQ2.Name = "PQ2";
            this.PQ2.Size = new System.Drawing.Size(376, 31);
            this.PQ2.TabIndex = 11;
            this.PQ2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.PQ2.WordWrap = false;
            // 
            // Q2
            // 
            this.Q2.BackColor = System.Drawing.Color.LightSalmon;
            this.Q2.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Q2.Location = new System.Drawing.Point(833, 233);
            this.Q2.Name = "Q2";
            this.Q2.Size = new System.Drawing.Size(376, 31);
            this.Q2.TabIndex = 12;
            this.Q2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.Q2.WordWrap = false;
            this.Q2.TextChanged += new System.EventHandler(this.Q2_TextChanged);
            // 
            // A2
            // 
            this.A2.BackColor = System.Drawing.Color.LightSalmon;
            this.A2.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.A2.Location = new System.Drawing.Point(1241, 233);
            this.A2.Name = "A2";
            this.A2.Size = new System.Drawing.Size(376, 31);
            this.A2.TabIndex = 13;
            this.A2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.A2.WordWrap = false;
         
            // 
            // P3
            // 
            this.P3.AutoCompleteCustomSource.AddRange(new string[] {
            "Apple",
            "Banana",
            "Mango",
            "Mosambi",
            "Orange",
            "WaterMelon"});
            this.P3.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.P3.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.P3.BackColor = System.Drawing.Color.LightSalmon;
            this.P3.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.P3.Location = new System.Drawing.Point(22, 286);
            this.P3.Name = "P3";
            this.P3.Size = new System.Drawing.Size(358, 31);
            this.P3.TabIndex = 14;
            this.P3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.P3.WordWrap = false;
           
            // 
            // PQ3
            // 
            this.PQ3.BackColor = System.Drawing.Color.LightSalmon;
            this.PQ3.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PQ3.Location = new System.Drawing.Point(415, 286);
            this.PQ3.Name = "PQ3";
            this.PQ3.Size = new System.Drawing.Size(376, 31);
            this.PQ3.TabIndex = 15;
            this.PQ3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.PQ3.WordWrap = false;
            // 
            // Q3
            // 
            this.Q3.BackColor = System.Drawing.Color.LightSalmon;
            this.Q3.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Q3.Location = new System.Drawing.Point(833, 286);
            this.Q3.Name = "Q3";
            this.Q3.Size = new System.Drawing.Size(376, 31);
            this.Q3.TabIndex = 16;
            this.Q3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.Q3.WordWrap = false;
            this.Q3.TextChanged += new System.EventHandler(this.Q3_TextChanged);
            // 
            // A3
            // 
            this.A3.BackColor = System.Drawing.Color.LightSalmon;
            this.A3.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.A3.Location = new System.Drawing.Point(1241, 286);
            this.A3.Name = "A3";
            this.A3.Size = new System.Drawing.Size(376, 31);
            this.A3.TabIndex = 17;
            this.A3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.A3.WordWrap = false;
         
            // 
            // P4
            // 
            this.P4.AutoCompleteCustomSource.AddRange(new string[] {
            "Apple",
            "Banana",
            "Mango",
            "Mosambi",
            "Orange",
            "WaterMelon"});
            this.P4.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.P4.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.P4.BackColor = System.Drawing.Color.LightSalmon;
            this.P4.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.P4.Location = new System.Drawing.Point(22, 337);
            this.P4.Name = "P4";
            this.P4.Size = new System.Drawing.Size(358, 31);
            this.P4.TabIndex = 18;
            this.P4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.P4.WordWrap = false;
          
            // 
            // PQ4
            // 
            this.PQ4.BackColor = System.Drawing.Color.LightSalmon;
            this.PQ4.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PQ4.Location = new System.Drawing.Point(415, 337);
            this.PQ4.Name = "PQ4";
            this.PQ4.Size = new System.Drawing.Size(376, 31);
            this.PQ4.TabIndex = 19;
            this.PQ4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.PQ4.WordWrap = false;
            // 
            // Q4
            // 
            this.Q4.BackColor = System.Drawing.Color.LightSalmon;
            this.Q4.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Q4.Location = new System.Drawing.Point(833, 337);
            this.Q4.Name = "Q4";
            this.Q4.Size = new System.Drawing.Size(376, 31);
            this.Q4.TabIndex = 20;
            this.Q4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.Q4.WordWrap = false;
            this.Q4.TextChanged += new System.EventHandler(this.Q4_TextChanged);
            // 
            // A4
            // 
            this.A4.BackColor = System.Drawing.Color.LightSalmon;
            this.A4.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.A4.Location = new System.Drawing.Point(1241, 337);
            this.A4.Name = "A4";
            this.A4.Size = new System.Drawing.Size(376, 31);
            this.A4.TabIndex = 21;
            this.A4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.A4.WordWrap = false;
          
            // 
            // P5
            // 
            this.P5.AutoCompleteCustomSource.AddRange(new string[] {
            "Apple",
            "Banana",
            "Mango",
            "Mosambi",
            "Orange",
            "WaterMelon"});
            this.P5.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.P5.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.P5.BackColor = System.Drawing.Color.LightSalmon;
            this.P5.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.P5.Location = new System.Drawing.Point(22, 384);
            this.P5.Name = "P5";
            this.P5.Size = new System.Drawing.Size(358, 31);
            this.P5.TabIndex = 22;
            this.P5.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.P5.WordWrap = false;
      
            // 
            // PQ5
            // 
            this.PQ5.BackColor = System.Drawing.Color.LightSalmon;
            this.PQ5.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PQ5.Location = new System.Drawing.Point(415, 384);
            this.PQ5.Name = "PQ5";
            this.PQ5.Size = new System.Drawing.Size(376, 31);
            this.PQ5.TabIndex = 23;
            this.PQ5.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.PQ5.WordWrap = false;
            // 
            // Q5
            // 
            this.Q5.BackColor = System.Drawing.Color.LightSalmon;
            this.Q5.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Q5.Location = new System.Drawing.Point(833, 384);
            this.Q5.Name = "Q5";
            this.Q5.Size = new System.Drawing.Size(376, 31);
            this.Q5.TabIndex = 24;
            this.Q5.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.Q5.WordWrap = false;
            this.Q5.TextChanged += new System.EventHandler(this.Q5_TextChanged);
            // 
            // A5
            // 
            this.A5.BackColor = System.Drawing.Color.LightSalmon;
            this.A5.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.A5.Location = new System.Drawing.Point(1241, 384);
            this.A5.Name = "A5";
            this.A5.Size = new System.Drawing.Size(376, 31);
            this.A5.TabIndex = 25;
            this.A5.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.A5.WordWrap = false;
            
            // 
            // Total
            // 
            this.Total.BackColor = System.Drawing.Color.LightSalmon;
            this.Total.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Total.Location = new System.Drawing.Point(1241, 452);
            this.Total.Multiline = true;
            this.Total.Name = "Total";
            this.Total.Size = new System.Drawing.Size(376, 28);
            this.Total.TabIndex = 26;
            this.Total.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.Total.WordWrap = false;
            
            // 
            // D1
            // 
            this.D1.BackColor = System.Drawing.Color.LightSalmon;
            this.D1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.D1.Location = new System.Drawing.Point(1241, 498);
            this.D1.Multiline = true;
            this.D1.Name = "D1";
            this.D1.Size = new System.Drawing.Size(188, 28);
            this.D1.TabIndex = 27;
            this.D1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.D1.WordWrap = false;
            this.D1.TextChanged += new System.EventHandler(this.D1_TextChanged);
            // 
            // D2
            // 
            this.D2.BackColor = System.Drawing.Color.LightSalmon;
            this.D2.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.D2.Location = new System.Drawing.Point(1449, 498);
            this.D2.Multiline = true;
            this.D2.Name = "D2";
            this.D2.Size = new System.Drawing.Size(168, 28);
            this.D2.TabIndex = 28;
            this.D2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.D2.WordWrap = false;
            this.D2.TextChanged += new System.EventHandler(this.D2_TextChanged);
            // 
            // NA
            // 
            this.NA.BackColor = System.Drawing.Color.LightSalmon;
            this.NA.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.NA.Location = new System.Drawing.Point(1241, 547);
            this.NA.Multiline = true;
            this.NA.Name = "NA";
            this.NA.Size = new System.Drawing.Size(376, 28);
            this.NA.TabIndex = 29;
            this.NA.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.NA.WordWrap = false;
            this.NA.TextChanged += new System.EventHandler(this.NA_TextChanged);
            // 
            // label7
            // 
            this.label7.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, ((System.Drawing.FontStyle)(((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic)
                            | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(1077, 443);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(132, 37);
            this.label7.TabIndex = 30;
            this.label7.Text = "TOTAL";
            this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label8
            // 
            this.label8.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, ((System.Drawing.FontStyle)(((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic)
                            | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(1034, 489);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(175, 37);
            this.label8.TabIndex = 31;
            this.label8.Text = "DISCOUNT";
            this.label8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label9
            // 
            this.label9.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, ((System.Drawing.FontStyle)(((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic)
                            | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(993, 538);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(216, 37);
            this.label9.TabIndex = 32;
            this.label9.Text = "NET AMOUNT";
            this.label9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.SeaShell;
            this.ClientSize = new System.Drawing.Size(1646, 636);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.NA);
            this.Controls.Add(this.D2);
            this.Controls.Add(this.D1);
            this.Controls.Add(this.Total);
            this.Controls.Add(this.A5);
            this.Controls.Add(this.Q5);
            this.Controls.Add(this.PQ5);
            this.Controls.Add(this.P5);
            this.Controls.Add(this.A4);
            this.Controls.Add(this.Q4);
            this.Controls.Add(this.PQ4);
            this.Controls.Add(this.P4);
            this.Controls.Add(this.A3);
            this.Controls.Add(this.Q3);
            this.Controls.Add(this.PQ3);
            this.Controls.Add(this.P3);
            this.Controls.Add(this.A2);
            this.Controls.Add(this.Q2);
            this.Controls.Add(this.PQ2);
            this.Controls.Add(this.P2);
            this.Controls.Add(this.A1);
            this.Controls.Add(this.Q1);
            this.Controls.Add(this.PQ1);
            this.Controls.Add(this.P1);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Fruit Stall";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox P1;
        private System.Windows.Forms.TextBox PQ1;
        private System.Windows.Forms.TextBox Q1;
        private System.Windows.Forms.TextBox A1;
        private System.Windows.Forms.TextBox P2;
        private System.Windows.Forms.TextBox PQ2;
        private System.Windows.Forms.TextBox Q2;
        private System.Windows.Forms.TextBox A2;
        private System.Windows.Forms.TextBox P3;
        private System.Windows.Forms.TextBox PQ3;
        private System.Windows.Forms.TextBox Q3;
        private System.Windows.Forms.TextBox A3;
        private System.Windows.Forms.TextBox P4;
        private System.Windows.Forms.TextBox PQ4;
        private System.Windows.Forms.TextBox Q4;
        private System.Windows.Forms.TextBox A4;
        private System.Windows.Forms.TextBox P5;
        private System.Windows.Forms.TextBox PQ5;
        private System.Windows.Forms.TextBox Q5;
        private System.Windows.Forms.TextBox A5;
        private System.Windows.Forms.TextBox Total;
        private System.Windows.Forms.TextBox D1;
        private System.Windows.Forms.TextBox D2;
        private System.Windows.Forms.TextBox NA;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
    }
}

