﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace BillingTask
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Q1_TextChanged(object sender, EventArgs e)
        {
            A1.Text = (Convert.ToInt32(PQ1.Text) * Convert.ToInt32(Q1.Text)).ToString();
            Total.Text = (Convert.ToInt32(A1.Text)).ToString();
            NA.Text = (Convert.ToInt32(Total.Text)).ToString();
        }

        private void D2_TextChanged(object sender, EventArgs e)
        {

            NA.Text = (Convert.ToDecimal(Total.Text) - Convert.ToDecimal(D2.Text)).ToString();
        }

        private void NA_TextChanged(object sender, EventArgs e)
        {
           
        }

        private void D1_TextChanged(object sender, EventArgs e)
        {
            D2.Text = (((Convert.ToDecimal(D1.Text)) / 100 * (Convert.ToInt32(Total.Text)))).ToString();
        }

        private void Q2_TextChanged(object sender, EventArgs e)
        {
            A2.Text = (Convert.ToInt32(PQ2.Text) * Convert.ToInt32(Q2.Text)).ToString();
            Total.Text = (Convert.ToInt32(A1.Text) + Convert.ToInt32(A2.Text)).ToString();
            NA.Text = (Convert.ToInt32(Total.Text)).ToString();
        }

        private void Q3_TextChanged(object sender, EventArgs e)
        {
            A3.Text = (Convert.ToInt32(PQ3.Text) * Convert.ToInt32(Q3.Text)).ToString();
            Total.Text = (Convert.ToInt32(A1.Text) + Convert.ToInt32(A2.Text) + Convert.ToInt32(A3.Text)).ToString();
            NA.Text = (Convert.ToInt32(Total.Text)).ToString();
        }

        private void Q4_TextChanged(object sender, EventArgs e)
        {
            A4.Text = (Convert.ToInt32(PQ4.Text) * Convert.ToInt32(Q4.Text)).ToString();
            Total.Text = (Convert.ToInt32(A1.Text) + Convert.ToInt32(A2.Text) + Convert.ToInt32(A3.Text) + Convert.ToInt32(A4.Text)).ToString();
            NA.Text = (Convert.ToInt32(Total.Text)).ToString();
        }

        private void Q5_TextChanged(object sender, EventArgs e)
        {
            A5.Text = (Convert.ToInt32(PQ5.Text) * Convert.ToInt32(Q5.Text)).ToString();
            Total.Text = (Convert.ToInt32(A1.Text) + Convert.ToInt32(A2.Text) + Convert.ToInt32(A3.Text) + Convert.ToInt32(A4.Text) + Convert.ToInt32(A5.Text)).ToString();
            NA.Text = (Convert.ToInt32(Total.Text)).ToString();
        }
    }
}
