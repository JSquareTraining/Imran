﻿namespace HotelMangament
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.nmetxtbx = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.fmlerdbtn = new System.Windows.Forms.RadioButton();
            this.mlerdbtn = new System.Windows.Forms.RadioButton();
            this.label3 = new System.Windows.Forms.Label();
            this.addrstxtbx = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.rmnotxtbx = new System.Windows.Forms.TextBox();
            this.rmtypecmbbx = new System.Windows.Forms.ComboBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.chckntmetxtbx = new System.Windows.Forms.TextBox();
            this.Nmeadd = new System.Windows.Forms.Button();
            this.Gndradd = new System.Windows.Forms.Button();
            this.Addrssbtn = new System.Windows.Forms.Button();
            this.Rmnmbrbtn = new System.Windows.Forms.Button();
            this.Rmtypebtn = new System.Windows.Forms.Button();
            this.nofdysbtn = new System.Windows.Forms.Button();
            this.chckntmebtn = new System.Windows.Forms.Button();
            this.smbtbtn = new System.Windows.Forms.Button();
            this.Rmaltbtn = new System.Windows.Forms.Button();
            this.Addlistbx = new System.Windows.Forms.ListBox();
            this.nofdystxtbx = new System.Windows.Forms.ComboBox();
            this.nwbtn = new System.Windows.Forms.Button();
            this.updtebtn = new System.Windows.Forms.Button();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(441, 51);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(100, 23);
            this.label1.TabIndex = 0;
            this.label1.Text = "Name";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // nmetxtbx
            // 
            this.nmetxtbx.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nmetxtbx.Location = new System.Drawing.Point(588, 51);
            this.nmetxtbx.Name = "nmetxtbx";
            this.nmetxtbx.Size = new System.Drawing.Size(191, 22);
            this.nmetxtbx.TabIndex = 1;
            // 
            // label2
            // 
            this.label2.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(441, 99);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(100, 23);
            this.label2.TabIndex = 2;
            this.label2.Text = "Gender";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.fmlerdbtn);
            this.groupBox1.Controls.Add(this.mlerdbtn);
            this.groupBox1.Location = new System.Drawing.Point(588, 89);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(191, 75);
            this.groupBox1.TabIndex = 3;
            this.groupBox1.TabStop = false;
            // 
            // fmlerdbtn
            // 
            this.fmlerdbtn.AutoSize = true;
            this.fmlerdbtn.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.fmlerdbtn.Location = new System.Drawing.Point(7, 38);
            this.fmlerdbtn.Name = "fmlerdbtn";
            this.fmlerdbtn.Size = new System.Drawing.Size(62, 19);
            this.fmlerdbtn.TabIndex = 1;
            this.fmlerdbtn.TabStop = true;
            this.fmlerdbtn.Text = "Female";
            this.fmlerdbtn.UseVisualStyleBackColor = true;
            // 
            // mlerdbtn
            // 
            this.mlerdbtn.AutoSize = true;
            this.mlerdbtn.Checked = true;
            this.mlerdbtn.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mlerdbtn.Location = new System.Drawing.Point(7, 14);
            this.mlerdbtn.Name = "mlerdbtn";
            this.mlerdbtn.Size = new System.Drawing.Size(52, 19);
            this.mlerdbtn.TabIndex = 0;
            this.mlerdbtn.TabStop = true;
            this.mlerdbtn.Text = "Male";
            this.mlerdbtn.UseVisualStyleBackColor = true;
            // 
            // label3
            // 
            this.label3.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(441, 183);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(100, 23);
            this.label3.TabIndex = 4;
            this.label3.Text = "Address";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // addrstxtbx
            // 
            this.addrstxtbx.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.addrstxtbx.Location = new System.Drawing.Point(588, 186);
            this.addrstxtbx.Multiline = true;
            this.addrstxtbx.Name = "addrstxtbx";
            this.addrstxtbx.Size = new System.Drawing.Size(191, 89);
            this.addrstxtbx.TabIndex = 5;
            // 
            // label4
            // 
            this.label4.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(441, 293);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(100, 23);
            this.label4.TabIndex = 6;
            this.label4.Text = "Room No";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label5
            // 
            this.label5.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(441, 342);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(100, 23);
            this.label5.TabIndex = 7;
            this.label5.Text = "Room Type";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // rmnotxtbx
            // 
            this.rmnotxtbx.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rmnotxtbx.Location = new System.Drawing.Point(588, 295);
            this.rmnotxtbx.Name = "rmnotxtbx";
            this.rmnotxtbx.Size = new System.Drawing.Size(191, 22);
            this.rmnotxtbx.TabIndex = 8;
            // 
            // rmtypecmbbx
            // 
            this.rmtypecmbbx.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.rmtypecmbbx.FormattingEnabled = true;
            this.rmtypecmbbx.Items.AddRange(new object[] {
            "DELUX",
            "SUPER DELUX",
            "GOLD",
            "PLATINUM"});
            this.rmtypecmbbx.Location = new System.Drawing.Point(588, 342);
            this.rmtypecmbbx.Name = "rmtypecmbbx";
            this.rmtypecmbbx.Size = new System.Drawing.Size(191, 21);
            this.rmtypecmbbx.TabIndex = 9;
            // 
            // label6
            // 
            this.label6.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(367, 386);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(174, 23);
            this.label6.TabIndex = 10;
            this.label6.Text = "Number of Days";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label7
            // 
            this.label7.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(367, 427);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(174, 23);
            this.label7.TabIndex = 12;
            this.label7.Text = "Check in Time";
            this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // chckntmetxtbx
            // 
            this.chckntmetxtbx.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chckntmetxtbx.Location = new System.Drawing.Point(588, 427);
            this.chckntmetxtbx.Name = "chckntmetxtbx";
            this.chckntmetxtbx.Size = new System.Drawing.Size(191, 22);
            this.chckntmetxtbx.TabIndex = 13;
            this.chckntmetxtbx.TextChanged += new System.EventHandler(this.chckntme_TextChanged);
            // 
            // Nmeadd
            // 
            this.Nmeadd.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Nmeadd.Location = new System.Drawing.Point(809, 51);
            this.Nmeadd.Name = "Nmeadd";
            this.Nmeadd.Size = new System.Drawing.Size(75, 23);
            this.Nmeadd.TabIndex = 14;
            this.Nmeadd.Text = "ADD";
            this.Nmeadd.UseVisualStyleBackColor = true;
            this.Nmeadd.Click += new System.EventHandler(this.Nmeadd_Click);
            // 
            // Gndradd
            // 
            this.Gndradd.Location = new System.Drawing.Point(809, 104);
            this.Gndradd.Name = "Gndradd";
            this.Gndradd.Size = new System.Drawing.Size(75, 23);
            this.Gndradd.TabIndex = 15;
            this.Gndradd.Text = "ADD";
            this.Gndradd.UseVisualStyleBackColor = true;
            this.Gndradd.Click += new System.EventHandler(this.Gndradd_Click);
            // 
            // Addrssbtn
            // 
            this.Addrssbtn.Location = new System.Drawing.Point(809, 183);
            this.Addrssbtn.Name = "Addrssbtn";
            this.Addrssbtn.Size = new System.Drawing.Size(75, 23);
            this.Addrssbtn.TabIndex = 16;
            this.Addrssbtn.Text = "ADD";
            this.Addrssbtn.UseVisualStyleBackColor = true;
            this.Addrssbtn.Click += new System.EventHandler(this.Addrssbtn_Click);
            // 
            // Rmnmbrbtn
            // 
            this.Rmnmbrbtn.Location = new System.Drawing.Point(809, 293);
            this.Rmnmbrbtn.Name = "Rmnmbrbtn";
            this.Rmnmbrbtn.Size = new System.Drawing.Size(75, 23);
            this.Rmnmbrbtn.TabIndex = 17;
            this.Rmnmbrbtn.Text = "ADD";
            this.Rmnmbrbtn.UseVisualStyleBackColor = true;
            this.Rmnmbrbtn.Click += new System.EventHandler(this.Rmnmbrbtn_Click);
            // 
            // Rmtypebtn
            // 
            this.Rmtypebtn.Location = new System.Drawing.Point(809, 340);
            this.Rmtypebtn.Name = "Rmtypebtn";
            this.Rmtypebtn.Size = new System.Drawing.Size(75, 23);
            this.Rmtypebtn.TabIndex = 18;
            this.Rmtypebtn.Text = "ADD";
            this.Rmtypebtn.UseVisualStyleBackColor = true;
            this.Rmtypebtn.Click += new System.EventHandler(this.Rmtypebtn_Click);
            // 
            // nofdysbtn
            // 
            this.nofdysbtn.Location = new System.Drawing.Point(809, 386);
            this.nofdysbtn.Name = "nofdysbtn";
            this.nofdysbtn.Size = new System.Drawing.Size(75, 23);
            this.nofdysbtn.TabIndex = 19;
            this.nofdysbtn.Text = "ADD";
            this.nofdysbtn.UseVisualStyleBackColor = true;
            this.nofdysbtn.Click += new System.EventHandler(this.nofdysbtn_Click);
            // 
            // chckntmebtn
            // 
            this.chckntmebtn.Location = new System.Drawing.Point(809, 428);
            this.chckntmebtn.Name = "chckntmebtn";
            this.chckntmebtn.Size = new System.Drawing.Size(75, 23);
            this.chckntmebtn.TabIndex = 20;
            this.chckntmebtn.Text = "ADD";
            this.chckntmebtn.UseVisualStyleBackColor = true;
            this.chckntmebtn.Click += new System.EventHandler(this.chckntmebtn_Click);
            // 
            // smbtbtn
            // 
            this.smbtbtn.Location = new System.Drawing.Point(588, 476);
            this.smbtbtn.Name = "smbtbtn";
            this.smbtbtn.Size = new System.Drawing.Size(75, 23);
            this.smbtbtn.TabIndex = 21;
            this.smbtbtn.Text = "Submit";
            this.smbtbtn.UseVisualStyleBackColor = true;
            this.smbtbtn.Click += new System.EventHandler(this.smbtbtn_Click);
            // 
            // Rmaltbtn
            // 
            this.Rmaltbtn.Location = new System.Drawing.Point(704, 476);
            this.Rmaltbtn.Name = "Rmaltbtn";
            this.Rmaltbtn.Size = new System.Drawing.Size(75, 23);
            this.Rmaltbtn.TabIndex = 22;
            this.Rmaltbtn.Text = "Room Alot";
            this.Rmaltbtn.UseVisualStyleBackColor = true;
            this.Rmaltbtn.Click += new System.EventHandler(this.Rmaltbtn_Click);
            // 
            // Addlistbx
            // 
            this.Addlistbx.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Addlistbx.FormattingEnabled = true;
            this.Addlistbx.HorizontalScrollbar = true;
            this.Addlistbx.ItemHeight = 15;
            this.Addlistbx.Location = new System.Drawing.Point(588, 534);
            this.Addlistbx.Name = "Addlistbx";
            this.Addlistbx.Size = new System.Drawing.Size(191, 169);
            this.Addlistbx.TabIndex = 23;
          
            // 
            // nofdystxtbx
            // 
            this.nofdystxtbx.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.nofdystxtbx.FormattingEnabled = true;
            this.nofdystxtbx.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10",
            "11",
            "12",
            "13",
            "14",
            "15",
            "16",
            "17",
            "18",
            "19",
            "20",
            "21",
            "22",
            "23",
            "24",
            "25",
            "26",
            "27",
            "28",
            "29",
            "30",
            "31",
            "32",
            "33",
            "35",
            "36",
            "37",
            "38",
            "39",
            "40",
            "41",
            "42",
            "43",
            "44",
            "45",
            "46",
            "47",
            "48",
            "49",
            "50"});
            this.nofdystxtbx.Location = new System.Drawing.Point(588, 388);
            this.nofdystxtbx.Name = "nofdystxtbx";
            this.nofdystxtbx.Size = new System.Drawing.Size(191, 21);
            this.nofdystxtbx.TabIndex = 24;
            // 
            // nwbtn
            // 
            this.nwbtn.Location = new System.Drawing.Point(874, 0);
            this.nwbtn.Name = "nwbtn";
            this.nwbtn.Size = new System.Drawing.Size(75, 23);
            this.nwbtn.TabIndex = 25;
            this.nwbtn.Text = "New";
            this.nwbtn.UseVisualStyleBackColor = true;
            this.nwbtn.Click += new System.EventHandler(this.nwbtn_Click);
            // 
            // updtebtn
            // 
            this.updtebtn.Location = new System.Drawing.Point(958, 0);
            this.updtebtn.Name = "updtebtn";
            this.updtebtn.Size = new System.Drawing.Size(75, 23);
            this.updtebtn.TabIndex = 26;
            this.updtebtn.Text = "Update";
            this.updtebtn.UseVisualStyleBackColor = true;
            this.updtebtn.Click += new System.EventHandler(this.updtebtn_Click);
            // 
            // textBox1
            // 
            this.textBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.textBox1.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox1.Location = new System.Drawing.Point(1, 716);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(191, 22);
            this.textBox1.TabIndex = 27;
            this.textBox1.Visible = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.ClientSize = new System.Drawing.Size(1045, 741);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.updtebtn);
            this.Controls.Add(this.nwbtn);
            this.Controls.Add(this.nofdystxtbx);
            this.Controls.Add(this.Addlistbx);
            this.Controls.Add(this.Rmaltbtn);
            this.Controls.Add(this.smbtbtn);
            this.Controls.Add(this.chckntmebtn);
            this.Controls.Add(this.nofdysbtn);
            this.Controls.Add(this.Rmtypebtn);
            this.Controls.Add(this.Rmnmbrbtn);
            this.Controls.Add(this.Addrssbtn);
            this.Controls.Add(this.Gndradd);
            this.Controls.Add(this.Nmeadd);
            this.Controls.Add(this.chckntmetxtbx);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.rmtypecmbbx);
            this.Controls.Add(this.rmnotxtbx);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.addrstxtbx);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.nmetxtbx);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
           
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox nmetxtbx;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.RadioButton fmlerdbtn;
        private System.Windows.Forms.RadioButton mlerdbtn;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox addrstxtbx;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox rmnotxtbx;
        private System.Windows.Forms.ComboBox rmtypecmbbx;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox chckntmetxtbx;
        private System.Windows.Forms.Button Nmeadd;
        private System.Windows.Forms.Button Gndradd;
        private System.Windows.Forms.Button Addrssbtn;
        private System.Windows.Forms.Button Rmnmbrbtn;
        private System.Windows.Forms.Button Rmtypebtn;
        private System.Windows.Forms.Button nofdysbtn;
        private System.Windows.Forms.Button chckntmebtn;
        private System.Windows.Forms.Button smbtbtn;
        private System.Windows.Forms.Button Rmaltbtn;
        private System.Windows.Forms.ComboBox nofdystxtbx;
        private System.Windows.Forms.Button nwbtn;
        private System.Windows.Forms.Button updtebtn;
        public System.Windows.Forms.ListBox Addlistbx;
        private System.Windows.Forms.TextBox textBox1;
    }
}

