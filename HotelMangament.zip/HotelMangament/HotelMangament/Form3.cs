﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace HotelMangament
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (rmtpetxtbx.Text == "DELUX")
            {
                tatxtbx.Text = ((Convert.ToInt32(ndystxtbx.Text) + Convert.ToInt32(updttxtbx.Text)) * 250).ToString();
            }
            else if (rmtpetxtbx.Text == "SUPER DELUX")
            {
                tatxtbx.Text = ((Convert.ToInt32(ndystxtbx.Text) + Convert.ToInt32(updttxtbx.Text)) * 500).ToString();
            }
            else if (rmtpetxtbx.Text == "GOLD")
            {
                tatxtbx.Text = ((Convert.ToInt32(ndystxtbx.Text) + Convert.ToInt32(updttxtbx.Text)) * 750).ToString();
            }
            else if (rmtpetxtbx.Text == "PLATINUM")
            {
                tatxtbx.Text = ((Convert.ToInt32(ndystxtbx.Text) + Convert.ToInt32(updttxtbx.Text)) * 1000).ToString();
            }
        }
    }
}
