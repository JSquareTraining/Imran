﻿namespace HotelMangament
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.mletxtbx1 = new System.Windows.Forms.ListBox();
            this.fmletxtbx1 = new System.Windows.Forms.ListBox();
            this.mletxtbx2 = new System.Windows.Forms.ListBox();
            this.fmletxtbx2 = new System.Windows.Forms.ListBox();
            this.SuspendLayout();
            // 
            // mletxtbx1
            // 
            this.mletxtbx1.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mletxtbx1.FormattingEnabled = true;
            this.mletxtbx1.HorizontalScrollbar = true;
            this.mletxtbx1.ItemHeight = 15;
            this.mletxtbx1.Location = new System.Drawing.Point(207, 94);
            this.mletxtbx1.Name = "mletxtbx1";
            this.mletxtbx1.Size = new System.Drawing.Size(204, 124);
            this.mletxtbx1.TabIndex = 0;
            this.mletxtbx1.SelectedIndexChanged += new System.EventHandler(this.mletxtbx1_SelectedIndexChanged);
            // 
            // fmletxtbx1
            // 
            this.fmletxtbx1.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.fmletxtbx1.FormattingEnabled = true;
            this.fmletxtbx1.ItemHeight = 15;
            this.fmletxtbx1.Location = new System.Drawing.Point(539, 94);
            this.fmletxtbx1.Name = "fmletxtbx1";
            this.fmletxtbx1.Size = new System.Drawing.Size(204, 124);
            this.fmletxtbx1.TabIndex = 1;
            // 
            // mletxtbx2
            // 
            this.mletxtbx2.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mletxtbx2.FormattingEnabled = true;
            this.mletxtbx2.ItemHeight = 15;
            this.mletxtbx2.Location = new System.Drawing.Point(207, 261);
            this.mletxtbx2.Name = "mletxtbx2";
            this.mletxtbx2.Size = new System.Drawing.Size(204, 124);
            this.mletxtbx2.TabIndex = 2;
            // 
            // fmletxtbx2
            // 
            this.fmletxtbx2.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.fmletxtbx2.FormattingEnabled = true;
            this.fmletxtbx2.ItemHeight = 15;
            this.fmletxtbx2.Location = new System.Drawing.Point(539, 261);
            this.fmletxtbx2.Name = "fmletxtbx2";
            this.fmletxtbx2.Size = new System.Drawing.Size(204, 124);
            this.fmletxtbx2.TabIndex = 3;
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.ClientSize = new System.Drawing.Size(987, 479);
            this.Controls.Add(this.fmletxtbx2);
            this.Controls.Add(this.mletxtbx2);
            this.Controls.Add(this.fmletxtbx1);
            this.Controls.Add(this.mletxtbx1);
            this.Name = "Form2";
            this.Text = "Form2";
            this.ResumeLayout(false);

        }

        #endregion

        public System.Windows.Forms.ListBox mletxtbx1;
        public System.Windows.Forms.ListBox fmletxtbx1;
        public System.Windows.Forms.ListBox mletxtbx2;
        public System.Windows.Forms.ListBox fmletxtbx2;
    }
}