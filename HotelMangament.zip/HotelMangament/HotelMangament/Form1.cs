﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace HotelMangament
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
     
        Form2 frm2 = new Form2();
        Form3 frm3 = new Form3();
        Properties.Settings st = new Properties.Settings();
        private void Nmeadd_Click(object sender, EventArgs e)
        {
            if (nmetxtbx.Text == "")
            {
                MessageBox.Show("Please Enter Your Name", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                if (Nmeadd.Text == "ADD")
                {
                    Nmeadd.Text = "REMOVE";
                 

                    if (mlerdbtn.Checked == true)
                    {
                       
                        if (st.Name == "" || st.Name1 == "" || st.Name2 == "" || st.Name3 == "" || st.Name4 == "" || st.Name5 == "" || st.Name6 == "" || st.Name7 == "" || st.Name8 == "" || st.Name9 == "")
                        {
                            if (st.Name == "")
                            {
                                Addlistbx.Items.Add(nmetxtbx.Text);
                                st.Name = nmetxtbx.Text;
                                frm2.mletxtbx1.Items.Add(nmetxtbx.Text);
                                st.Save();
                            }
                            else if (st.Name1 == "")
                            {
                                Addlistbx.Items.Add(nmetxtbx.Text);
                                st.Name1 = nmetxtbx.Text;
                                frm2.mletxtbx1.Items.Add(nmetxtbx.Text);
                                st.Save();
                            }
                            else if (st.Name2 == "")
                            {
                                Addlistbx.Items.Add(nmetxtbx.Text);
                                st.Name2 = nmetxtbx.Text;
                                frm2.mletxtbx1.Items.Add(nmetxtbx.Text);
                                st.Save();
                            }
                            else if (st.Name3 == "")
                            {
                                Addlistbx.Items.Add(nmetxtbx.Text);
                                st.Name3 = nmetxtbx.Text;
                                frm2.mletxtbx1.Items.Add(nmetxtbx.Text);
                                st.Save();
                            }
                            else if (st.Name4 == "")
                            {
                                Addlistbx.Items.Add(nmetxtbx.Text);
                                st.Name4 = nmetxtbx.Text;
                                frm2.mletxtbx1.Items.Add(nmetxtbx.Text);
                                st.Save();
                            }
                            else if (st.Name5 == "")
                            {
                                Addlistbx.Items.Add(nmetxtbx.Text);
                                st.Name5 = nmetxtbx.Text;
                                frm2.mletxtbx2.Items.Add(nmetxtbx.Text);
                                st.Save();
                            }
                            else if (st.Name6 == "")
                            {
                                Addlistbx.Items.Add(nmetxtbx.Text);
                                st.Name6 = nmetxtbx.Text;
                                frm2.mletxtbx2.Items.Add(nmetxtbx.Text);
                                st.Save();
                            }

                            else if (st.Name7 == "")
                            {
                                Addlistbx.Items.Add(nmetxtbx.Text);
                                st.Name7 = nmetxtbx.Text;
                                frm2.mletxtbx2.Items.Add(nmetxtbx.Text);
                                st.Save();
                            }
                            else if (st.Name8 == "")
                            {
                                Addlistbx.Items.Add(nmetxtbx.Text);
                                st.Name8 = nmetxtbx.Text;
                                frm2.mletxtbx2.Items.Add(nmetxtbx.Text);
                                st.Save();
                            }
                            else if (st.Name9 == "")
                            {
                                Addlistbx.Items.Add(nmetxtbx.Text);
                                st.Name9 = nmetxtbx.Text;
                                frm2.mletxtbx2.Items.Add(nmetxtbx.Text);
                                st.Save();
                            }

                        }
                        else
                        {
                            MessageBox.Show("Room not available", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }


                    }
                    else
                    {
                        
                        if (st.Name10 == "" || st.Name11 == "" || st.Name12 == "" || st.Name13 == "" || st.Name14 == "" || st.Name15 == "" || st.Name16 == "" || st.Name17 == "" || st.Name18 == "" || st.Name19 == "")
                        {
                            if (st.Name10 == "")
                            {
                                Addlistbx.Items.Add(nmetxtbx.Text);
                                st.Name10 = nmetxtbx.Text;
                                frm2.fmletxtbx1.Items.Add(nmetxtbx.Text);
                                st.Save();
                            }
                            else if (st.Name11 == "")
                            {
                                Addlistbx.Items.Add(nmetxtbx.Text);
                                st.Name11 = nmetxtbx.Text;
                                frm2.fmletxtbx1.Items.Add(nmetxtbx.Text);
                                st.Save();
                            }
                            else if (st.Name12 == "")
                            {
                                Addlistbx.Items.Add(nmetxtbx.Text);
                                st.Name12 = nmetxtbx.Text;
                                frm2.fmletxtbx1.Items.Add(nmetxtbx.Text);
                                st.Save();
                            }
                            else if (st.Name13 == "")
                            {
                                Addlistbx.Items.Add(nmetxtbx.Text);
                                st.Name13 = nmetxtbx.Text;
                                frm2.fmletxtbx1.Items.Add(nmetxtbx.Text);
                                st.Save();
                            }
                            else if (st.Name14 == "")
                            {
                                Addlistbx.Items.Add(nmetxtbx.Text);
                                st.Name14 = nmetxtbx.Text;
                                frm2.fmletxtbx1.Items.Add(nmetxtbx.Text);
                                st.Save();
                            }
                            else if (st.Name15 == "")
                            {
                                Addlistbx.Items.Add(nmetxtbx.Text);
                                st.Name15 = nmetxtbx.Text;
                                frm2.fmletxtbx2.Items.Add(nmetxtbx.Text);
                                st.Save();
                            }
                            else if (st.Name16 == "")
                            {
                                Addlistbx.Items.Add(nmetxtbx.Text);
                                st.Name16 = nmetxtbx.Text;
                                frm2.fmletxtbx2.Items.Add(nmetxtbx.Text);
                                st.Save();
                            }

                            else if (st.Name17 == "")
                            {
                                Addlistbx.Items.Add(nmetxtbx.Text);
                                st.Name17 = nmetxtbx.Text;
                                frm2.fmletxtbx2.Items.Add(nmetxtbx.Text);
                                st.Save();
                            }
                            else if (st.Name18 == "")
                            {
                                Addlistbx.Items.Add(nmetxtbx.Text);
                                st.Name18 = nmetxtbx.Text;
                                frm2.fmletxtbx2.Items.Add(nmetxtbx.Text);
                                st.Save();
                            }
                            else if (st.Name19 == "")
                            {
                                Addlistbx.Items.Add(nmetxtbx.Text);
                                st.Name19 = nmetxtbx.Text;
                                frm2.fmletxtbx2.Items.Add(nmetxtbx.Text);
                                st.Save();
                            }


                            else
                            {
                                MessageBox.Show("Room not available", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            }
                        }
                    }
                }
                else
                {
                    Nmeadd.Text = "ADD";
              
                    Addlistbx.Items.Remove(nmetxtbx.Text);

                    if (mlerdbtn.Checked == true)
                    {
                        if (st.Name == nmetxtbx.Text || st.Name1 == nmetxtbx.Text || st.Name2 == nmetxtbx.Text || st.Name3 == nmetxtbx.Text || st.Name4 == nmetxtbx.Text || st.Name5 == nmetxtbx.Text || st.Name6 == nmetxtbx.Text || st.Name7 == nmetxtbx.Text || st.Name8 == nmetxtbx.Text || st.Name9 == nmetxtbx.Text)
                        {
                            if (st.Name == nmetxtbx.Text)
                            {
                                frm3.nmetxtbx.Text = st.Name;
                                frm3.rmtpetxtbx.Text = st.rmtype;
                                frm3.ndystxtbx.Text = st.NumberofDays.ToString();
                                frm3.cittxtbx.Text = st.Checkintime;
                                frm3.ShowDialog();
                                frm2.mletxtbx1.Items.Remove(nmetxtbx.Text);
                                st.Name = "";
                                st.rmtype = "";
                                st.NumberofDays = 0;
                                st.Checkintime = "";
                                st.Save();
                            }
                            else if (st.Name1 == nmetxtbx.Text)
                            {
                                frm3.nmetxtbx.Text = st.Name1;
                                frm3.rmtpetxtbx.Text = st.rmtype1;
                                frm3.ndystxtbx.Text = st.NumberofDays1.ToString();
                                frm3.cittxtbx.Text = st.Checkintime1;
                                frm3.ShowDialog();
                                frm2.mletxtbx1.Items.Remove(nmetxtbx.Text);
                                st.Name1 = "";
                                st.rmtype1 = "";
                                st.NumberofDays1 = 0;
                                st.Checkintime1 = "";
                                st.Save();
                            }
                            else if (st.Name2 == nmetxtbx.Text)
                            {
                                frm3.nmetxtbx.Text = st.Name2;
                                frm3.rmtpetxtbx.Text = st.rmtype2;
                                frm3.ndystxtbx.Text = st.NumberofDays2.ToString();
                                frm3.cittxtbx.Text = st.Checkintime2;
                                frm3.ShowDialog();
                                frm2.mletxtbx1.Items.Remove(nmetxtbx.Text);
                                st.Name2 = "";
                                st.rmtype2 = "";
                                st.NumberofDays2 = 0;
                                st.Checkintime2 = "";
                                st.Save();
                            }
                            else if (st.Name3 == nmetxtbx.Text)
                            {
                                frm3.nmetxtbx.Text = st.Name3;
                                frm3.rmtpetxtbx.Text = st.rmtype3;
                                frm3.ndystxtbx.Text = st.NumberofDays3.ToString();
                                frm3.cittxtbx.Text = st.Checkintime3;
                                frm3.ShowDialog();
                                frm2.mletxtbx1.Items.Remove(nmetxtbx.Text);
                                st.Name3 = "";
                                st.rmtype3 = "";
                                st.NumberofDays3 = 0;
                                st.Checkintime3 = "";
                                st.Save();
                            }
                            else if (st.Name4 == nmetxtbx.Text)
                            {
                                frm3.nmetxtbx.Text = st.Name4;
                                frm3.rmtpetxtbx.Text = st.rmtype4;
                                frm3.ndystxtbx.Text = st.NumberofDays4.ToString();
                                frm3.cittxtbx.Text = st.Checkintime4;
                                frm3.ShowDialog();
                                frm2.mletxtbx1.Items.Remove(nmetxtbx.Text);
                                st.Name4 = "";
                                st.rmtype4 = "";
                                st.NumberofDays4 = 0;
                                st.Checkintime4 = "";
                                st.Save();
                            }
                            else if (st.Name5 == nmetxtbx.Text)
                            {
                                frm3.nmetxtbx.Text = st.Name5;
                                frm3.rmtpetxtbx.Text = st.rmtype5;
                                frm3.ndystxtbx.Text = st.NumberofDays5.ToString();
                                frm3.cittxtbx.Text = st.Checkintime5;
                                frm3.ShowDialog();
                                frm2.mletxtbx2.Items.Remove(nmetxtbx.Text);
                                st.Name5 = "";
                                st.rmtype5 = "";
                                st.NumberofDays5 = 0;
                                st.Checkintime5 = "";
                                st.Save();
                            }
                            else if (st.Name6 == nmetxtbx.Text)
                            {
                                frm3.nmetxtbx.Text = st.Name6;
                                frm3.rmtpetxtbx.Text = st.rmtype6;
                                frm3.ndystxtbx.Text = st.NumberofDays6.ToString();
                                frm3.cittxtbx.Text = st.Checkintime6;
                                frm3.ShowDialog();
                                frm2.mletxtbx2.Items.Remove(nmetxtbx.Text);
                                st.Name6 = "";
                                st.rmtype6 = "";
                                st.NumberofDays6 = 0;
                                st.Checkintime6 = "";
                                st.Save();
                            }
                            else if (st.Name7 == nmetxtbx.Text)
                            {
                                frm3.nmetxtbx.Text = st.Name7;
                                frm3.rmtpetxtbx.Text = st.rmtype7;
                                frm3.ndystxtbx.Text = st.NumberofDays7.ToString();
                                frm3.cittxtbx.Text = st.Checkintime7;
                                frm3.ShowDialog();
                                frm2.mletxtbx2.Items.Remove(nmetxtbx.Text);
                                st.Name7 = "";
                                st.rmtype7 = "";
                                st.NumberofDays7 = 0;
                                st.Checkintime7 = "";
                                st.Save();
                            }
                            else if (st.Name8 == nmetxtbx.Text)
                            {
                                frm3.nmetxtbx.Text = st.Name8;
                                frm3.rmtpetxtbx.Text = st.rmtype8;
                                frm3.ndystxtbx.Text = st.NumberofDays8.ToString();
                                frm3.cittxtbx.Text = st.Checkintime8;
                                frm3.ShowDialog();
                                frm2.mletxtbx2.Items.Remove(nmetxtbx.Text);
                                st.Name8 = "";
                                st.rmtype8 = "";
                                st.NumberofDays8 = 0;
                                st.Checkintime8 = "";
                                st.Save();
                            }
                            else if (st.Name9 == nmetxtbx.Text)
                            {
                                frm3.nmetxtbx.Text = st.Name9;
                                frm3.rmtpetxtbx.Text = st.rmtype9;
                                frm3.ndystxtbx.Text = st.NumberofDays9.ToString();
                                frm3.cittxtbx.Text = st.Checkintime9;
                                frm3.ShowDialog();
                                frm2.mletxtbx2.Items.Remove(nmetxtbx.Text);
                                st.Name9 = "";
                                st.rmtype9 = "";
                                st.NumberofDays9 = 0;
                                st.Checkintime9 = "";
                                st.Save();
                            }
                        }

                    }
                    else
                    {
                        frm2.fmletxtbx1.Items.Remove(nmetxtbx.Text);
                        if (fmlerdbtn.Checked == true)
                        {
                            if (st.Name10 == nmetxtbx.Text || st.Name11 == nmetxtbx.Text || st.Name12 == nmetxtbx.Text || st.Name13 == nmetxtbx.Text || st.Name14 == nmetxtbx.Text || st.Name15 == nmetxtbx.Text || st.Name16 == nmetxtbx.Text || st.Name17 == nmetxtbx.Text || st.Name18 == nmetxtbx.Text || st.Name19 == nmetxtbx.Text)
                            {
                                if (st.Name10 == nmetxtbx.Text)
                                {
                                    frm3.nmetxtbx.Text = st.Name10;
                                    frm3.rmtpetxtbx.Text = st.rmtype10;
                                    frm3.ndystxtbx.Text = st.NumberofDays10.ToString();
                                    frm3.cittxtbx.Text = st.Checkintime10;
                                    frm3.ShowDialog();
                                    frm2.fmletxtbx1.Items.Remove(nmetxtbx.Text);
                                    st.Name10 = "";
                                    st.rmtype10 = "";
                                    st.NumberofDays10 = 0;
                                    st.Checkintime10 = "";
                                    st.Save();
                                }
                                else if (st.Name11 == nmetxtbx.Text)
                                {
                                    frm3.nmetxtbx.Text = st.Name11;
                                    frm3.rmtpetxtbx.Text = st.rmtype11;
                                    frm3.ndystxtbx.Text = st.NumberofDays11.ToString();
                                    frm3.cittxtbx.Text = st.Checkintime11;
                                    frm3.ShowDialog();
                                    frm2.fmletxtbx1.Items.Remove(nmetxtbx.Text);
                                    st.Name11 = "";
                                    st.rmtype11 = "";
                                    st.NumberofDays11 = 0;
                                    st.Checkintime11 = "";
                                    st.Save();
                                }
                                else if (st.Name12 == nmetxtbx.Text)
                                {
                                    frm3.nmetxtbx.Text = st.Name12;
                                    frm3.rmtpetxtbx.Text = st.rmtype12;
                                    frm3.ndystxtbx.Text = st.NumberofDays12.ToString();
                                    frm3.cittxtbx.Text = st.Checkintime12;
                                    frm3.ShowDialog();
                                    frm2.fmletxtbx1.Items.Remove(nmetxtbx.Text);
                                    st.Name12 = "";
                                    st.rmtype12 = "";
                                    st.NumberofDays12 = 0;
                                    st.Checkintime12 = "";
                                    st.Save();
                                }
                                else if (st.Name13 == nmetxtbx.Text)
                                {
                                    frm3.nmetxtbx.Text = st.Name13;
                                    frm3.rmtpetxtbx.Text = st.rmtype13;
                                    frm3.ndystxtbx.Text = st.NumberofDays13.ToString();
                                    frm3.cittxtbx.Text = st.Checkintime13;
                                    frm3.ShowDialog();
                                    frm2.fmletxtbx1.Items.Remove(nmetxtbx.Text);
                                    st.Name13 = "";
                                    st.rmtype13 = "";
                                    st.NumberofDays13 = 0;
                                    st.Checkintime13 = "";
                                    st.Save();
                                }
                                else if (st.Name14 == nmetxtbx.Text)
                                {
                                    frm3.nmetxtbx.Text = st.Name14;
                                    frm3.rmtpetxtbx.Text = st.rmtype14;
                                    frm3.ndystxtbx.Text = st.NumberofDays14.ToString();
                                    frm3.cittxtbx.Text = st.Checkintime14;
                                    frm3.ShowDialog();
                                    frm2.fmletxtbx1.Items.Remove(nmetxtbx.Text);
                                    st.Name14 = "";
                                    st.rmtype14 = "";
                                    st.NumberofDays14 = 0;
                                    st.Checkintime14 = "";
                                    st.Save();
                                }
                                else if (st.Name15 == nmetxtbx.Text)
                                {
                                    frm3.nmetxtbx.Text = st.Name15;
                                    frm3.rmtpetxtbx.Text = st.rmtype15;
                                    frm3.ndystxtbx.Text = st.NumberofDays15.ToString();
                                    frm3.cittxtbx.Text = st.Checkintime15;
                                    frm3.ShowDialog();
                                    frm2.fmletxtbx2.Items.Remove(nmetxtbx.Text);
                                    st.Name15 = "";
                                    st.rmtype15 = "";
                                    st.NumberofDays15 = 0;
                                    st.Checkintime15 = "";
                                    st.Save();
                                }
                                else if (st.Name16 == nmetxtbx.Text)
                                {
                                    frm3.nmetxtbx.Text = st.Name16;
                                    frm3.rmtpetxtbx.Text = st.rmtype16;
                                    frm3.ndystxtbx.Text = st.NumberofDays16.ToString();
                                    frm3.cittxtbx.Text = st.Checkintime16;
                                    frm3.ShowDialog();
                                    frm2.fmletxtbx2.Items.Remove(nmetxtbx.Text);
                                    st.Name16 = "";
                                    st.rmtype16 = "";
                                    st.NumberofDays16 = 0;
                                    st.Checkintime16 = "";
                                    st.Save();
                                }
                                else if (st.Name17 == nmetxtbx.Text)
                                {
                                    frm3.nmetxtbx.Text = st.Name17;
                                    frm3.rmtpetxtbx.Text = st.rmtype17;
                                    frm3.ndystxtbx.Text = st.NumberofDays17.ToString();
                                    frm3.cittxtbx.Text = st.Checkintime17;
                                    frm3.ShowDialog();
                                    frm2.fmletxtbx2.Items.Remove(nmetxtbx.Text);
                                    st.Name17 = "";
                                    st.rmtype17 = "";
                                    st.NumberofDays17 = 0;
                                    st.Checkintime17 = "";
                                    st.Save();
                                }
                                else if (st.Name18 == nmetxtbx.Text)
                                {
                                    frm3.nmetxtbx.Text = st.Name18;
                                    frm3.rmtpetxtbx.Text = st.rmtype18;
                                    frm3.ndystxtbx.Text = st.NumberofDays18.ToString();
                                    frm3.cittxtbx.Text = st.Checkintime18;
                                    frm3.ShowDialog();
                                    frm2.fmletxtbx2.Items.Remove(nmetxtbx.Text);
                                    st.Name18 = "";
                                    st.rmtype18 = "";
                                    st.NumberofDays18 = 0;
                                    st.Checkintime18 = "";
                                    st.Save();
                                }
                                else if (st.Name19 == nmetxtbx.Text)
                                {
                                    frm3.nmetxtbx.Text = st.Name19;
                                    frm3.rmtpetxtbx.Text = st.rmtype19;
                                    frm3.ndystxtbx.Text = st.NumberofDays19.ToString();
                                    frm3.cittxtbx.Text = st.Checkintime19;
                                    frm3.ShowDialog();
                                    frm2.fmletxtbx2.Items.Remove(nmetxtbx.Text);
                                    st.Name19 = "";
                                    st.rmtype19 = "";
                                    st.NumberofDays19 = 0;
                                    st.Checkintime19 = "";
                                    st.Save();
                                }
                            }
                        }

                    }

                }
            }

        }

        private void Gndradd_Click(object sender, EventArgs e)
        {
            if (Gndradd.Text == "ADD")
            {
                if (mlerdbtn.Checked == true)
                {
                    Gndradd.Text = "REMOVE";
                    Addlistbx.Items.Add("Male");
                   
                    

                }
                else if(fmlerdbtn.Checked == true)
                {
                    Gndradd.Text = "REMOVE";
                    Addlistbx.Items.Add("Female");
                   
                
                }

            }
            else
            {
                if (mlerdbtn.Checked == true)
                {
                    Gndradd.Text = "ADD";
                    Addlistbx.Items.Remove("Male");
                   

                }
                else if (fmlerdbtn.Checked == true)
                {
                    Gndradd.Text = "ADD";
                    Addlistbx.Items.Remove("Female");
                    
                 
                }
            }
        }

        private void Addrssbtn_Click(object sender, EventArgs e)
        {
            if (addrstxtbx.Text == "")
            {
                MessageBox.Show("Please Enter the Address", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                if (Addrssbtn.Text == "ADD")
                {
                    Addrssbtn.Text = "REMOVE";
                    Addlistbx.Items.Add(addrstxtbx.Text);
                }
                else
                {
                    Addrssbtn.Text = "ADD";
                    Addlistbx.Items.Remove(addrstxtbx.Text);
                }
            }
        }

        private void Rmnmbrbtn_Click(object sender, EventArgs e)
        {
            if (rmnotxtbx.Text == "")
            {
                MessageBox.Show("Please Enter the Room Number", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                if (Rmnmbrbtn.Text == "ADD")
                {
                    Rmnmbrbtn.Text = "REMOVE";
                    Addlistbx.Items.Add(rmnotxtbx.Text);
                }
                else
                {
                    Rmnmbrbtn.Text = "ADD";
                    Addlistbx.Items.Remove(rmnotxtbx.Text);
                }
            }
        }

        private void Rmtypebtn_Click(object sender, EventArgs e)
        {
            if (rmtypecmbbx.Text == "")
            {
                MessageBox.Show("Please Select the Room Type", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                if (Rmtypebtn.Text == "ADD")
                {
                    Rmtypebtn.Text = "REMOVE";
                    Addlistbx.Items.Add(rmtypecmbbx.Text);

                }
                else
                {
                    Rmtypebtn.Text = "ADD";
                    Addlistbx.Items.Remove(rmtypecmbbx.Text);
                }
            }
        }

        private void nofdysbtn_Click(object sender, EventArgs e)
        {
            if (nofdystxtbx.Text == "")
            {
                MessageBox.Show("Please Enter the Number Of Days", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                if (nofdysbtn.Text == "ADD")
                {
                    nofdysbtn.Text = "REMOVE";
                    Addlistbx.Items.Add(nofdystxtbx.Text);
                }
                else
                {
                    nofdysbtn.Text = "ADD";
                    Addlistbx.Items.Remove(nofdystxtbx.Text);
                }
            }
        }

        private void chckntme_TextChanged(object sender, EventArgs e)
        {
            chckntmetxtbx.Text = (String.Format( "{0:D} , {0:T}",DateTime.Now));
        }

        private void chckntmebtn_Click(object sender, EventArgs e)
        {
            if (chckntmetxtbx.Text == "")
            {
                MessageBox.Show("Please Enter the Check In Time", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                if (chckntmebtn.Text == "ADD")
                {
                    chckntmebtn.Text = "REMOVE";
                    Addlistbx.Items.Add(chckntmetxtbx.Text);
                }
                else
                {
                    chckntmebtn.Text = "ADD";
                    Addlistbx.Items.Remove(chckntmetxtbx.Text);
                }
            }
        }

        private void smbtbtn_Click(object sender, EventArgs e)
        {
            Nmeadd.Text = "ADD";
            Gndradd.Text = "ADD";
            Addrssbtn.Text = "ADD";
            Rmnmbrbtn.Text = "ADD";
            Rmtypebtn.Text = "ADD";
            nofdysbtn.Text = "ADD";
            chckntmebtn.Text = "ADD";

                   if (nmetxtbx.Text == "" || addrstxtbx.Text == "" || rmnotxtbx.Text == "" || rmtypecmbbx.Text == "" || nofdystxtbx.Text == "" || chckntmetxtbx.Text == "")
            {
                MessageBox.Show("Please Fill the Blank Field", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                if (mlerdbtn.Checked == true)
                {
                    if (st.Name == "" || st.Name1 == "" || st.Name2 == "" || st.Name3 == "" || st.Name4 == "" || st.Name5 == "" || st.Name6 == "" || st.Name7 == "" || st.Name8 == "" || st.Name9 == "")
                    {

                        if (st.Name == "")
                        {
                            Addlistbx.Items.Add(nmetxtbx.Text);
                            st.Name = nmetxtbx.Text;
                            frm2.mletxtbx1.Items.Add(nmetxtbx.Text);
                            Addlistbx.Items.Add("Male");
                            Addlistbx.Items.Add(addrstxtbx.Text);
                            Addlistbx.Items.Add(rmnotxtbx.Text);
                            Addlistbx.Items.Add(rmtypecmbbx.Text);
                            st.rmtype = rmtypecmbbx.Text;
                            Addlistbx.Items.Add(nofdystxtbx.Text);
                            st.NumberofDays = Convert.ToInt32(nofdystxtbx.Text);
                            Addlistbx.Items.Add(chckntmetxtbx.Text);
                            st.Checkintime = chckntmetxtbx.Text;

                            st.Save();
                        }
                        else if (st.Name1 == "")
                        {
                            Addlistbx.Items.Add(nmetxtbx.Text);
                            st.Name1 = nmetxtbx.Text;
                            frm2.mletxtbx1.Items.Add(nmetxtbx.Text);
                            Addlistbx.Items.Add("Male");
                            Addlistbx.Items.Add(addrstxtbx.Text);
                            Addlistbx.Items.Add(rmnotxtbx.Text);
                            Addlistbx.Items.Add(rmtypecmbbx.Text);
                            st.rmtype1 = rmtypecmbbx.Text;
                            Addlistbx.Items.Add(nofdystxtbx.Text);
                            st.NumberofDays1 = Convert.ToInt32(nofdystxtbx.Text);
                            Addlistbx.Items.Add(chckntmetxtbx.Text);
                            st.Checkintime1 = chckntmetxtbx.Text;
                            st.Save();
                        }
                        else if (st.Name2 == "")
                        {
                            Addlistbx.Items.Add(nmetxtbx.Text);
                            st.Name2 = nmetxtbx.Text;
                            frm2.mletxtbx1.Items.Add(nmetxtbx.Text);
                            Addlistbx.Items.Add("Male");
                            Addlistbx.Items.Add(addrstxtbx.Text);
                            Addlistbx.Items.Add(rmnotxtbx.Text);
                            Addlistbx.Items.Add(rmtypecmbbx.Text);
                            st.rmtype2 = rmtypecmbbx.Text;
                            Addlistbx.Items.Add(nofdystxtbx.Text);
                            st.NumberofDays2 = Convert.ToInt32(nofdystxtbx.Text);
                            Addlistbx.Items.Add(chckntmetxtbx.Text);
                            st.Checkintime2 = chckntmetxtbx.Text;
                            st.Save();
                        }
                        else if (st.Name3 == "")
                        {
                            Addlistbx.Items.Add(nmetxtbx.Text);
                            st.Name3 = nmetxtbx.Text;
                            frm2.mletxtbx1.Items.Add(nmetxtbx.Text);
                            Addlistbx.Items.Add("Male");
                            Addlistbx.Items.Add(addrstxtbx.Text);
                            Addlistbx.Items.Add(rmnotxtbx.Text);
                            Addlistbx.Items.Add(rmtypecmbbx.Text);
                            st.rmtype3 = rmtypecmbbx.Text;
                            Addlistbx.Items.Add(nofdystxtbx.Text);
                            st.NumberofDays3 = Convert.ToInt32(nofdystxtbx.Text);
                            Addlistbx.Items.Add(chckntmetxtbx.Text);
                            st.Checkintime3 = chckntmetxtbx.Text;
                            st.Save();
                        }
                        else if (st.Name4 == "")
                        {
                            Addlistbx.Items.Add(nmetxtbx.Text);
                            st.Name4 = nmetxtbx.Text;
                            frm2.mletxtbx1.Items.Add(nmetxtbx.Text);
                            Addlistbx.Items.Add("Male");
                            Addlistbx.Items.Add(addrstxtbx.Text);
                            Addlistbx.Items.Add(rmnotxtbx.Text);
                            Addlistbx.Items.Add(rmtypecmbbx.Text);
                            st.rmtype4 = rmtypecmbbx.Text;
                            Addlistbx.Items.Add(nofdystxtbx.Text);
                            st.NumberofDays4 = Convert.ToInt32(nofdystxtbx.Text);
                            Addlistbx.Items.Add(chckntmetxtbx.Text);
                            st.Checkintime4 = chckntmetxtbx.Text;
                            st.Save();
                        }
                        else if (st.Name5 == "")
                        {
                            Addlistbx.Items.Add(nmetxtbx.Text);
                            st.Name5 = nmetxtbx.Text;
                            frm2.mletxtbx2.Items.Add(nmetxtbx.Text);
                            Addlistbx.Items.Add("Male");
                            Addlistbx.Items.Add(addrstxtbx.Text);
                            Addlistbx.Items.Add(rmnotxtbx.Text);
                            Addlistbx.Items.Add(rmtypecmbbx.Text);
                            st.rmtype5 = rmtypecmbbx.Text;
                            Addlistbx.Items.Add(nofdystxtbx.Text);
                            st.NumberofDays5 = Convert.ToInt32(nofdystxtbx.Text);
                            Addlistbx.Items.Add(chckntmetxtbx.Text);
                            st.Checkintime5 = chckntmetxtbx.Text;
                            st.Save();
                        }
                        else if (st.Name6 == "")
                        {
                            Addlistbx.Items.Add(nmetxtbx.Text);
                            st.Name6 = nmetxtbx.Text;
                            frm2.mletxtbx2.Items.Add(nmetxtbx.Text);
                            Addlistbx.Items.Add("Male");
                            Addlistbx.Items.Add(addrstxtbx.Text);
                            Addlistbx.Items.Add(rmnotxtbx.Text);
                            Addlistbx.Items.Add(rmtypecmbbx.Text);
                            st.rmtype6 = rmtypecmbbx.Text;
                            Addlistbx.Items.Add(nofdystxtbx.Text);
                            st.NumberofDays6 = Convert.ToInt32(nofdystxtbx.Text);
                            Addlistbx.Items.Add(chckntmetxtbx.Text);
                            st.Checkintime6 = chckntmetxtbx.Text;
                            st.Save();
                        }

                        else if (st.Name7 == "")
                        {
                            Addlistbx.Items.Add(nmetxtbx.Text);
                            st.Name7 = nmetxtbx.Text;
                            frm2.mletxtbx2.Items.Add(nmetxtbx.Text);
                            Addlistbx.Items.Add("Male");
                            Addlistbx.Items.Add(addrstxtbx.Text);
                            Addlistbx.Items.Add(rmnotxtbx.Text);
                            Addlistbx.Items.Add(rmtypecmbbx.Text);
                            st.rmtype7 = rmtypecmbbx.Text;
                            Addlistbx.Items.Add(nofdystxtbx.Text);
                            st.NumberofDays7 = Convert.ToInt32(nofdystxtbx.Text);
                            Addlistbx.Items.Add(chckntmetxtbx.Text);
                            st.Checkintime7 = chckntmetxtbx.Text;
                            st.Save();
                        }
                        else if (st.Name8 == "")
                        {
                            Addlistbx.Items.Add(nmetxtbx.Text);
                            st.Name8 = nmetxtbx.Text;
                            frm2.mletxtbx2.Items.Add(nmetxtbx.Text);
                            Addlistbx.Items.Add("Male");
                            Addlistbx.Items.Add(addrstxtbx.Text);
                            Addlistbx.Items.Add(rmnotxtbx.Text);
                            Addlistbx.Items.Add(rmtypecmbbx.Text);
                            st.rmtype8 = rmtypecmbbx.Text;
                            Addlistbx.Items.Add(nofdystxtbx.Text);
                            st.NumberofDays8 = Convert.ToInt32(nofdystxtbx.Text);
                            Addlistbx.Items.Add(chckntmetxtbx.Text);
                            st.Checkintime8 = chckntmetxtbx.Text;
                            st.Save();
                        }
                        else if (st.Name9 == "")
                        {
                            Addlistbx.Items.Add(nmetxtbx.Text);
                            st.Name9 = nmetxtbx.Text;
                            frm2.mletxtbx2.Items.Add(nmetxtbx.Text);
                            Addlistbx.Items.Add("Male");
                            Addlistbx.Items.Add(addrstxtbx.Text);
                            Addlistbx.Items.Add(rmnotxtbx.Text);
                            Addlistbx.Items.Add(rmtypecmbbx.Text);
                            st.rmtype9 = rmtypecmbbx.Text;
                            Addlistbx.Items.Add(nofdystxtbx.Text);
                            st.NumberofDays9 = Convert.ToInt32(nofdystxtbx.Text);
                            Addlistbx.Items.Add(chckntmetxtbx.Text);
                            st.Checkintime9 = chckntmetxtbx.Text;
                            st.Save();
                        }
                    }
                    else
                    {
                        MessageBox.Show("Room not available", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }

                if (fmlerdbtn.Checked == true)
                {
                    if (st.Name10 == "" || st.Name11 == "" || st.Name12 == "" || st.Name13 == "" || st.Name14 == "" || st.Name15 == "" || st.Name16 == "" || st.Name17 == "" || st.Name18 == "" || st.Name19 == "")
                    {
                        if (st.Name10 == "")
                        {
                            Addlistbx.Items.Add(nmetxtbx.Text);
                            st.Name10 = nmetxtbx.Text;
                            frm2.fmletxtbx1.Items.Add(nmetxtbx.Text);
                            Addlistbx.Items.Add("Female");
                            Addlistbx.Items.Add(addrstxtbx.Text);
                            Addlistbx.Items.Add(rmnotxtbx.Text);
                            Addlistbx.Items.Add(rmtypecmbbx.Text);
                            st.rmtype10 = rmtypecmbbx.Text;
                            Addlistbx.Items.Add(nofdystxtbx.Text);
                            st.NumberofDays10 = Convert.ToInt32(nofdystxtbx.Text);
                            Addlistbx.Items.Add(chckntmetxtbx.Text);
                            st.Checkintime10 = chckntmetxtbx.Text;
                            st.Save();
                        }
                        else if (st.Name11 == "")
                        {
                            Addlistbx.Items.Add(nmetxtbx.Text);
                            st.Name11 = nmetxtbx.Text;
                            frm2.fmletxtbx1.Items.Add(nmetxtbx.Text);
                            Addlistbx.Items.Add("Female");
                            Addlistbx.Items.Add(addrstxtbx.Text);
                            Addlistbx.Items.Add(rmnotxtbx.Text);
                            Addlistbx.Items.Add(rmtypecmbbx.Text);
                            st.rmtype11 = rmtypecmbbx.Text;
                            Addlistbx.Items.Add(nofdystxtbx.Text);
                            st.NumberofDays11 = Convert.ToInt32(nofdystxtbx.Text);
                            Addlistbx.Items.Add(chckntmetxtbx.Text);
                            st.Checkintime11 = chckntmetxtbx.Text;
                            st.Save();
                        }
                        else if (st.Name12 == "")
                        {
                            Addlistbx.Items.Add(nmetxtbx.Text);
                            st.Name12 = nmetxtbx.Text;
                            frm2.fmletxtbx1.Items.Add(nmetxtbx.Text);
                            Addlistbx.Items.Add("Female");
                            Addlistbx.Items.Add(addrstxtbx.Text);
                            Addlistbx.Items.Add(rmnotxtbx.Text);
                            Addlistbx.Items.Add(rmtypecmbbx.Text);
                            st.rmtype12 = rmtypecmbbx.Text;
                            Addlistbx.Items.Add(nofdystxtbx.Text);
                            st.NumberofDays12 = Convert.ToInt32(nofdystxtbx.Text);
                            Addlistbx.Items.Add(chckntmetxtbx.Text);
                            st.Checkintime12 = chckntmetxtbx.Text;
                            st.Save();
                        }
                        else if (st.Name13 == "")
                        {
                            Addlistbx.Items.Add(nmetxtbx.Text);
                            st.Name13 = nmetxtbx.Text;
                            frm2.fmletxtbx1.Items.Add(nmetxtbx.Text);
                            Addlistbx.Items.Add("Female");
                            Addlistbx.Items.Add(addrstxtbx.Text);
                            Addlistbx.Items.Add(rmnotxtbx.Text);
                            Addlistbx.Items.Add(rmtypecmbbx.Text);
                            st.rmtype13 = rmtypecmbbx.Text;
                            Addlistbx.Items.Add(nofdystxtbx.Text);
                            st.NumberofDays13 = Convert.ToInt32(nofdystxtbx.Text);
                            Addlistbx.Items.Add(chckntmetxtbx.Text);
                            st.Checkintime13 = chckntmetxtbx.Text;
                            st.Save();
                        }
                        else if (st.Name14 == "")
                        {
                            Addlistbx.Items.Add(nmetxtbx.Text);
                            st.Name14 = nmetxtbx.Text;
                            frm2.fmletxtbx1.Items.Add(nmetxtbx.Text);
                            Addlistbx.Items.Add("Female");
                            Addlistbx.Items.Add(addrstxtbx.Text);
                            Addlistbx.Items.Add(rmnotxtbx.Text);
                            Addlistbx.Items.Add(rmtypecmbbx.Text);
                            st.rmtype14 = rmtypecmbbx.Text;
                            Addlistbx.Items.Add(nofdystxtbx.Text);
                            st.NumberofDays14 = Convert.ToInt32(nofdystxtbx.Text);
                            Addlistbx.Items.Add(chckntmetxtbx.Text);
                            st.Checkintime14 = chckntmetxtbx.Text;
                            st.Save();
                        }
                        else if (st.Name15 == "")
                        {
                            Addlistbx.Items.Add(nmetxtbx.Text);
                            st.Name15 = nmetxtbx.Text;
                            frm2.fmletxtbx2.Items.Add(nmetxtbx.Text);
                            Addlistbx.Items.Add("Female");
                            Addlistbx.Items.Add(addrstxtbx.Text);
                            Addlistbx.Items.Add(rmnotxtbx.Text);
                            Addlistbx.Items.Add(rmtypecmbbx.Text);
                            st.rmtype15 = rmtypecmbbx.Text;
                            Addlistbx.Items.Add(nofdystxtbx.Text);
                            st.NumberofDays15 = Convert.ToInt32(nofdystxtbx.Text);
                            Addlistbx.Items.Add(chckntmetxtbx.Text);
                            st.Checkintime15 = chckntmetxtbx.Text;
                            st.Save();
                        }
                        else if (st.Name16 == "")
                        {
                            Addlistbx.Items.Add(nmetxtbx.Text);
                            st.Name16 = nmetxtbx.Text;
                            frm2.fmletxtbx2.Items.Add(nmetxtbx.Text);
                            Addlistbx.Items.Add("Female");
                            Addlistbx.Items.Add(addrstxtbx.Text);
                            Addlistbx.Items.Add(rmnotxtbx.Text);
                            Addlistbx.Items.Add(rmtypecmbbx.Text);
                            st.rmtype16 = rmtypecmbbx.Text;
                            Addlistbx.Items.Add(nofdystxtbx.Text);
                            st.NumberofDays16 = Convert.ToInt32(nofdystxtbx.Text);
                            Addlistbx.Items.Add(chckntmetxtbx.Text);
                            st.Checkintime16 = chckntmetxtbx.Text;
                            st.Save();
                        }

                        else if (st.Name17 == "")
                        {
                            Addlistbx.Items.Add(nmetxtbx.Text);
                            st.Name17 = nmetxtbx.Text;
                            frm2.fmletxtbx2.Items.Add(nmetxtbx.Text);
                            Addlistbx.Items.Add("Female");
                            Addlistbx.Items.Add(addrstxtbx.Text);
                            Addlistbx.Items.Add(rmnotxtbx.Text);
                            Addlistbx.Items.Add(rmtypecmbbx.Text);
                            st.rmtype17 = rmtypecmbbx.Text;
                            Addlistbx.Items.Add(nofdystxtbx.Text);
                            st.NumberofDays17 = Convert.ToInt32(nofdystxtbx.Text);
                            Addlistbx.Items.Add(chckntmetxtbx.Text);
                            st.Checkintime17 = chckntmetxtbx.Text;
                            st.Save();
                        }
                        else if (st.Name18 == "")
                        {
                            Addlistbx.Items.Add(nmetxtbx.Text);
                            st.Name18 = nmetxtbx.Text;
                            frm2.fmletxtbx2.Items.Add(nmetxtbx.Text);
                            Addlistbx.Items.Add("Female");
                            Addlistbx.Items.Add(addrstxtbx.Text);
                            Addlistbx.Items.Add(rmnotxtbx.Text);
                            Addlistbx.Items.Add(rmtypecmbbx.Text);
                            st.rmtype18 = rmtypecmbbx.Text;
                            Addlistbx.Items.Add(nofdystxtbx.Text);
                            st.NumberofDays18 = Convert.ToInt32(nofdystxtbx.Text);
                            Addlistbx.Items.Add(chckntmetxtbx.Text);
                            st.Checkintime18 = chckntmetxtbx.Text;
                            st.Save();
                        }
                        else if (st.Name19 == "")
                        {
                            Addlistbx.Items.Add(nmetxtbx.Text);
                            st.Name19 = nmetxtbx.Text;
                            frm2.fmletxtbx2.Items.Add(nmetxtbx.Text);
                            Addlistbx.Items.Add("Female");
                            Addlistbx.Items.Add(addrstxtbx.Text);
                            Addlistbx.Items.Add(rmnotxtbx.Text);
                            Addlistbx.Items.Add(rmtypecmbbx.Text);
                            st.rmtype19 = rmtypecmbbx.Text;
                            Addlistbx.Items.Add(nofdystxtbx.Text);
                            st.NumberofDays19 = Convert.ToInt32(nofdystxtbx.Text);
                            Addlistbx.Items.Add(chckntmetxtbx.Text);
                            st.Checkintime19 = chckntmetxtbx.Text;
                            st.Save();
                        }
                        else
                        {
                            MessageBox.Show("Room not available", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                }


            }
        }
            
        private void Rmaltbtn_Click(object sender, EventArgs e)
        {
            frm2.ShowDialog();
        }

        private void nwbtn_Click(object sender, EventArgs e)
        {
           
            nmetxtbx.Text = "";
            addrstxtbx.Text = "";
            rmnotxtbx.Text = "";
            rmtypecmbbx.Text = "";
            nofdystxtbx.Text = "";
            chckntmetxtbx.Text = "";
            Nmeadd.Text = "ADD";
            Gndradd.Text = "ADD";
            Addrssbtn.Text = "ADD";
            Rmnmbrbtn.Text = "ADD";
            Rmtypebtn.Text = "ADD";
            nofdysbtn.Text = "ADD";
            chckntmebtn.Text = "ADD";
        }

        private void updtebtn_Click(object sender, EventArgs e)
        {
            nmetxtbx.Text = "";
            addrstxtbx.Text = "";
            rmnotxtbx.Text = "";
            rmtypecmbbx.Text = "";
            nofdystxtbx.Text = "";
            chckntmetxtbx.Text = "";
            Nmeadd.Text = "REMOVE";
            Gndradd.Text = "REMOVE";
            Addrssbtn.Text = "REMOVE";
            Rmnmbrbtn.Text = "REMOVE";
            Rmtypebtn.Text = "REMOVE";
            nofdysbtn.Text = "REMOVE";
            chckntmebtn.Text = "REMOVE";
        }
     }
}
