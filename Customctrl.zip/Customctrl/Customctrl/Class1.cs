﻿using System;
using System.Windows.Forms;
using System.Drawing;

namespace Customctrl
{
    class Class1:TextBox     
    {
       
        string wt;
        int len;
        
        public string wtermark
        {
            get
            {
                return wt;
            }
            set
            {
                wt = value;
            }
        }

        public int length
        {
            get
            {
                return len;
            }
            set
            {
                len = value;
            }
        }
        public int length1
        {
            get
            {
                return len1;
            }
            set
            {
                len1 = value;
            }
        }
        
        protected override void InitLayout()
        {
            base.Text = wt;
            base.ForeColor = Color.Gray;
            base.InitLayout();
           
        }

        protected override void OnTextChanged(EventArgs e)
        {
            len = base.Text.Length;
           
            base.OnTextChanged(e);
        }
        protected override void OnMouseClick(MouseEventArgs e)
        {
            base.Text = "";
            base.ForeColor = Color.Black;
            base.OnMouseClick(e);
        }
        protected override void OnMouseLeave(EventArgs e)
        {
            if (base.Text == "")
            {
                InitLayout();
            }
            base.OnMouseLeave(e);
        }
        
        protected override void OnKeyPress(KeyPressEventArgs e)
        {

            if (wt == "Enter the Password")
            {

                if (len <= 9)
                {
                    if (char.IsLetter(e.KeyChar))
                    {
                        e.Handled = true;
                    }


                }
                
                if (len > 10)
                {
                    wt = "Enter the String";
                    
                }
            }
            else if(wt == "Enter the String")
 
            {

                if (char.IsNumber(e.KeyChar))
                {
                    e.Handled = true;
                }
            }


          
            base.OnKeyPress(e);
        }
    }
    
}
