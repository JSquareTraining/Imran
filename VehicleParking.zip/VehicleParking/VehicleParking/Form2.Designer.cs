﻿namespace VehicleParking
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.txtbx_chckouttme = new System.Windows.Forms.TextBox();
            this.txtbx_totlamt2 = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.txtbx_chckintme2 = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.btn_entry2 = new System.Windows.Forms.Button();
            this.lbl_entry2 = new System.Windows.Forms.Label();
            this.lbl_nme = new System.Windows.Forms.Label();
            this.txtbx_nme2 = new System.Windows.Forms.TextBox();
            this.txtbx_phnnmbr2 = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.txtbx_vechlenmbr2 = new System.Windows.Forms.TextBox();
            this.dtetmepckr_chckouttme = new System.Windows.Forms.DateTimePicker();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.txtbx_chckouttme);
            this.groupBox1.Controls.Add(this.txtbx_totlamt2);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.txtbx_chckintme2);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.btn_entry2);
            this.groupBox1.Controls.Add(this.lbl_entry2);
            this.groupBox1.Controls.Add(this.lbl_nme);
            this.groupBox1.Controls.Add(this.txtbx_nme2);
            this.groupBox1.Controls.Add(this.txtbx_phnnmbr2);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.txtbx_vechlenmbr2);
            this.groupBox1.Location = new System.Drawing.Point(232, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(601, 446);
            this.groupBox1.TabIndex = 11;
            this.groupBox1.TabStop = false;
            // 
            // txtbx_chckouttme
            // 
            this.txtbx_chckouttme.Font = new System.Drawing.Font("Palatino Linotype", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbx_chckouttme.Location = new System.Drawing.Point(300, 291);
            this.txtbx_chckouttme.Name = "txtbx_chckouttme";
            this.txtbx_chckouttme.ReadOnly = true;
            this.txtbx_chckouttme.Size = new System.Drawing.Size(230, 25);
            this.txtbx_chckouttme.TabIndex = 15;
            // 
            // txtbx_totlamt2
            // 
            this.txtbx_totlamt2.Font = new System.Drawing.Font("Palatino Linotype", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbx_totlamt2.Location = new System.Drawing.Point(300, 339);
            this.txtbx_totlamt2.Name = "txtbx_totlamt2";
            this.txtbx_totlamt2.ReadOnly = true;
            this.txtbx_totlamt2.Size = new System.Drawing.Size(230, 25);
            this.txtbx_totlamt2.TabIndex = 14;
            // 
            // label6
            // 
            this.label6.Font = new System.Drawing.Font("Palatino Linotype", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.White;
            this.label6.Location = new System.Drawing.Point(64, 341);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(180, 23);
            this.label6.TabIndex = 13;
            this.label6.Text = "TOTAL AMOUNT";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label5
            // 
            this.label5.Font = new System.Drawing.Font("Palatino Linotype", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.White;
            this.label5.Location = new System.Drawing.Point(42, 293);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(202, 23);
            this.label5.TabIndex = 11;
            this.label5.Text = "CHECKOUT TIME";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // txtbx_chckintme2
            // 
            this.txtbx_chckintme2.Font = new System.Drawing.Font("Palatino Linotype", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbx_chckintme2.Location = new System.Drawing.Point(300, 245);
            this.txtbx_chckintme2.Name = "txtbx_chckintme2";
            this.txtbx_chckintme2.ReadOnly = true;
            this.txtbx_chckintme2.Size = new System.Drawing.Size(230, 25);
            this.txtbx_chckintme2.TabIndex = 10;
            // 
            // label4
            // 
            this.label4.Font = new System.Drawing.Font("Palatino Linotype", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.Location = new System.Drawing.Point(64, 244);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(180, 23);
            this.label4.TabIndex = 9;
            this.label4.Text = "CHECKIN TIME";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // btn_entry2
            // 
            this.btn_entry2.BackColor = System.Drawing.Color.DarkOrchid;
            this.btn_entry2.Font = new System.Drawing.Font("Palatino Linotype", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_entry2.Location = new System.Drawing.Point(257, 399);
            this.btn_entry2.Name = "btn_entry2";
            this.btn_entry2.Size = new System.Drawing.Size(78, 31);
            this.btn_entry2.TabIndex = 8;
            this.btn_entry2.Text = "ENTRY";
            this.btn_entry2.UseVisualStyleBackColor = false;
            this.btn_entry2.Click += new System.EventHandler(this.btn_entry2_Click);
            // 
            // lbl_entry2
            // 
            this.lbl_entry2.Font = new System.Drawing.Font("Palatino Linotype", 18F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_entry2.ForeColor = System.Drawing.Color.White;
            this.lbl_entry2.Location = new System.Drawing.Point(176, 32);
            this.lbl_entry2.Name = "lbl_entry2";
            this.lbl_entry2.Size = new System.Drawing.Size(251, 35);
            this.lbl_entry2.TabIndex = 2;
            this.lbl_entry2.Text = "ENTRY DETAILS";
            this.lbl_entry2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl_nme
            // 
            this.lbl_nme.Font = new System.Drawing.Font("Palatino Linotype", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_nme.ForeColor = System.Drawing.Color.White;
            this.lbl_nme.Location = new System.Drawing.Point(144, 102);
            this.lbl_nme.Name = "lbl_nme";
            this.lbl_nme.Size = new System.Drawing.Size(100, 23);
            this.lbl_nme.TabIndex = 1;
            this.lbl_nme.Text = "NAME";
            this.lbl_nme.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // txtbx_nme2
            // 
            this.txtbx_nme2.Font = new System.Drawing.Font("Palatino Linotype", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbx_nme2.Location = new System.Drawing.Point(300, 102);
            this.txtbx_nme2.Name = "txtbx_nme2";
            this.txtbx_nme2.ReadOnly = true;
            this.txtbx_nme2.Size = new System.Drawing.Size(230, 25);
            this.txtbx_nme2.TabIndex = 3;
            // 
            // txtbx_phnnmbr2
            // 
            this.txtbx_phnnmbr2.Font = new System.Drawing.Font("Palatino Linotype", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbx_phnnmbr2.Location = new System.Drawing.Point(300, 195);
            this.txtbx_phnnmbr2.Name = "txtbx_phnnmbr2";
            this.txtbx_phnnmbr2.ReadOnly = true;
            this.txtbx_phnnmbr2.Size = new System.Drawing.Size(230, 25);
            this.txtbx_phnnmbr2.TabIndex = 7;
            // 
            // label2
            // 
            this.label2.Font = new System.Drawing.Font("Palatino Linotype", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(43, 147);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(201, 23);
            this.label2.TabIndex = 4;
            this.label2.Text = "VEHICLE NUMBER";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label3
            // 
            this.label3.Font = new System.Drawing.Font("Palatino Linotype", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(64, 195);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(180, 23);
            this.label3.TabIndex = 6;
            this.label3.Text = "PHONE NUMBER";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // txtbx_vechlenmbr2
            // 
            this.txtbx_vechlenmbr2.Font = new System.Drawing.Font("Palatino Linotype", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbx_vechlenmbr2.Location = new System.Drawing.Point(300, 147);
            this.txtbx_vechlenmbr2.Name = "txtbx_vechlenmbr2";
            this.txtbx_vechlenmbr2.ReadOnly = true;
            this.txtbx_vechlenmbr2.Size = new System.Drawing.Size(230, 25);
            this.txtbx_vechlenmbr2.TabIndex = 5;
            // 
            // dtetmepckr_chckouttme
            // 
            this.dtetmepckr_chckouttme.Location = new System.Drawing.Point(28, 475);
            this.dtetmepckr_chckouttme.Name = "dtetmepckr_chckouttme";
            this.dtetmepckr_chckouttme.Size = new System.Drawing.Size(230, 20);
            this.dtetmepckr_chckouttme.TabIndex = 15;
            this.dtetmepckr_chckouttme.Value = new System.DateTime(2014, 6, 21, 20, 40, 22, 0);
            this.dtetmepckr_chckouttme.Visible = false;
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Location = new System.Drawing.Point(755, 475);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(230, 20);
            this.dateTimePicker1.TabIndex = 16;
            this.dateTimePicker1.Value = new System.DateTime(2014, 6, 21, 20, 40, 22, 0);
            this.dateTimePicker1.Visible = false;
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Black;
            this.ClientSize = new System.Drawing.Size(987, 497);
            this.Controls.Add(this.dtetmepckr_chckouttme);
            this.Controls.Add(this.dateTimePicker1);
            this.Controls.Add(this.groupBox1);
            this.Name = "Form2";
            this.Text = "Form2";
            this.Load += new System.EventHandler(this.Form2_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox txtbx_totlamt2;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button btn_entry2;
        private System.Windows.Forms.Label lbl_entry2;
        private System.Windows.Forms.Label lbl_nme;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        public System.Windows.Forms.TextBox txtbx_nme2;
        public System.Windows.Forms.TextBox txtbx_phnnmbr2;
        public System.Windows.Forms.TextBox txtbx_vechlenmbr2;
        private System.Windows.Forms.DateTimePicker dtetmepckr_chckouttme;
        public System.Windows.Forms.TextBox txtbx_chckintme2;
        public System.Windows.Forms.DateTimePicker dateTimePicker1;
        public System.Windows.Forms.TextBox txtbx_chckouttme;
    }
}