﻿namespace usernameandpassword
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.usernmelbl = new System.Windows.Forms.Label();
            this.pswdlbl = new System.Windows.Forms.Label();
            this.usernmetxtbx = new System.Windows.Forms.TextBox();
            this.pswdtxtbx = new System.Windows.Forms.TextBox();
            this.lgnbtn = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // usernmelbl
            // 
            this.usernmelbl.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.usernmelbl.Location = new System.Drawing.Point(123, 85);
            this.usernmelbl.Name = "usernmelbl";
            this.usernmelbl.Size = new System.Drawing.Size(130, 31);
            this.usernmelbl.TabIndex = 0;
            this.usernmelbl.Text = "Username";
            this.usernmelbl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pswdlbl
            // 
            this.pswdlbl.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pswdlbl.Location = new System.Drawing.Point(123, 156);
            this.pswdlbl.Name = "pswdlbl";
            this.pswdlbl.Size = new System.Drawing.Size(130, 31);
            this.pswdlbl.TabIndex = 1;
            this.pswdlbl.Text = "Password";
            this.pswdlbl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // usernmetxtbx
            // 
            this.usernmetxtbx.BackColor = System.Drawing.SystemColors.Window;
            this.usernmetxtbx.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.usernmetxtbx.Location = new System.Drawing.Point(269, 90);
            this.usernmetxtbx.Name = "usernmetxtbx";
            this.usernmetxtbx.Size = new System.Drawing.Size(196, 26);
            this.usernmetxtbx.TabIndex = 2;
            // 
            // pswdtxtbx
            // 
            this.pswdtxtbx.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pswdtxtbx.Location = new System.Drawing.Point(269, 156);
            this.pswdtxtbx.Name = "pswdtxtbx";
            this.pswdtxtbx.PasswordChar = '*';
            this.pswdtxtbx.Size = new System.Drawing.Size(196, 26);
            this.pswdtxtbx.TabIndex = 3;
            // 
            // lgnbtn
            // 
            this.lgnbtn.BackColor = System.Drawing.Color.LightSteelBlue;
            this.lgnbtn.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lgnbtn.Location = new System.Drawing.Point(229, 220);
            this.lgnbtn.Name = "lgnbtn";
            this.lgnbtn.Size = new System.Drawing.Size(103, 28);
            this.lgnbtn.TabIndex = 4;
            this.lgnbtn.Text = "Login";
            this.lgnbtn.UseVisualStyleBackColor = false;
            this.lgnbtn.Click += new System.EventHandler(this.lgnbtn_Click);
            // 
            // Form1
            // 
            this.AcceptButton = this.lgnbtn;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.NavajoWhite;
            this.ClientSize = new System.Drawing.Size(596, 332);
            this.Controls.Add(this.lgnbtn);
            this.Controls.Add(this.pswdtxtbx);
            this.Controls.Add(this.usernmetxtbx);
            this.Controls.Add(this.pswdlbl);
            this.Controls.Add(this.usernmelbl);
            this.Name = "Form1";
            this.Text = "Login Form";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label usernmelbl;
        private System.Windows.Forms.Label pswdlbl;
        private System.Windows.Forms.TextBox usernmetxtbx;
        private System.Windows.Forms.TextBox pswdtxtbx;
        private System.Windows.Forms.Button lgnbtn;
    }
}

