﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace usernameandpassword
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        int count = 3;

        private void lgnbtn_Click(object sender, EventArgs e)
        {
            if (usernmetxtbx.Text =="admin" && pswdtxtbx.Text == "admin")
            {
                DialogResult odr2 = new DialogResult();
                odr2 = MessageBox.Show("You have Loged in Sucessfully", "Information",MessageBoxButtons.OK);
                if (odr2 == DialogResult.OK)
                {
                    this.Close();
                }
                else
                {
                    this.Close();
                }
                
               
            }
            else if (usernmetxtbx.Text == "" && pswdtxtbx.Text == "")
            {
                MessageBox.Show("Please Enter the Username and Password", "Information", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else if (usernmetxtbx.Text == "")
            {
                MessageBox.Show("Please Enter the Username", "Information", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else if (pswdtxtbx.Text == "")
            {
                MessageBox.Show("Please Enter the Password", "Information", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            
            else
            {
                DialogResult odr = new DialogResult();
                odr = MessageBox.Show("Please enter the correct Username/Password", "Information", MessageBoxButtons.OKCancel, MessageBoxIcon.Error, MessageBoxDefaultButton.Button1);
                if (odr == DialogResult.OK || odr == DialogResult.Cancel)
                {
                    if (count == 0)
                    {
                        DialogResult odr1 = new DialogResult();
                        odr1 = MessageBox.Show("You have used all your chances", "Information", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        if (odr1 == DialogResult.OK)
                        {
                            this.Close();
                        }
                        else
                        {
                            this.Close();
                        }
                    }
                    else
                    {
                        count--;
                        MessageBox.Show("You have only " + count + "chances", "Information");
                    }
                }


            }
        }
    }
}