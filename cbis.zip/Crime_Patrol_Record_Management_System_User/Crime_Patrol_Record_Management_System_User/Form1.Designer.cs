﻿namespace Crime_Patrol_Record_Management_System_User
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.panel_banner = new System.Windows.Forms.Panel();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.panel_Complaint = new System.Windows.Forms.Panel();
            this.panel12 = new System.Windows.Forms.Panel();
            this.btn_complaint_submit = new System.Windows.Forms.Button();
            this.txtbx_chrctr_dec = new System.Windows.Forms.TextBox();
            this.txtbx_chrctr_plc = new System.Windows.Forms.TextBox();
            this.label80 = new System.Windows.Forms.Label();
            this.rchtxtbx_descrptn_of_cmplnt = new System.Windows.Forms.RichTextBox();
            this.label79 = new System.Windows.Forms.Label();
            this.rchtxtbx_plce_of_occrnce = new System.Windows.Forms.RichTextBox();
            this.label78 = new System.Windows.Forms.Label();
            this.dte_time = new System.Windows.Forms.DateTimePicker();
            this.dte_date = new System.Windows.Forms.DateTimePicker();
            this.label77 = new System.Windows.Forms.Label();
            this.cmbx_subject = new System.Windows.Forms.ComboBox();
            this.label76 = new System.Windows.Forms.Label();
            this.panel11 = new System.Windows.Forms.Panel();
            this.txtbx_emailid = new System.Windows.Forms.TextBox();
            this.label75 = new System.Windows.Forms.Label();
            this.txtbx_id_proof_2 = new System.Windows.Forms.TextBox();
            this.label73 = new System.Windows.Forms.Label();
            this.cmbx_id_proof_2 = new System.Windows.Forms.ComboBox();
            this.label74 = new System.Windows.Forms.Label();
            this.txtbx_id_proof_1 = new System.Windows.Forms.TextBox();
            this.label72 = new System.Windows.Forms.Label();
            this.txtbx_mblenmbr = new System.Windows.Forms.TextBox();
            this.label71 = new System.Windows.Forms.Label();
            this.cmbx_idnty_proof_1 = new System.Windows.Forms.ComboBox();
            this.label70 = new System.Windows.Forms.Label();
            this.txtbx_pincode = new System.Windows.Forms.TextBox();
            this.label69 = new System.Windows.Forms.Label();
            this.txtbx_state = new System.Windows.Forms.TextBox();
            this.label68 = new System.Windows.Forms.Label();
            this.txtbx_district = new System.Windows.Forms.TextBox();
            this.label67 = new System.Windows.Forms.Label();
            this.txtbx_city = new System.Windows.Forms.TextBox();
            this.label66 = new System.Windows.Forms.Label();
            this.txtbx_addrss_fr_cmmtion1 = new System.Windows.Forms.TextBox();
            this.txtbx_addrss_fr_cmmtion = new System.Windows.Forms.TextBox();
            this.label65 = new System.Windows.Forms.Label();
            this.txtbx_age = new System.Windows.Forms.TextBox();
            this.label64 = new System.Windows.Forms.Label();
            this.dte_dob = new System.Windows.Forms.DateTimePicker();
            this.label63 = new System.Windows.Forms.Label();
            this.cmbx_gndr = new System.Windows.Forms.ComboBox();
            this.label62 = new System.Windows.Forms.Label();
            this.txtbx_nme = new System.Windows.Forms.TextBox();
            this.label61 = new System.Windows.Forms.Label();
            this.panel10 = new System.Windows.Forms.Panel();
            this.cmbx_police_station_1 = new System.Windows.Forms.ComboBox();
            this.label57 = new System.Windows.Forms.Label();
            this.cmbx_district1 = new System.Windows.Forms.ComboBox();
            this.label58 = new System.Windows.Forms.Label();
            this.rdbtn_police_station_1 = new System.Windows.Forms.RadioButton();
            this.label59 = new System.Windows.Forms.Label();
            this.label60 = new System.Windows.Forms.Label();
            this.panel9 = new System.Windows.Forms.Panel();
            this.label56 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label47 = new System.Windows.Forms.Label();
            this.label48 = new System.Windows.Forms.Label();
            this.label49 = new System.Windows.Forms.Label();
            this.label50 = new System.Windows.Forms.Label();
            this.label51 = new System.Windows.Forms.Label();
            this.label52 = new System.Windows.Forms.Label();
            this.label53 = new System.Windows.Forms.Label();
            this.label54 = new System.Windows.Forms.Label();
            this.label55 = new System.Windows.Forms.Label();
            this.label46 = new System.Windows.Forms.Label();
            this.panel_fir = new System.Windows.Forms.Panel();
            this.label83 = new System.Windows.Forms.Label();
            this.lbl_status = new System.Windows.Forms.Label();
            this.label82 = new System.Windows.Forms.Label();
            this.btn_search = new System.Windows.Forms.Button();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.label81 = new System.Windows.Forms.Label();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.label39 = new System.Windows.Forms.Label();
            this.txtbx_fir_nmbr = new System.Windows.Forms.TextBox();
            this.label34 = new System.Windows.Forms.Label();
            this.panel_Information = new System.Windows.Forms.Panel();
            this.btn_Submit = new System.Windows.Forms.Button();
            this.panel7 = new System.Windows.Forms.Panel();
            this.txtbx_chrcts = new System.Windows.Forms.TextBox();
            this.label29 = new System.Windows.Forms.Label();
            this.rchtxtbx_decription = new System.Windows.Forms.RichTextBox();
            this.label28 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.cmbx_subject_information = new System.Windows.Forms.ComboBox();
            this.label25 = new System.Windows.Forms.Label();
            this.panel5 = new System.Windows.Forms.Panel();
            this.txtbx_Mobile_number = new System.Windows.Forms.TextBox();
            this.label24 = new System.Windows.Forms.Label();
            this.txtbx_email_id = new System.Windows.Forms.TextBox();
            this.label20 = new System.Windows.Forms.Label();
            this.panel6 = new System.Windows.Forms.Panel();
            this.txtbx_lndlne_number = new System.Windows.Forms.TextBox();
            this.label23 = new System.Windows.Forms.Label();
            this.txtbx_lndlne_code = new System.Windows.Forms.TextBox();
            this.label22 = new System.Windows.Forms.Label();
            this.txtbx_Lstnme = new System.Windows.Forms.TextBox();
            this.label21 = new System.Windows.Forms.Label();
            this.txtbx_Frstnme = new System.Windows.Forms.TextBox();
            this.label19 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.panel4 = new System.Windows.Forms.Panel();
            this.cmbx_Police_Station = new System.Windows.Forms.ComboBox();
            this.label17 = new System.Windows.Forms.Label();
            this.cmbx_dstrct = new System.Windows.Forms.ComboBox();
            this.label16 = new System.Windows.Forms.Label();
            this.rdbtn_Police_Station = new System.Windows.Forms.RadioButton();
            this.label15 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.panel8 = new System.Windows.Forms.Panel();
            this.label42 = new System.Windows.Forms.Label();
            this.label45 = new System.Windows.Forms.Label();
            this.label43 = new System.Windows.Forms.Label();
            this.label44 = new System.Windows.Forms.Label();
            this.label41 = new System.Windows.Forms.Label();
            this.label40 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.label36 = new System.Windows.Forms.Label();
            this.label37 = new System.Windows.Forms.Label();
            this.label38 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel_banner.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panel_Complaint.SuspendLayout();
            this.panel12.SuspendLayout();
            this.panel11.SuspendLayout();
            this.panel10.SuspendLayout();
            this.panel9.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel_fir.SuspendLayout();
            this.panel_Information.SuspendLayout();
            this.panel7.SuspendLayout();
            this.panel5.SuspendLayout();
            this.panel6.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel8.SuspendLayout();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel_banner
            // 
            this.panel_banner.BackColor = System.Drawing.Color.Black;
            this.panel_banner.Controls.Add(this.label3);
            this.panel_banner.Controls.Add(this.label2);
            this.panel_banner.Controls.Add(this.label1);
            this.panel_banner.Controls.Add(this.pictureBox1);
            this.panel_banner.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel_banner.Location = new System.Drawing.Point(0, 0);
            this.panel_banner.Name = "panel_banner";
            this.panel_banner.Size = new System.Drawing.Size(1368, 122);
            this.panel_banner.TabIndex = 0;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Black;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.PaleTurquoise;
            this.label3.Location = new System.Drawing.Point(545, 96);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(370, 16);
            this.label3.TabIndex = 3;
            this.label3.Text = "Empowering citizens through Information Technology";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Black;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.PaleTurquoise;
            this.label2.Location = new System.Drawing.Point(508, 65);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(440, 24);
            this.label2.TabIndex = 2;
            this.label2.Text = "Crime and Criminal Tracking Network Systems";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Black;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.PaleTurquoise;
            this.label1.Location = new System.Drawing.Point(434, 30);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(601, 33);
            this.label1.TabIndex = 1;
            this.label1.Text = "TAMILNADU POLICE - CITIZEN SEVICES";
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.Black;
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(270, 8);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(138, 130);
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // panel_Complaint
            // 
            this.panel_Complaint.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel_Complaint.Controls.Add(this.panel12);
            this.panel_Complaint.Controls.Add(this.panel_fir);
            this.panel_Complaint.Controls.Add(this.panel11);
            this.panel_Complaint.Controls.Add(this.panel10);
            this.panel_Complaint.Controls.Add(this.panel9);
            this.panel_Complaint.Controls.Add(this.panel2);
            this.panel_Complaint.Controls.Add(this.label46);
            this.panel_Complaint.Location = new System.Drawing.Point(3, 3);
            this.panel_Complaint.Name = "panel_Complaint";
            this.panel_Complaint.Size = new System.Drawing.Size(1123, 609);
            this.panel_Complaint.TabIndex = 5;
            // 
            // panel12
            // 
            this.panel12.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel12.Controls.Add(this.btn_complaint_submit);
            this.panel12.Controls.Add(this.txtbx_chrctr_dec);
            this.panel12.Controls.Add(this.txtbx_chrctr_plc);
            this.panel12.Controls.Add(this.label80);
            this.panel12.Controls.Add(this.rchtxtbx_descrptn_of_cmplnt);
            this.panel12.Controls.Add(this.label79);
            this.panel12.Controls.Add(this.rchtxtbx_plce_of_occrnce);
            this.panel12.Controls.Add(this.label78);
            this.panel12.Controls.Add(this.dte_time);
            this.panel12.Controls.Add(this.dte_date);
            this.panel12.Controls.Add(this.label77);
            this.panel12.Controls.Add(this.cmbx_subject);
            this.panel12.Controls.Add(this.label76);
            this.panel12.Location = new System.Drawing.Point(16, 456);
            this.panel12.Name = "panel12";
            this.panel12.Size = new System.Drawing.Size(1088, 143);
            this.panel12.TabIndex = 6;
            // 
            // btn_complaint_submit
            // 
            this.btn_complaint_submit.BackColor = System.Drawing.Color.CornflowerBlue;
            this.btn_complaint_submit.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_complaint_submit.Location = new System.Drawing.Point(1001, 3);
            this.btn_complaint_submit.Name = "btn_complaint_submit";
            this.btn_complaint_submit.Size = new System.Drawing.Size(81, 29);
            this.btn_complaint_submit.TabIndex = 50;
            this.btn_complaint_submit.Text = "Submit";
            this.btn_complaint_submit.UseVisualStyleBackColor = false;
            this.btn_complaint_submit.Click += new System.EventHandler(this.btn_complaint_submit_Click);
            // 
            // txtbx_chrctr_dec
            // 
            this.txtbx_chrctr_dec.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbx_chrctr_dec.ForeColor = System.Drawing.Color.Green;
            this.txtbx_chrctr_dec.Location = new System.Drawing.Point(985, 110);
            this.txtbx_chrctr_dec.Name = "txtbx_chrctr_dec";
            this.txtbx_chrctr_dec.Size = new System.Drawing.Size(62, 21);
            this.txtbx_chrctr_dec.TabIndex = 49;
            this.txtbx_chrctr_dec.Text = "2000";
            this.txtbx_chrctr_dec.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtbx_chrctr_dec.TextChanged += new System.EventHandler(this.txtbx_chrctr_dec_TextChanged);
            // 
            // txtbx_chrctr_plc
            // 
            this.txtbx_chrctr_plc.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbx_chrctr_plc.ForeColor = System.Drawing.Color.Green;
            this.txtbx_chrctr_plc.Location = new System.Drawing.Point(985, 51);
            this.txtbx_chrctr_plc.Name = "txtbx_chrctr_plc";
            this.txtbx_chrctr_plc.Size = new System.Drawing.Size(62, 21);
            this.txtbx_chrctr_plc.TabIndex = 48;
            this.txtbx_chrctr_plc.Text = "2000";
            this.txtbx_chrctr_plc.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtbx_chrctr_plc.TextChanged += new System.EventHandler(this.txtbx_chrctr_plc_TextChanged);
            // 
            // label80
            // 
            this.label80.AutoSize = true;
            this.label80.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label80.ForeColor = System.Drawing.Color.Red;
            this.label80.Location = new System.Drawing.Point(873, 53);
            this.label80.Name = "label80";
            this.label80.Size = new System.Drawing.Size(116, 16);
            this.label80.TabIndex = 47;
            this.label80.Text = "Characters Left ";
            // 
            // rchtxtbx_descrptn_of_cmplnt
            // 
            this.rchtxtbx_descrptn_of_cmplnt.Location = new System.Drawing.Point(200, 105);
            this.rchtxtbx_descrptn_of_cmplnt.MaxLength = 2000;
            this.rchtxtbx_descrptn_of_cmplnt.Name = "rchtxtbx_descrptn_of_cmplnt";
            this.rchtxtbx_descrptn_of_cmplnt.Size = new System.Drawing.Size(776, 27);
            this.rchtxtbx_descrptn_of_cmplnt.TabIndex = 46;
            this.rchtxtbx_descrptn_of_cmplnt.Text = "";
            this.rchtxtbx_descrptn_of_cmplnt.TextChanged += new System.EventHandler(this.rchtxtbx_descrptn_of_cmplnt_TextChanged);
            // 
            // label79
            // 
            this.label79.AutoSize = true;
            this.label79.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label79.ForeColor = System.Drawing.Color.Red;
            this.label79.Location = new System.Drawing.Point(7, 115);
            this.label79.Name = "label79";
            this.label79.Size = new System.Drawing.Size(187, 16);
            this.label79.TabIndex = 45;
            this.label79.Text = "Description of Complaint *";
            // 
            // rchtxtbx_plce_of_occrnce
            // 
            this.rchtxtbx_plce_of_occrnce.Location = new System.Drawing.Point(200, 72);
            this.rchtxtbx_plce_of_occrnce.MaxLength = 2000;
            this.rchtxtbx_plce_of_occrnce.Name = "rchtxtbx_plce_of_occrnce";
            this.rchtxtbx_plce_of_occrnce.Size = new System.Drawing.Size(776, 27);
            this.rchtxtbx_plce_of_occrnce.TabIndex = 44;
            this.rchtxtbx_plce_of_occrnce.Text = "";
            this.rchtxtbx_plce_of_occrnce.TextChanged += new System.EventHandler(this.rchtxtbx_plce_of_occrnce_TextChanged);
            // 
            // label78
            // 
            this.label78.AutoSize = true;
            this.label78.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label78.ForeColor = System.Drawing.Color.Red;
            this.label78.Location = new System.Drawing.Point(16, 73);
            this.label78.Name = "label78";
            this.label78.Size = new System.Drawing.Size(153, 16);
            this.label78.TabIndex = 43;
            this.label78.Text = "Place of Occurence *";
            // 
            // dte_time
            // 
            this.dte_time.Format = System.Windows.Forms.DateTimePickerFormat.Time;
            this.dte_time.Location = new System.Drawing.Point(451, 41);
            this.dte_time.Name = "dte_time";
            this.dte_time.Size = new System.Drawing.Size(200, 20);
            this.dte_time.TabIndex = 42;
            // 
            // dte_date
            // 
            this.dte_date.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dte_date.Location = new System.Drawing.Point(236, 41);
            this.dte_date.Name = "dte_date";
            this.dte_date.Size = new System.Drawing.Size(200, 20);
            this.dte_date.TabIndex = 41;
            // 
            // label77
            // 
            this.label77.AutoSize = true;
            this.label77.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label77.ForeColor = System.Drawing.Color.Black;
            this.label77.Location = new System.Drawing.Point(16, 42);
            this.label77.Name = "label77";
            this.label77.Size = new System.Drawing.Size(205, 16);
            this.label77.TabIndex = 40;
            this.label77.Text = "Date and Time of Occurence";
            // 
            // cmbx_subject
            // 
            this.cmbx_subject.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbx_subject.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbx_subject.FormattingEnabled = true;
            this.cmbx_subject.Items.AddRange(new object[] {
            "Others ( பிற குற்றங்கள் )",
            "Attempt To Commit Crime ( குற்றம்   முயற்சி நிகழ்த்த )",
            "Charging Exorbitant Interest ( அளவு கடந்தவட்டி வசுலித்தல் )",
            "Conspiracy ( சதி )",
            "Counterfeiting Of Currency ( கள்ள நாணயம் தயாரித்தல் )",
            "Criminal Intimidation ( குற்றமுறு மிரட்டுதல் )",
            "Criminal Trespass ( குற்றமுறு அச்சுறுத்தல் )",
            "Cyber Crimes ( இணையதள குற்றங்கள் )",
            "Dacoity (  கூட்டுக் கொள்ளை )",
            "Document Missing ( காணாமல் போன ஆவணம் )",
            "Embezzlement ( பணமோசடி )",
            "Eve Teasing ( கேலி செய்தல் )",
            "Extortion ( அச்சுறுத்திப் பறித்தல் )",
            "Forgery ( பொய் ஆவணம் புனைதல் )",
            "Hurt ( உடல் ஊறு )",
            "ImPersonation ( ஆள்மாறாட்டம் )",
            "Incitement ( தூண்டுதல் )",
            "Juvenile delinguency ( இளமை தீச்செயல் )",
            "Kidnapping ( ஆள் கடத்தல் )",
            "Land Grabbing ( நில அபகரிப்பு )",
            "Misappropriation ( கையாடல் - பணம் கையாடல் )",
            "Mischief ( தீங்கு )",
            "Missing Persons ( காணாமல் போன ஆட்கள் )",
            "Mobile Missing ( காணாமல் போன கைபேசி )",
            "Murder ( கொலை )",
            "Non Banking Financial Institution cases ( தனியார் நிதிநிறுவன வழக்குகள் )",
            "Nuisance ( தொல்லை )",
            "Offecnces Against Religion & Public Worship ( மத வழிபாட்டுதலங்களுக்கெதிரான குற்றங" +
                "்கள் )",
            "Offences Against State ( அரசுக்கு எதிரான குற்றங்கள் )",
            "Offences Relating To Marriage ( திருமணம் சார் குற்றங்கள் )",
            "Political Offence ( அரசியல் குற்றங்கள் )",
            "Quarrel-Altercations ( வாய் தகராறு )",
            "Ragging ( வன் சீண்டல் )",
            "Rape ( கற்பழிப்பு )",
            "Robbery ( கொள்ளை )",
            "Stolen Property ( திருட்டுச் சொத்து )",
            "Theft ( திருட்டு )",
            "Traffic Violations ( போக்குவரத்து விதி மீறுகை )",
            "Vehicle Missing (  காணாமல் போன வாகனம் )",
            "Women Harassment ( பெண் சீண்டல் )",
            "Wrongful Confinement ( சட்டவிரோதமாக அடைத்து வைத்தல் )"});
            this.cmbx_subject.Location = new System.Drawing.Point(97, 8);
            this.cmbx_subject.Name = "cmbx_subject";
            this.cmbx_subject.Size = new System.Drawing.Size(688, 24);
            this.cmbx_subject.TabIndex = 39;
            // 
            // label76
            // 
            this.label76.AutoSize = true;
            this.label76.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label76.ForeColor = System.Drawing.Color.Red;
            this.label76.Location = new System.Drawing.Point(16, 9);
            this.label76.Name = "label76";
            this.label76.Size = new System.Drawing.Size(70, 16);
            this.label76.TabIndex = 38;
            this.label76.Text = "Subject *";
            // 
            // panel11
            // 
            this.panel11.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel11.Controls.Add(this.txtbx_emailid);
            this.panel11.Controls.Add(this.label75);
            this.panel11.Controls.Add(this.txtbx_id_proof_2);
            this.panel11.Controls.Add(this.label73);
            this.panel11.Controls.Add(this.cmbx_id_proof_2);
            this.panel11.Controls.Add(this.label74);
            this.panel11.Controls.Add(this.txtbx_id_proof_1);
            this.panel11.Controls.Add(this.label72);
            this.panel11.Controls.Add(this.txtbx_mblenmbr);
            this.panel11.Controls.Add(this.label71);
            this.panel11.Controls.Add(this.cmbx_idnty_proof_1);
            this.panel11.Controls.Add(this.label70);
            this.panel11.Controls.Add(this.txtbx_pincode);
            this.panel11.Controls.Add(this.label69);
            this.panel11.Controls.Add(this.txtbx_state);
            this.panel11.Controls.Add(this.label68);
            this.panel11.Controls.Add(this.txtbx_district);
            this.panel11.Controls.Add(this.label67);
            this.panel11.Controls.Add(this.txtbx_city);
            this.panel11.Controls.Add(this.label66);
            this.panel11.Controls.Add(this.txtbx_addrss_fr_cmmtion1);
            this.panel11.Controls.Add(this.txtbx_addrss_fr_cmmtion);
            this.panel11.Controls.Add(this.label65);
            this.panel11.Controls.Add(this.txtbx_age);
            this.panel11.Controls.Add(this.label64);
            this.panel11.Controls.Add(this.dte_dob);
            this.panel11.Controls.Add(this.label63);
            this.panel11.Controls.Add(this.cmbx_gndr);
            this.panel11.Controls.Add(this.label62);
            this.panel11.Controls.Add(this.txtbx_nme);
            this.panel11.Controls.Add(this.label61);
            this.panel11.Location = new System.Drawing.Point(16, 296);
            this.panel11.Name = "panel11";
            this.panel11.Size = new System.Drawing.Size(1090, 154);
            this.panel11.TabIndex = 5;
            this.panel11.Paint += new System.Windows.Forms.PaintEventHandler(this.panel11_Paint);
            // 
            // txtbx_emailid
            // 
            this.txtbx_emailid.Location = new System.Drawing.Point(862, 129);
            this.txtbx_emailid.Name = "txtbx_emailid";
            this.txtbx_emailid.Size = new System.Drawing.Size(220, 20);
            this.txtbx_emailid.TabIndex = 37;
            // 
            // label75
            // 
            this.label75.AutoSize = true;
            this.label75.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label75.ForeColor = System.Drawing.Color.Black;
            this.label75.Location = new System.Drawing.Point(804, 131);
            this.label75.Name = "label75";
            this.label75.Size = new System.Drawing.Size(47, 16);
            this.label75.TabIndex = 36;
            this.label75.Text = "Email";
            // 
            // txtbx_id_proof_2
            // 
            this.txtbx_id_proof_2.Location = new System.Drawing.Point(933, 88);
            this.txtbx_id_proof_2.Name = "txtbx_id_proof_2";
            this.txtbx_id_proof_2.Size = new System.Drawing.Size(150, 20);
            this.txtbx_id_proof_2.TabIndex = 35;
            this.txtbx_id_proof_2.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtbx_id_proof_2_KeyPress);
            // 
            // label73
            // 
            this.label73.AutoSize = true;
            this.label73.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label73.ForeColor = System.Drawing.Color.Black;
            this.label73.Location = new System.Drawing.Point(788, 91);
            this.label73.Name = "label73";
            this.label73.Size = new System.Drawing.Size(141, 13);
            this.label73.TabIndex = 34;
            this.label73.Text = "Identity Proof 2 Number";
            this.label73.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // cmbx_id_proof_2
            // 
            this.cmbx_id_proof_2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbx_id_proof_2.FormattingEnabled = true;
            this.cmbx_id_proof_2.Items.AddRange(new object[] {
            "AADHAR CARD",
            "DRIVING LICENSE",
            "ELECTION CARD",
            "PAN CARD",
            "RATION CARD"});
            this.cmbx_id_proof_2.Location = new System.Drawing.Point(933, 59);
            this.cmbx_id_proof_2.Name = "cmbx_id_proof_2";
            this.cmbx_id_proof_2.Size = new System.Drawing.Size(150, 21);
            this.cmbx_id_proof_2.TabIndex = 33;
            // 
            // label74
            // 
            this.label74.AutoSize = true;
            this.label74.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label74.ForeColor = System.Drawing.Color.Black;
            this.label74.Location = new System.Drawing.Point(788, 62);
            this.label74.Name = "label74";
            this.label74.Size = new System.Drawing.Size(126, 13);
            this.label74.TabIndex = 32;
            this.label74.Text = "Identity Proof 2 Type";
            this.label74.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // txtbx_id_proof_1
            // 
            this.txtbx_id_proof_1.Location = new System.Drawing.Point(933, 33);
            this.txtbx_id_proof_1.Name = "txtbx_id_proof_1";
            this.txtbx_id_proof_1.Size = new System.Drawing.Size(150, 20);
            this.txtbx_id_proof_1.TabIndex = 31;
            this.txtbx_id_proof_1.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtbx_id_proof_1_KeyPress);
            // 
            // label72
            // 
            this.label72.AutoSize = true;
            this.label72.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label72.ForeColor = System.Drawing.Color.Black;
            this.label72.Location = new System.Drawing.Point(788, 36);
            this.label72.Name = "label72";
            this.label72.Size = new System.Drawing.Size(141, 13);
            this.label72.TabIndex = 30;
            this.label72.Text = "Identity Proof 1 Number";
            this.label72.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // txtbx_mblenmbr
            // 
            this.txtbx_mblenmbr.Location = new System.Drawing.Point(124, 123);
            this.txtbx_mblenmbr.Name = "txtbx_mblenmbr";
            this.txtbx_mblenmbr.Size = new System.Drawing.Size(229, 20);
            this.txtbx_mblenmbr.TabIndex = 29;
            // 
            // label71
            // 
            this.label71.AutoSize = true;
            this.label71.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label71.ForeColor = System.Drawing.Color.Black;
            this.label71.Location = new System.Drawing.Point(6, 124);
            this.label71.Name = "label71";
            this.label71.Size = new System.Drawing.Size(113, 16);
            this.label71.TabIndex = 28;
            this.label71.Text = "Mobile Number";
            // 
            // cmbx_idnty_proof_1
            // 
            this.cmbx_idnty_proof_1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbx_idnty_proof_1.FormattingEnabled = true;
            this.cmbx_idnty_proof_1.Items.AddRange(new object[] {
            "AADHAR CARD",
            "DRIVING LICENSE",
            "ELECTION CARD",
            "PAN CARD",
            "RATION CARD"});
            this.cmbx_idnty_proof_1.Location = new System.Drawing.Point(933, 4);
            this.cmbx_idnty_proof_1.Name = "cmbx_idnty_proof_1";
            this.cmbx_idnty_proof_1.Size = new System.Drawing.Size(150, 21);
            this.cmbx_idnty_proof_1.TabIndex = 27;
            // 
            // label70
            // 
            this.label70.AutoSize = true;
            this.label70.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label70.ForeColor = System.Drawing.Color.Black;
            this.label70.Location = new System.Drawing.Point(789, 10);
            this.label70.Name = "label70";
            this.label70.Size = new System.Drawing.Size(126, 13);
            this.label70.TabIndex = 26;
            this.label70.Text = "Identity Proof 1 Type";
            this.label70.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // txtbx_pincode
            // 
            this.txtbx_pincode.Location = new System.Drawing.Point(556, 131);
            this.txtbx_pincode.Name = "txtbx_pincode";
            this.txtbx_pincode.Size = new System.Drawing.Size(229, 20);
            this.txtbx_pincode.TabIndex = 25;
            this.txtbx_pincode.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtbx_pincode_KeyPress);
            // 
            // label69
            // 
            this.label69.AutoSize = true;
            this.label69.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label69.ForeColor = System.Drawing.Color.Black;
            this.label69.Location = new System.Drawing.Point(481, 135);
            this.label69.Name = "label69";
            this.label69.Size = new System.Drawing.Size(65, 16);
            this.label69.TabIndex = 24;
            this.label69.Text = "Pincode";
            // 
            // txtbx_state
            // 
            this.txtbx_state.Location = new System.Drawing.Point(556, 107);
            this.txtbx_state.Name = "txtbx_state";
            this.txtbx_state.Size = new System.Drawing.Size(229, 20);
            this.txtbx_state.TabIndex = 23;
            // 
            // label68
            // 
            this.label68.AutoSize = true;
            this.label68.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label68.ForeColor = System.Drawing.Color.Black;
            this.label68.Location = new System.Drawing.Point(501, 110);
            this.label68.Name = "label68";
            this.label68.Size = new System.Drawing.Size(44, 16);
            this.label68.TabIndex = 22;
            this.label68.Text = "State";
            // 
            // txtbx_district
            // 
            this.txtbx_district.Location = new System.Drawing.Point(556, 82);
            this.txtbx_district.Name = "txtbx_district";
            this.txtbx_district.Size = new System.Drawing.Size(229, 20);
            this.txtbx_district.TabIndex = 21;
            // 
            // label67
            // 
            this.label67.AutoSize = true;
            this.label67.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label67.ForeColor = System.Drawing.Color.Black;
            this.label67.Location = new System.Drawing.Point(488, 85);
            this.label67.Name = "label67";
            this.label67.Size = new System.Drawing.Size(56, 16);
            this.label67.TabIndex = 20;
            this.label67.Text = "District";
            // 
            // txtbx_city
            // 
            this.txtbx_city.Location = new System.Drawing.Point(556, 56);
            this.txtbx_city.Name = "txtbx_city";
            this.txtbx_city.Size = new System.Drawing.Size(229, 20);
            this.txtbx_city.TabIndex = 19;
            // 
            // label66
            // 
            this.label66.AutoSize = true;
            this.label66.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label66.ForeColor = System.Drawing.Color.Black;
            this.label66.Location = new System.Drawing.Point(510, 60);
            this.label66.Name = "label66";
            this.label66.Size = new System.Drawing.Size(34, 16);
            this.label66.TabIndex = 18;
            this.label66.Text = "City";
            // 
            // txtbx_addrss_fr_cmmtion1
            // 
            this.txtbx_addrss_fr_cmmtion1.Location = new System.Drawing.Point(556, 31);
            this.txtbx_addrss_fr_cmmtion1.Name = "txtbx_addrss_fr_cmmtion1";
            this.txtbx_addrss_fr_cmmtion1.Size = new System.Drawing.Size(229, 20);
            this.txtbx_addrss_fr_cmmtion1.TabIndex = 17;
            // 
            // txtbx_addrss_fr_cmmtion
            // 
            this.txtbx_addrss_fr_cmmtion.Location = new System.Drawing.Point(556, 6);
            this.txtbx_addrss_fr_cmmtion.Name = "txtbx_addrss_fr_cmmtion";
            this.txtbx_addrss_fr_cmmtion.Size = new System.Drawing.Size(229, 20);
            this.txtbx_addrss_fr_cmmtion.TabIndex = 16;
            // 
            // label65
            // 
            this.label65.AutoSize = true;
            this.label65.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label65.ForeColor = System.Drawing.Color.Black;
            this.label65.Location = new System.Drawing.Point(342, 6);
            this.label65.Name = "label65";
            this.label65.Size = new System.Drawing.Size(202, 16);
            this.label65.TabIndex = 15;
            this.label65.Text = "Address For Communication";
            // 
            // txtbx_age
            // 
            this.txtbx_age.Location = new System.Drawing.Point(123, 93);
            this.txtbx_age.Name = "txtbx_age";
            this.txtbx_age.Size = new System.Drawing.Size(229, 20);
            this.txtbx_age.TabIndex = 14;
            // 
            // label64
            // 
            this.label64.AutoSize = true;
            this.label64.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label64.ForeColor = System.Drawing.Color.Black;
            this.label64.Location = new System.Drawing.Point(10, 94);
            this.label64.Name = "label64";
            this.label64.Size = new System.Drawing.Size(36, 16);
            this.label64.TabIndex = 13;
            this.label64.Text = "Age";
            // 
            // dte_dob
            // 
            this.dte_dob.Location = new System.Drawing.Point(122, 64);
            this.dte_dob.Name = "dte_dob";
            this.dte_dob.Size = new System.Drawing.Size(229, 20);
            this.dte_dob.TabIndex = 12;
            // 
            // label63
            // 
            this.label63.AutoSize = true;
            this.label63.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label63.ForeColor = System.Drawing.Color.Black;
            this.label63.Location = new System.Drawing.Point(9, 66);
            this.label63.Name = "label63";
            this.label63.Size = new System.Drawing.Size(93, 16);
            this.label63.TabIndex = 11;
            this.label63.Text = "Date of Birth";
            // 
            // cmbx_gndr
            // 
            this.cmbx_gndr.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbx_gndr.FormattingEnabled = true;
            this.cmbx_gndr.Items.AddRange(new object[] {
            "Male",
            "Female",
            "Other"});
            this.cmbx_gndr.Location = new System.Drawing.Point(122, 34);
            this.cmbx_gndr.Name = "cmbx_gndr";
            this.cmbx_gndr.Size = new System.Drawing.Size(230, 21);
            this.cmbx_gndr.TabIndex = 10;
            // 
            // label62
            // 
            this.label62.AutoSize = true;
            this.label62.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label62.ForeColor = System.Drawing.Color.Black;
            this.label62.Location = new System.Drawing.Point(8, 37);
            this.label62.Name = "label62";
            this.label62.Size = new System.Drawing.Size(59, 16);
            this.label62.TabIndex = 9;
            this.label62.Text = "Gender";
            // 
            // txtbx_nme
            // 
            this.txtbx_nme.Location = new System.Drawing.Point(122, 5);
            this.txtbx_nme.Name = "txtbx_nme";
            this.txtbx_nme.Size = new System.Drawing.Size(217, 20);
            this.txtbx_nme.TabIndex = 8;
            // 
            // label61
            // 
            this.label61.AutoSize = true;
            this.label61.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label61.ForeColor = System.Drawing.Color.Red;
            this.label61.Location = new System.Drawing.Point(9, 7);
            this.label61.Name = "label61";
            this.label61.Size = new System.Drawing.Size(59, 16);
            this.label61.TabIndex = 7;
            this.label61.Text = "Name *";
            // 
            // panel10
            // 
            this.panel10.BackColor = System.Drawing.Color.SeaShell;
            this.panel10.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel10.Controls.Add(this.cmbx_police_station_1);
            this.panel10.Controls.Add(this.label57);
            this.panel10.Controls.Add(this.cmbx_district1);
            this.panel10.Controls.Add(this.label58);
            this.panel10.Controls.Add(this.rdbtn_police_station_1);
            this.panel10.Controls.Add(this.label59);
            this.panel10.Controls.Add(this.label60);
            this.panel10.Location = new System.Drawing.Point(15, 224);
            this.panel10.Name = "panel10";
            this.panel10.Size = new System.Drawing.Size(1090, 62);
            this.panel10.TabIndex = 4;
            // 
            // cmbx_police_station_1
            // 
            this.cmbx_police_station_1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbx_police_station_1.FormattingEnabled = true;
            this.cmbx_police_station_1.Items.AddRange(new object[] {
            "CHETTIPALAYAM",
            "AWPS-THUDIYALUR",
            "ANNUR",
            "K.G.CHAVADI",
            "NEGAMAM",
            "AWPS-PERUR",
            "GOMANGALAM",
            "SULUR",
            "KINATHUKADAVU",
            "PERUR",
            "KEDAMBARAI",
            "ALLANDURAI",
            "METTUPALAYAM",
            "VADAVALLI",
            "MADUKKARAI",
            "KOVILPALAYAM",
            "VEDAKKIPALAYAM",
            "PILLUR DAM",
            "POLLACHI TOWN",
            "POLLACHI BAZAAR",
            "POLLACHI TALUK",
            "PERIYANAIKENPALAYAM",
            "MUDIS",
            "THONDAMUTHUR",
            "SIRUMUGAI",
            "AANAMALAI",
            "KARUMATHAMPATTY",
            "KARUNYA NAGAR",
            "MALINGAPURAM",
            "VALPARAI",
            "ALIYAR",
            "KARAMADAI",
            "THUDIYALUR",
            "KOTTUR",
            "AWPS-POLLACHI",
            "SAIBABA COLONY",
            "BAZAAR",
            "SELVAPURAM",
            "SINGANALLUR",
            "AWPS-CENTRAL",
            "PEELAMEDU",
            "UKKADAM",
            "AWPS-WEST",
            "SARAVANAMPATTI",
            "RATHUNAPURI",
            "KATTUR",
            "KUNIYAMUTHUR",
            "POTHANUR",
            "AWPS-EAST",
            "RACE COURSE",
            "VARIETYHALL ROAD",
            "R.S.PURAM",
            "RAMANATHAPURAM"});
            this.cmbx_police_station_1.Location = new System.Drawing.Point(704, 27);
            this.cmbx_police_station_1.Name = "cmbx_police_station_1";
            this.cmbx_police_station_1.Size = new System.Drawing.Size(200, 24);
            this.cmbx_police_station_1.TabIndex = 6;
            this.cmbx_police_station_1.Text = "Choose One...";
            // 
            // label57
            // 
            this.label57.AutoSize = true;
            this.label57.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label57.Location = new System.Drawing.Point(592, 30);
            this.label57.Name = "label57";
            this.label57.Size = new System.Drawing.Size(104, 16);
            this.label57.TabIndex = 5;
            this.label57.Text = "Police Station";
            // 
            // cmbx_district1
            // 
            this.cmbx_district1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbx_district1.FormattingEnabled = true;
            this.cmbx_district1.Location = new System.Drawing.Point(388, 27);
            this.cmbx_district1.Name = "cmbx_district1";
            this.cmbx_district1.Size = new System.Drawing.Size(184, 24);
            this.cmbx_district1.TabIndex = 4;
            this.cmbx_district1.Text = "COIMBATORE";
            // 
            // label58
            // 
            this.label58.AutoSize = true;
            this.label58.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label58.Location = new System.Drawing.Point(325, 32);
            this.label58.Name = "label58";
            this.label58.Size = new System.Drawing.Size(56, 16);
            this.label58.TabIndex = 3;
            this.label58.Text = "District";
            // 
            // rdbtn_police_station_1
            // 
            this.rdbtn_police_station_1.AutoSize = true;
            this.rdbtn_police_station_1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdbtn_police_station_1.Location = new System.Drawing.Point(206, 30);
            this.rdbtn_police_station_1.Name = "rdbtn_police_station_1";
            this.rdbtn_police_station_1.Size = new System.Drawing.Size(108, 20);
            this.rdbtn_police_station_1.TabIndex = 2;
            this.rdbtn_police_station_1.TabStop = true;
            this.rdbtn_police_station_1.Text = "Police Station";
            this.rdbtn_police_station_1.UseVisualStyleBackColor = true;
            this.rdbtn_police_station_1.CheckedChanged += new System.EventHandler(this.rdbtn_police_station_1_CheckedChanged);
            // 
            // label59
            // 
            this.label59.AutoSize = true;
            this.label59.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label59.ForeColor = System.Drawing.Color.Red;
            this.label59.Location = new System.Drawing.Point(63, 31);
            this.label59.Name = "label59";
            this.label59.Size = new System.Drawing.Size(114, 16);
            this.label59.TabIndex = 1;
            this.label59.Text = "Complaint To* :";
            // 
            // label60
            // 
            this.label60.BackColor = System.Drawing.Color.WhiteSmoke;
            this.label60.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label60.Dock = System.Windows.Forms.DockStyle.Top;
            this.label60.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label60.ForeColor = System.Drawing.Color.Red;
            this.label60.Location = new System.Drawing.Point(0, 0);
            this.label60.Name = "label60";
            this.label60.Size = new System.Drawing.Size(1088, 25);
            this.label60.TabIndex = 0;
            this.label60.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel9
            // 
            this.panel9.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel9.Controls.Add(this.label56);
            this.panel9.Location = new System.Drawing.Point(15, 190);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(1090, 26);
            this.panel9.TabIndex = 3;
            // 
            // label56
            // 
            this.label56.AutoSize = true;
            this.label56.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label56.ForeColor = System.Drawing.Color.Red;
            this.label56.Location = new System.Drawing.Point(252, 5);
            this.label56.Name = "label56";
            this.label56.Size = new System.Drawing.Size(652, 13);
            this.label56.TabIndex = 0;
            this.label56.Text = "For Mobile Missing complaints - Provide your alternate Mobile Number in the Prese" +
                "nt Address Column of this Form.";
            this.label56.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // panel2
            // 
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel2.Controls.Add(this.label47);
            this.panel2.Controls.Add(this.label48);
            this.panel2.Controls.Add(this.label49);
            this.panel2.Controls.Add(this.label50);
            this.panel2.Controls.Add(this.label51);
            this.panel2.Controls.Add(this.label52);
            this.panel2.Controls.Add(this.label53);
            this.panel2.Controls.Add(this.label54);
            this.panel2.Controls.Add(this.label55);
            this.panel2.Location = new System.Drawing.Point(15, 63);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1090, 120);
            this.panel2.TabIndex = 2;
            // 
            // label47
            // 
            this.label47.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label47.ForeColor = System.Drawing.Color.MidnightBlue;
            this.label47.Location = new System.Drawing.Point(52, 93);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(1033, 16);
            this.label47.TabIndex = 10;
            this.label47.Text = "Fields given in Red Color are mandatory.";
            this.label47.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label48
            // 
            this.label48.Image = ((System.Drawing.Image)(resources.GetObject("label48.Image")));
            this.label48.Location = new System.Drawing.Point(22, 92);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(23, 19);
            this.label48.TabIndex = 9;
            this.label48.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label49
            // 
            this.label49.AutoSize = true;
            this.label49.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label49.ForeColor = System.Drawing.Color.MidnightBlue;
            this.label49.Location = new System.Drawing.Point(51, 73);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(645, 13);
            this.label49.TabIndex = 8;
            this.label49.Text = "Your complaints will reach the Police Station, SP or the Commissioner of the area" +
                " to which the complaint relates.";
            this.label49.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label50
            // 
            this.label50.Image = ((System.Drawing.Image)(resources.GetObject("label50.Image")));
            this.label50.Location = new System.Drawing.Point(22, 69);
            this.label50.Name = "label50";
            this.label50.Size = new System.Drawing.Size(23, 19);
            this.label50.TabIndex = 7;
            this.label50.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label51
            // 
            this.label51.AutoSize = true;
            this.label51.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label51.ForeColor = System.Drawing.Color.MidnightBlue;
            this.label51.Location = new System.Drawing.Point(51, 51);
            this.label51.Name = "label51";
            this.label51.Size = new System.Drawing.Size(287, 13);
            this.label51.TabIndex = 6;
            this.label51.Text = "You can use this form to register your complaints.";
            this.label51.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label52
            // 
            this.label52.Image = ((System.Drawing.Image)(resources.GetObject("label52.Image")));
            this.label52.Location = new System.Drawing.Point(22, 47);
            this.label52.Name = "label52";
            this.label52.Size = new System.Drawing.Size(23, 19);
            this.label52.TabIndex = 5;
            this.label52.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label53
            // 
            this.label53.AutoSize = true;
            this.label53.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label53.ForeColor = System.Drawing.Color.MidnightBlue;
            this.label53.Location = new System.Drawing.Point(51, 29);
            this.label53.Name = "label53";
            this.label53.Size = new System.Drawing.Size(317, 13);
            this.label53.TabIndex = 4;
            this.label53.Text = "False complaints are subject to prosecution under IPC.";
            this.label53.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label54
            // 
            this.label54.Image = ((System.Drawing.Image)(resources.GetObject("label54.Image")));
            this.label54.Location = new System.Drawing.Point(23, 25);
            this.label54.Name = "label54";
            this.label54.Size = new System.Drawing.Size(23, 19);
            this.label54.TabIndex = 3;
            this.label54.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label55
            // 
            this.label55.BackColor = System.Drawing.Color.Silver;
            this.label55.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label55.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label55.ForeColor = System.Drawing.Color.Red;
            this.label55.Location = new System.Drawing.Point(0, 0);
            this.label55.Name = "label55";
            this.label55.Size = new System.Drawing.Size(1090, 23);
            this.label55.TabIndex = 2;
            this.label55.Text = "Notes To Users";
            this.label55.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label46
            // 
            this.label46.BackColor = System.Drawing.Color.Green;
            this.label46.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label46.ForeColor = System.Drawing.Color.PaleTurquoise;
            this.label46.Location = new System.Drawing.Point(15, 27);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(1093, 23);
            this.label46.TabIndex = 1;
            this.label46.Text = "COMPLAINT REGISTRATION FORM";
            this.label46.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel_fir
            // 
            this.panel_fir.BackColor = System.Drawing.Color.Bisque;
            this.panel_fir.Controls.Add(this.label83);
            this.panel_fir.Controls.Add(this.lbl_status);
            this.panel_fir.Controls.Add(this.label82);
            this.panel_fir.Controls.Add(this.btn_search);
            this.panel_fir.Controls.Add(this.dateTimePicker1);
            this.panel_fir.Controls.Add(this.label81);
            this.panel_fir.Controls.Add(this.textBox2);
            this.panel_fir.Controls.Add(this.label39);
            this.panel_fir.Controls.Add(this.txtbx_fir_nmbr);
            this.panel_fir.Controls.Add(this.label34);
            this.panel_fir.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panel_fir.Location = new System.Drawing.Point(-1, 3);
            this.panel_fir.Name = "panel_fir";
            this.panel_fir.Size = new System.Drawing.Size(593, 359);
            this.panel_fir.TabIndex = 4;
            // 
            // label83
            // 
            this.label83.AutoSize = true;
            this.label83.Location = new System.Drawing.Point(246, 334);
            this.label83.Name = "label83";
            this.label83.Size = new System.Drawing.Size(94, 16);
            this.label83.TabIndex = 9;
            this.label83.Text = "View Details";
            this.label83.Click += new System.EventHandler(this.label83_Click);
            // 
            // lbl_status
            // 
            this.lbl_status.Location = new System.Drawing.Point(197, 234);
            this.lbl_status.Name = "lbl_status";
            this.lbl_status.Size = new System.Drawing.Size(187, 39);
            this.lbl_status.TabIndex = 8;
            this.lbl_status.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label82
            // 
            this.label82.AutoSize = true;
            this.label82.Location = new System.Drawing.Point(265, 211);
            this.label82.Name = "label82";
            this.label82.Size = new System.Drawing.Size(51, 16);
            this.label82.TabIndex = 7;
            this.label82.Text = "Status";
            // 
            // btn_search
            // 
            this.btn_search.Location = new System.Drawing.Point(245, 289);
            this.btn_search.Name = "btn_search";
            this.btn_search.Size = new System.Drawing.Size(90, 32);
            this.btn_search.TabIndex = 6;
            this.btn_search.Text = "Search";
            this.btn_search.UseVisualStyleBackColor = true;
            this.btn_search.Click += new System.EventHandler(this.btn_search_Click);
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Location = new System.Drawing.Point(177, 154);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(261, 22);
            this.dateTimePicker1.TabIndex = 5;
            // 
            // label81
            // 
            this.label81.AutoSize = true;
            this.label81.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label81.Location = new System.Drawing.Point(10, 159);
            this.label81.Name = "label81";
            this.label81.Size = new System.Drawing.Size(148, 16);
            this.label81.TabIndex = 4;
            this.label81.Text = "Date Of Registration";
            // 
            // textBox2
            // 
            this.textBox2.Enabled = false;
            this.textBox2.Location = new System.Drawing.Point(176, 54);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(261, 22);
            this.textBox2.TabIndex = 3;
            this.textBox2.Text = "Coimbatore";
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label39.Location = new System.Drawing.Point(52, 57);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(104, 16);
            this.label39.TabIndex = 2;
            this.label39.Text = "Select District";
            // 
            // txtbx_fir_nmbr
            // 
            this.txtbx_fir_nmbr.Location = new System.Drawing.Point(177, 103);
            this.txtbx_fir_nmbr.Name = "txtbx_fir_nmbr";
            this.txtbx_fir_nmbr.Size = new System.Drawing.Size(261, 22);
            this.txtbx_fir_nmbr.TabIndex = 1;
            this.txtbx_fir_nmbr.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtbx_fir_nmbr_KeyPress);
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label34.Location = new System.Drawing.Point(64, 111);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(90, 16);
            this.label34.TabIndex = 0;
            this.label34.Text = "FIR Number";
            // 
            // panel_Information
            // 
            this.panel_Information.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel_Information.Controls.Add(this.panel_Complaint);
            this.panel_Information.Controls.Add(this.btn_Submit);
            this.panel_Information.Controls.Add(this.panel7);
            this.panel_Information.Controls.Add(this.panel5);
            this.panel_Information.Controls.Add(this.panel4);
            this.panel_Information.Controls.Add(this.panel3);
            this.panel_Information.Controls.Add(this.label4);
            this.panel_Information.Location = new System.Drawing.Point(229, 129);
            this.panel_Information.Name = "panel_Information";
            this.panel_Information.Size = new System.Drawing.Size(1127, 606);
            this.panel_Information.TabIndex = 2;
            // 
            // btn_Submit
            // 
            this.btn_Submit.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.btn_Submit.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Submit.ForeColor = System.Drawing.Color.Black;
            this.btn_Submit.Location = new System.Drawing.Point(493, 565);
            this.btn_Submit.Name = "btn_Submit";
            this.btn_Submit.Size = new System.Drawing.Size(100, 30);
            this.btn_Submit.TabIndex = 5;
            this.btn_Submit.Text = "Submit";
            this.btn_Submit.UseVisualStyleBackColor = false;
            this.btn_Submit.Click += new System.EventHandler(this.btn_Submit_Click);
            // 
            // panel7
            // 
            this.panel7.BackColor = System.Drawing.Color.SeaShell;
            this.panel7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel7.Controls.Add(this.txtbx_chrcts);
            this.panel7.Controls.Add(this.label29);
            this.panel7.Controls.Add(this.rchtxtbx_decription);
            this.panel7.Controls.Add(this.label28);
            this.panel7.Controls.Add(this.label27);
            this.panel7.Controls.Add(this.label26);
            this.panel7.Controls.Add(this.cmbx_subject_information);
            this.panel7.Controls.Add(this.label25);
            this.panel7.Location = new System.Drawing.Point(22, 359);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(1088, 197);
            this.panel7.TabIndex = 4;
            // 
            // txtbx_chrcts
            // 
            this.txtbx_chrcts.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbx_chrcts.ForeColor = System.Drawing.Color.Green;
            this.txtbx_chrcts.Location = new System.Drawing.Point(346, 170);
            this.txtbx_chrcts.Name = "txtbx_chrcts";
            this.txtbx_chrcts.Size = new System.Drawing.Size(62, 21);
            this.txtbx_chrcts.TabIndex = 14;
            this.txtbx_chrcts.Text = "2000";
            this.txtbx_chrcts.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label29.ForeColor = System.Drawing.Color.Red;
            this.label29.Location = new System.Drawing.Point(234, 172);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(116, 16);
            this.label29.TabIndex = 13;
            this.label29.Text = "Characters Left ";
            // 
            // rchtxtbx_decription
            // 
            this.rchtxtbx_decription.Location = new System.Drawing.Point(230, 60);
            this.rchtxtbx_decription.MaxLength = 2000;
            this.rchtxtbx_decription.Name = "rchtxtbx_decription";
            this.rchtxtbx_decription.Size = new System.Drawing.Size(791, 108);
            this.rchtxtbx_decription.TabIndex = 12;
            this.rchtxtbx_decription.Text = "";
            this.rchtxtbx_decription.TextChanged += new System.EventHandler(this.rchtxtbx_decription_TextChanged);
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label28.ForeColor = System.Drawing.Color.Red;
            this.label28.Location = new System.Drawing.Point(28, 81);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(165, 16);
            this.label28.TabIndex = 11;
            this.label28.Text = "(Max. 2000 Characters)";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label27.ForeColor = System.Drawing.Color.Red;
            this.label27.Location = new System.Drawing.Point(3, 65);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(227, 16);
            this.label27.TabIndex = 10;
            this.label27.Text = "Description of the Information * :";
            // 
            // label26
            // 
            this.label26.BackColor = System.Drawing.Color.Silver;
            this.label26.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label26.Dock = System.Windows.Forms.DockStyle.Top;
            this.label26.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label26.ForeColor = System.Drawing.Color.Red;
            this.label26.Location = new System.Drawing.Point(0, 0);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(1086, 23);
            this.label26.TabIndex = 9;
            this.label26.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // cmbx_subject_information
            // 
            this.cmbx_subject_information.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbx_subject_information.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbx_subject_information.FormattingEnabled = true;
            this.cmbx_subject_information.Items.AddRange(new object[] {
            "Anti-Social Activities ( சமூக விரோத குற்றங்கள் )",
            "Illegal Sale Of Liquors ( சட்ட விரோத மதுபான விற்பனை )",
            "Sabotage ( நாசவேலை )",
            "Anti-Religious Activities ( மத விரோத செயல்பாடுகள் )",
            "Govt.Employees Unrest. ( அரசு ஊழியர்கள் அமைதியின்மை )",
            "Labour Unrest ( தொழிலாளர் அமைதியின்மை )",
            "Trade Union Activities ( தொழிற்சங்க நடவடிக்கைகள் )",
            "Social Unrest ( சமூக அமைதியின்மை )",
            "Black Marketing ( கருப்பு பண சந்தை)",
            "Communal Tensions ( சாதிப் பிரச்சனை சார்ந்த பதட்டங்கள் )",
            "Immoral trafficking ( ஒழுக்கக்கேடான விபச்சாரம் )",
            "Foreign Intelligence Operations ( வெளிநாட்டு புலனாய்வு நடவடிக்கைகள் )",
            "Public Gambling ( பொது இடச் சூதாட்டம் )",
            "Ongoing Crime ( நடப்பு குற்றங்கள் )",
            "Organized Crime ( ஒருங்கிணைக்கப்பட்ட குற்றம் )",
            "Movement of Extremist-Terrorist ( தீவிரவாதிகள் -கொடுமையானவர்கள் நடமாட்டம் )",
            "Illegal Transport Of Arms & Ammunition ( போர் ஆயுதங்களையும் -தளவாடங்களையும் சட்ட" +
                "த்திற்கு எதிராக அனுப்புதல் )",
            "Hoarding Of Harmful - Dangerous Drugs ( மயக்க பொருள்களைப் பதுக்குதல் )",
            "Hoarding of Explosives Substances ( வெடி பொருள்களைப் பதுக்குதல் )",
            "Hoarding of Essential Commodities( இன்றியமையா பொருள்களைப் பதுக்குதல் )",
            "Others ( பிற - மற்றவை )",
            "Copyright Infringement ( பதிப்புரிமை மீறுதல் )"});
            this.cmbx_subject_information.Location = new System.Drawing.Point(230, 28);
            this.cmbx_subject_information.Name = "cmbx_subject_information";
            this.cmbx_subject_information.Size = new System.Drawing.Size(791, 26);
            this.cmbx_subject_information.TabIndex = 8;
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label25.ForeColor = System.Drawing.Color.Red;
            this.label25.Location = new System.Drawing.Point(152, 32);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(78, 16);
            this.label25.TabIndex = 7;
            this.label25.Text = "Subject * :";
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.MistyRose;
            this.panel5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel5.Controls.Add(this.txtbx_Mobile_number);
            this.panel5.Controls.Add(this.label24);
            this.panel5.Controls.Add(this.txtbx_email_id);
            this.panel5.Controls.Add(this.label20);
            this.panel5.Controls.Add(this.panel6);
            this.panel5.Controls.Add(this.label18);
            this.panel5.Location = new System.Drawing.Point(21, 271);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(1088, 75);
            this.panel5.TabIndex = 3;
            // 
            // txtbx_Mobile_number
            // 
            this.txtbx_Mobile_number.Location = new System.Drawing.Point(562, 52);
            this.txtbx_Mobile_number.Name = "txtbx_Mobile_number";
            this.txtbx_Mobile_number.Size = new System.Drawing.Size(236, 20);
            this.txtbx_Mobile_number.TabIndex = 8;
            this.txtbx_Mobile_number.TextChanged += new System.EventHandler(this.txtbx_Mobile_number_TextChanged);
            this.txtbx_Mobile_number.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtbx_Mobile_number_KeyPress);
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label24.Location = new System.Drawing.Point(432, 53);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(122, 18);
            this.label24.TabIndex = 5;
            this.label24.Text = "Mobile Number";
            this.label24.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtbx_email_id
            // 
            this.txtbx_email_id.Location = new System.Drawing.Point(173, 52);
            this.txtbx_email_id.Name = "txtbx_email_id";
            this.txtbx_email_id.Size = new System.Drawing.Size(236, 20);
            this.txtbx_email_id.TabIndex = 3;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.Location = new System.Drawing.Point(115, 53);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(50, 18);
            this.label20.TabIndex = 2;
            this.label20.Text = "Email";
            this.label20.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel6
            // 
            this.panel6.BackColor = System.Drawing.Color.LightCyan;
            this.panel6.Controls.Add(this.txtbx_lndlne_number);
            this.panel6.Controls.Add(this.label23);
            this.panel6.Controls.Add(this.txtbx_lndlne_code);
            this.panel6.Controls.Add(this.label22);
            this.panel6.Controls.Add(this.txtbx_Lstnme);
            this.panel6.Controls.Add(this.label21);
            this.panel6.Controls.Add(this.txtbx_Frstnme);
            this.panel6.Controls.Add(this.label19);
            this.panel6.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel6.Location = new System.Drawing.Point(0, 23);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(1086, 28);
            this.panel6.TabIndex = 4;
            // 
            // txtbx_lndlne_number
            // 
            this.txtbx_lndlne_number.Location = new System.Drawing.Point(955, 3);
            this.txtbx_lndlne_number.Name = "txtbx_lndlne_number";
            this.txtbx_lndlne_number.Size = new System.Drawing.Size(128, 20);
            this.txtbx_lndlne_number.TabIndex = 7;
            this.txtbx_lndlne_number.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtbx_lndlne_number_KeyPress);
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label23.Location = new System.Drawing.Point(938, 8);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(11, 13);
            this.label23.TabIndex = 6;
            this.label23.Text = "-";
            // 
            // txtbx_lndlne_code
            // 
            this.txtbx_lndlne_code.Location = new System.Drawing.Point(871, 4);
            this.txtbx_lndlne_code.Name = "txtbx_lndlne_code";
            this.txtbx_lndlne_code.Size = new System.Drawing.Size(62, 20);
            this.txtbx_lndlne_code.TabIndex = 5;
            this.txtbx_lndlne_code.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtbx_lndlne_code_KeyPress);
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.Location = new System.Drawing.Point(790, 4);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(75, 18);
            this.label22.TabIndex = 4;
            this.label22.Text = "LandLine";
            this.label22.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtbx_Lstnme
            // 
            this.txtbx_Lstnme.Location = new System.Drawing.Point(530, 4);
            this.txtbx_Lstnme.Name = "txtbx_Lstnme";
            this.txtbx_Lstnme.Size = new System.Drawing.Size(236, 20);
            this.txtbx_Lstnme.TabIndex = 3;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.Location = new System.Drawing.Point(432, 5);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(89, 18);
            this.label21.TabIndex = 2;
            this.label21.Text = "Last Name";
            this.label21.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtbx_Frstnme
            // 
            this.txtbx_Frstnme.Location = new System.Drawing.Point(173, 3);
            this.txtbx_Frstnme.Name = "txtbx_Frstnme";
            this.txtbx_Frstnme.Size = new System.Drawing.Size(236, 20);
            this.txtbx_Frstnme.TabIndex = 1;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.Location = new System.Drawing.Point(75, 4);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(91, 18);
            this.label19.TabIndex = 0;
            this.label19.Text = "First Name";
            this.label19.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label18
            // 
            this.label18.BackColor = System.Drawing.Color.Silver;
            this.label18.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label18.Dock = System.Windows.Forms.DockStyle.Top;
            this.label18.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.ForeColor = System.Drawing.Color.Red;
            this.label18.Location = new System.Drawing.Point(0, 0);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(1086, 23);
            this.label18.TabIndex = 3;
            this.label18.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.SeaShell;
            this.panel4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel4.Controls.Add(this.cmbx_Police_Station);
            this.panel4.Controls.Add(this.label17);
            this.panel4.Controls.Add(this.cmbx_dstrct);
            this.panel4.Controls.Add(this.label16);
            this.panel4.Controls.Add(this.rdbtn_Police_Station);
            this.panel4.Controls.Add(this.label15);
            this.panel4.Controls.Add(this.label14);
            this.panel4.Location = new System.Drawing.Point(20, 201);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(1090, 62);
            this.panel4.TabIndex = 2;
            // 
            // cmbx_Police_Station
            // 
            this.cmbx_Police_Station.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbx_Police_Station.FormattingEnabled = true;
            this.cmbx_Police_Station.Items.AddRange(new object[] {
            "CHETTIPALAYAM",
            "AWPS-THUDIYALUR",
            "ANNUR",
            "K.G.CHAVADI",
            "NEGAMAM",
            "AWPS-PERUR",
            "GOMANGALAM",
            "SULUR",
            "KINATHUKADAVU",
            "PERUR",
            "KEDAMBARAI",
            "ALLANDURAI",
            "METTUPALAYAM",
            "VADAVALLI",
            "MADUKKARAI",
            "KOVILPALAYAM",
            "VEDAKKIPALAYAM",
            "PILLUR DAM",
            "POLLACHI TOWN",
            "POLLACHI BAZAAR",
            "POLLACHI TALUK",
            "PERIYANAIKENPALAYAM",
            "MUDIS",
            "THONDAMUTHUR",
            "SIRUMUGAI",
            "AANAMALAI",
            "KARUMATHAMPATTY",
            "KARUNYA NAGAR",
            "MALINGAPURAM",
            "VALPARAI",
            "ALIYAR",
            "KARAMADAI",
            "THUDIYALUR",
            "KOTTUR",
            "AWPS-POLLACHI",
            "SAIBABA COLONY",
            "BAZAAR",
            "SELVAPURAM",
            "SINGANALLUR",
            "AWPS-CENTRAL",
            "PEELAMEDU",
            "UKKADAM",
            "AWPS-WEST",
            "SARAVANAMPATTI",
            "RATHUNAPURI",
            "KATTUR",
            "KUNIYAMUTHUR",
            "POTHANUR",
            "AWPS-EAST",
            "RACE COURSE",
            "VARIETYHALL ROAD",
            "R.S.PURAM",
            "RAMANATHAPURAM"});
            this.cmbx_Police_Station.Location = new System.Drawing.Point(704, 27);
            this.cmbx_Police_Station.Name = "cmbx_Police_Station";
            this.cmbx_Police_Station.Size = new System.Drawing.Size(200, 24);
            this.cmbx_Police_Station.TabIndex = 6;
            this.cmbx_Police_Station.Text = "Choose One...";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(592, 30);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(104, 16);
            this.label17.TabIndex = 5;
            this.label17.Text = "Police Station";
            // 
            // cmbx_dstrct
            // 
            this.cmbx_dstrct.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbx_dstrct.FormattingEnabled = true;
            this.cmbx_dstrct.Location = new System.Drawing.Point(388, 27);
            this.cmbx_dstrct.Name = "cmbx_dstrct";
            this.cmbx_dstrct.Size = new System.Drawing.Size(184, 24);
            this.cmbx_dstrct.TabIndex = 4;
            this.cmbx_dstrct.Text = "COIMBATORE";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(325, 32);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(56, 16);
            this.label16.TabIndex = 3;
            this.label16.Text = "District";
            // 
            // rdbtn_Police_Station
            // 
            this.rdbtn_Police_Station.AutoSize = true;
            this.rdbtn_Police_Station.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdbtn_Police_Station.Location = new System.Drawing.Point(206, 30);
            this.rdbtn_Police_Station.Name = "rdbtn_Police_Station";
            this.rdbtn_Police_Station.Size = new System.Drawing.Size(108, 20);
            this.rdbtn_Police_Station.TabIndex = 2;
            this.rdbtn_Police_Station.Text = "Police Station";
            this.rdbtn_Police_Station.UseVisualStyleBackColor = true;
            this.rdbtn_Police_Station.CheckedChanged += new System.EventHandler(this.rdbtn_Police_Station_CheckedChanged);
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.ForeColor = System.Drawing.Color.Red;
            this.label15.Location = new System.Drawing.Point(63, 31);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(121, 16);
            this.label15.TabIndex = 1;
            this.label15.Text = "Information To* :";
            // 
            // label14
            // 
            this.label14.BackColor = System.Drawing.Color.WhiteSmoke;
            this.label14.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label14.Dock = System.Windows.Forms.DockStyle.Top;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.ForeColor = System.Drawing.Color.Red;
            this.label14.Location = new System.Drawing.Point(0, 0);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(1088, 25);
            this.label14.TabIndex = 0;
            this.label14.Text = "Identity of the information provider is voluntary and would be kept confidential " +
                "";
            this.label14.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel3
            // 
            this.panel3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel3.Controls.Add(this.label12);
            this.panel3.Controls.Add(this.label13);
            this.panel3.Controls.Add(this.label10);
            this.panel3.Controls.Add(this.label11);
            this.panel3.Controls.Add(this.label8);
            this.panel3.Controls.Add(this.label9);
            this.panel3.Controls.Add(this.label7);
            this.panel3.Controls.Add(this.label6);
            this.panel3.Controls.Add(this.label5);
            this.panel3.Location = new System.Drawing.Point(19, 57);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(1090, 127);
            this.panel3.TabIndex = 1;
            // 
            // label12
            // 
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.ForeColor = System.Drawing.Color.MidnightBlue;
            this.label12.Location = new System.Drawing.Point(52, 90);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(1033, 32);
            this.label12.TabIndex = 10;
            this.label12.Text = "If you give your address, contact number or email, it will facilitate communicati" +
                "on with you if the need arises. However, if you prefer to give any information a" +
                "nonymously, you may do so.";
            this.label12.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label13
            // 
            this.label13.Image = ((System.Drawing.Image)(resources.GetObject("label13.Image")));
            this.label13.Location = new System.Drawing.Point(22, 90);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(23, 19);
            this.label13.TabIndex = 9;
            this.label13.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.Color.MidnightBlue;
            this.label10.Location = new System.Drawing.Point(51, 73);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(655, 13);
            this.label10.TabIndex = 8;
            this.label10.Text = "Your information will reach the Police Station, SP or the Commissioner of the are" +
                "a to which the information relates.";
            this.label10.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label11
            // 
            this.label11.Image = ((System.Drawing.Image)(resources.GetObject("label11.Image")));
            this.label11.Location = new System.Drawing.Point(22, 69);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(23, 19);
            this.label11.TabIndex = 7;
            this.label11.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.MidnightBlue;
            this.label8.Location = new System.Drawing.Point(51, 51);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(905, 13);
            this.label8.TabIndex = 6;
            this.label8.Text = "Do not use this form to report an on-going crime that requires immediate police i" +
                "ntervention. If such a crime is occurring CALL 100 or your local police station." +
                " ";
            this.label8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label9
            // 
            this.label9.Image = ((System.Drawing.Image)(resources.GetObject("label9.Image")));
            this.label9.Location = new System.Drawing.Point(22, 47);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(23, 19);
            this.label9.TabIndex = 5;
            this.label9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.MidnightBlue;
            this.label7.Location = new System.Drawing.Point(51, 29);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(540, 13);
            this.label7.TabIndex = 4;
            this.label7.Text = "You can use this form to furnish any information about crimes or law and order or" +
                " traffic issues";
            this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label6
            // 
            this.label6.Image = ((System.Drawing.Image)(resources.GetObject("label6.Image")));
            this.label6.Location = new System.Drawing.Point(23, 25);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(23, 19);
            this.label6.TabIndex = 3;
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label5
            // 
            this.label5.BackColor = System.Drawing.Color.Silver;
            this.label5.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.Red;
            this.label5.Location = new System.Drawing.Point(0, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(1090, 23);
            this.label5.TabIndex = 2;
            this.label5.Text = "Please Remember";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label4
            // 
            this.label4.BackColor = System.Drawing.Color.Green;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.PaleTurquoise;
            this.label4.Location = new System.Drawing.Point(18, 22);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(1093, 23);
            this.label4.TabIndex = 0;
            this.label4.Text = "INFORMATION REGISTRATION FORM";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel8
            // 
            this.panel8.BackColor = System.Drawing.Color.SeaShell;
            this.panel8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel8.Controls.Add(this.label42);
            this.panel8.Controls.Add(this.label45);
            this.panel8.Controls.Add(this.label43);
            this.panel8.Controls.Add(this.label44);
            this.panel8.Controls.Add(this.label41);
            this.panel8.Controls.Add(this.label40);
            this.panel8.Location = new System.Drawing.Point(3, 425);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(220, 146);
            this.panel8.TabIndex = 3;
            // 
            // label42
            // 
            this.label42.Image = ((System.Drawing.Image)(resources.GetObject("label42.Image")));
            this.label42.Location = new System.Drawing.Point(19, 99);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(28, 24);
            this.label42.TabIndex = 14;
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label45.Location = new System.Drawing.Point(47, 102);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(168, 16);
            this.label45.TabIndex = 13;
            this.label45.Text = "Driving License Details";
            // 
            // label43
            // 
            this.label43.Image = ((System.Drawing.Image)(resources.GetObject("label43.Image")));
            this.label43.Location = new System.Drawing.Point(19, 65);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(28, 24);
            this.label43.TabIndex = 12;
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label44.Location = new System.Drawing.Point(48, 68);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(121, 16);
            this.label44.TabIndex = 11;
            this.label44.Text = "Vechical Search";
            // 
            // label41
            // 
            this.label41.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label41.ForeColor = System.Drawing.Color.Navy;
            this.label41.Location = new System.Drawing.Point(64, 16);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(137, 18);
            this.label41.TabIndex = 10;
            this.label41.Text = "Other Services";
            // 
            // label40
            // 
            this.label40.Image = ((System.Drawing.Image)(resources.GetObject("label40.Image")));
            this.label40.Location = new System.Drawing.Point(16, 12);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(41, 39);
            this.label40.TabIndex = 10;
            this.label40.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label30
            // 
            this.label30.Image = ((System.Drawing.Image)(resources.GetObject("label30.Image")));
            this.label30.Location = new System.Drawing.Point(15, 14);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(41, 39);
            this.label30.TabIndex = 0;
            this.label30.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label31
            // 
            this.label31.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label31.ForeColor = System.Drawing.Color.Navy;
            this.label31.Location = new System.Drawing.Point(63, 14);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(137, 18);
            this.label31.TabIndex = 1;
            this.label31.Text = "Online Services";
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label32.Location = new System.Drawing.Point(71, 76);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(84, 16);
            this.label32.TabIndex = 2;
            this.label32.Text = "Information";
            this.label32.Click += new System.EventHandler(this.label32_Click);
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label33.Location = new System.Drawing.Point(70, 112);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(77, 16);
            this.label33.TabIndex = 3;
            this.label33.Text = "Complaint";
            this.label33.Click += new System.EventHandler(this.label33_Click);
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label35.Location = new System.Drawing.Point(70, 147);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(91, 16);
            this.label35.TabIndex = 5;
            this.label35.Text = "Case Status";
            this.label35.Click += new System.EventHandler(this.label35_Click);
            // 
            // label36
            // 
            this.label36.Image = ((System.Drawing.Image)(resources.GetObject("label36.Image")));
            this.label36.Location = new System.Drawing.Point(40, 73);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(28, 24);
            this.label36.TabIndex = 6;
            // 
            // label37
            // 
            this.label37.Image = ((System.Drawing.Image)(resources.GetObject("label37.Image")));
            this.label37.Location = new System.Drawing.Point(38, 107);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(28, 24);
            this.label37.TabIndex = 7;
            // 
            // label38
            // 
            this.label38.Image = ((System.Drawing.Image)(resources.GetObject("label38.Image")));
            this.label38.Location = new System.Drawing.Point(38, 143);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(28, 24);
            this.label38.TabIndex = 9;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.SeaShell;
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.label38);
            this.panel1.Controls.Add(this.label37);
            this.panel1.Controls.Add(this.label36);
            this.panel1.Controls.Add(this.label35);
            this.panel1.Controls.Add(this.label33);
            this.panel1.Controls.Add(this.label32);
            this.panel1.Controls.Add(this.label31);
            this.panel1.Controls.Add(this.label30);
            this.panel1.Location = new System.Drawing.Point(3, 177);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(222, 216);
            this.panel1.TabIndex = 1;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.WhiteSmoke;
            this.ClientSize = new System.Drawing.Size(1368, 747);
            this.ControlBox = false;
            this.Controls.Add(this.panel8);
            this.Controls.Add(this.panel_Information);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.panel_banner);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "COMPLAINT";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.Form1_Load);
            this.panel_banner.ResumeLayout(false);
            this.panel_banner.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panel_Complaint.ResumeLayout(false);
            this.panel12.ResumeLayout(false);
            this.panel12.PerformLayout();
            this.panel11.ResumeLayout(false);
            this.panel11.PerformLayout();
            this.panel10.ResumeLayout(false);
            this.panel10.PerformLayout();
            this.panel9.ResumeLayout(false);
            this.panel9.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel_fir.ResumeLayout(false);
            this.panel_fir.PerformLayout();
            this.panel_Information.ResumeLayout(false);
            this.panel7.ResumeLayout(false);
            this.panel7.PerformLayout();
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel8.ResumeLayout(false);
            this.panel8.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel_banner;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Panel panel_Information;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.RadioButton rdbtn_Police_Station;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.ComboBox cmbx_dstrct;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.ComboBox cmbx_Police_Station;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.TextBox txtbx_Frstnme;
        private System.Windows.Forms.TextBox txtbx_email_id;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.TextBox txtbx_Lstnme;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.TextBox txtbx_lndlne_code;
        private System.Windows.Forms.TextBox txtbx_lndlne_number;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.TextBox txtbx_Mobile_number;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.ComboBox cmbx_subject_information;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.RichTextBox rchtxtbx_decription;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.TextBox txtbx_chrcts;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.Panel panel_Complaint;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label47;
        private System.Windows.Forms.Label label48;
        private System.Windows.Forms.Label label49;
        private System.Windows.Forms.Label label50;
        private System.Windows.Forms.Label label51;
        private System.Windows.Forms.Label label52;
        private System.Windows.Forms.Label label53;
        private System.Windows.Forms.Label label54;
        private System.Windows.Forms.Label label55;
        private System.Windows.Forms.Label label46;
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.Label label56;
        private System.Windows.Forms.Panel panel10;
        private System.Windows.Forms.ComboBox cmbx_police_station_1;
        private System.Windows.Forms.Label label57;
        private System.Windows.Forms.ComboBox cmbx_district1;
        private System.Windows.Forms.Label label58;
        private System.Windows.Forms.RadioButton rdbtn_police_station_1;
        private System.Windows.Forms.Label label59;
        private System.Windows.Forms.Label label60;
        private System.Windows.Forms.Panel panel12;
        private System.Windows.Forms.Panel panel11;
        private System.Windows.Forms.Label label61;
        private System.Windows.Forms.Label label62;
        private System.Windows.Forms.TextBox txtbx_nme;
        private System.Windows.Forms.DateTimePicker dte_dob;
        private System.Windows.Forms.Label label63;
        private System.Windows.Forms.ComboBox cmbx_gndr;
        private System.Windows.Forms.Label label64;
        private System.Windows.Forms.TextBox txtbx_addrss_fr_cmmtion;
        private System.Windows.Forms.Label label65;
        private System.Windows.Forms.TextBox txtbx_age;
        private System.Windows.Forms.Label label66;
        private System.Windows.Forms.TextBox txtbx_addrss_fr_cmmtion1;
        private System.Windows.Forms.TextBox txtbx_district;
        private System.Windows.Forms.Label label67;
        private System.Windows.Forms.TextBox txtbx_city;
        private System.Windows.Forms.TextBox txtbx_pincode;
        private System.Windows.Forms.Label label69;
        private System.Windows.Forms.TextBox txtbx_state;
        private System.Windows.Forms.Label label68;
        private System.Windows.Forms.Label label70;
        private System.Windows.Forms.TextBox txtbx_mblenmbr;
        private System.Windows.Forms.Label label71;
        private System.Windows.Forms.ComboBox cmbx_idnty_proof_1;
        private System.Windows.Forms.Label label72;
        private System.Windows.Forms.TextBox txtbx_id_proof_2;
        private System.Windows.Forms.Label label73;
        private System.Windows.Forms.ComboBox cmbx_id_proof_2;
        private System.Windows.Forms.Label label74;
        private System.Windows.Forms.TextBox txtbx_id_proof_1;
        private System.Windows.Forms.TextBox txtbx_emailid;
        private System.Windows.Forms.Label label75;
        private System.Windows.Forms.Label label76;
        private System.Windows.Forms.ComboBox cmbx_subject;
        private System.Windows.Forms.Label label77;
        private System.Windows.Forms.Label label78;
        private System.Windows.Forms.DateTimePicker dte_time;
        private System.Windows.Forms.DateTimePicker dte_date;
        private System.Windows.Forms.Label label79;
        private System.Windows.Forms.RichTextBox rchtxtbx_plce_of_occrnce;
        private System.Windows.Forms.RichTextBox rchtxtbx_descrptn_of_cmplnt;
        private System.Windows.Forms.TextBox txtbx_chrctr_dec;
        private System.Windows.Forms.TextBox txtbx_chrctr_plc;
        private System.Windows.Forms.Label label80;
        private System.Windows.Forms.Button btn_Submit;
        private System.Windows.Forms.Button btn_complaint_submit;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel_fir;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.TextBox txtbx_fir_nmbr;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.Label label81;
        private System.Windows.Forms.Button btn_search;
        private System.Windows.Forms.Label label82;
        private System.Windows.Forms.Label lbl_status;
        private System.Windows.Forms.Label label83;

    }
}

