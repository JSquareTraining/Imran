﻿namespace Crime_Patrol_Record_Management_System_User
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form2));
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.panel_banner = new System.Windows.Forms.Panel();
            this.txtcriminalno = new System.Windows.Forms.TextBox();
            this.Label26 = new System.Windows.Forms.Label();
            this.txtwitnesoccup = new System.Windows.Forms.TextBox();
            this.txtwitnesadd = new System.Windows.Forms.TextBox();
            this.txtaccusaction = new System.Windows.Forms.TextBox();
            this.txtaccuscurntstation = new System.Windows.Forms.TextBox();
            this.Label18 = new System.Windows.Forms.Label();
            this.Label17 = new System.Windows.Forms.Label();
            this.Label16 = new System.Windows.Forms.Label();
            this.Label15 = new System.Windows.Forms.Label();
            this.txtwitnesname = new System.Windows.Forms.TextBox();
            this.Label19 = new System.Windows.Forms.Label();
            this.txtcomplaintno = new System.Windows.Forms.TextBox();
            this.Label21 = new System.Windows.Forms.Label();
            this.txtaccusoccup = new System.Windows.Forms.TextBox();
            this.txtaccusage = new System.Windows.Forms.TextBox();
            this.txtaccusadd = new System.Windows.Forms.TextBox();
            this.txtaccussex = new System.Windows.Forms.TextBox();
            this.txtaccusname = new System.Windows.Forms.TextBox();
            this.txtinfooccup = new System.Windows.Forms.TextBox();
            this.txtinfoadd = new System.Windows.Forms.TextBox();
            this.txtinfoname = new System.Windows.Forms.TextBox();
            this.txtdistrict = new System.Windows.Forms.TextBox();
            this.Label14 = new System.Windows.Forms.Label();
            this.txtfirno = new System.Windows.Forms.TextBox();
            this.Label13 = new System.Windows.Forms.Label();
            this.Label12 = new System.Windows.Forms.Label();
            this.Label11 = new System.Windows.Forms.Label();
            this.Label10 = new System.Windows.Forms.Label();
            this.Label8 = new System.Windows.Forms.Label();
            this.Label7 = new System.Windows.Forms.Label();
            this.Label6 = new System.Windows.Forms.Label();
            this.Label5 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.txtpolicestationname = new System.Windows.Forms.TextBox();
            this.label20 = new System.Windows.Forms.Label();
            this.txtchargshetno = new System.Windows.Forms.TextBox();
            this.label22 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panel_banner.SuspendLayout();
            this.SuspendLayout();
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Black;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.PaleTurquoise;
            this.label3.Location = new System.Drawing.Point(445, 96);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(370, 16);
            this.label3.TabIndex = 3;
            this.label3.Text = "Empowering citizens through Information Technology";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Black;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.PaleTurquoise;
            this.label2.Location = new System.Drawing.Point(408, 65);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(440, 24);
            this.label2.TabIndex = 2;
            this.label2.Text = "Crime and Criminal Tracking Network Systems";
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.Black;
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(170, 8);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(138, 126);
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Black;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.PaleTurquoise;
            this.label1.Location = new System.Drawing.Point(334, 30);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(601, 33);
            this.label1.TabIndex = 1;
            this.label1.Text = "TAMILNADU POLICE - CITIZEN SEVICES";
            // 
            // panel_banner
            // 
            this.panel_banner.BackColor = System.Drawing.Color.Black;
            this.panel_banner.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel_banner.Controls.Add(this.label3);
            this.panel_banner.Controls.Add(this.label2);
            this.panel_banner.Controls.Add(this.label1);
            this.panel_banner.Controls.Add(this.pictureBox1);
            this.panel_banner.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel_banner.Location = new System.Drawing.Point(0, 0);
            this.panel_banner.Name = "panel_banner";
            this.panel_banner.Size = new System.Drawing.Size(1205, 122);
            this.panel_banner.TabIndex = 1;
            // 
            // txtcriminalno
            // 
            this.txtcriminalno.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtcriminalno.Location = new System.Drawing.Point(844, 309);
            this.txtcriminalno.Name = "txtcriminalno";
            this.txtcriminalno.ReadOnly = true;
            this.txtcriminalno.Size = new System.Drawing.Size(158, 22);
            this.txtcriminalno.TabIndex = 179;
            // 
            // Label26
            // 
            this.Label26.AutoSize = true;
            this.Label26.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label26.Location = new System.Drawing.Point(715, 309);
            this.Label26.Name = "Label26";
            this.Label26.Size = new System.Drawing.Size(108, 16);
            this.Label26.TabIndex = 178;
            this.Label26.Text = "CRIMINAL NO.";
            // 
            // txtwitnesoccup
            // 
            this.txtwitnesoccup.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtwitnesoccup.Location = new System.Drawing.Point(844, 269);
            this.txtwitnesoccup.Name = "txtwitnesoccup";
            this.txtwitnesoccup.ReadOnly = true;
            this.txtwitnesoccup.Size = new System.Drawing.Size(158, 22);
            this.txtwitnesoccup.TabIndex = 175;
            // 
            // txtwitnesadd
            // 
            this.txtwitnesadd.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtwitnesadd.Location = new System.Drawing.Point(844, 234);
            this.txtwitnesadd.Name = "txtwitnesadd";
            this.txtwitnesadd.ReadOnly = true;
            this.txtwitnesadd.Size = new System.Drawing.Size(158, 22);
            this.txtwitnesadd.TabIndex = 174;
            // 
            // txtaccusaction
            // 
            this.txtaccusaction.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtaccusaction.Location = new System.Drawing.Point(844, 164);
            this.txtaccusaction.Name = "txtaccusaction";
            this.txtaccusaction.ReadOnly = true;
            this.txtaccusaction.Size = new System.Drawing.Size(158, 22);
            this.txtaccusaction.TabIndex = 173;
            // 
            // txtaccuscurntstation
            // 
            this.txtaccuscurntstation.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtaccuscurntstation.Location = new System.Drawing.Point(844, 133);
            this.txtaccuscurntstation.Name = "txtaccuscurntstation";
            this.txtaccuscurntstation.ReadOnly = true;
            this.txtaccuscurntstation.Size = new System.Drawing.Size(158, 22);
            this.txtaccuscurntstation.TabIndex = 172;
            // 
            // Label18
            // 
            this.Label18.AutoSize = true;
            this.Label18.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label18.Location = new System.Drawing.Point(659, 238);
            this.Label18.Name = "Label18";
            this.Label18.Size = new System.Drawing.Size(164, 16);
            this.Label18.TabIndex = 169;
            this.Label18.Text = "WITTNESS ADDRESS";
            // 
            // Label17
            // 
            this.Label17.AutoSize = true;
            this.Label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label17.Location = new System.Drawing.Point(689, 198);
            this.Label17.Name = "Label17";
            this.Label17.Size = new System.Drawing.Size(134, 16);
            this.Label17.TabIndex = 168;
            this.Label17.Text = "WITTNESS NAME";
            // 
            // Label16
            // 
            this.Label16.AutoSize = true;
            this.Label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label16.Location = new System.Drawing.Point(704, 165);
            this.Label16.Name = "Label16";
            this.Label16.Size = new System.Drawing.Size(119, 16);
            this.Label16.TabIndex = 167;
            this.Label16.Text = "ACCUS ACTION";
            // 
            // Label15
            // 
            this.Label15.AutoSize = true;
            this.Label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label15.Location = new System.Drawing.Point(606, 133);
            this.Label15.Name = "Label15";
            this.Label15.Size = new System.Drawing.Size(217, 16);
            this.Label15.TabIndex = 166;
            this.Label15.Text = "ACCCUS CURRENT STATION";
            // 
            // txtwitnesname
            // 
            this.txtwitnesname.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtwitnesname.Location = new System.Drawing.Point(844, 198);
            this.txtwitnesname.Name = "txtwitnesname";
            this.txtwitnesname.ReadOnly = true;
            this.txtwitnesname.Size = new System.Drawing.Size(158, 22);
            this.txtwitnesname.TabIndex = 171;
            // 
            // Label19
            // 
            this.Label19.AutoSize = true;
            this.Label19.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label19.Location = new System.Drawing.Point(634, 273);
            this.Label19.Name = "Label19";
            this.Label19.Size = new System.Drawing.Size(189, 16);
            this.Label19.TabIndex = 170;
            this.Label19.Text = "WITTNESS OCCUPATION";
            // 
            // txtcomplaintno
            // 
            this.txtcomplaintno.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtcomplaintno.Location = new System.Drawing.Point(387, 210);
            this.txtcomplaintno.Name = "txtcomplaintno";
            this.txtcomplaintno.ReadOnly = true;
            this.txtcomplaintno.Size = new System.Drawing.Size(158, 22);
            this.txtcomplaintno.TabIndex = 165;
            // 
            // Label21
            // 
            this.Label21.AutoSize = true;
            this.Label21.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label21.Location = new System.Drawing.Point(243, 211);
            this.Label21.Name = "Label21";
            this.Label21.Size = new System.Drawing.Size(120, 16);
            this.Label21.TabIndex = 164;
            this.Label21.Text = "COMPLAINT NO";
            // 
            // txtaccusoccup
            // 
            this.txtaccusoccup.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtaccusoccup.Location = new System.Drawing.Point(387, 589);
            this.txtaccusoccup.Name = "txtaccusoccup";
            this.txtaccusoccup.ReadOnly = true;
            this.txtaccusoccup.Size = new System.Drawing.Size(158, 22);
            this.txtaccusoccup.TabIndex = 163;
            // 
            // txtaccusage
            // 
            this.txtaccusage.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtaccusage.Location = new System.Drawing.Point(387, 549);
            this.txtaccusage.Name = "txtaccusage";
            this.txtaccusage.ReadOnly = true;
            this.txtaccusage.Size = new System.Drawing.Size(158, 22);
            this.txtaccusage.TabIndex = 162;
            // 
            // txtaccusadd
            // 
            this.txtaccusadd.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtaccusadd.Location = new System.Drawing.Point(387, 474);
            this.txtaccusadd.Name = "txtaccusadd";
            this.txtaccusadd.ReadOnly = true;
            this.txtaccusadd.Size = new System.Drawing.Size(158, 22);
            this.txtaccusadd.TabIndex = 161;
            // 
            // txtaccussex
            // 
            this.txtaccussex.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtaccussex.Location = new System.Drawing.Point(387, 511);
            this.txtaccussex.Name = "txtaccussex";
            this.txtaccussex.ReadOnly = true;
            this.txtaccussex.Size = new System.Drawing.Size(158, 22);
            this.txtaccussex.TabIndex = 160;
            // 
            // txtaccusname
            // 
            this.txtaccusname.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtaccusname.Location = new System.Drawing.Point(386, 435);
            this.txtaccusname.Name = "txtaccusname";
            this.txtaccusname.ReadOnly = true;
            this.txtaccusname.Size = new System.Drawing.Size(158, 22);
            this.txtaccusname.TabIndex = 159;
            // 
            // txtinfooccup
            // 
            this.txtinfooccup.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtinfooccup.Location = new System.Drawing.Point(387, 397);
            this.txtinfooccup.Name = "txtinfooccup";
            this.txtinfooccup.ReadOnly = true;
            this.txtinfooccup.Size = new System.Drawing.Size(158, 22);
            this.txtinfooccup.TabIndex = 158;
            // 
            // txtinfoadd
            // 
            this.txtinfoadd.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtinfoadd.Location = new System.Drawing.Point(387, 360);
            this.txtinfoadd.Name = "txtinfoadd";
            this.txtinfoadd.ReadOnly = true;
            this.txtinfoadd.Size = new System.Drawing.Size(158, 22);
            this.txtinfoadd.TabIndex = 157;
            // 
            // txtinfoname
            // 
            this.txtinfoname.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtinfoname.Location = new System.Drawing.Point(386, 320);
            this.txtinfoname.Name = "txtinfoname";
            this.txtinfoname.ReadOnly = true;
            this.txtinfoname.Size = new System.Drawing.Size(158, 22);
            this.txtinfoname.TabIndex = 156;
            // 
            // txtdistrict
            // 
            this.txtdistrict.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtdistrict.Location = new System.Drawing.Point(386, 284);
            this.txtdistrict.Name = "txtdistrict";
            this.txtdistrict.ReadOnly = true;
            this.txtdistrict.Size = new System.Drawing.Size(158, 22);
            this.txtdistrict.TabIndex = 155;
            // 
            // Label14
            // 
            this.Label14.AutoSize = true;
            this.Label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label14.Location = new System.Drawing.Point(217, 590);
            this.Label14.Name = "Label14";
            this.Label14.Size = new System.Drawing.Size(161, 16);
            this.Label14.TabIndex = 153;
            this.Label14.Text = "ACCUS OCCUPATION";
            // 
            // txtfirno
            // 
            this.txtfirno.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtfirno.Location = new System.Drawing.Point(387, 247);
            this.txtfirno.Name = "txtfirno";
            this.txtfirno.ReadOnly = true;
            this.txtfirno.Size = new System.Drawing.Size(157, 22);
            this.txtfirno.TabIndex = 154;
            // 
            // Label13
            // 
            this.Label13.AutoSize = true;
            this.Label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label13.Location = new System.Drawing.Point(263, 554);
            this.Label13.Name = "Label13";
            this.Label13.Size = new System.Drawing.Size(94, 16);
            this.Label13.TabIndex = 152;
            this.Label13.Text = "ACCUS AGE";
            // 
            // Label12
            // 
            this.Label12.AutoSize = true;
            this.Label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label12.Location = new System.Drawing.Point(266, 516);
            this.Label12.Name = "Label12";
            this.Label12.Size = new System.Drawing.Size(92, 16);
            this.Label12.TabIndex = 151;
            this.Label12.Text = "ACCUS SEX";
            // 
            // Label11
            // 
            this.Label11.AutoSize = true;
            this.Label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label11.Location = new System.Drawing.Point(233, 480);
            this.Label11.Name = "Label11";
            this.Label11.Size = new System.Drawing.Size(136, 16);
            this.Label11.TabIndex = 150;
            this.Label11.Text = "ACCUS ADDRESS";
            // 
            // Label10
            // 
            this.Label10.AutoSize = true;
            this.Label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label10.Location = new System.Drawing.Point(254, 440);
            this.Label10.Name = "Label10";
            this.Label10.Size = new System.Drawing.Size(106, 16);
            this.Label10.TabIndex = 149;
            this.Label10.Text = "ACCUS NAME";
            // 
            // Label8
            // 
            this.Label8.AutoSize = true;
            this.Label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label8.Location = new System.Drawing.Point(228, 402);
            this.Label8.Name = "Label8";
            this.Label8.Size = new System.Drawing.Size(145, 16);
            this.Label8.TabIndex = 148;
            this.Label8.Text = "INFO OCCUPATION";
            // 
            // Label7
            // 
            this.Label7.AutoSize = true;
            this.Label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label7.Location = new System.Drawing.Point(273, 361);
            this.Label7.Name = "Label7";
            this.Label7.Size = new System.Drawing.Size(79, 16);
            this.Label7.TabIndex = 147;
            this.Label7.Text = "INFO ADD";
            // 
            // Label6
            // 
            this.Label6.AutoSize = true;
            this.Label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label6.Location = new System.Drawing.Point(267, 324);
            this.Label6.Name = "Label6";
            this.Label6.Size = new System.Drawing.Size(90, 16);
            this.Label6.TabIndex = 146;
            this.Label6.Text = "INFO NAME";
            // 
            // Label5
            // 
            this.Label5.AutoSize = true;
            this.Label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label5.Location = new System.Drawing.Point(274, 284);
            this.Label5.Name = "Label5";
            this.Label5.Size = new System.Drawing.Size(78, 16);
            this.Label5.TabIndex = 145;
            this.Label5.Text = "DISTRICT";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(288, 248);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(58, 16);
            this.label9.TabIndex = 144;
            this.label9.Text = "FIR NO";
            // 
            // txtpolicestationname
            // 
            this.txtpolicestationname.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtpolicestationname.Location = new System.Drawing.Point(387, 170);
            this.txtpolicestationname.Name = "txtpolicestationname";
            this.txtpolicestationname.ReadOnly = true;
            this.txtpolicestationname.Size = new System.Drawing.Size(158, 22);
            this.txtpolicestationname.TabIndex = 143;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.Location = new System.Drawing.Point(202, 173);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(178, 16);
            this.label20.TabIndex = 142;
            this.label20.Text = "POLICE STATION NAME";
            // 
            // txtchargshetno
            // 
            this.txtchargshetno.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtchargshetno.Location = new System.Drawing.Point(386, 128);
            this.txtchargshetno.Name = "txtchargshetno";
            this.txtchargshetno.ReadOnly = true;
            this.txtchargshetno.Size = new System.Drawing.Size(158, 22);
            this.txtchargshetno.TabIndex = 141;
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.Location = new System.Drawing.Point(217, 129);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(152, 16);
            this.label22.TabIndex = 140;
            this.label22.Text = "CHARGE SHEET NO";
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.BackColor = System.Drawing.Color.DarkKhaki;
            this.ClientSize = new System.Drawing.Size(1205, 674);
            this.Controls.Add(this.txtcriminalno);
            this.Controls.Add(this.Label26);
            this.Controls.Add(this.txtwitnesoccup);
            this.Controls.Add(this.txtwitnesadd);
            this.Controls.Add(this.txtaccusaction);
            this.Controls.Add(this.txtaccuscurntstation);
            this.Controls.Add(this.Label18);
            this.Controls.Add(this.Label17);
            this.Controls.Add(this.Label16);
            this.Controls.Add(this.Label15);
            this.Controls.Add(this.txtwitnesname);
            this.Controls.Add(this.Label19);
            this.Controls.Add(this.txtcomplaintno);
            this.Controls.Add(this.Label21);
            this.Controls.Add(this.txtaccusoccup);
            this.Controls.Add(this.txtaccusage);
            this.Controls.Add(this.txtaccusadd);
            this.Controls.Add(this.txtaccussex);
            this.Controls.Add(this.txtaccusname);
            this.Controls.Add(this.txtinfooccup);
            this.Controls.Add(this.txtinfoadd);
            this.Controls.Add(this.txtinfoname);
            this.Controls.Add(this.txtdistrict);
            this.Controls.Add(this.Label14);
            this.Controls.Add(this.txtfirno);
            this.Controls.Add(this.Label13);
            this.Controls.Add(this.Label12);
            this.Controls.Add(this.Label11);
            this.Controls.Add(this.Label10);
            this.Controls.Add(this.Label8);
            this.Controls.Add(this.Label7);
            this.Controls.Add(this.Label6);
            this.Controls.Add(this.Label5);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.txtpolicestationname);
            this.Controls.Add(this.label20);
            this.Controls.Add(this.txtchargshetno);
            this.Controls.Add(this.label22);
            this.Controls.Add(this.panel_banner);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Form2";
            this.Text = "FIR";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panel_banner.ResumeLayout(false);
            this.panel_banner.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel_banner;
        internal System.Windows.Forms.Label Label26;
        internal System.Windows.Forms.Label Label18;
        internal System.Windows.Forms.Label Label17;
        internal System.Windows.Forms.Label Label16;
        internal System.Windows.Forms.Label Label15;
        internal System.Windows.Forms.Label Label19;
        internal System.Windows.Forms.Label Label21;
        public System.Windows.Forms.TextBox txtinfoadd;
        public System.Windows.Forms.TextBox txtinfoname;
        internal System.Windows.Forms.Label Label14;
        internal System.Windows.Forms.Label Label13;
        internal System.Windows.Forms.Label Label12;
        internal System.Windows.Forms.Label Label11;
        internal System.Windows.Forms.Label Label10;
        internal System.Windows.Forms.Label Label8;
        internal System.Windows.Forms.Label Label7;
        internal System.Windows.Forms.Label Label6;
        internal System.Windows.Forms.Label Label5;
        internal System.Windows.Forms.Label label9;
        internal System.Windows.Forms.Label label20;
        internal System.Windows.Forms.Label label22;
        public System.Windows.Forms.TextBox txtcriminalno;
        public System.Windows.Forms.TextBox txtwitnesoccup;
        public System.Windows.Forms.TextBox txtwitnesadd;
        public System.Windows.Forms.TextBox txtaccusaction;
        public System.Windows.Forms.TextBox txtaccuscurntstation;
        public System.Windows.Forms.TextBox txtwitnesname;
        public System.Windows.Forms.TextBox txtcomplaintno;
        public System.Windows.Forms.TextBox txtaccusoccup;
        public System.Windows.Forms.TextBox txtaccusage;
        public System.Windows.Forms.TextBox txtaccusadd;
        public System.Windows.Forms.TextBox txtaccussex;
        public System.Windows.Forms.TextBox txtaccusname;
        public System.Windows.Forms.TextBox txtinfooccup;
        public System.Windows.Forms.TextBox txtdistrict;
        public System.Windows.Forms.TextBox txtfirno;
        public System.Windows.Forms.TextBox txtpolicestationname;
        public System.Windows.Forms.TextBox txtchargshetno;
    }
}