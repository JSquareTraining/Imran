﻿using System;
using System.Drawing;
using System.Windows.Forms;
using System.IO;

namespace Crime_Patrol_Record_Management_System_User
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            panel_Complaint.Hide();
            panel_Information.Show();
            panel_fir.Hide();

            panel_Complaint.Parent = this;
            panel_Complaint.Location = new Point(229, 129);

            panel_fir.Parent = this;
            panel_fir.Location = new Point(229, 129);

            cmbx_dstrct.Enabled = false;
            cmbx_Police_Station.Enabled = false;

            cmbx_district1.Enabled = false;
            cmbx_police_station_1.Enabled = false;
        }

        private void label33_Click(object sender, EventArgs e)
        {
            panel_Complaint.Show();
            panel_Information.Hide();
            panel_fir.Hide();
        }

        private void label32_Click(object sender, EventArgs e)
        {
            panel_Complaint.Hide();
            panel_Information.Show();
            panel_fir.Hide();
        }

        private void btn_Submit_Click(object sender, EventArgs e)
        {
            if (txtbx_Frstnme.Text == "" || txtbx_Lstnme.Text == "" || txtbx_lndlne_code.Text == "" || txtbx_lndlne_number.Text == "" || txtbx_email_id.Text == "" || txtbx_Mobile_number.Text == "" || cmbx_subject_information.Text == "" || rchtxtbx_decription.Text == "")
            {
                MessageBox.Show("Please enter the blank field", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                if (Directory.Exists(@"C:\Patrol Management\User\Information Complaints\" + cmbx_Police_Station.Text) == true)
                {
                    TextWriter tw;
                    tw = File.CreateText(@"C:\Patrol Management\User\Information Complaints\"+cmbx_Police_Station.Text+ @"\" +cmbx_subject_information.Text+txtbx_Frstnme.Text+txtbx_Lstnme.Text+ ".txt");
                    tw.WriteLine(txtbx_Frstnme.Text+"|"+txtbx_Lstnme.Text+"|"+txtbx_lndlne_code.Text+"-"+txtbx_lndlne_number.Text+"|"+txtbx_email_id.Text+"|"+txtbx_Mobile_number.Text+"|"+cmbx_subject_information.Text+"|"+rchtxtbx_decription.Text+"|");
                    tw.Flush();
                    tw.Dispose();
                    tw.Close();
                    MessageBox.Show("Complaint Submitted Successfully", "TNPD", MessageBoxButtons.OK, MessageBoxIcon.Information);

                    txtbx_Frstnme.Text = "";
                    txtbx_Lstnme.Text = "";
                    txtbx_lndlne_code.Text = "";
                    txtbx_lndlne_number.Text = "";
                    txtbx_email_id.Text = "";
                    txtbx_Mobile_number.Text = "";

                }
                else
                {
                    Directory.CreateDirectory(@"C:\Patrol Management\User\Information Complaints\"+cmbx_Police_Station.Text);
                    TextWriter tw;
                    tw = File.CreateText(@"C:\Patrol Management\User\Information Complaints\" + cmbx_Police_Station.Text +@"\"+cmbx_subject_information.Text+txtbx_Frstnme.Text+txtbx_Lstnme.Text+ ".txt");
                    tw.WriteLine(txtbx_Frstnme.Text+"|"+txtbx_Lstnme.Text+"|"+txtbx_lndlne_code.Text+"-"+txtbx_lndlne_number.Text+"|"+txtbx_email_id.Text+"|"+txtbx_Mobile_number.Text+"|"+cmbx_subject_information.Text+"|"+rchtxtbx_decription.Text+"|");
                    tw.Flush();
                    tw.Dispose();
                    tw.Close();
                    MessageBox.Show("Complaint Submitted Successfully", "TNPD", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
        }
        private void rdbtn_Police_Station_CheckedChanged(object sender, EventArgs e)
        {
            if (rdbtn_Police_Station.Checked == true)
            {
                cmbx_dstrct.Enabled = true;
                cmbx_Police_Station.Enabled = true;
            }
            else
            {
                cmbx_dstrct.Enabled = false;
                cmbx_Police_Station.Enabled = false;
            }
        }
        
        private void rchtxtbx_decription_TextChanged(object sender, EventArgs e)
        {
            int text_length = 2000;
            int text_count = rchtxtbx_decription.TextLength;
            
            text_length = text_length - text_count;
            
            txtbx_chrcts.Text = text_length.ToString();

            if (text_length < 50)
            {
                txtbx_chrcts.ForeColor = Color.Red;
            }
            else
            {
                txtbx_chrcts.ForeColor = Color.Green;
            }

        }

        private void rdbtn_police_station_1_CheckedChanged(object sender, EventArgs e)
        {
            if (rdbtn_police_station_1.Checked == true)
            {
                cmbx_district1.Enabled = true;
                cmbx_police_station_1.Enabled = true;
            }
            else
            {
                cmbx_district1.Enabled = false;
                cmbx_police_station_1.Enabled = false;
            }
        }

        private void btn_complaint_submit_Click(object sender, EventArgs e)
        {
            if (txtbx_nme.Text == "" || cmbx_gndr.Text == "" || txtbx_age.Text == "" || txtbx_mblenmbr.Text == "" || txtbx_addrss_fr_cmmtion.Text == "" || txtbx_city.Text == "" || txtbx_district.Text == "" || txtbx_state.Text == "" || txtbx_pincode.Text == "" || cmbx_idnty_proof_1.Text == "" || txtbx_id_proof_1.Text == "" || txtbx_emailid.Text == "" || cmbx_subject.Text == "" || rchtxtbx_plce_of_occrnce.Text == "" || rchtxtbx_descrptn_of_cmplnt.Text == "")
            {
                MessageBox.Show("Please enter the blank field", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                if (Directory.Exists(@"C:\Patrol Management\User\Complaints\") == false)
                {
                    Directory.CreateDirectory(@"C:\Patrol Management\User\Complaints\");
                    if (Directory.Exists(@"C:\Patrol Management\User\Information Complaints\" +   cmbx_police_station_1.Text) == false)
                    {
                        Directory.CreateDirectory(@"C:\Patrol Management\User\Complaints\" + cmbx_police_station_1.Text);
                        TextWriter tw;
                        tw = File.CreateText(@"C:\Patrol Management\User\Complaints\" + cmbx_police_station_1.Text + @"\" + cmbx_subject.Text + txtbx_nme.Text + ".txt");
                        tw.WriteLine(txtbx_nme.Text + '|' + cmbx_gndr.Text + '|' + dte_dob.Value.ToShortDateString() + '|' + txtbx_age.Text + '|' + txtbx_mblenmbr.Text + '|' + txtbx_addrss_fr_cmmtion.Text + "," + txtbx_addrss_fr_cmmtion1.Text + '|' + txtbx_city.Text + '|' + txtbx_district.Text + '|' + txtbx_state.Text + '|' + txtbx_pincode.Text + '|' + cmbx_idnty_proof_1.Text + "," + txtbx_id_proof_1.Text + '|' + cmbx_id_proof_2.Text + '|' + txtbx_id_proof_2.Text + '|' + txtbx_emailid.Text + '|'+cmbx_subject.Text +'|'+dte_date.Value+'|'+dte_time.Value+'|'+rchtxtbx_plce_of_occrnce.Text+'|'+rchtxtbx_descrptn_of_cmplnt.Text+'|');
                        tw.Flush();
                        tw.Dispose();
                        tw.Close();
                        MessageBox.Show("Submitted Successfully", "TNPD", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    else
                    {
                        TextWriter tw;
                        tw = File.CreateText(@"C:\Patrol Management\User\Complaints\" + cmbx_police_station_1.Text + @"\" + cmbx_subject.Text + txtbx_nme.Text + ".txt");
                        tw.WriteLine(txtbx_nme.Text + '|' + cmbx_gndr.Text + '|' + dte_dob.Value.ToShortDateString() + '|' + txtbx_age.Text + '|' + txtbx_mblenmbr.Text + '|' + txtbx_addrss_fr_cmmtion.Text + "," + txtbx_addrss_fr_cmmtion1.Text + '|' + txtbx_city.Text + '|' + txtbx_district.Text + '|' + txtbx_state.Text + '|' + txtbx_pincode.Text + '|' + cmbx_idnty_proof_1.Text + "," + txtbx_id_proof_1.Text + '|' + cmbx_id_proof_2.Text + '|' + txtbx_id_proof_2.Text + '|' + txtbx_emailid.Text + '|' + cmbx_subject.Text + '|' + dte_date.Value + '|' + dte_time.Value + '|' + rchtxtbx_plce_of_occrnce.Text + '|' + rchtxtbx_descrptn_of_cmplnt.Text + '|');
                        tw.Flush();
                        tw.Dispose();
                        tw.Close();
                        MessageBox.Show("Submitted Successfully", "TNPD", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }

                }
                else
                {
                    if (Directory.Exists(@"C:\Patrol Management\User\Complaints\" + cmbx_police_station_1.Text) == false)
                    {
                        Directory.CreateDirectory(@"C:\Patrol Management\User\Complaints\" + cmbx_police_station_1.Text);
                        TextWriter tw;
                        tw = File.CreateText(@"C:\Patrol Management\User\Complaints\" + cmbx_police_station_1.Text + @"\" + cmbx_subject.Text + txtbx_nme.Text + ".txt");
                        tw.WriteLine(txtbx_nme.Text + '|' + cmbx_gndr.Text + '|' + dte_dob.Value.ToShortDateString() + '|' + txtbx_age.Text + '|' + txtbx_mblenmbr.Text + '|' + txtbx_addrss_fr_cmmtion.Text + "," + txtbx_addrss_fr_cmmtion1.Text + '|' + txtbx_city.Text + '|' + txtbx_district.Text + '|' + txtbx_state.Text + '|' + txtbx_pincode.Text + '|' + cmbx_idnty_proof_1.Text + "," + txtbx_id_proof_1.Text + '|' + cmbx_id_proof_2.Text + '|' + txtbx_id_proof_2.Text + '|' + txtbx_emailid.Text + '|');
                        tw.Flush();
                        tw.Dispose();
                        tw.Close();
                        MessageBox.Show("Submitted Successfully", "TNPD", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    else
                    {
                        TextWriter tw;
                        tw = File.CreateText(@"C:\Patrol Management\User\Complaints\" + cmbx_police_station_1.Text + @"\" + cmbx_subject.Text + txtbx_nme.Text + ".txt");
                        tw.WriteLine(txtbx_nme.Text + '|' + cmbx_gndr.Text + '|' + dte_dob.Value.ToShortDateString() + '|' + txtbx_age.Text + '|' + txtbx_mblenmbr.Text + '|' + txtbx_addrss_fr_cmmtion.Text + "," + txtbx_addrss_fr_cmmtion1.Text + '|' + txtbx_city.Text + '|' + txtbx_district.Text + '|' + txtbx_state.Text + '|' + txtbx_pincode.Text + '|' + cmbx_idnty_proof_1.Text + "," + txtbx_id_proof_1.Text + '|' + cmbx_id_proof_2.Text + '|' + txtbx_id_proof_2.Text + '|' + txtbx_emailid.Text + '|');
                        tw.Flush();
                        tw.Dispose();
                        tw.Close();
                        MessageBox.Show("Submitted Successfully", "TNPD", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }

            }
        }

        private void txtbx_chrctr_plc_TextChanged(object sender, EventArgs e)
        {
           
        }

        private void txtbx_chrctr_dec_TextChanged(object sender, EventArgs e)
        {
           
        }

        private void rchtxtbx_plce_of_occrnce_TextChanged(object sender, EventArgs e)
        {
            int text_length = 2000;
            int text_count = rchtxtbx_plce_of_occrnce.TextLength;

            text_length = text_length - text_count;

            txtbx_chrctr_plc.Text = text_length.ToString();

            if (text_length < 50)
            {
                txtbx_chrctr_plc.ForeColor = Color.Red;
            }
            else
            {
                txtbx_chrctr_plc.ForeColor = Color.Green;
            }
        }

        private void rchtxtbx_descrptn_of_cmplnt_TextChanged(object sender, EventArgs e)
        {
            int text_length = 2000;
            int text_count = rchtxtbx_descrptn_of_cmplnt.TextLength;

            text_length = text_length - text_count;

            txtbx_chrctr_dec.Text = text_length.ToString();

            if (text_length < 50)
            {
                txtbx_chrctr_dec.ForeColor = Color.Red;
            }
            else
            {
                txtbx_chrctr_dec.ForeColor = Color.Green;
            }
        }

        private void label35_Click(object sender, EventArgs e)
        {
            panel_Complaint.Hide();
            panel_Information.Hide();
            panel_fir.Show();
        }

        private void btn_search_Click(object sender, EventArgs e)
        {
            if (File.Exists(@"C:\Patrol Management\FIR\" + txtbx_fir_nmbr.Text + ".txt") == true)
            {
                TextReader tr;
                tr = File.OpenText(@"C:\Patrol Management\FIR\" + txtbx_fir_nmbr.Text + ".txt");
                string data = tr.ReadToEnd();
                string[] all_data = data.Split(',');
                lbl_status.Text = all_data[19];
                tr.Dispose();
                tr.Close();
            }
            else
            {
                MessageBox.Show("Data Not Found", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void label83_Click(object sender, EventArgs e)
        {
            if (txtbx_fir_nmbr.Text == "")
            {
                MessageBox.Show("Data Not Found", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                if (File.Exists(@"C:\Patrol Management\FIR\" + txtbx_fir_nmbr.Text + ".txt") == true)
                {
                    TextReader tr;
                    tr = File.OpenText(@"C:\Patrol Management\FIR\" + txtbx_fir_nmbr.Text + ".txt");
                    string data = tr.ReadToEnd();
                    string[] all_data = data.Split(',');
                    lbl_status.Text = all_data[19];
                    Form2 frm2 = new Form2();
                    frm2.txtchargshetno.Text = all_data[0];
                    frm2.txtpolicestationname.Text = all_data[1];
                    frm2.txtcomplaintno.Text = all_data[2];
                    frm2.txtfirno.Text = all_data[3];
                    frm2.txtdistrict.Text = all_data[4];
                    frm2.txtinfoname.Text = all_data[5];
                    frm2.txtinfooccup.Text = all_data[6];
                    frm2.txtaccusname.Text = all_data[7];
                    frm2.txtaccusadd.Text = all_data[8];
                    frm2.txtaccussex.Text = all_data[9];
                    frm2.txtaccusage.Text = all_data[10];
                    frm2.txtaccuscurntstation.Text = all_data[11];
                    frm2.txtaccusaction.Text = all_data[12];
                    frm2.txtwitnesname.Text = all_data[13];
                    frm2.txtwitnesadd.Text = all_data[14];
                    frm2.txtwitnesoccup.Text = all_data[15];
                    frm2.txtcriminalno.Text = all_data[17];
                    tr.Dispose();
                    tr.Close();

                    this.Hide();
                    frm2.Show();
                }
                else
                {
                    MessageBox.Show("Data Not Found", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void txtbx_fir_nmbr_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsLetter(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void txtbx_mblenmbr_KeyPress(object sender, KeyPressEventArgs e)
        {

        }

        private void txtbx_id_proof_1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsLetter(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void txtbx_id_proof_2_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsLetter(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void panel11_Paint(object sender, PaintEventArgs e)
        {

        }

        private void txtbx_pincode_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsLetter(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void txtbx_Mobile_number_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtbx_Mobile_number_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsLetter(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void txtbx_lndlne_code_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsLetter(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void txtbx_lndlne_number_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsLetter(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        

        

       
    }
}
