﻿using System;
using System.Windows.Forms;
using System.IO;
namespace Crime_Patrol_Record_Mangement_System
{
    public partial class Form5 : Form
    {
        public Form5()
        {
            InitializeComponent();
        }

        private void Form5_Load(object sender, EventArgs e)
        {
           
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (txtaccusaction.Text == "" || txtaccusadd.Text == "" || txtaccusage.Text == "" || txtaccuscurntstation.Text == "" || txtaccusname.Text == "" || txtaccusoccup.Text == "" || txtaccussex.Text == "" || txtchargshetno.Text == "" || txtcomplaintno.Text == "" || txtcriminalno.Text == "" || txtdistrict.Text == "" || txtfirno.Text == "" || txtinfoadd.Text == "" || txtinfoname.Text == "" || txtinfooccup.Text == "" || txtpolicestationname.Text == "" || txtwitnesadd.Text == "" || txtwitnesname.Text == "" || txtwitnesoccup.Text == "")
            {
                MessageBox.Show("Please enter the blank field", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                TextWriter tw;
                tw = File.CreateText(@"C:\Patrol Management\FIR\" + txtfirno.Text + ".txt");
                tw.WriteLine(txtchargshetno.Text+",");
                tw.WriteLine(txtpolicestationname.Text+",");
                tw.WriteLine(txtcomplaintno.Text+",");
                tw.WriteLine(txtfirno.Text+",");
                tw.WriteLine(txtdistrict.Text+",");
                tw.WriteLine(txtinfoname.Text+",");
                tw.WriteLine(txtinfoadd.Text+",");
                tw.WriteLine(txtinfooccup.Text+",");
                tw.WriteLine(txtaccusname.Text+",");
                tw.WriteLine(txtaccusadd.Text+",");
                tw.WriteLine(txtaccussex.Text+",");
                tw.WriteLine(txtaccusage.Text+",");
                tw.WriteLine(txtaccuscurntstation.Text+",");
                tw.WriteLine(txtaccusaction.Text+",");
                tw.WriteLine(txtwitnesname.Text+",");
                tw.WriteLine(txtwitnesadd.Text+",");
                tw.WriteLine(txtwitnesoccup.Text+",");
                tw.WriteLine(DateTimePicker1.Value.ToShortDateString()+",");
                tw.WriteLine(txtcriminalno.Text+",");
                tw.WriteLine(cmbx_status.Text+",");
                tw.Flush();
                tw.Dispose();
                tw.Close();

                DialogResult dr = new DialogResult();
                dr = MessageBox.Show("Charge Sheet Created Successfully", "TNPD", MessageBoxButtons.OK, MessageBoxIcon.Information);
                if (dr == DialogResult.OK)
                {
                    Form4 frm4 = new Form4();
                    this.Hide();
                    frm4.Show();
                }
            }
        }

        private void txtchargshetno_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsLetter(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void txtcomplaintno_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsLetter(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void txtfirno_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsLetter(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void txtcriminalno_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsLetter(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void txtaccusage_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsLetter(e.KeyChar))
            {
                e.Handled = true;
            }
        }

      
    }
}
