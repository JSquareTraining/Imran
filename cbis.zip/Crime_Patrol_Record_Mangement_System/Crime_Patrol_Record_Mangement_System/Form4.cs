﻿using System;
using System.Windows.Forms;
using System.IO;
using System.Net.Mail;
namespace Crime_Patrol_Record_Mangement_System
{
    public partial class Form4 : Form
    {
        public Form4()
        {
            InitializeComponent();
        }

        private void Form4_Load(object sender, EventArgs e)
        {
            DirectoryInfo di = new DirectoryInfo(@"C:\Patrol Management\User\Information Complaints\");
            foreach (object o in di.GetDirectories())
            {
                comboBox1.Items.Add(o);
            }
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            comboBox2.Items.Clear();
            DirectoryInfo di2 = new DirectoryInfo(@"C:\Patrol Management\User\Information Complaints\" + comboBox1.Text + @"\");
            foreach (object o1 in di2.GetFiles())
            {
                string separate = o1.ToString();
                string[] separate_data = separate.Split('.'); 
                comboBox2.Items.Add(separate_data[0]);
            }

        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (File.Exists(@"C:\Patrol Management\User\Information Complaints\"+comboBox1.Text+ @"\"+comboBox2.Text+".txt") == true)
            {
                TextReader tr;
                tr = File.OpenText(@"C:\Patrol Management\User\Information Complaints\"+comboBox1.Text+@"\"+comboBox2.Text+".txt");
                string complaint_data = tr.ReadToEnd();
                string[] complaint_all_data = complaint_data.Split('|');
                txtbx_Firstname.Text = complaint_all_data[0];
                txtbx_Lstnme.Text = complaint_all_data[1];
                txtbx_lndlne_numbr.Text = complaint_all_data[2];
                txtbx_email_id.Text = complaint_all_data[3];
                txtbx_mble_nmbr.Text = complaint_all_data[4];
                txtbx_sbjct.Text = complaint_all_data[5];
                rchtxtxbx_description.Text = complaint_all_data[6];
                tr.Dispose();
                tr.Close();
            }
        }
        private void btn_submit_Click(object sender, EventArgs e)
        {
            if (txtbx_fir.Enabled == false)
            {
                txtbx_Firstname.Text = "";
                txtbx_Lstnme.Text = "";
                txtbx_mble_nmbr.Text = "";
                txtbx_sbjct.Text = "";
                txtbx_lndlne_numbr.Text = "";
                txtbx_email_id.Text = "";
                txtbx_fir.Text = "";
                cmbx_status.Text = "";
                rchtxtxbx_description.Text = "";
            }
            else
            {
                TextReader tr;
                tr = File.OpenText(@"C:\Patrol Management\User\Information Complaints\" + comboBox1.Text + @"\" + comboBox2.Text + ".txt");
                string complaint_data = tr.ReadToEnd();
                string[] complaint_all_data = complaint_data.Split('|');

                tr.Dispose();
                tr.Close();
                
                TextWriter tw;
                tw = File.CreateText(@"C:\Patrol Management\User\Information Complaints\" + comboBox1.Text + @"\" + comboBox2.Text + ".txt");
                tw.WriteLine(complaint_all_data[0] + "|" + complaint_all_data[1] + "|" + complaint_all_data[2] + "|" + complaint_all_data[3] + "|" + complaint_all_data[4] + "|" + complaint_all_data[5] + "|" + complaint_all_data[6] + "|" + cmbx_status.Text + "|" + txtbx_fir.Text + "|");
                tw.Flush();
                tw.Dispose();
                tw.Close();
                
                File.Move(@"C:\Patrol Management\User\Information Complaints\" + comboBox1.Text + @"\" + comboBox2.Text + ".txt", @"C:\Patrol Management\FIR\" + comboBox2.Text + ".txt");
                Form5 frm5 = new Form5();
                frm5.txtinfoname.Text = string.Concat(complaint_all_data[0] + " " + complaint_all_data[1]);
                this.Hide();
                frm5.Show();
            }
        }

        private void cmbx_status_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cmbx_status.Text == "Complaint Accepted")
            {
                txtbx_fir.Enabled = true;
            }
            else
            {
                txtbx_fir.Enabled = false;
            }
        }

        private void txtbx_fir_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsLetter(e.KeyChar))
            {
                e.Handled = true;
            }
        }
    }
}
