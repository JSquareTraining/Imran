﻿namespace Crime_Patrol_Record_Mangement_System
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form2));
            this.panel1 = new System.Windows.Forms.Panel();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.panel_authentication = new System.Windows.Forms.Panel();
            this.btn_go = new System.Windows.Forms.Button();
            this.txtbx_athtcatnpin = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txtbx_idnumbr = new System.Windows.Forms.TextBox();
            this.txtbx_pswd = new System.Windows.Forms.TextBox();
            this.btn_lgn = new System.Windows.Forms.Button();
            this.btn_regstr = new System.Windows.Forms.Button();
            this.lbl_notification = new System.Windows.Forms.Label();
            this.timer_security_protect = new System.Windows.Forms.Timer(this.components);
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panel_authentication.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.pictureBox2);
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(560, 126);
            this.panel1.TabIndex = 0;
            // 
            // label4
            // 
            this.label4.BackColor = System.Drawing.Color.Black;
            this.label4.Font = new System.Drawing.Font("Times New Roman", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.PaleTurquoise;
            this.label4.Location = new System.Drawing.Point(240, 72);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(181, 23);
            this.label4.TabIndex = 3;
            this.label4.Text = "COIMBATORE";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label3
            // 
            this.label3.BackColor = System.Drawing.Color.Black;
            this.label3.Font = new System.Drawing.Font("Times New Roman", 18F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.PaleTurquoise;
            this.label3.Location = new System.Drawing.Point(117, 38);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(435, 34);
            this.label3.TabIndex = 2;
            this.label3.Text = "TAMILNADU POLICE DEPARTMENT";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackColor = System.Drawing.Color.Black;
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(12, 3);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(105, 121);
            this.pictureBox2.TabIndex = 1;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.Black;
            this.pictureBox1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox1.Dock = System.Windows.Forms.DockStyle.Top;
            this.pictureBox1.Location = new System.Drawing.Point(0, 0);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(560, 128);
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // panel_authentication
            // 
            this.panel_authentication.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel_authentication.Controls.Add(this.btn_go);
            this.panel_authentication.Controls.Add(this.txtbx_athtcatnpin);
            this.panel_authentication.Controls.Add(this.label6);
            this.panel_authentication.Location = new System.Drawing.Point(38, 136);
            this.panel_authentication.Name = "panel_authentication";
            this.panel_authentication.Size = new System.Drawing.Size(478, 143);
            this.panel_authentication.TabIndex = 8;
            // 
            // btn_go
            // 
            this.btn_go.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.btn_go.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_go.Image = ((System.Drawing.Image)(resources.GetObject("btn_go.Image")));
            this.btn_go.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btn_go.Location = new System.Drawing.Point(338, 76);
            this.btn_go.Name = "btn_go";
            this.btn_go.Size = new System.Drawing.Size(80, 27);
            this.btn_go.TabIndex = 2;
            this.btn_go.Text = "Go";
            this.btn_go.UseVisualStyleBackColor = false;
            this.btn_go.Click += new System.EventHandler(this.btn_go_Click);
            // 
            // txtbx_athtcatnpin
            // 
            this.txtbx_athtcatnpin.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbx_athtcatnpin.Location = new System.Drawing.Point(50, 77);
            this.txtbx_athtcatnpin.Name = "txtbx_athtcatnpin";
            this.txtbx_athtcatnpin.PasswordChar = '*';
            this.txtbx_athtcatnpin.Size = new System.Drawing.Size(291, 25);
            this.txtbx_athtcatnpin.TabIndex = 1;
            this.txtbx_athtcatnpin.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label6
            // 
            this.label6.Font = new System.Drawing.Font("Times New Roman", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.PaleTurquoise;
            this.label6.Location = new System.Drawing.Point(57, 38);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(346, 29);
            this.label6.TabIndex = 0;
            this.label6.Text = "Please Enter the Authentication Code";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("Verdana", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.PaleTurquoise;
            this.label1.Location = new System.Drawing.Point(50, 143);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(146, 35);
            this.label1.TabIndex = 1;
            this.label1.Text = "Id Number";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label2
            // 
            this.label2.Font = new System.Drawing.Font("Verdana", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.PaleTurquoise;
            this.label2.Location = new System.Drawing.Point(50, 187);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(146, 35);
            this.label2.TabIndex = 2;
            this.label2.Text = "Password";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // txtbx_idnumbr
            // 
            this.txtbx_idnumbr.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbx_idnumbr.Location = new System.Drawing.Point(217, 147);
            this.txtbx_idnumbr.Name = "txtbx_idnumbr";
            this.txtbx_idnumbr.Size = new System.Drawing.Size(252, 26);
            this.txtbx_idnumbr.TabIndex = 3;
            // 
            // txtbx_pswd
            // 
            this.txtbx_pswd.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbx_pswd.Location = new System.Drawing.Point(217, 191);
            this.txtbx_pswd.Name = "txtbx_pswd";
            this.txtbx_pswd.PasswordChar = '*';
            this.txtbx_pswd.Size = new System.Drawing.Size(252, 26);
            this.txtbx_pswd.TabIndex = 4;
            // 
            // btn_lgn
            // 
            this.btn_lgn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.btn_lgn.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_lgn.Image = ((System.Drawing.Image)(resources.GetObject("btn_lgn.Image")));
            this.btn_lgn.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btn_lgn.Location = new System.Drawing.Point(217, 250);
            this.btn_lgn.Name = "btn_lgn";
            this.btn_lgn.Size = new System.Drawing.Size(92, 28);
            this.btn_lgn.TabIndex = 5;
            this.btn_lgn.Text = "    Login";
            this.btn_lgn.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_lgn.UseVisualStyleBackColor = false;
            this.btn_lgn.Click += new System.EventHandler(this.btn_lgn_Click);
            // 
            // btn_regstr
            // 
            this.btn_regstr.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.btn_regstr.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_regstr.Image = ((System.Drawing.Image)(resources.GetObject("btn_regstr.Image")));
            this.btn_regstr.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btn_regstr.Location = new System.Drawing.Point(331, 250);
            this.btn_regstr.Name = "btn_regstr";
            this.btn_regstr.Size = new System.Drawing.Size(92, 28);
            this.btn_regstr.TabIndex = 6;
            this.btn_regstr.Text = "Register";
            this.btn_regstr.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_regstr.UseVisualStyleBackColor = false;
            this.btn_regstr.Click += new System.EventHandler(this.btn_regstr_Click);
            // 
            // lbl_notification
            // 
            this.lbl_notification.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_notification.ForeColor = System.Drawing.Color.DarkOrange;
            this.lbl_notification.Location = new System.Drawing.Point(214, 224);
            this.lbl_notification.Name = "lbl_notification";
            this.lbl_notification.Size = new System.Drawing.Size(330, 23);
            this.lbl_notification.TabIndex = 7;
            this.lbl_notification.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // timer_security_protect
            // 
            this.timer_security_protect.Tick += new System.EventHandler(this.timer_security_protect_Tick);
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.BackColor = System.Drawing.Color.DimGray;
            this.ClientSize = new System.Drawing.Size(560, 289);
            this.ControlBox = false;
            this.Controls.Add(this.panel_authentication);
            this.Controls.Add(this.lbl_notification);
            this.Controls.Add(this.btn_regstr);
            this.Controls.Add(this.btn_lgn);
            this.Controls.Add(this.txtbx_pswd);
            this.Controls.Add(this.txtbx_idnumbr);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Form2";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form2";
            this.Load += new System.EventHandler(this.Form2_Load);
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panel_authentication.ResumeLayout(false);
            this.panel_authentication.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtbx_idnumbr;
        private System.Windows.Forms.TextBox txtbx_pswd;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button btn_lgn;
        private System.Windows.Forms.Button btn_regstr;
        private System.Windows.Forms.Label lbl_notification;
        private System.Windows.Forms.Panel panel_authentication;
        private System.Windows.Forms.TextBox txtbx_athtcatnpin;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button btn_go;
        private System.Windows.Forms.Timer timer_security_protect;
    }
}