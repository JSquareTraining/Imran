﻿using System;
using System.Data;
using System.Windows.Forms;
using System.IO;

namespace Crime_Patrol_Record_Mangement_System
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }

        private void Form3_Load(object sender, EventArgs e)
        {

            if (Directory.Exists(@"C:\Patrol Management\Department\Members Profile") == false)
                {
                    Directory.CreateDirectory(@"C:\Patrol Management\Department\Members Profile");
                }
            DataTable registered_record = new DataTable();

            registered_record.Columns.Add("ID NUMBER", typeof(string));
            registered_record.Columns.Add("FIRST NAME", typeof(string));
            registered_record.Columns.Add("LAST NAME", typeof(string));
            registered_record.Columns.Add("DESIGNATION", typeof(string));
            DirectoryInfo get_records = new DirectoryInfo(@"C:\Patrol Management\Department\Members Profile\");

            foreach (object records in get_records.GetFiles())
            {
                TextReader read_records;
                read_records = File.OpenText(@"C:\Patrol Management\Department\Members Profile\" + records);
                string all_records = read_records.ReadToEnd();
                string[] all_records_separate = all_records.Split('|');

                registered_record.Rows.Add(all_records_separate[0], all_records_separate[1], all_records_separate[2], all_records_separate[3]);

                read_records.Dispose();
                read_records.Close();
            }

            dataGridView_registered_record.DataSource = registered_record;
        }

        private void txtbx_idnum_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsLetter(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void txtbx_frstnme_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsNumber(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void txtbx_lstnme_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsNumber(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void txtbx_pswd_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsLetter(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void btn_submit_Click(object sender, EventArgs e)
        {
            if (txtbx_frstnme.Text == "" || txtbx_idnum.Text == "" || txtbx_lstnme.Text == "" || txtbx_pswd.Text == "" || cmbobx_designation.Text == "")
            {
                MessageBox.Show("Please Fill the Blank Field", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                if (Directory.Exists(@"C:\Patrol Management\Department\Members Profile") == false)
                {
                    Directory.CreateDirectory(@"C:\Patrol Management\Department\Members Profile");

                    TextWriter submit_writer;
                    submit_writer = File.CreateText(@"C:\Patrol Management\Department\Members Profile\" + txtbx_idnum.Text + ".txt");
                    submit_writer.WriteLine(txtbx_idnum.Text + "|" + txtbx_frstnme.Text + "|" + txtbx_lstnme.Text + "|" + cmbobx_designation.Text + "|" + txtbx_pswd.Text + "|");
                    submit_writer.Flush();
                    submit_writer.Dispose();
                    submit_writer.Close();
                }
                else
                {
                    if (File.Exists(@"C:\Patrol Management\Department\Members Profile\" + txtbx_idnum.Text + ".txt") == false)
                    {
                        TextWriter submit_writer;
                        submit_writer = File.CreateText(@"C:\Patrol Management\Department\Members Profile\" + txtbx_idnum.Text + ".txt");
                        submit_writer.WriteLine(txtbx_idnum.Text + "|" + txtbx_frstnme.Text + "|" + txtbx_lstnme.Text + "|" + cmbobx_designation.Text + "|" + txtbx_pswd.Text + "|");
                        submit_writer.Flush();
                        submit_writer.Dispose();
                        submit_writer.Close();

                        txtbx_frstnme.Text = ""; txtbx_idnum.Text = ""; txtbx_lstnme.Text = ""; txtbx_pswd.Text = ""; cmbobx_designation.Text = "";

                        DataTable registered_record = new DataTable();

                        registered_record.Columns.Add("ID NUMBER", typeof(string));
                        registered_record.Columns.Add("FIRST NAME", typeof(string));
                        registered_record.Columns.Add("LAST NAME", typeof(string));
                        registered_record.Columns.Add("DESIGNATION", typeof(string));
                        DirectoryInfo get_records = new DirectoryInfo(@"C:\Patrol Management\Department\Members Profile\");

                        foreach (object records in get_records.GetFiles())
                        {
                            TextReader read_records;
                            read_records = File.OpenText(@"C:\Patrol Management\Department\Members Profile\" + records);
                            string all_records = read_records.ReadToEnd();
                            string[] all_records_separate = all_records.Split('|');

                            registered_record.Rows.Add(all_records_separate[0], all_records_separate[1], all_records_separate[2], all_records_separate[3]);

                            read_records.Dispose();
                            read_records.Close();
                        }

                        dataGridView_registered_record.DataSource = registered_record;
                    }
                    else
                    {
                        MessageBox.Show("User already Exists", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
        }

        private void btn_update_Click(object sender, EventArgs e)
        {
            if (txtbx_idnum.Text != "")
            {
                File.Delete(@"C:\Patrol Management\Department\Members Profile\" + txtbx_idnum.Text + ".txt");
                TextWriter submit_writer;
                submit_writer = File.CreateText(@"C:\Patrol Management\Department\Members Profile\" + txtbx_idnum.Text + ".txt");
                submit_writer.WriteLine(txtbx_idnum.Text + "|" + txtbx_frstnme.Text + "|" + txtbx_lstnme.Text + "|" + cmbobx_designation.Text + "|" + txtbx_pswd.Text + "|");
                submit_writer.Flush();
                submit_writer.Dispose();
                submit_writer.Close();
                txtbx_frstnme.Text = ""; txtbx_idnum.Text = ""; txtbx_lstnme.Text = ""; txtbx_pswd.Text = ""; cmbobx_designation.Text = "";
                DataTable registered_record = new DataTable();
                registered_record.Columns.Add("ID NUMBER", typeof(string));
                registered_record.Columns.Add("FIRST NAME", typeof(string));
                registered_record.Columns.Add("LAST NAME", typeof(string));
                registered_record.Columns.Add("DESIGNATION", typeof(string));
                DirectoryInfo get_records = new DirectoryInfo(@"C:\Patrol Management\Department\Members Profile\");

                foreach (object records in get_records.GetFiles())
                {
                    TextReader read_records;
                    read_records = File.OpenText(@"C:\Patrol Management\Department\Members Profile\" + records);
                    string all_records = read_records.ReadToEnd();
                    string[] all_records_separate = all_records.Split('|');
                    registered_record.Rows.Add(all_records_separate[0], all_records_separate[1], all_records_separate[2], all_records_separate[3]);
                    read_records.Dispose();
                    read_records.Close();
                }

                dataGridView_registered_record.DataSource = registered_record;

                MessageBox.Show("Updated Successfully", "TNPD", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                MessageBox.Show("Please Select the ID NUMBER", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void dataGridView_registered_record_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            object k = dataGridView_registered_record.CurrentCell.Value;
            if (File.Exists(@"C:\Patrol Management\Department\Members Profile\" + k + ".txt") == true)
            {                
                TextReader read_records;
                read_records = File.OpenText(@"C:\Patrol Management\Department\Members Profile\" + k + ".txt");
                string all_records = read_records.ReadToEnd();
                string[] all_records_separate = all_records.Split('|');
                txtbx_idnum.Text = all_records_separate[0];
                txtbx_frstnme.Text = all_records_separate[1];
                txtbx_lstnme.Text = all_records_separate[2];
                cmbobx_designation.Text = all_records_separate[3];
                txtbx_pswd.Text = all_records_separate[4];
                read_records.Dispose();
                read_records.Close();
            }
        }

        private void btn_delete_Click(object sender, EventArgs e)
        {
            File.Delete(@"C:\Patrol Management\Department\Members Profile\" + txtbx_idnum.Text + ".txt");
            txtbx_frstnme.Text = ""; txtbx_idnum.Text = ""; txtbx_lstnme.Text = ""; txtbx_pswd.Text = ""; cmbobx_designation.Text = "";
            DataTable registered_record = new DataTable();
            registered_record.Columns.Add("ID NUMBER", typeof(string));
            registered_record.Columns.Add("FIRST NAME", typeof(string));
            registered_record.Columns.Add("LAST NAME", typeof(string));
            registered_record.Columns.Add("DESIGNATION", typeof(string));
            DirectoryInfo get_records = new DirectoryInfo(@"C:\Patrol Management\Department\Members Profile\");

            foreach (object records in get_records.GetFiles())
            {
                TextReader read_records;
                read_records = File.OpenText(@"C:\Patrol Management\Department\Members Profile\" + records);
                string all_records = read_records.ReadToEnd();
                string[] all_records_separate = all_records.Split('|');
                registered_record.Rows.Add(all_records_separate[0], all_records_separate[1], all_records_separate[2], all_records_separate[3]);
                read_records.Dispose();
                read_records.Close();
            }

            dataGridView_registered_record.DataSource = registered_record;
            MessageBox.Show("Deleted Successfully", "TNPD", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void btn_back_Click(object sender, EventArgs e)
        {
            Form2 frm2 = new Form2();
            this.Hide();
            frm2.Show();
        }
    }
}
