﻿namespace Crime_Patrol_Record_Mangement_System
{
    partial class Form5
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form5));
            this.txtchargshetno = new System.Windows.Forms.TextBox();
            this.Label1 = new System.Windows.Forms.Label();
            this.txtpolicestationname = new System.Windows.Forms.TextBox();
            this.Label2 = new System.Windows.Forms.Label();
            this.txtcomplaintno = new System.Windows.Forms.TextBox();
            this.Label21 = new System.Windows.Forms.Label();
            this.txtaccusoccup = new System.Windows.Forms.TextBox();
            this.txtaccusage = new System.Windows.Forms.TextBox();
            this.txtaccusadd = new System.Windows.Forms.TextBox();
            this.txtaccussex = new System.Windows.Forms.TextBox();
            this.txtaccusname = new System.Windows.Forms.TextBox();
            this.txtinfooccup = new System.Windows.Forms.TextBox();
            this.txtinfoadd = new System.Windows.Forms.TextBox();
            this.txtinfoname = new System.Windows.Forms.TextBox();
            this.txtdistrict = new System.Windows.Forms.TextBox();
            this.Label14 = new System.Windows.Forms.Label();
            this.txtfirno = new System.Windows.Forms.TextBox();
            this.Label13 = new System.Windows.Forms.Label();
            this.Label12 = new System.Windows.Forms.Label();
            this.Label11 = new System.Windows.Forms.Label();
            this.Label10 = new System.Windows.Forms.Label();
            this.Label8 = new System.Windows.Forms.Label();
            this.Label7 = new System.Windows.Forms.Label();
            this.Label6 = new System.Windows.Forms.Label();
            this.Label5 = new System.Windows.Forms.Label();
            this.Label4 = new System.Windows.Forms.Label();
            this.txtwitnesoccup = new System.Windows.Forms.TextBox();
            this.txtwitnesadd = new System.Windows.Forms.TextBox();
            this.txtaccusaction = new System.Windows.Forms.TextBox();
            this.txtaccuscurntstation = new System.Windows.Forms.TextBox();
            this.Label18 = new System.Windows.Forms.Label();
            this.Label17 = new System.Windows.Forms.Label();
            this.Label16 = new System.Windows.Forms.Label();
            this.Label15 = new System.Windows.Forms.Label();
            this.txtwitnesname = new System.Windows.Forms.TextBox();
            this.Label19 = new System.Windows.Forms.Label();
            this.txtcriminalno = new System.Windows.Forms.TextBox();
            this.Label26 = new System.Windows.Forms.Label();
            this.DateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.Label3 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.label20 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label9 = new System.Windows.Forms.Label();
            this.cmbx_status = new System.Windows.Forms.ComboBox();
            this.label23 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // txtchargshetno
            // 
            this.txtchargshetno.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtchargshetno.Location = new System.Drawing.Point(189, 205);
            this.txtchargshetno.Name = "txtchargshetno";
            this.txtchargshetno.Size = new System.Drawing.Size(158, 22);
            this.txtchargshetno.TabIndex = 73;
            this.txtchargshetno.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtchargshetno_KeyPress);
            // 
            // Label1
            // 
            this.Label1.AutoSize = true;
            this.Label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label1.Location = new System.Drawing.Point(20, 206);
            this.Label1.Name = "Label1";
            this.Label1.Size = new System.Drawing.Size(152, 16);
            this.Label1.TabIndex = 72;
            this.Label1.Text = "CHARGE SHEET NO";
            // 
            // txtpolicestationname
            // 
            this.txtpolicestationname.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtpolicestationname.Location = new System.Drawing.Point(190, 247);
            this.txtpolicestationname.Name = "txtpolicestationname";
            this.txtpolicestationname.Size = new System.Drawing.Size(158, 22);
            this.txtpolicestationname.TabIndex = 75;
            // 
            // Label2
            // 
            this.Label2.AutoSize = true;
            this.Label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label2.Location = new System.Drawing.Point(5, 250);
            this.Label2.Name = "Label2";
            this.Label2.Size = new System.Drawing.Size(178, 16);
            this.Label2.TabIndex = 74;
            this.Label2.Text = "POLICE STATION NAME";
            // 
            // txtcomplaintno
            // 
            this.txtcomplaintno.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtcomplaintno.Location = new System.Drawing.Point(190, 287);
            this.txtcomplaintno.Name = "txtcomplaintno";
            this.txtcomplaintno.Size = new System.Drawing.Size(158, 22);
            this.txtcomplaintno.TabIndex = 117;
            this.txtcomplaintno.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtcomplaintno_KeyPress);
            // 
            // Label21
            // 
            this.Label21.AutoSize = true;
            this.Label21.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label21.Location = new System.Drawing.Point(46, 288);
            this.Label21.Name = "Label21";
            this.Label21.Size = new System.Drawing.Size(120, 16);
            this.Label21.TabIndex = 116;
            this.Label21.Text = "COMPLAINT NO";
            // 
            // txtaccusoccup
            // 
            this.txtaccusoccup.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtaccusoccup.Location = new System.Drawing.Point(190, 666);
            this.txtaccusoccup.Name = "txtaccusoccup";
            this.txtaccusoccup.Size = new System.Drawing.Size(158, 22);
            this.txtaccusoccup.TabIndex = 115;
            // 
            // txtaccusage
            // 
            this.txtaccusage.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtaccusage.Location = new System.Drawing.Point(190, 626);
            this.txtaccusage.MaxLength = 3;
            this.txtaccusage.Name = "txtaccusage";
            this.txtaccusage.Size = new System.Drawing.Size(158, 22);
            this.txtaccusage.TabIndex = 114;
            this.txtaccusage.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtaccusage_KeyPress);
            // 
            // txtaccusadd
            // 
            this.txtaccusadd.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtaccusadd.Location = new System.Drawing.Point(190, 551);
            this.txtaccusadd.Name = "txtaccusadd";
            this.txtaccusadd.Size = new System.Drawing.Size(158, 22);
            this.txtaccusadd.TabIndex = 113;
            // 
            // txtaccussex
            // 
            this.txtaccussex.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtaccussex.Location = new System.Drawing.Point(190, 588);
            this.txtaccussex.Name = "txtaccussex";
            this.txtaccussex.Size = new System.Drawing.Size(158, 22);
            this.txtaccussex.TabIndex = 112;
            // 
            // txtaccusname
            // 
            this.txtaccusname.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtaccusname.Location = new System.Drawing.Point(189, 512);
            this.txtaccusname.Name = "txtaccusname";
            this.txtaccusname.Size = new System.Drawing.Size(158, 22);
            this.txtaccusname.TabIndex = 111;
            // 
            // txtinfooccup
            // 
            this.txtinfooccup.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtinfooccup.Location = new System.Drawing.Point(190, 474);
            this.txtinfooccup.Name = "txtinfooccup";
            this.txtinfooccup.Size = new System.Drawing.Size(158, 22);
            this.txtinfooccup.TabIndex = 109;
            // 
            // txtinfoadd
            // 
            this.txtinfoadd.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtinfoadd.Location = new System.Drawing.Point(190, 437);
            this.txtinfoadd.Name = "txtinfoadd";
            this.txtinfoadd.Size = new System.Drawing.Size(158, 22);
            this.txtinfoadd.TabIndex = 108;
            // 
            // txtinfoname
            // 
            this.txtinfoname.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtinfoname.Location = new System.Drawing.Point(189, 397);
            this.txtinfoname.Name = "txtinfoname";
            this.txtinfoname.Size = new System.Drawing.Size(158, 22);
            this.txtinfoname.TabIndex = 107;
            // 
            // txtdistrict
            // 
            this.txtdistrict.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtdistrict.Location = new System.Drawing.Point(189, 361);
            this.txtdistrict.Name = "txtdistrict";
            this.txtdistrict.ReadOnly = true;
            this.txtdistrict.Size = new System.Drawing.Size(158, 22);
            this.txtdistrict.TabIndex = 106;
            this.txtdistrict.Text = "Coimbatore";
            // 
            // Label14
            // 
            this.Label14.AutoSize = true;
            this.Label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label14.Location = new System.Drawing.Point(20, 667);
            this.Label14.Name = "Label14";
            this.Label14.Size = new System.Drawing.Size(161, 16);
            this.Label14.TabIndex = 104;
            this.Label14.Text = "ACCUS OCCUPATION";
            // 
            // txtfirno
            // 
            this.txtfirno.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtfirno.Location = new System.Drawing.Point(190, 324);
            this.txtfirno.Name = "txtfirno";
            this.txtfirno.Size = new System.Drawing.Size(157, 22);
            this.txtfirno.TabIndex = 105;
            this.txtfirno.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtfirno_KeyPress);
            // 
            // Label13
            // 
            this.Label13.AutoSize = true;
            this.Label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label13.Location = new System.Drawing.Point(66, 631);
            this.Label13.Name = "Label13";
            this.Label13.Size = new System.Drawing.Size(94, 16);
            this.Label13.TabIndex = 103;
            this.Label13.Text = "ACCUS AGE";
            // 
            // Label12
            // 
            this.Label12.AutoSize = true;
            this.Label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label12.Location = new System.Drawing.Point(69, 593);
            this.Label12.Name = "Label12";
            this.Label12.Size = new System.Drawing.Size(92, 16);
            this.Label12.TabIndex = 102;
            this.Label12.Text = "ACCUS SEX";
            // 
            // Label11
            // 
            this.Label11.AutoSize = true;
            this.Label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label11.Location = new System.Drawing.Point(36, 557);
            this.Label11.Name = "Label11";
            this.Label11.Size = new System.Drawing.Size(136, 16);
            this.Label11.TabIndex = 101;
            this.Label11.Text = "ACCUS ADDRESS";
            // 
            // Label10
            // 
            this.Label10.AutoSize = true;
            this.Label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label10.Location = new System.Drawing.Point(57, 517);
            this.Label10.Name = "Label10";
            this.Label10.Size = new System.Drawing.Size(106, 16);
            this.Label10.TabIndex = 100;
            this.Label10.Text = "ACCUS NAME";
            // 
            // Label8
            // 
            this.Label8.AutoSize = true;
            this.Label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label8.Location = new System.Drawing.Point(31, 479);
            this.Label8.Name = "Label8";
            this.Label8.Size = new System.Drawing.Size(145, 16);
            this.Label8.TabIndex = 98;
            this.Label8.Text = "INFO OCCUPATION";
            // 
            // Label7
            // 
            this.Label7.AutoSize = true;
            this.Label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label7.Location = new System.Drawing.Point(76, 438);
            this.Label7.Name = "Label7";
            this.Label7.Size = new System.Drawing.Size(79, 16);
            this.Label7.TabIndex = 97;
            this.Label7.Text = "INFO ADD";
            // 
            // Label6
            // 
            this.Label6.AutoSize = true;
            this.Label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label6.Location = new System.Drawing.Point(70, 401);
            this.Label6.Name = "Label6";
            this.Label6.Size = new System.Drawing.Size(90, 16);
            this.Label6.TabIndex = 96;
            this.Label6.Text = "INFO NAME";
            // 
            // Label5
            // 
            this.Label5.AutoSize = true;
            this.Label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label5.Location = new System.Drawing.Point(77, 361);
            this.Label5.Name = "Label5";
            this.Label5.Size = new System.Drawing.Size(78, 16);
            this.Label5.TabIndex = 95;
            this.Label5.Text = "DISTRICT";
            // 
            // Label4
            // 
            this.Label4.AutoSize = true;
            this.Label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label4.Location = new System.Drawing.Point(91, 325);
            this.Label4.Name = "Label4";
            this.Label4.Size = new System.Drawing.Size(58, 16);
            this.Label4.TabIndex = 94;
            this.Label4.Text = "FIR NO";
            // 
            // txtwitnesoccup
            // 
            this.txtwitnesoccup.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtwitnesoccup.Location = new System.Drawing.Point(647, 346);
            this.txtwitnesoccup.Name = "txtwitnesoccup";
            this.txtwitnesoccup.Size = new System.Drawing.Size(158, 22);
            this.txtwitnesoccup.TabIndex = 127;
            // 
            // txtwitnesadd
            // 
            this.txtwitnesadd.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtwitnesadd.Location = new System.Drawing.Point(647, 311);
            this.txtwitnesadd.Name = "txtwitnesadd";
            this.txtwitnesadd.Size = new System.Drawing.Size(158, 22);
            this.txtwitnesadd.TabIndex = 126;
            // 
            // txtaccusaction
            // 
            this.txtaccusaction.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtaccusaction.Location = new System.Drawing.Point(647, 241);
            this.txtaccusaction.Name = "txtaccusaction";
            this.txtaccusaction.Size = new System.Drawing.Size(158, 22);
            this.txtaccusaction.TabIndex = 125;
            // 
            // txtaccuscurntstation
            // 
            this.txtaccuscurntstation.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtaccuscurntstation.Location = new System.Drawing.Point(647, 210);
            this.txtaccuscurntstation.Name = "txtaccuscurntstation";
            this.txtaccuscurntstation.Size = new System.Drawing.Size(158, 22);
            this.txtaccuscurntstation.TabIndex = 124;
            // 
            // Label18
            // 
            this.Label18.AutoSize = true;
            this.Label18.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label18.Location = new System.Drawing.Point(462, 315);
            this.Label18.Name = "Label18";
            this.Label18.Size = new System.Drawing.Size(164, 16);
            this.Label18.TabIndex = 121;
            this.Label18.Text = "WITTNESS ADDRESS";
            // 
            // Label17
            // 
            this.Label17.AutoSize = true;
            this.Label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label17.Location = new System.Drawing.Point(492, 275);
            this.Label17.Name = "Label17";
            this.Label17.Size = new System.Drawing.Size(134, 16);
            this.Label17.TabIndex = 120;
            this.Label17.Text = "WITTNESS NAME";
            // 
            // Label16
            // 
            this.Label16.AutoSize = true;
            this.Label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label16.Location = new System.Drawing.Point(507, 242);
            this.Label16.Name = "Label16";
            this.Label16.Size = new System.Drawing.Size(119, 16);
            this.Label16.TabIndex = 119;
            this.Label16.Text = "ACCUS ACTION";
            // 
            // Label15
            // 
            this.Label15.AutoSize = true;
            this.Label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label15.Location = new System.Drawing.Point(409, 210);
            this.Label15.Name = "Label15";
            this.Label15.Size = new System.Drawing.Size(217, 16);
            this.Label15.TabIndex = 118;
            this.Label15.Text = "ACCCUS CURRENT STATION";
            // 
            // txtwitnesname
            // 
            this.txtwitnesname.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtwitnesname.Location = new System.Drawing.Point(647, 275);
            this.txtwitnesname.Name = "txtwitnesname";
            this.txtwitnesname.Size = new System.Drawing.Size(158, 22);
            this.txtwitnesname.TabIndex = 123;
            // 
            // Label19
            // 
            this.Label19.AutoSize = true;
            this.Label19.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label19.Location = new System.Drawing.Point(437, 350);
            this.Label19.Name = "Label19";
            this.Label19.Size = new System.Drawing.Size(189, 16);
            this.Label19.TabIndex = 122;
            this.Label19.Text = "WITTNESS OCCUPATION";
            // 
            // txtcriminalno
            // 
            this.txtcriminalno.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtcriminalno.Location = new System.Drawing.Point(647, 422);
            this.txtcriminalno.Name = "txtcriminalno";
            this.txtcriminalno.Size = new System.Drawing.Size(158, 22);
            this.txtcriminalno.TabIndex = 131;
            this.txtcriminalno.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtcriminalno_KeyPress);
            // 
            // Label26
            // 
            this.Label26.AutoSize = true;
            this.Label26.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label26.Location = new System.Drawing.Point(518, 426);
            this.Label26.Name = "Label26";
            this.Label26.Size = new System.Drawing.Size(108, 16);
            this.Label26.TabIndex = 130;
            this.Label26.Text = "CRIMINAL NO.";
            // 
            // DateTimePicker1
            // 
            this.DateTimePicker1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DateTimePicker1.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.DateTimePicker1.Location = new System.Drawing.Point(647, 382);
            this.DateTimePicker1.Name = "DateTimePicker1";
            this.DateTimePicker1.Size = new System.Drawing.Size(158, 22);
            this.DateTimePicker1.TabIndex = 129;
            // 
            // Label3
            // 
            this.Label3.AutoSize = true;
            this.Label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label3.Location = new System.Drawing.Point(455, 386);
            this.Label3.Name = "Label3";
            this.Label3.Size = new System.Drawing.Size(171, 16);
            this.Label3.TabIndex = 128;
            this.Label3.Text = "CHARGE SHEET DATE";
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(367, 699);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(181, 36);
            this.button1.TabIndex = 132;
            this.button1.Text = "Produce Charge Sheet";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label20
            // 
            this.label20.BackColor = System.Drawing.Color.Black;
            this.label20.Font = new System.Drawing.Font("Times New Roman", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.ForeColor = System.Drawing.Color.PaleTurquoise;
            this.label20.Location = new System.Drawing.Point(367, 73);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(181, 23);
            this.label20.TabIndex = 136;
            this.label20.Text = "COIMBATORE";
            this.label20.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label22
            // 
            this.label22.BackColor = System.Drawing.Color.Black;
            this.label22.Font = new System.Drawing.Font("Times New Roman", 18F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.ForeColor = System.Drawing.Color.PaleTurquoise;
            this.label22.Location = new System.Drawing.Point(244, 39);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(435, 34);
            this.label22.TabIndex = 135;
            this.label22.Text = "TAMILNADU POLICE DEPARTMENT";
            this.label22.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackColor = System.Drawing.Color.Black;
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(139, 0);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(105, 121);
            this.pictureBox2.TabIndex = 134;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.Black;
            this.pictureBox1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pictureBox1.Dock = System.Windows.Forms.DockStyle.Top;
            this.pictureBox1.Location = new System.Drawing.Point(0, 0);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(882, 130);
            this.pictureBox1.TabIndex = 133;
            this.pictureBox1.TabStop = false;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(343, 151);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(171, 24);
            this.label9.TabIndex = 137;
            this.label9.Text = "CHARGE SHEET";
            // 
            // cmbx_status
            // 
            this.cmbx_status.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbx_status.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbx_status.FormattingEnabled = true;
            this.cmbx_status.Items.AddRange(new object[] {
            "Complaint Accepted",
            "Complaint Cancelled"});
            this.cmbx_status.Location = new System.Drawing.Point(647, 465);
            this.cmbx_status.Name = "cmbx_status";
            this.cmbx_status.Size = new System.Drawing.Size(158, 28);
            this.cmbx_status.TabIndex = 139;
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label23.Location = new System.Drawing.Point(557, 477);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(69, 16);
            this.label23.TabIndex = 138;
            this.label23.Text = "STATUS";
            // 
            // Form5
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.BackColor = System.Drawing.Color.LemonChiffon;
            this.ClientSize = new System.Drawing.Size(882, 747);
            this.Controls.Add(this.cmbx_status);
            this.Controls.Add(this.label23);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label20);
            this.Controls.Add(this.label22);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.txtcriminalno);
            this.Controls.Add(this.Label26);
            this.Controls.Add(this.DateTimePicker1);
            this.Controls.Add(this.Label3);
            this.Controls.Add(this.txtwitnesoccup);
            this.Controls.Add(this.txtwitnesadd);
            this.Controls.Add(this.txtaccusaction);
            this.Controls.Add(this.txtaccuscurntstation);
            this.Controls.Add(this.Label18);
            this.Controls.Add(this.Label17);
            this.Controls.Add(this.Label16);
            this.Controls.Add(this.Label15);
            this.Controls.Add(this.txtwitnesname);
            this.Controls.Add(this.Label19);
            this.Controls.Add(this.txtcomplaintno);
            this.Controls.Add(this.Label21);
            this.Controls.Add(this.txtaccusoccup);
            this.Controls.Add(this.txtaccusage);
            this.Controls.Add(this.txtaccusadd);
            this.Controls.Add(this.txtaccussex);
            this.Controls.Add(this.txtaccusname);
            this.Controls.Add(this.txtinfooccup);
            this.Controls.Add(this.txtinfoadd);
            this.Controls.Add(this.txtinfoname);
            this.Controls.Add(this.txtdistrict);
            this.Controls.Add(this.Label14);
            this.Controls.Add(this.txtfirno);
            this.Controls.Add(this.Label13);
            this.Controls.Add(this.Label12);
            this.Controls.Add(this.Label11);
            this.Controls.Add(this.Label10);
            this.Controls.Add(this.Label8);
            this.Controls.Add(this.Label7);
            this.Controls.Add(this.Label6);
            this.Controls.Add(this.Label5);
            this.Controls.Add(this.Label4);
            this.Controls.Add(this.txtpolicestationname);
            this.Controls.Add(this.Label2);
            this.Controls.Add(this.txtchargshetno);
            this.Controls.Add(this.Label1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Form5";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "CHARGE SHEET";
            this.Load += new System.EventHandler(this.Form5_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        internal System.Windows.Forms.TextBox txtchargshetno;
        internal System.Windows.Forms.Label Label1;
        internal System.Windows.Forms.TextBox txtpolicestationname;
        internal System.Windows.Forms.Label Label2;
        internal System.Windows.Forms.TextBox txtcomplaintno;
        internal System.Windows.Forms.Label Label21;
        internal System.Windows.Forms.TextBox txtaccusoccup;
        internal System.Windows.Forms.TextBox txtaccusage;
        internal System.Windows.Forms.TextBox txtaccusadd;
        internal System.Windows.Forms.TextBox txtaccussex;
        internal System.Windows.Forms.TextBox txtaccusname;
        internal System.Windows.Forms.TextBox txtinfooccup;
        internal System.Windows.Forms.TextBox txtdistrict;
        internal System.Windows.Forms.Label Label14;
        internal System.Windows.Forms.TextBox txtfirno;
        internal System.Windows.Forms.Label Label13;
        internal System.Windows.Forms.Label Label12;
        internal System.Windows.Forms.Label Label11;
        internal System.Windows.Forms.Label Label10;
        internal System.Windows.Forms.Label Label8;
        internal System.Windows.Forms.Label Label7;
        internal System.Windows.Forms.Label Label6;
        internal System.Windows.Forms.Label Label5;
        internal System.Windows.Forms.Label Label4;
        internal System.Windows.Forms.TextBox txtwitnesoccup;
        internal System.Windows.Forms.TextBox txtwitnesadd;
        internal System.Windows.Forms.TextBox txtaccusaction;
        internal System.Windows.Forms.TextBox txtaccuscurntstation;
        internal System.Windows.Forms.Label Label18;
        internal System.Windows.Forms.Label Label17;
        internal System.Windows.Forms.Label Label16;
        internal System.Windows.Forms.Label Label15;
        internal System.Windows.Forms.TextBox txtwitnesname;
        internal System.Windows.Forms.Label Label19;
        internal System.Windows.Forms.TextBox txtcriminalno;
        internal System.Windows.Forms.Label Label26;
        internal System.Windows.Forms.DateTimePicker DateTimePicker1;
        internal System.Windows.Forms.Label Label3;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox1;
        public System.Windows.Forms.TextBox txtinfoadd;
        public System.Windows.Forms.TextBox txtinfoname;
        internal System.Windows.Forms.Label label9;
        private System.Windows.Forms.ComboBox cmbx_status;
        private System.Windows.Forms.Label label23;
    }
}