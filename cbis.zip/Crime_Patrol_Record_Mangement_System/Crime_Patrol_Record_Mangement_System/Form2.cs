﻿using System;
using System.Windows.Forms;
using System.IO;
using Microsoft.DirectX.AudioVideoPlayback;

namespace Crime_Patrol_Record_Mangement_System
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
            timer_security_protect.Interval = 500;
        }
        Properties.Settings st = new Properties.Settings();
        int fixedtimer = 10;
        private void Form2_Load(object sender, EventArgs e)
        {
            panel_authentication.Hide();
        }

        private void btn_regstr_Click(object sender, EventArgs e)
        {
            panel_authentication.Show();
        }

        private void btn_go_Click(object sender, EventArgs e)
        {
            TextReader tr;
            tr = File.OpenText(@"C:\Patrol Management\Access Pin.txt");
            string access_pin = tr.ReadToEnd();
            string[] access_pin_getdata = access_pin.Split(',');
            tr.Dispose();
            tr.Close();
            if (txtbx_athtcatnpin.Text == access_pin_getdata[0])
            {
                DialogResult dr2 = new DialogResult();
                dr2 = MessageBox.Show("Access Granted", "TNPD", MessageBoxButtons.OK, MessageBoxIcon.Information);
                if (dr2 == DialogResult.OK)
                {
                    st.pin = 3;
                    st.Save();
                    Form3 frm3 = new Form3();
                    this.Hide();
                    frm3.Show();
                }
            }
            else
            {
                st.pin = st.pin - 1;
                st.Save();
                MessageBox.Show("Please Enter the Valid Pin", "Error", MessageBoxButtons.OK, MessageBoxIcon.Information);
                if (st.pin > 0)
                {
                    if (st.pin == 1)
                    {
                        MessageBox.Show("This is the Last Chance", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                    else
                    {
                        MessageBox.Show("Only " + st.pin + " Chances Left");
                    }   
                }
                else
                {
                    Audio security_alert;
                    security_alert = new Audio(@"C:\Patrol Management\Security.wav");
                    st.pin = 3;
                    st.Save();
                    security_alert.Play();
                    panel_authentication.Hide();
                    txtbx_athtcatnpin.Text = "";
                    timer_security_protect.Start();
                }
            }
        }

        private void timer_security_protect_Tick(object sender, EventArgs e)
        {
            fixedtimer = fixedtimer - 1;
            if (fixedtimer > 0)
            {
                btn_lgn.Enabled = false;
                btn_regstr.Enabled = false;
            }
            else
            {
                btn_lgn.Enabled = true;
                btn_regstr.Enabled = true;
                timer_security_protect.Stop();
            }
        }

        private void btn_lgn_Click(object sender, EventArgs e)
        {
            if (txtbx_idnumbr.Text == "" || txtbx_pswd.Text == "")
            {
                lbl_notification.Text = "Please enter the valid ID Number/Password";
            }
            else
            {
               
                    if (File.Exists(@"C:\Patrol Management\Department\Members Profile\" + txtbx_idnumbr.Text + ".txt") == true)
                    {
                        TextReader tr;
                        tr = File.OpenText(@"C:\Patrol Management\Department\Members Profile\" + txtbx_idnumbr.Text + ".txt");
                        string get_data = tr.ReadToEnd();
                        string[] get_data_split = get_data.Split('|');

                        if (txtbx_idnumbr.Text == get_data_split[0] && txtbx_pswd.Text == get_data_split[4])
                        {
                            DialogResult dr = new DialogResult();
                            dr = MessageBox.Show("Login Successfull", "TNPD", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            if (dr == DialogResult.OK)
                            {
                                Form4 frm4 = new Form4();
                                this.Hide();
                                frm4.Show();
                            }

                        }
                    }
                    else
                    {
                        lbl_notification.Text = "Please enter the valid ID Number/Password";
                    }
                
            }
        }      
    }
}
