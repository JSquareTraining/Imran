﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Passingdatainlistbox
{
    public partial class Passing_Data_in_ListBox : Form
    {
        public Passing_Data_in_ListBox()
        {
            InitializeComponent();
        }
        
        private void rghtarw_btn_Click(object sender, EventArgs e)
        {
            if (listbx_drvr.SelectedItem == null || listbx_car.SelectedItem == null)
            {
                MessageBox.Show("Please Select the Driver/Car", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                int j = listbx_drvr.SelectedItems.Count;
                int a = listbx_car.SelectedItems.Count;
                if (j != a)
                {
                    MessageBox.Show("Please Select the Driver/Car", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);

                }
                else
                {
                    for (int i = 0; i < j; i++)
                    {

                        if (listbx_drvr.SelectedItem == null || listbx_car.SelectedItem == null)
                        {
                            MessageBox.Show("Please Select the Driver/Car", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                        else
                        {
                            listbx_altd.Items.Add(String.Concat(listbx_drvr.SelectedItem, " is Alotted to ", listbx_car.SelectedItem));
                            listbx_drvr.Items.Remove(listbx_drvr.SelectedItem);
                            listbx_car.Items.Remove(listbx_car.SelectedItem);

                        }

                    }   
                }
                    
                }
            }

        private void rghtarw2_btn_Click(object sender, EventArgs e)
        {

            int k = listbx_drvr.Items.Count;
            for (int l = 0; l < k; l++)
            {
                listbx_altd.Items.Add(String.Concat(listbx_drvr.Items[l]," is Alotted to ", listbx_car.Items[l]));
              
            }
            listbx_drvr.Items.Clear();
            listbx_car.Items.Clear();
        }

        private void lftarw_btn_Click(object sender, EventArgs e)
        {
            if (listbx_altd.SelectedItem == null)
            {
                MessageBox.Show("Please Select the Driver/Car","Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                int p = listbx_altd.SelectedItems.Count;
                for (int q = 0; q < p; q++)
                {
                    String[] s = listbx_altd.Text.Split(' ');

                    listbx_drvr.Items.Add(String.Format("{0:t}", s));

                    listbx_car.Items.Add(String.Format("{4:t}", s));

                    listbx_altd.Items.Remove(listbx_altd.SelectedItem);
                }
            }
            

        }

        private void lftarw2_btn_Click(object sender, EventArgs e)
        {
            int x = listbx_altd.Items.Count;
            for (int y = 0; y < x; y++)
            {
                string s = listbx_altd.Items[y].ToString();
                String[] t = s.Split(' ');
                listbx_drvr.Items.Add(String.Format("{0:z}", t));

                listbx_car.Items.Add(String.Format("{4:z}", t));       
            }
            listbx_altd.Items.Clear();
        }

        }
    }

