﻿namespace Passingdatainlistbox
{
    partial class Passing_Data_in_ListBox
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.listbx_drvr = new System.Windows.Forms.ListBox();
            this.listbx_car = new System.Windows.Forms.ListBox();
            this.listbx_altd = new System.Windows.Forms.ListBox();
            this.btn_rghtarw = new System.Windows.Forms.Button();
            this.btn_rghtarw2 = new System.Windows.Forms.Button();
            this.btn_lftarw = new System.Windows.Forms.Button();
            this.btn_lftarw2 = new System.Windows.Forms.Button();
            this.lbl_drvrnme = new System.Windows.Forms.Label();
            this.lbl_carnmbr = new System.Windows.Forms.Label();
            this.lbl_altdlst = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // listbx_drvr
            // 
            this.listbx_drvr.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.listbx_drvr.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.listbx_drvr.FormattingEnabled = true;
            this.listbx_drvr.ItemHeight = 15;
            this.listbx_drvr.Items.AddRange(new object[] {
            "Imran",
            "Anand",
            "Saravanan",
            "Sriram",
            "Basil",
            "Naresh",
            "Mukesh",
            "Sankar",
            "Mani",
            "Balu"});
            this.listbx_drvr.Location = new System.Drawing.Point(302, 225);
            this.listbx_drvr.Name = "listbx_drvr";
            this.listbx_drvr.SelectionMode = System.Windows.Forms.SelectionMode.MultiSimple;
            this.listbx_drvr.Size = new System.Drawing.Size(180, 199);
            this.listbx_drvr.TabIndex = 0;
            // 
            // listbx_car
            // 
            this.listbx_car.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.listbx_car.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.listbx_car.FormattingEnabled = true;
            this.listbx_car.ItemHeight = 15;
            this.listbx_car.Items.AddRange(new object[] {
            "1191",
            "5644",
            "2200",
            "1001",
            "9999",
            "1111",
            "5555",
            "6666",
            "7777",
            "8888"});
            this.listbx_car.Location = new System.Drawing.Point(523, 225);
            this.listbx_car.Name = "listbx_car";
            this.listbx_car.SelectionMode = System.Windows.Forms.SelectionMode.MultiSimple;
            this.listbx_car.Size = new System.Drawing.Size(180, 199);
            this.listbx_car.TabIndex = 1;
            // 
            // listbx_altd
            // 
            this.listbx_altd.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.listbx_altd.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.listbx_altd.FormattingEnabled = true;
            this.listbx_altd.ItemHeight = 15;
            this.listbx_altd.Location = new System.Drawing.Point(827, 225);
            this.listbx_altd.Name = "listbx_altd";
            this.listbx_altd.SelectionMode = System.Windows.Forms.SelectionMode.MultiSimple;
            this.listbx_altd.Size = new System.Drawing.Size(195, 199);
            this.listbx_altd.TabIndex = 2;
            // 
            // btn_rghtarw
            // 
            this.btn_rghtarw.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_rghtarw.Location = new System.Drawing.Point(745, 272);
            this.btn_rghtarw.Name = "btn_rghtarw";
            this.btn_rghtarw.Size = new System.Drawing.Size(38, 33);
            this.btn_rghtarw.TabIndex = 3;
            this.btn_rghtarw.Text = ">";
            this.btn_rghtarw.UseVisualStyleBackColor = true;
            this.btn_rghtarw.Click += new System.EventHandler(this.rghtarw_btn_Click);
            // 
            // btn_rghtarw2
            // 
            this.btn_rghtarw2.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_rghtarw2.Location = new System.Drawing.Point(745, 311);
            this.btn_rghtarw2.Name = "btn_rghtarw2";
            this.btn_rghtarw2.Size = new System.Drawing.Size(38, 33);
            this.btn_rghtarw2.TabIndex = 4;
            this.btn_rghtarw2.Text = ">>";
            this.btn_rghtarw2.UseVisualStyleBackColor = true;
            this.btn_rghtarw2.Click += new System.EventHandler(this.rghtarw2_btn_Click);
            // 
            // btn_lftarw
            // 
            this.btn_lftarw.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_lftarw.Location = new System.Drawing.Point(745, 350);
            this.btn_lftarw.Name = "btn_lftarw";
            this.btn_lftarw.Size = new System.Drawing.Size(38, 33);
            this.btn_lftarw.TabIndex = 5;
            this.btn_lftarw.Text = "<";
            this.btn_lftarw.UseVisualStyleBackColor = true;
            this.btn_lftarw.Click += new System.EventHandler(this.lftarw_btn_Click);
            // 
            // btn_lftarw2
            // 
            this.btn_lftarw2.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_lftarw2.Location = new System.Drawing.Point(745, 389);
            this.btn_lftarw2.Name = "btn_lftarw2";
            this.btn_lftarw2.Size = new System.Drawing.Size(38, 33);
            this.btn_lftarw2.TabIndex = 6;
            this.btn_lftarw2.Text = "<<";
            this.btn_lftarw2.UseVisualStyleBackColor = true;
            this.btn_lftarw2.Click += new System.EventHandler(this.lftarw2_btn_Click);
            // 
            // lbl_drvrnme
            // 
            this.lbl_drvrnme.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_drvrnme.Location = new System.Drawing.Point(327, 199);
            this.lbl_drvrnme.Name = "lbl_drvrnme";
            this.lbl_drvrnme.Size = new System.Drawing.Size(129, 23);
            this.lbl_drvrnme.TabIndex = 7;
            this.lbl_drvrnme.Text = "DRIVER NAME";
            this.lbl_drvrnme.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl_carnmbr
            // 
            this.lbl_carnmbr.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_carnmbr.Location = new System.Drawing.Point(547, 199);
            this.lbl_carnmbr.Name = "lbl_carnmbr";
            this.lbl_carnmbr.Size = new System.Drawing.Size(129, 23);
            this.lbl_carnmbr.TabIndex = 8;
            this.lbl_carnmbr.Text = "CAR NUMBER";
            this.lbl_carnmbr.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl_altdlst
            // 
            this.lbl_altdlst.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_altdlst.Location = new System.Drawing.Point(855, 199);
            this.lbl_altdlst.Name = "lbl_altdlst";
            this.lbl_altdlst.Size = new System.Drawing.Size(129, 23);
            this.lbl_altdlst.TabIndex = 9;
            this.lbl_altdlst.Text = "ALOTTED LIST";
            this.lbl_altdlst.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Passing_Data_in_ListBox
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.ClientSize = new System.Drawing.Size(1034, 474);
            this.Controls.Add(this.lbl_altdlst);
            this.Controls.Add(this.lbl_carnmbr);
            this.Controls.Add(this.lbl_drvrnme);
            this.Controls.Add(this.btn_lftarw2);
            this.Controls.Add(this.btn_lftarw);
            this.Controls.Add(this.btn_rghtarw2);
            this.Controls.Add(this.btn_rghtarw);
            this.Controls.Add(this.listbx_altd);
            this.Controls.Add(this.listbx_car);
            this.Controls.Add(this.listbx_drvr);
            this.Name = "Passing_Data_in_ListBox";
            this.Text = "Passing Data in ListBox";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ListBox listbx_drvr;
        private System.Windows.Forms.ListBox listbx_car;
        private System.Windows.Forms.ListBox listbx_altd;
        private System.Windows.Forms.Button btn_rghtarw;
        private System.Windows.Forms.Button btn_rghtarw2;
        private System.Windows.Forms.Button btn_lftarw;
        private System.Windows.Forms.Button btn_lftarw2;
        private System.Windows.Forms.Label lbl_drvrnme;
        private System.Windows.Forms.Label lbl_carnmbr;
        private System.Windows.Forms.Label lbl_altdlst;
    }
}

