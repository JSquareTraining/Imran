﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Reflection;
using System.Resources;

namespace onlineexam
{
    public partial class Form3 : Form
    {
        
        public Form3()
        {
            InitializeComponent();
            
        }

        
        ResourceManager omr = new ResourceManager("onlineexam.Properties.Resources", Assembly.GetExecutingAssembly());
        Properties.Settings ha = new Properties.Settings();

       
        private void Form3_Load(object sender, EventArgs e)
        {
            
            if (ha.count == 4)
            {
                label3.Text = omr.GetString("ntlabel1");
                label5.Text = omr.GetString("ntlabel2");
                label7.Text = omr.GetString("ntlabel3");
                label9.Text = omr.GetString("ntlabel4");
                if (label3.Text == omr.GetString("ntlabel1") && label5.Text == omr.GetString("ntlabel2") && label7.Text == omr.GetString("ntlabel3") && label9.Text == omr.GetString("ntlabel4"))
                {
                    ntq1r1.Text = omr.GetString("ntq1ra1");
                    ntq1r2.Text = omr.GetString("ntq1ra2");
                    ntq1r3.Text = omr.GetString("ntq1ra3");
                    ntq1r4.Text = omr.GetString("ntq1ra4");

                    ntq2r1.Text = omr.GetString("ntq2ra1");
                    ntq2r2.Text = omr.GetString("ntq2ra2");
                    ntq2r3.Text = omr.GetString("ntq2ra3");
                    ntq2r4.Text = omr.GetString("ntq2ra4");

                    ntq3r1.Text = omr.GetString("ntq3ra1");
                    ntq3r2.Text = omr.GetString("ntq3ra2");
                    ntq3r3.Text = omr.GetString("ntq3ra3");
                    ntq3r4.Text = omr.GetString("ntq3ra4");

                    ntq4r1.Text = omr.GetString("ntq4ra1");
                    ntq4r2.Text = omr.GetString("ntq4ra2");
                    ntq4r3.Text = omr.GetString("ntq4ra3");
                    ntq4r4.Text = omr.GetString("ntq4ra4");

                }
                else
                {
                    MessageBox.Show("Error", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }

            else if (ha.count == 3)
            {
                label3.Text = omr.GetString("ntlabel3");
                label5.Text = omr.GetString("ntlabel1");
                label7.Text = omr.GetString("ntlabel4");
                label9.Text = omr.GetString("ntlabel2");

                if (label3.Text == omr.GetString("ntlabel3") && label5.Text == omr.GetString("ntlabel1") && label7.Text == omr.GetString("ntlabel4") && label9.Text == omr.GetString("ntlabel2"))
                {
                    ntq1r1.Text = omr.GetString("ntq3ra1");
                    ntq1r2.Text = omr.GetString("ntq3ra2");
                    ntq1r3.Text = omr.GetString("ntq3ra3");
                    ntq1r4.Text = omr.GetString("ntq3ra4");

                    ntq2r1.Text = omr.GetString("ntq1ra1");
                    ntq2r2.Text = omr.GetString("ntq1ra2");
                    ntq2r3.Text = omr.GetString("ntq1ra3");
                    ntq2r4.Text = omr.GetString("ntq1ra4");

                    ntq3r1.Text = omr.GetString("ntq4ra1");
                    ntq3r2.Text = omr.GetString("ntq4ra2");
                    ntq3r3.Text = omr.GetString("ntq4ra3");
                    ntq3r4.Text = omr.GetString("ntq4ra4");

                    ntq4r1.Text = omr.GetString("ntq2ra1");
                    ntq4r2.Text = omr.GetString("ntq2ra2");
                    ntq4r3.Text = omr.GetString("ntq2ra3");
                    ntq4r4.Text = omr.GetString("ntq2ra4");
                }
                else
                {
                    MessageBox.Show("Error", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else if (ha.count == 2)
            {
                label3.Text = omr.GetString("ntlabel2");
                label5.Text = omr.GetString("ntlabel4");
                label7.Text = omr.GetString("ntlabel3");
                label9.Text = omr.GetString("ntlabel1");

                if (label3.Text == omr.GetString("ntlabel2") && label5.Text == omr.GetString("ntlabel4") && label7.Text == omr.GetString("ntlabel3") && label9.Text == omr.GetString("ntlabel1"))
                {
                    ntq1r1.Text = omr.GetString("ntq2ra1");
                    ntq1r2.Text = omr.GetString("ntq2ra2");
                    ntq1r3.Text = omr.GetString("ntq2ra3");
                    ntq1r4.Text = omr.GetString("ntq2ra4");

                    ntq2r1.Text = omr.GetString("ntq4ra1");
                    ntq2r2.Text = omr.GetString("ntq4ra2");
                    ntq2r3.Text = omr.GetString("ntq4ra3");
                    ntq2r4.Text = omr.GetString("ntq4ra4");

                    ntq3r1.Text = omr.GetString("ntq3ra1");
                    ntq3r2.Text = omr.GetString("ntq3ra2");
                    ntq3r3.Text = omr.GetString("ntq3ra3");
                    ntq3r4.Text = omr.GetString("ntq3ra4");

                    ntq4r1.Text = omr.GetString("ntq1ra1");
                    ntq4r2.Text = omr.GetString("ntq1ra2");
                    ntq4r3.Text = omr.GetString("ntq1ra3");
                    ntq4r4.Text = omr.GetString("ntq1ra4");
                }
                else
                {
                    MessageBox.Show("Error", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else if (ha.count == 1)
            {   
                label3.Text = omr.GetString("ntlabel4");
                label5.Text = omr.GetString("ntlabel3");
                label7.Text = omr.GetString("ntlabel2");
                label9.Text = omr.GetString("ntlabel1");

                if (label3.Text == omr.GetString("ntlabel4") && label5.Text == omr.GetString("ntlabel3") && label7.Text == omr.GetString("ntlabel2") && label9.Text == omr.GetString("ntlabel1"))
                {

                    ntq1r1.Text = omr.GetString("ntq4ra1");
                    ntq1r2.Text = omr.GetString("ntq4ra2");
                    ntq1r3.Text = omr.GetString("ntq4ra3");
                    ntq1r4.Text = omr.GetString("ntq4ra4");

                    ntq2r1.Text = omr.GetString("ntq3ra1");
                    ntq2r2.Text = omr.GetString("ntq3ra2");
                    ntq2r3.Text = omr.GetString("ntq3ra3");
                    ntq2r4.Text = omr.GetString("ntq3ra4");

                    ntq3r1.Text = omr.GetString("ntq2ra1");
                    ntq3r2.Text = omr.GetString("ntq2ra2");
                    ntq3r3.Text = omr.GetString("ntq2ra3");
                    ntq3r4.Text = omr.GetString("ntq2ra4");

                    ntq4r1.Text = omr.GetString("ntq1ra1");
                    ntq4r2.Text = omr.GetString("ntq1ra2");
                    ntq4r3.Text = omr.GetString("ntq1ra3");
                    ntq4r4.Text = omr.GetString("ntq1ra4");
                }
                else
                {
                    MessageBox.Show("Error", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else
            {
                label3.Text = omr.GetString("ntlabel3");
                label5.Text = omr.GetString("ntlabel4");
                label7.Text = omr.GetString("ntlabel1");
                label9.Text = omr.GetString("ntlabel2");
               
                if (label3.Text == omr.GetString("ntlabel3") && label5.Text == omr.GetString("ntlabel4") && label7.Text == omr.GetString("ntlabel1") && label9.Text == omr.GetString("ntlabel2"))
                {
                    ntq1r1.Text = omr.GetString("ntq3ra1");
                    ntq1r2.Text = omr.GetString("ntq3ra2");
                    ntq1r3.Text = omr.GetString("ntq3ra3");
                    ntq1r4.Text = omr.GetString("ntq3ra4");

                    ntq2r1.Text = omr.GetString("ntq4ra1");
                    ntq2r2.Text = omr.GetString("ntq4ra2");
                    ntq2r3.Text = omr.GetString("ntq4ra3");
                    ntq2r4.Text = omr.GetString("ntq4ra4");

                    ntq3r1.Text = omr.GetString("ntq1ra1");
                    ntq3r2.Text = omr.GetString("ntq1ra2");
                    ntq3r3.Text = omr.GetString("ntq1ra3");
                    ntq3r4.Text = omr.GetString("ntq1ra4");

                    ntq4r1.Text = omr.GetString("ntq2ra1");
                    ntq4r2.Text = omr.GetString("ntq2ra2");
                    ntq4r3.Text = omr.GetString("ntq2ra3");
                    ntq4r4.Text = omr.GetString("ntq2ra4");
                }
                else
                {
                    MessageBox.Show("Error", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
           

        }

        private void button1_Click(object sender, EventArgs e)
        {
          

            if (checkBox3.Checked == true)
            {
                this.Hide();
                Form4 frm4 = new Form4();
                frm4.textBox5.Text = textBox4.Text;

                

                    if (checkBox4.Checked == true)
                    {
                        frm4.checkBox5.Checked = true;
                    }
                    else
                    {
                        frm4.checkBox5.Checked = false;
                    }
              if (ha.count == 4)
                 {

                    if (ntq1r1.Checked == true)
                    {
                        frm4.h1.Checked = true;
                    }
                    else
                    {
                        frm4.h1.Checked = false;
                    }

                    if (ntq2r3.Checked == true)
                    {
                        frm4.h2.Checked = true;
                    }
                    else
                    {
                        frm4.h2.Checked = false;
                    }

                    if (ntq3r4.Checked == true)
                    {
                        frm4.h3.Checked = true;
                    }
                    else
                    {
                        frm4.h3.Checked = false;
                    }

                    if (ntq4r3.Checked == true)
                    {
                        frm4.h4.Checked = true;
                    }
                    else
                    {
                        frm4.h4.Checked = false;
                    }
                  
                    frm4.ShowDialog();
                    
                }
                else if(ha.count == 3)
                {
                    if (ntq1r4.Checked == true)
                    {
                        frm4.h1.Checked = true;
                    }
                    else
                    {
                        frm4.h1.Checked = false;
                    }
                    if (ntq2r1.Checked == true)
                    {
                        frm4.h2.Checked = true;
                    }
                    else
                    {
                        frm4.h2.Checked = false;
                    }
                    if (ntq3r3.Checked == true)
                    {
                        frm4.h3.Checked = true;
                    }
                    else
                    {
                        frm4.h3.Checked = false;
                    }
                    if (ntq4r3.Checked == true)
                    {
                        frm4.h4.Checked = true;
                    }
                    else
                    {
                        frm4.h4.Checked = false;
                    }
                    frm4.ShowDialog();
                }

              else if(ha.count == 2)
                {
                    if (ntq1r3.Checked == true)
                    {
                        frm4.h1.Checked = true;
                    }
                  else
                    {
                        frm4.h1.Checked = false;
                    }

                  if(ntq2r3.Checked == true)
                  {
                      frm4.h2.Checked = true;
                  }
                  else
                  {
                      frm4.h2.Checked = false;
                  }
                  if(ntq3r4.Checked == true)
                  {
                      frm4.h3.Checked = true;
                  }
                  else
                  {
                      frm4.h3.Checked = false;
                  }
                  if (ntq4r1.Checked == true)
                  {
                      frm4.h4.Checked = true;
                  }
                  else
                  {
                      frm4.h4.Checked = false;
                  }
                  frm4.ShowDialog();
                }

              else if (ha.count == 1)
              {
                  if (ntq1r3.Checked == true)
                  {
                      frm4.h1.Checked = true;
                  }
                  else
                  {
                      frm4.h1.Checked = false;
                  }
                  if (ntq2r4.Checked == true)
                  {
                      frm4.h2.Checked = true;
                  }
                  else
                  {
                      frm4.h2.Checked = false;
                  }
                  if (ntq3r3.Checked == true)
                  {
                      frm4.h3.Checked = true;
                  }
                  else
                  {
                      frm4.h3.Checked = false;
                  }
                  if (ntq4r1.Checked == true)
                  {
                      frm4.h4.Checked = true;
                  }
                  else
                  {
                      frm4.h4.Checked = false;
                  }
                  frm4.ShowDialog();
              }

              else
              {
                  if (ntq1r4.Checked == true)
                  {
                      frm4.h1.Checked = true;
                  }
                  else
                  {
                      frm4.h1.Checked = false;
                  }
                  if (ntq2r3.Checked == true)
                  {
                      frm4.h2.Checked = true;
                  }
                  else
                  {
                      frm4.h2.Checked = false;
                  }
                  if (ntq3r1.Checked == true)
                  {
                      frm4.h3.Checked = true;
                  }
                  else
                  {
                      frm4.h3.Checked = false;
                  }
                  if (ntq4r3.Checked == true)
                  {
                      frm4.h4.Checked = true;
                  }
                  else
                  {
                      frm4.h4.Checked = false;
                  }
                  frm4.ShowDialog();
                  ha.count = ha.count + 4;
              }

            }
            else if (checkBox4.Checked == true)
            {
                this.Hide();
                Form5 frm5 = new Form5();
                frm5.textBox6.Text = textBox4.Text;

                if (ha.count == 4)
                {

                    if (ntq1r1.Checked == true)
                    {
                        frm5.h5.Checked = true;
                    }
                    else
                    {
                        frm5.h5.Checked = false;
                    }
                    if (ntq2r3.Checked == true)
                    {
                        frm5.h6.Checked = true;
                    }
                    else
                    {
                        frm5.h6.Checked = false;
                    }
                    if (ntq3r4.Checked == true)
                    {
                        frm5.h7.Checked = true;
                    }
                    else
                    {
                        frm5.h7.Checked = false;
                    }
                    if (ntq4r3.Checked == true)
                    {
                        frm5.h8.Checked = true;
                    }
                    else
                    {
                        frm5.h8.Checked = false;
                    }
                    frm5.ShowDialog();
                }
                else if (ha.count == 3)
                {
                    if (ntq1r4.Checked == true)
                    {
                        frm5.h5.Checked = true;
                    }
                    else
                    {
                        frm5.h5.Checked = false;
                    }
                    if (ntq2r1.Checked == true)
                    {
                        frm5.h6.Checked = true;
                    }
                    else
                    {
                        frm5.h6.Checked = false;
                    }
                    if (ntq3r3.Checked == true)
                    {
                        frm5.h7.Checked = true;
                    }
                    else
                    {
                        frm5.h7.Checked = false;
                    }
                    if (ntq4r3.Checked == true)
                    {
                        frm5.h8.Checked = true;
                    }
                    else
                    {
                        frm5.h8.Checked = false;
                    }
                    frm5.ShowDialog();

                }

                else if (ha.count == 2)
                {
                    if (ntq1r3.Checked == true)
                    {
                        frm5.h5.Checked = true;
                    }
                    else
                    {
                        frm5.h5.Checked = false;
                    }

                    if (ntq2r3.Checked == true)
                    {
                        frm5.h6.Checked = true;
                    }
                    else
                    {
                        frm5.h6.Checked = false;
                    }
                    if (ntq3r4.Checked == true)
                    {
                        frm5.h7.Checked = true;
                    }
                    else
                    {
                        frm5.h7.Checked = false;
                    }
                    if (ntq4r1.Checked == true)
                    {
                        frm5.h8.Checked = true;
                    }
                    else
                    {
                        frm5.h8.Checked = false;
                    }
                    frm5.ShowDialog();
                }

                else if (ha.count == 1)
                {
                    if (ntq1r3.Checked == true)
                    {
                        frm5.h5.Checked = true;
                    }
                    else
                    {
                        frm5.h5.Checked = false;
                    }
                    if (ntq2r4.Checked == true)
                    {
                        frm5.h6.Checked = true;
                    }
                    else
                    {
                        frm5.h6.Checked = false;
                    }
                    if (ntq3r3.Checked == true)
                    {
                        frm5.h7.Checked = true;
                    }
                    else
                    {
                        frm5.h7.Checked = false;
                    }
                    if (ntq4r1.Checked == true)
                    {
                        frm5.h8.Checked = true;
                    }
                    else
                    {
                        frm5.h8.Checked = false;
                    }
                    frm5.ShowDialog();
                }
                else
                {
                    if (ntq1r4.Checked == true)
                    {
                        frm5.h5.Checked = true;
                    }
                    else
                    {
                        frm5.h5.Checked = false;
                    }
                    if (ntq2r3.Checked == true)
                    {
                        frm5.h6.Checked = true;
                    }
                    else
                    {
                        frm5.h6.Checked = false;
                    }
                    if (ntq3r1.Checked == true)
                    {
                        frm5.h7.Checked = true;
                    }
                    else
                    {
                        frm5.h7.Checked = false;
                    }
                    if (ntq4r3.Checked == true)
                    {
                        frm5.h8.Checked = true;
                    }
                    else
                    {
                        frm5.h8.Checked = false;
                    }
                    ha.count = ha.count + 4;
                    ha.Save();
                    frm5.ShowDialog();
                    
                }
            }
            else
            {
                this.Hide();
                Form6 frm6 = new Form6();
                frm6.resltnme.Text = textBox4.Text;
                if (ha.count == 4)
                {
                    if (ntq1r1.Checked == true)
                    {
                        frm6.ntans1.Checked = true;
                    }
                    else
                    {
                        frm6.ntans1.Checked = false;
                    }
                    if (ntq2r3.Checked == true)
                    {
                        frm6.ntans2.Checked = true;
                    }
                    else
                    {
                        frm6.ntans2.Checked = false;
                    }
                    if (ntq3r4.Checked == true)
                    {
                        frm6.ntans3.Checked = true;
                    }
                    else
                    {
                        frm6.ntans3.Checked = false;
                    }
                    if (ntq4r3.Checked == true)
                    {
                        frm6.ntans4.Checked = true;
                    }
                    else
                    {
                        frm6.ntans4.Checked = false;
                    }
                    frm6.ShowDialog();
                }
                else if (ha.count == 3)
                {
                    if (ntq1r4.Checked == true)
                    {
                        frm6.ntans1.Checked = true;
                    }
                    else
                    {
                        frm6.ntans1.Checked = false;
                    }
                    if (ntq2r1.Checked == true)
                    {
                        frm6.ntans2.Checked = true;
                    }
                    else
                    {
                        frm6.ntans2.Checked = false;
                    }
                    if (ntq3r3.Checked == true)
                    {
                        frm6.ntans3.Checked = true;
                    }
                    else
                    {
                        frm6.ntans3.Checked = false;
                    }
                    if (ntq4r3.Checked == true)
                    {
                        frm6.ntans4.Checked = true;
                    }
                    else
                    {
                        frm6.ntans4.Checked = false;
                    }
                    frm6.ShowDialog();

                }
                else if (ha.count == 2)
                {
                    if (ntq1r3.Checked == true)
                    {
                        frm6.ntans1.Checked = true;
                    }
                    else
                    {
                        frm6.ntans1.Checked = false;
                    }

                    if (ntq2r3.Checked == true)
                    {
                        frm6.ntans2.Checked = true;
                    }
                    else
                    {
                        frm6.ntans2.Checked = false;
                    }
                    if (ntq3r4.Checked == true)
                    {
                        frm6.ntans3.Checked = true;
                    }
                    else
                    {
                        frm6.ntans3.Checked = false;
                    }
                    if (ntq4r1.Checked == true)
                    {
                        frm6.ntans4.Checked = true;
                    }
                    else
                    {
                        frm6.ntans4.Checked = false;
                    }
                    frm6.ShowDialog();
                }

                else if (ha.count == 1)
                {
                    if (ntq1r3.Checked == true)
                    {
                        frm6.ntans1.Checked = true;
                    }
                    else
                    {
                        frm6.ntans1.Checked = false;
                    }
                    if (ntq2r4.Checked == true)
                    {
                        frm6.ntans2.Checked = true;
                    }
                    else
                    {
                        frm6.ntans2.Checked = false;
                    }
                    if (ntq3r3.Checked == true)
                    {
                        frm6.ntans3.Checked = true;
                    }
                    else
                    {
                        frm6.ntans3.Checked = false;
                    }
                    if (ntq4r1.Checked == true)
                    {
                        frm6.ntans4.Checked = true;
                    }
                    else
                    {
                        frm6.ntans4.Checked = false;
                    }
                    frm6.ShowDialog();
                }
                else
                {
                    if (ntq1r4.Checked == true)
                    {
                        frm6.ntans1.Checked = true;
                    }
                    else
                    {
                        frm6.ntans1.Checked = false;
                    }
                    if (ntq2r3.Checked == true)
                    {
                        frm6.ntans2.Checked = true;
                    }
                    else
                    {
                        frm6.ntans2.Checked = false;
                    }
                    if (ntq3r1.Checked == true)
                    {
                        frm6.ntans3.Checked = true;
                    }
                    else
                    {
                        frm6.ntans3.Checked = false;
                    }
                    if (ntq4r3.Checked == true)
                    {
                        frm6.ntans4.Checked = true;
                    }
                    else
                    {
                        frm6.ntans4.Checked = false;
                    }
                    ha.count = ha.count + 4;
                    ha.Save();
                    frm6.ShowDialog();
                   
                }
            
            }
            
            
        }
    }
 }
