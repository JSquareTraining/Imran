﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace onlineexam
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }
     
        private void usrnmetxtbx_TextChanged(object sender, EventArgs e)
        {
            if (nmetxtbx.Text == "")
            {
                MessageBox.Show("Please enter the Name", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            
        }

        private void dobtxtbx_TextChanged(object sender, EventArgs e)
        {
            if (usrnmetxtbx.Text == "")
            {
                MessageBox.Show("Please enter the username", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            
        }

        private void emailidtxtbx_TextChanged(object sender, EventArgs e)
        {
            if (ntchckbx.Checked == false && cchkbx.Checked == false && cpluschckbx.Checked == false)
            {
                MessageBox.Show("Please choose the Course", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            
        }

        private void addrstxtbx_TextChanged(object sender, EventArgs e)
        {
            if (emailidtxtbx.Text == "")
            {
                MessageBox.Show("Please enter the Email Id", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            
        }

        private void sbmtbtn_Click(object sender, EventArgs e)
        {
            if (nmetxtbx.Text == "")
            {
                MessageBox.Show("Please enter the Name", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else if(usrnmetxtbx.Text == "")
            {
                MessageBox.Show("Please enter the username", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else if (ntchckbx.Checked == false && cchkbx.Checked == false && cpluschckbx.Checked == false)
            {
                MessageBox.Show("Please choose the Course", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else if (emailidtxtbx.Text == "")
            {
                MessageBox.Show("Please enter the Email Id", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else if (addrstxtbx.Text == "")
            {
                MessageBox.Show("Please enter the Address", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else if (accptchckbx.Checked == false)
            {
                MessageBox.Show("Please accept the Terms and Conditions", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error); 
            }
            
            else
            {
                MessageBox.Show("You have Registered Successfully", "Success", MessageBoxButtons.OK);
                this.Hide();

                Properties.Settings or = new Properties.Settings();
                or.username = usrnmetxtbx.Text;
                or.password = dobtxtbx.Text;
                or.Save();

                Form1 frm1 = new Form1();
                frm1.textBox3.Text = nmetxtbx.Text;
               
                if (ntchckbx.Checked == true)
                {
                    frm1.checkBox1.Checked = true;
                }
                else
                {
                    frm1.checkBox1.Checked = false;
                }
                if (cchkbx.Checked == true)
                {
                    frm1.checkBox2.Checked = true;
                }
                else
                {
                    frm1.checkBox2.Checked = false;
                }
                if (cpluschckbx.Checked == true)
                {
                    frm1.checkBox3.Checked = true;
                    Form4 frm4 = new Form4();
                    frm4.checkBox5.Checked = true;

                }
                else
                {
                    frm1.checkBox3.Checked = false;
                   
                }
                frm1.Show();

                
            }
        }

       

       
    }
}
