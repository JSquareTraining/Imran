﻿namespace onlineexam
{
    partial class Form3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.ntq1r4 = new System.Windows.Forms.RadioButton();
            this.ntq1r3 = new System.Windows.Forms.RadioButton();
            this.ntq1r2 = new System.Windows.Forms.RadioButton();
            this.ntq1r1 = new System.Windows.Forms.RadioButton();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.ntq2r2 = new System.Windows.Forms.RadioButton();
            this.ntq2r4 = new System.Windows.Forms.RadioButton();
            this.ntq2r3 = new System.Windows.Forms.RadioButton();
            this.ntq2r1 = new System.Windows.Forms.RadioButton();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.ntq3r4 = new System.Windows.Forms.RadioButton();
            this.ntq3r3 = new System.Windows.Forms.RadioButton();
            this.ntq3r2 = new System.Windows.Forms.RadioButton();
            this.ntq3r1 = new System.Windows.Forms.RadioButton();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.panel4 = new System.Windows.Forms.Panel();
            this.ntq4r4 = new System.Windows.Forms.RadioButton();
            this.ntq4r3 = new System.Windows.Forms.RadioButton();
            this.ntq4r2 = new System.Windows.Forms.RadioButton();
            this.ntq4r1 = new System.Windows.Forms.RadioButton();
            this.button1 = new System.Windows.Forms.Button();
            this.checkBox3 = new System.Windows.Forms.CheckBox();
            this.checkBox4 = new System.Windows.Forms.CheckBox();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel4.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("Times New Roman", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(334, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(214, 30);
            this.label1.TabIndex = 0;
            this.label1.Text = ".NET QUESTIONS";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label2
            // 
            this.label2.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(12, 78);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(34, 27);
            this.label2.TabIndex = 1;
            this.label2.Text = "1.";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label3
            // 
            this.label3.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(38, 65);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(735, 52);
            this.label3.TabIndex = 2;
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.ntq1r4);
            this.panel1.Controls.Add(this.ntq1r3);
            this.panel1.Controls.Add(this.ntq1r2);
            this.panel1.Controls.Add(this.ntq1r1);
            this.panel1.Location = new System.Drawing.Point(42, 121);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(254, 98);
            this.panel1.TabIndex = 3;
            // 
            // ntq1r4
            // 
            this.ntq1r4.AutoSize = true;
            this.ntq1r4.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ntq1r4.Location = new System.Drawing.Point(4, 76);
            this.ntq1r4.Name = "ntq1r4";
            this.ntq1r4.Size = new System.Drawing.Size(14, 13);
            this.ntq1r4.TabIndex = 3;
            this.ntq1r4.UseVisualStyleBackColor = true;
            // 
            // ntq1r3
            // 
            this.ntq1r3.AutoSize = true;
            this.ntq1r3.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ntq1r3.Location = new System.Drawing.Point(4, 52);
            this.ntq1r3.Name = "ntq1r3";
            this.ntq1r3.Size = new System.Drawing.Size(14, 13);
            this.ntq1r3.TabIndex = 2;
            this.ntq1r3.UseVisualStyleBackColor = true;
            // 
            // ntq1r2
            // 
            this.ntq1r2.AutoSize = true;
            this.ntq1r2.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ntq1r2.Location = new System.Drawing.Point(4, 28);
            this.ntq1r2.Name = "ntq1r2";
            this.ntq1r2.Size = new System.Drawing.Size(14, 13);
            this.ntq1r2.TabIndex = 1;
            this.ntq1r2.UseVisualStyleBackColor = true;
            // 
            // ntq1r1
            // 
            this.ntq1r1.AutoSize = true;
            this.ntq1r1.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ntq1r1.Location = new System.Drawing.Point(4, 4);
            this.ntq1r1.Name = "ntq1r1";
            this.ntq1r1.Size = new System.Drawing.Size(14, 13);
            this.ntq1r1.TabIndex = 0;
            this.ntq1r1.UseVisualStyleBackColor = true;
            // 
            // label4
            // 
            this.label4.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(12, 236);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(34, 27);
            this.label4.TabIndex = 4;
            this.label4.Text = "2.";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label5
            // 
            this.label5.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(38, 229);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(735, 40);
            this.label5.TabIndex = 5;
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.ntq2r2);
            this.panel2.Controls.Add(this.ntq2r4);
            this.panel2.Controls.Add(this.ntq2r3);
            this.panel2.Controls.Add(this.ntq2r1);
            this.panel2.Location = new System.Drawing.Point(42, 272);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(254, 107);
            this.panel2.TabIndex = 4;
            // 
            // ntq2r2
            // 
            this.ntq2r2.AutoSize = true;
            this.ntq2r2.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ntq2r2.Location = new System.Drawing.Point(4, 31);
            this.ntq2r2.Name = "ntq2r2";
            this.ntq2r2.Size = new System.Drawing.Size(14, 13);
            this.ntq2r2.TabIndex = 1;
            this.ntq2r2.TabStop = true;
            this.ntq2r2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ntq2r2.UseVisualStyleBackColor = true;
            // 
            // ntq2r4
            // 
            this.ntq2r4.AutoSize = true;
            this.ntq2r4.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ntq2r4.Location = new System.Drawing.Point(5, 83);
            this.ntq2r4.Name = "ntq2r4";
            this.ntq2r4.Size = new System.Drawing.Size(14, 13);
            this.ntq2r4.TabIndex = 3;
            this.ntq2r4.TabStop = true;
            this.ntq2r4.UseVisualStyleBackColor = true;
            // 
            // ntq2r3
            // 
            this.ntq2r3.AutoSize = true;
            this.ntq2r3.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ntq2r3.Location = new System.Drawing.Point(5, 57);
            this.ntq2r3.Name = "ntq2r3";
            this.ntq2r3.Size = new System.Drawing.Size(14, 13);
            this.ntq2r3.TabIndex = 2;
            this.ntq2r3.TabStop = true;
            this.ntq2r3.UseVisualStyleBackColor = true;
            // 
            // ntq2r1
            // 
            this.ntq2r1.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ntq2r1.Location = new System.Drawing.Point(5, 4);
            this.ntq2r1.Name = "ntq2r1";
            this.ntq2r1.Size = new System.Drawing.Size(246, 21);
            this.ntq2r1.TabIndex = 0;
            this.ntq2r1.TabStop = true;
            this.ntq2r1.UseVisualStyleBackColor = true;
            // 
            // label6
            // 
            this.label6.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(12, 389);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(34, 27);
            this.label6.TabIndex = 6;
            this.label6.Text = "3.";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label7
            // 
            this.label7.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(38, 382);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(735, 40);
            this.label7.TabIndex = 7;
            this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.ntq3r4);
            this.panel3.Controls.Add(this.ntq3r3);
            this.panel3.Controls.Add(this.ntq3r2);
            this.panel3.Controls.Add(this.ntq3r1);
            this.panel3.Location = new System.Drawing.Point(42, 419);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(254, 98);
            this.panel3.TabIndex = 5;
            // 
            // ntq3r4
            // 
            this.ntq3r4.AutoSize = true;
            this.ntq3r4.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ntq3r4.Location = new System.Drawing.Point(4, 76);
            this.ntq3r4.Name = "ntq3r4";
            this.ntq3r4.Size = new System.Drawing.Size(14, 13);
            this.ntq3r4.TabIndex = 3;
            this.ntq3r4.TabStop = true;
            this.ntq3r4.UseVisualStyleBackColor = true;
            // 
            // ntq3r3
            // 
            this.ntq3r3.AutoSize = true;
            this.ntq3r3.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ntq3r3.Location = new System.Drawing.Point(4, 52);
            this.ntq3r3.Name = "ntq3r3";
            this.ntq3r3.Size = new System.Drawing.Size(14, 13);
            this.ntq3r3.TabIndex = 2;
            this.ntq3r3.TabStop = true;
            this.ntq3r3.UseVisualStyleBackColor = true;
            // 
            // ntq3r2
            // 
            this.ntq3r2.AutoSize = true;
            this.ntq3r2.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ntq3r2.Location = new System.Drawing.Point(4, 28);
            this.ntq3r2.Name = "ntq3r2";
            this.ntq3r2.Size = new System.Drawing.Size(14, 13);
            this.ntq3r2.TabIndex = 1;
            this.ntq3r2.TabStop = true;
            this.ntq3r2.UseVisualStyleBackColor = true;
            // 
            // ntq3r1
            // 
            this.ntq3r1.AutoSize = true;
            this.ntq3r1.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ntq3r1.Location = new System.Drawing.Point(4, 4);
            this.ntq3r1.Name = "ntq3r1";
            this.ntq3r1.Size = new System.Drawing.Size(14, 13);
            this.ntq3r1.TabIndex = 0;
            this.ntq3r1.TabStop = true;
            this.ntq3r1.UseVisualStyleBackColor = true;
            // 
            // label8
            // 
            this.label8.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(12, 529);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(34, 27);
            this.label8.TabIndex = 8;
            this.label8.Text = "4.";
            this.label8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label9
            // 
            this.label9.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(38, 522);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(735, 40);
            this.label9.TabIndex = 9;
            this.label9.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.ntq4r4);
            this.panel4.Controls.Add(this.ntq4r3);
            this.panel4.Controls.Add(this.ntq4r2);
            this.panel4.Controls.Add(this.ntq4r1);
            this.panel4.Location = new System.Drawing.Point(42, 559);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(254, 98);
            this.panel4.TabIndex = 6;
            // 
            // ntq4r4
            // 
            this.ntq4r4.AutoSize = true;
            this.ntq4r4.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ntq4r4.Location = new System.Drawing.Point(4, 76);
            this.ntq4r4.Name = "ntq4r4";
            this.ntq4r4.Size = new System.Drawing.Size(14, 13);
            this.ntq4r4.TabIndex = 3;
            this.ntq4r4.TabStop = true;
            this.ntq4r4.UseVisualStyleBackColor = true;
            // 
            // ntq4r3
            // 
            this.ntq4r3.AutoSize = true;
            this.ntq4r3.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ntq4r3.Location = new System.Drawing.Point(4, 52);
            this.ntq4r3.Name = "ntq4r3";
            this.ntq4r3.Size = new System.Drawing.Size(14, 13);
            this.ntq4r3.TabIndex = 2;
            this.ntq4r3.TabStop = true;
            this.ntq4r3.UseVisualStyleBackColor = true;
            // 
            // ntq4r2
            // 
            this.ntq4r2.AutoSize = true;
            this.ntq4r2.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ntq4r2.Location = new System.Drawing.Point(4, 28);
            this.ntq4r2.Name = "ntq4r2";
            this.ntq4r2.Size = new System.Drawing.Size(14, 13);
            this.ntq4r2.TabIndex = 1;
            this.ntq4r2.TabStop = true;
            this.ntq4r2.UseVisualStyleBackColor = true;
            // 
            // ntq4r1
            // 
            this.ntq4r1.AutoSize = true;
            this.ntq4r1.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ntq4r1.Location = new System.Drawing.Point(4, 4);
            this.ntq4r1.Name = "ntq4r1";
            this.ntq4r1.Size = new System.Drawing.Size(14, 13);
            this.ntq4r1.TabIndex = 0;
            this.ntq4r1.TabStop = true;
            this.ntq4r1.UseVisualStyleBackColor = true;
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(416, 678);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(96, 39);
            this.button1.TabIndex = 10;
            this.button1.Text = "Next";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // checkBox3
            // 
            this.checkBox3.AutoSize = true;
            this.checkBox3.Location = new System.Drawing.Point(799, 21);
            this.checkBox3.Name = "checkBox3";
            this.checkBox3.Size = new System.Drawing.Size(15, 14);
            this.checkBox3.TabIndex = 11;
            this.checkBox3.UseVisualStyleBackColor = true;
            this.checkBox3.Visible = false;
            // 
            // checkBox4
            // 
            this.checkBox4.AutoSize = true;
            this.checkBox4.Location = new System.Drawing.Point(799, 45);
            this.checkBox4.Name = "checkBox4";
            this.checkBox4.Size = new System.Drawing.Size(15, 14);
            this.checkBox4.TabIndex = 12;
            this.checkBox4.UseVisualStyleBackColor = true;
            this.checkBox4.Visible = false;
            // 
            // textBox4
            // 
            this.textBox4.BackColor = System.Drawing.Color.LightSteelBlue;
            this.textBox4.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox4.Location = new System.Drawing.Point(710, 125);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(209, 13);
            this.textBox4.TabIndex = 13;
            this.textBox4.Visible = false;
            // 
            // Form3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.LightSteelBlue;
            this.ClientSize = new System.Drawing.Size(931, 741);
            this.Controls.Add(this.textBox4);
            this.Controls.Add(this.checkBox4);
            this.Controls.Add(this.checkBox3);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Form3";
            this.Text = ".Net Questions";
            this.Load += new System.EventHandler(this.Form3_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.RadioButton ntq1r4;
        private System.Windows.Forms.RadioButton ntq1r3;
        private System.Windows.Forms.RadioButton ntq1r2;
        private System.Windows.Forms.RadioButton ntq1r1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.RadioButton ntq2r4;
        private System.Windows.Forms.RadioButton ntq2r3;
        private System.Windows.Forms.RadioButton ntq2r1;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.RadioButton ntq3r4;
        private System.Windows.Forms.RadioButton ntq3r3;
        private System.Windows.Forms.RadioButton ntq3r2;
        private System.Windows.Forms.RadioButton ntq3r1;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.RadioButton ntq4r4;
        private System.Windows.Forms.RadioButton ntq4r3;
        private System.Windows.Forms.RadioButton ntq4r2;
        private System.Windows.Forms.RadioButton ntq4r1;
        private System.Windows.Forms.Button button1;
        public System.Windows.Forms.CheckBox checkBox3;
        public System.Windows.Forms.CheckBox checkBox4;
        public System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.RadioButton ntq2r2;
    }
}