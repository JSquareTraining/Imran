﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace onlineexam
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        Properties.Settings or1 = new Properties.Settings();
        private void Lgnbtn_Click(object sender, EventArgs e)
        {
            if (usrnmetxtbx.Text == "" && pswdtxtbx.Text == "")
            {
                MessageBox.Show("Please enter the Username and Password", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else if (usrnmetxtbx.Text == "")
            {
                MessageBox.Show("Please enter the Username", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else if (pswdtxtbx.Text == "")
            {
                MessageBox.Show("Please enter the Password", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else if (usrnmetxtbx.Text ==or1.username  && pswdtxtbx.Text == or1.password)
            {
                DialogResult lgn = new DialogResult();
                lgn = MessageBox.Show("You have Logged in Successfully", "Success", MessageBoxButtons.OK);
                if (lgn == DialogResult.OK)
                {
                    if (checkBox1.Checked == true)
                    {
                        this.Hide();
                        Form3 frm3 = new Form3();
                        frm3.textBox4.Text = textBox3.Text;
                        if (checkBox2.Checked == true)
                        {
                            frm3.checkBox3.Checked = true;
                        }
                        else
                        {
                            frm3.checkBox3.Checked = false;
                        }
                        if (checkBox3.Checked == true)
                        {
                            frm3.checkBox4.Checked = true;
                        }
                        else
                        {
                            frm3.checkBox4.Checked = false;
                        }
                        frm3.ShowDialog();
                    }
                    else if (checkBox2.Checked == true)
                    {
                        this.Hide();
                        Form4 frm4 = new Form4();
                        frm4.textBox5.Text = textBox3.Text;
                        frm4.checkBox5.Checked = true;
                        frm4.ShowDialog();
                    }
                    else
                    {
                        this.Hide();
                        Form5 frm5 = new Form5();
                        frm5.textBox6.Text = textBox3.Text;
                        frm5.ShowDialog();
                    }

                }
            }
            else
            {
                MessageBox.Show("Please enter the Correct Username/Password", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void Regstrbtn_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form2 frm2 = new Form2();
            frm2.ShowDialog();

        }

       
    }
}
