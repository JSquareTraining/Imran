﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Reflection;
using System.Resources;

namespace onlineexam
{
    public partial class Form4 : Form
    {
        public Form4()
        {
            InitializeComponent();
        }
       
        ResourceManager omr = new ResourceManager("onlineexam.Properties.Resources", Assembly.GetExecutingAssembly());
        Properties.Settings ha = new Properties.Settings();


        private void Form4_Load(object sender, EventArgs e)
        {
            
            ha.count = ha.count - 1;
            ha.Save();

            if (ha.count == 4)
            {
                label3.Text = omr.GetString("clabel1");
                label5.Text = omr.GetString("clabel2");
                label7.Text = omr.GetString("clabel3");
                label9.Text = omr.GetString("clabel4");

                if (label3.Text == omr.GetString("clabel1") && label5.Text == omr.GetString("clabel2") && label7.Text == omr.GetString("clabel3") && label9.Text == omr.GetString("clabel4"))
                {
                    cq1r1.Text = omr.GetString("cq1ra1");
                    cq1r2.Text = omr.GetString("cq1ra2");
                    cq1r3.Text = omr.GetString("cq1ra3");
                    cq1r4.Text = omr.GetString("cq1ra4");

                    cq2r1.Text = omr.GetString("cq2ra1");
                    cq2r2.Text = omr.GetString("cq2ra2");
                    cq2r3.Text = omr.GetString("cq2ra3");
                    cq2r4.Text = omr.GetString("cq2ra4");

                    cq3r1.Text = omr.GetString("cq3ra1");
                    cq3r2.Text = omr.GetString("cq3ra2");
                    cq3r3.Text = omr.GetString("cq3ra3");
                    cq3r4.Text = omr.GetString("cq3ra4");

                    cq4r1.Text = omr.GetString("cq4ra1");
                    cq4r2.Text = omr.GetString("cq4ra2");
                    cq4r3.Text = omr.GetString("cq4ra3");
                    cq4r4.Text = omr.GetString("cq4ra4");

                }
                else
                {
                    MessageBox.Show("Error", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }

            }

            else if (ha.count == 3)
            {
                label3.Text = omr.GetString("clabel3");
                label5.Text = omr.GetString("clabel1");
                label7.Text = omr.GetString("clabel4");
                label9.Text = omr.GetString("clabel2");

                if (label3.Text == omr.GetString("clabel3") && label5.Text == omr.GetString("clabel1") && label7.Text == omr.GetString("clabel4") && label9.Text == omr.GetString("clabel2"))
                {
                    cq1r1.Text = omr.GetString("cq3ra1");
                    cq1r2.Text = omr.GetString("cq3ra2");
                    cq1r3.Text = omr.GetString("cq3ra3");
                    cq1r4.Text = omr.GetString("cq3ra4");

                    cq2r1.Text = omr.GetString("cq1ra1");
                    cq2r2.Text = omr.GetString("cq1ra2");
                    cq2r3.Text = omr.GetString("cq1ra3");
                    cq2r4.Text = omr.GetString("cq1ra4");

                    cq3r1.Text = omr.GetString("cq4ra1");
                    cq3r2.Text = omr.GetString("cq4ra2");
                    cq3r3.Text = omr.GetString("cq4ra3");
                    cq3r4.Text = omr.GetString("cq4ra4");

                    cq4r1.Text = omr.GetString("cq2ra1");
                    cq4r2.Text = omr.GetString("cq2ra2");
                    cq4r3.Text = omr.GetString("cq2ra3");
                    cq4r4.Text = omr.GetString("cq2ra4");
                }
                else
                {
                    MessageBox.Show("Error", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }

            else if (ha.count == 2)
            {
                label3.Text = omr.GetString("clabel2");
                label5.Text = omr.GetString("clabel4");
                label7.Text = omr.GetString("clabel3");
                label9.Text = omr.GetString("clabel1");
                if (label3.Text == omr.GetString("clabel2") && label5.Text == omr.GetString("clabel4") && label7.Text == omr.GetString("clabel3") && label9.Text == omr.GetString("clabel1"))
                {
                    cq1r1.Text = omr.GetString("cq2ra1");
                    cq1r2.Text = omr.GetString("cq2ra2");
                    cq1r3.Text = omr.GetString("cq2ra3");
                    cq1r4.Text = omr.GetString("cq2ra4");

                    cq2r1.Text = omr.GetString("cq4ra1");
                    cq2r2.Text = omr.GetString("cq4ra2");
                    cq2r3.Text = omr.GetString("cq4ra3");
                    cq2r4.Text = omr.GetString("cq4ra4");

                    cq3r1.Text = omr.GetString("cq3ra1");
                    cq3r2.Text = omr.GetString("cq3ra2");
                    cq3r3.Text = omr.GetString("cq3ra3");
                    cq3r4.Text = omr.GetString("cq3ra4");

                    cq4r1.Text = omr.GetString("cq1ra1");
                    cq4r2.Text = omr.GetString("cq1ra2");
                    cq4r3.Text = omr.GetString("cq1ra3");
                    cq4r4.Text = omr.GetString("cq1ra4");

                }
                else
                {
                    MessageBox.Show("Error", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }

            }
            else if (ha.count == 1)
            {
                label3.Text = omr.GetString("clabel4");
                label5.Text = omr.GetString("clabel3");
                label7.Text = omr.GetString("clabel2");
                label9.Text = omr.GetString("clabel1");
                if (label3.Text == omr.GetString("clabel4") && label5.Text == omr.GetString("clabel3") && label7.Text == omr.GetString("clabel2") && label9.Text == omr.GetString("clabel1"))
                {
                    cq1r1.Text = omr.GetString("cq4ra1");
                    cq1r2.Text = omr.GetString("cq4ra2");
                    cq1r3.Text = omr.GetString("cq4ra3");
                    cq1r4.Text = omr.GetString("cq4ra4");

                    cq2r1.Text = omr.GetString("cq3ra1");
                    cq2r2.Text = omr.GetString("cq3ra2");
                    cq2r3.Text = omr.GetString("cq3ra3");
                    cq2r4.Text = omr.GetString("cq3ra4");

                    cq3r1.Text = omr.GetString("cq2ra1");
                    cq3r2.Text = omr.GetString("cq2ra2");
                    cq3r3.Text = omr.GetString("cq2ra3");
                    cq3r4.Text = omr.GetString("cq2ra4");

                    cq4r1.Text = omr.GetString("cq1ra1");
                    cq4r2.Text = omr.GetString("cq1ra2");
                    cq4r3.Text = omr.GetString("cq1ra3");
                    cq4r4.Text = omr.GetString("cq1ra4");

                }
                else
                {
                    MessageBox.Show("Error", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else
            {
                label3.Text = omr.GetString("clabel3");
                label5.Text = omr.GetString("clabel4");
                label7.Text = omr.GetString("clabel1");
                label9.Text = omr.GetString("clabel2");

                if (label3.Text == omr.GetString("clabel3") && label5.Text == omr.GetString("clabel4") && label7.Text == omr.GetString("clabel1") && label9.Text == omr.GetString("clabel2"))
                {
                    cq1r1.Text = omr.GetString("cq3ra1");
                    cq1r2.Text = omr.GetString("cq3ra2");
                    cq1r3.Text = omr.GetString("cq3ra3");
                    cq1r4.Text = omr.GetString("cq3ra4");

                    cq2r1.Text = omr.GetString("cq4ra1");
                    cq2r2.Text = omr.GetString("cq4ra2");
                    cq2r3.Text = omr.GetString("cq4ra3");
                    cq2r4.Text = omr.GetString("cq4ra4");

                    cq3r1.Text = omr.GetString("cq1ra1");
                    cq3r2.Text = omr.GetString("cq1ra2");
                    cq3r3.Text = omr.GetString("cq1ra3");
                    cq3r4.Text = omr.GetString("cq1ra4");

                    cq4r1.Text = omr.GetString("cq2ra1");
                    cq4r2.Text = omr.GetString("cq2ra2");
                    cq4r3.Text = omr.GetString("cq2ra3");
                    cq4r4.Text = omr.GetString("cq2ra4");

                }
                else
                {
                    MessageBox.Show("Error", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }

        }
        private void button1_Click(object sender, EventArgs e)
        {
            

            if (checkBox5.Checked == true)
            {
                this.Hide();
                Form5 frm5 = new Form5();
                frm5.textBox6.Text = textBox5.Text;
                if (h1.Checked == true)
                {
                    frm5.h5.Checked = true;
                }
                else
                {
                    frm5.h5.Checked = false;
                }
                if (h2.Checked == true)
                {
                    frm5.h6.Checked = true;
                }
                else
                {
                    frm5.h6.Checked = false;
                }
                if (h3.Checked == true)
                {
                    frm5.h7.Checked = true;
                }
                else
                {
                    frm5.h7.Checked = false;
                }
                if (h4.Checked == true)
                {
                    frm5.h8.Checked = true;
                }
                else
                {
                    frm5.h8.Checked = false;
                }



                if (ha.count == 4)
                {
                    if (cq1r3.Checked == true)
                    {
                        frm5.h9.Checked = true;
                    }
                    else
                    {
                        frm5.h9.Checked = false;
                    }
                    if (cq2r4.Checked == true)
                    {
                        frm5.h10.Checked = true;
                    }
                    else
                    {
                        frm5.h10.Checked = false;
                    }
                    if (cq3r2.Checked == true)
                    {
                        frm5.h11.Checked = true;
                    }
                    else
                    {
                        frm5.h11.Checked = false;
                    }
                    if (cq4r1.Checked == true)
                    {
                        frm5.h12.Checked = true;
                    }
                    else
                    {
                        frm5.h12.Checked = false;
                    }
                    frm5.ShowDialog();
                }

                else if (ha.count == 3)
                {
                    if (cq1r2.Checked == true)
                    {
                        frm5.h11.Checked = true;
                    }
                    else
                    {
                        frm5.h11.Checked = false;
                    }
                    if (cq2r3.Checked == true)
                    {
                        frm5.h9.Checked = true;
                    }
                    else
                    {
                        frm5.h9.Checked = false;
                    }
                    if (cq3r1.Checked == true)
                    {
                        frm5.h12.Checked = true;
                    }
                    else
                    {
                        frm5.h12.Checked = false;
                    }
                    if (cq4r4.Checked == true)
                    {
                        frm5.h10.Checked = true;
                    }
                    else
                    {
                        frm5.h10.Checked = false;
                    }
                    frm5.ShowDialog();
                }
                else if (ha.count == 2)
                {
                    if (cq1r4.Checked == true)
                    {
                        frm5.h11.Checked = true;
                    }
                    else
                    {
                        frm5.h11.Checked = false;
                    }
                    if (cq2r1.Checked == true)
                    {
                        frm5.h9.Checked = true;
                    }
                    else
                    {
                        frm5.h9.Checked = false;
                    }
                    if (cq3r2.Checked == true)
                    {
                        frm5.h12.Checked = true;
                    }
                    else
                    {
                        frm5.h12.Checked = false;
                    }
                    if (cq4r3.Checked == true)
                    {
                        frm5.h10.Checked = true;
                    }
                    else
                    {
                        frm5.h10.Checked = false;
                    }
                    frm5.ShowDialog();
                }
                else if (ha.count == 1)
                {
                    if (cq1r1.Checked == true)
                    {
                        frm5.h11.Checked = true;
                    }
                    else
                    {
                        frm5.h11.Checked = false;
                    }
                    if (cq2r2.Checked == true)
                    {
                        frm5.h9.Checked = true;
                    }
                    else
                    {
                        frm5.h9.Checked = false;
                    }
                    if (cq3r4.Checked == true)
                    {
                        frm5.h12.Checked = true;
                    }
                    else
                    {
                        frm5.h12.Checked = false;
                    }
                    if (cq4r3.Checked == true)
                    {
                        frm5.h10.Checked = true;
                    }
                    else
                    {
                        frm5.h10.Checked = false;
                    }
                    frm5.ShowDialog();
                }

                else
                {

                    if (cq1r2.Checked == true)
                    {
                        frm5.h11.Checked = true;
                    }
                    else
                    {
                        frm5.h11.Checked = false;
                    }
                    if (cq2r1.Checked == true)
                    {
                        frm5.h9.Checked = true;
                    }
                    else
                    {
                        frm5.h9.Checked = false;
                    }
                    if (cq3r3.Checked == true)
                    {
                        frm5.h12.Checked = true;
                    }
                    else
                    {
                        frm5.h12.Checked = false;
                    }
                    if (cq4r4.Checked == true)
                    {
                        frm5.h10.Checked = true;
                    }
                    else
                    {
                        frm5.h10.Checked = false;
                    }
                    ha.count = ha.count + 3;
                    frm5.ShowDialog();
                    
                }
            }
            else
            {
                this.Hide();
                Form6 frm6 = new Form6();
                frm6.resltnme.Text = textBox5.Text;
                if (h1.Checked == true)
                {
                    frm6.ntans1.Checked = true;
                }
                else
                {
                    frm6.ntans1.Checked = false;
                }
                if (h2.Checked == true)
                {
                    frm6.ntans2.Checked = true;
                }
                else
                {
                    frm6.ntans2.Checked = false;
                }
                if (h3.Checked == true)
                {
                    frm6.ntans3.Checked = true;
                }
                else
                {
                    frm6.ntans3.Checked = false;
                }
                if (h4.Checked == true)
                {
                    frm6.ntans4.Checked = true;
                }
                else
                {
                    frm6.ntans4.Checked = false;
                }

                if (ha.count == 4)
                {
                    if (cq1r3.Checked == true)
                    {
                        frm6.cans1.Checked = true;
                    }
                    else
                    {
                        frm6.cans1.Checked = false;
                    }
                    if (cq2r4.Checked == true)
                    {
                        frm6.cans2.Checked = true;
                    }
                    else
                    {
                        frm6.cans2.Checked = false;
                    }
                    if (cq3r2.Checked == true)
                    {
                        frm6.cans3.Checked = true;
                    }
                    else
                    {
                        frm6.cans3.Checked = false;
                    }
                    if (cq4r1.Checked == true)
                    {
                        frm6.cans4.Checked = true;
                    }
                    else
                    {
                        frm6.cans4.Checked = false;
                    }
                    frm6.ShowDialog();
                }
                else if (ha.count == 3)
                {
                    if (cq1r2.Checked == true)
                    {
                        frm6.cans1.Checked = true;
                    }
                    else
                    {
                        frm6.cans1.Checked = false;
                    }
                    if (cq2r3.Checked == true)
                    {
                        frm6.cans2.Checked = true;
                    }
                    else
                    {
                        frm6.cans2.Checked = false;
                    }
                    if (cq3r1.Checked == true)
                    {
                        frm6.cans3.Checked = true;
                    }
                    else
                    {
                        frm6.cans3.Checked = false;
                    }
                    if (cq4r4.Checked == true)
                    {
                        frm6.cans4.Checked = true;
                    }
                    else
                    {
                        frm6.cans4.Checked = false;
                    }
                    frm6.ShowDialog();
                }
                else if (ha.count == 2)
                {
                    if (cq1r4.Checked == true)
                    {
                        frm6.cans1.Checked = true;
                    }
                    else
                    {
                        frm6.cans1.Checked = false;
                    }
                    if (cq2r1.Checked == true)
                    {
                        frm6.cans2.Checked = true;
                    }
                    else
                    {
                        frm6.cans2.Checked = false;
                    }
                    if (cq3r2.Checked == true)
                    {
                        frm6.cans3.Checked = true;
                    }
                    else
                    {
                        frm6.cans3.Checked = false;
                    }
                    if (cq4r3.Checked == true)
                    {
                        frm6.cans4.Checked = true;
                    }
                    else
                    {
                        frm6.cans4.Checked = false;
                    }
                    frm6.ShowDialog();
                }
                else if (ha.count == 1)
                {
                    if (cq1r1.Checked == true)
                    {
                        frm6.cans1.Checked = true;
                    }
                    else
                    {
                        frm6.cans1.Checked = false;
                    }
                    if (cq2r2.Checked == true)
                    {
                        frm6.cans2.Checked = true;
                    }
                    else
                    {
                        frm6.cans2.Checked = false;
                    }
                    if (cq3r4.Checked == true)
                    {
                        frm6.cans3.Checked = true;
                    }
                    else
                    {
                        frm6.cans3.Checked = false;
                    }
                    if (cq4r3.Checked == true)
                    {
                        frm6.cans4.Checked = true;
                    }
                    else
                    {
                        frm6.cans4.Checked = false;
                    }
                    frm6.ShowDialog();
                }
                else
                {
                    if (cq1r2.Checked == true)
                    {
                        frm6.cans1.Checked = true;
                    }
                    else
                    {
                        frm6.cans1.Checked = false;
                    }
                    if (cq2r1.Checked == true)
                    {
                        frm6.cans2.Checked = true;
                    }
                    else
                    {
                        frm6.cans2.Checked = false;
                    }
                    if (cq3r3.Checked == true)
                    {
                        frm6.cans3.Checked = true;
                    }
                    else
                    {
                        frm6.cans3.Checked = false;
                    }
                    if (cq4r4.Checked == true)
                    {
                        frm6.cans4.Checked = true;
                    }
                    else
                    {
                        frm6.cans4.Checked = false;
                    }
                    ha.count = ha.count + 3;
                    ha.Save();
                    frm6.ShowDialog();
                    
                }
            }
        }

    }
}
