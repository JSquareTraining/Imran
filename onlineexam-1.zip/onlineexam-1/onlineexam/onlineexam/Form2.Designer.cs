﻿namespace onlineexam
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.accptchckbx = new System.Windows.Forms.CheckBox();
            this.sbmtbtn = new System.Windows.Forms.Button();
            this.nmetxtbx = new System.Windows.Forms.TextBox();
            this.usrnmetxtbx = new System.Windows.Forms.TextBox();
            this.dobtxtbx = new System.Windows.Forms.TextBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.fmlerdbtn = new System.Windows.Forms.RadioButton();
            this.mlerdbtn = new System.Windows.Forms.RadioButton();
            this.ntchckbx = new System.Windows.Forms.CheckBox();
            this.cchkbx = new System.Windows.Forms.CheckBox();
            this.cpluschckbx = new System.Windows.Forms.CheckBox();
            this.emailidtxtbx = new System.Windows.Forms.TextBox();
            this.addrstxtbx = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(159, 86);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(220, 39);
            this.label1.TabIndex = 0;
            this.label1.Text = "NAME";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label3
            // 
            this.label3.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ImageAlign = System.Drawing.ContentAlignment.BottomRight;
            this.label3.Location = new System.Drawing.Point(183, 167);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(220, 39);
            this.label3.TabIndex = 2;
            this.label3.Text = "DATE OF BIRTH";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label4
            // 
            this.label4.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ImageAlign = System.Drawing.ContentAlignment.BottomRight;
            this.label4.Location = new System.Drawing.Point(159, 203);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(220, 39);
            this.label4.TabIndex = 3;
            this.label4.Text = "GENDER";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label5
            // 
            this.label5.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ImageAlign = System.Drawing.ContentAlignment.BottomRight;
            this.label5.Location = new System.Drawing.Point(159, 276);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(220, 39);
            this.label5.TabIndex = 4;
            this.label5.Text = "COURSE";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label6
            // 
            this.label6.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ImageAlign = System.Drawing.ContentAlignment.BottomRight;
            this.label6.Location = new System.Drawing.Point(159, 352);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(220, 39);
            this.label6.TabIndex = 5;
            this.label6.Text = "EMAIL-ID";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label7
            // 
            this.label7.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ImageAlign = System.Drawing.ContentAlignment.BottomRight;
            this.label7.Location = new System.Drawing.Point(159, 391);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(220, 39);
            this.label7.TabIndex = 6;
            this.label7.Text = "ADDRESS";
            this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label2
            // 
            this.label2.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ImageAlign = System.Drawing.ContentAlignment.BottomRight;
            this.label2.Location = new System.Drawing.Point(159, 125);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(220, 39);
            this.label2.TabIndex = 1;
            this.label2.Text = "USERNAME";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label8
            // 
            this.label8.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(367, 480);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(327, 27);
            this.label8.TabIndex = 7;
            this.label8.Text = "I Accept the terms and Conditions";
            // 
            // accptchckbx
            // 
            this.accptchckbx.Location = new System.Drawing.Point(342, 480);
            this.accptchckbx.Name = "accptchckbx";
            this.accptchckbx.Size = new System.Drawing.Size(19, 27);
            this.accptchckbx.TabIndex = 8;
            this.accptchckbx.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.accptchckbx.UseVisualStyleBackColor = true;
            // 
            // sbmtbtn
            // 
            this.sbmtbtn.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.sbmtbtn.Location = new System.Drawing.Point(452, 519);
            this.sbmtbtn.Name = "sbmtbtn";
            this.sbmtbtn.Size = new System.Drawing.Size(82, 32);
            this.sbmtbtn.TabIndex = 9;
            this.sbmtbtn.Text = "Submit";
            this.sbmtbtn.UseVisualStyleBackColor = true;
            this.sbmtbtn.Click += new System.EventHandler(this.sbmtbtn_Click);
            // 
            // nmetxtbx
            // 
            this.nmetxtbx.Font = new System.Drawing.Font("Lucida Calligraphy", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nmetxtbx.Location = new System.Drawing.Point(396, 92);
            this.nmetxtbx.Name = "nmetxtbx";
            this.nmetxtbx.Size = new System.Drawing.Size(269, 33);
            this.nmetxtbx.TabIndex = 10;
            // 
            // usrnmetxtbx
            // 
            this.usrnmetxtbx.Font = new System.Drawing.Font("Lucida Calligraphy", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.usrnmetxtbx.Location = new System.Drawing.Point(396, 131);
            this.usrnmetxtbx.Name = "usrnmetxtbx";
            this.usrnmetxtbx.Size = new System.Drawing.Size(269, 33);
            this.usrnmetxtbx.TabIndex = 11;
            this.usrnmetxtbx.TextChanged += new System.EventHandler(this.usrnmetxtbx_TextChanged);
            // 
            // dobtxtbx
            // 
            this.dobtxtbx.Font = new System.Drawing.Font("Lucida Calligraphy", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dobtxtbx.Location = new System.Drawing.Point(396, 170);
            this.dobtxtbx.Name = "dobtxtbx";
            this.dobtxtbx.Size = new System.Drawing.Size(269, 33);
            this.dobtxtbx.TabIndex = 12;
            this.dobtxtbx.TextChanged += new System.EventHandler(this.dobtxtbx_TextChanged);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.fmlerdbtn);
            this.panel1.Controls.Add(this.mlerdbtn);
            this.panel1.Location = new System.Drawing.Point(396, 210);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(200, 62);
            this.panel1.TabIndex = 13;
            // 
            // fmlerdbtn
            // 
            this.fmlerdbtn.AutoSize = true;
            this.fmlerdbtn.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.fmlerdbtn.Location = new System.Drawing.Point(42, 35);
            this.fmlerdbtn.Name = "fmlerdbtn";
            this.fmlerdbtn.Size = new System.Drawing.Size(76, 23);
            this.fmlerdbtn.TabIndex = 1;
            this.fmlerdbtn.Text = "Female";
            this.fmlerdbtn.UseVisualStyleBackColor = true;
            // 
            // mlerdbtn
            // 
            this.mlerdbtn.AutoSize = true;
            this.mlerdbtn.Checked = true;
            this.mlerdbtn.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mlerdbtn.Location = new System.Drawing.Point(42, 6);
            this.mlerdbtn.Name = "mlerdbtn";
            this.mlerdbtn.Size = new System.Drawing.Size(63, 23);
            this.mlerdbtn.TabIndex = 0;
            this.mlerdbtn.TabStop = true;
            this.mlerdbtn.Text = "Male";
            this.mlerdbtn.UseVisualStyleBackColor = true;
            // 
            // ntchckbx
            // 
            this.ntchckbx.AutoSize = true;
            this.ntchckbx.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ntchckbx.Location = new System.Drawing.Point(438, 278);
            this.ntchckbx.Name = "ntchckbx";
            this.ntchckbx.Size = new System.Drawing.Size(64, 23);
            this.ntchckbx.TabIndex = 14;
            this.ntchckbx.Text = ".NET";
            this.ntchckbx.UseVisualStyleBackColor = true;
            // 
            // cchkbx
            // 
            this.cchkbx.AutoSize = true;
            this.cchkbx.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cchkbx.Location = new System.Drawing.Point(438, 301);
            this.cchkbx.Name = "cchkbx";
            this.cchkbx.Size = new System.Drawing.Size(39, 23);
            this.cchkbx.TabIndex = 15;
            this.cchkbx.Text = "C";
            this.cchkbx.UseVisualStyleBackColor = true;
            // 
            // cpluschckbx
            // 
            this.cpluschckbx.AutoSize = true;
            this.cpluschckbx.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cpluschckbx.Location = new System.Drawing.Point(438, 324);
            this.cpluschckbx.Name = "cpluschckbx";
            this.cpluschckbx.Size = new System.Drawing.Size(57, 23);
            this.cpluschckbx.TabIndex = 16;
            this.cpluschckbx.Text = "C++";
            this.cpluschckbx.UseVisualStyleBackColor = true;
            // 
            // emailidtxtbx
            // 
            this.emailidtxtbx.Font = new System.Drawing.Font("Lucida Calligraphy", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.emailidtxtbx.Location = new System.Drawing.Point(396, 352);
            this.emailidtxtbx.Name = "emailidtxtbx";
            this.emailidtxtbx.Size = new System.Drawing.Size(269, 33);
            this.emailidtxtbx.TabIndex = 17;
            this.emailidtxtbx.TextChanged += new System.EventHandler(this.emailidtxtbx_TextChanged);
            // 
            // addrstxtbx
            // 
            this.addrstxtbx.Font = new System.Drawing.Font("Lucida Calligraphy", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.addrstxtbx.Location = new System.Drawing.Point(396, 391);
            this.addrstxtbx.Multiline = true;
            this.addrstxtbx.Name = "addrstxtbx";
            this.addrstxtbx.Size = new System.Drawing.Size(269, 73);
            this.addrstxtbx.TabIndex = 18;
            this.addrstxtbx.TextChanged += new System.EventHandler(this.addrstxtbx_TextChanged);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Times New Roman", 18F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(351, 27);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(272, 26);
            this.label9.TabIndex = 19;
            this.label9.Text = "REGISTRATION FORM";
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.LightSteelBlue;
            this.ClientSize = new System.Drawing.Size(995, 573);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.addrstxtbx);
            this.Controls.Add(this.emailidtxtbx);
            this.Controls.Add(this.cpluschckbx);
            this.Controls.Add(this.cchkbx);
            this.Controls.Add(this.ntchckbx);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.dobtxtbx);
            this.Controls.Add(this.usrnmetxtbx);
            this.Controls.Add(this.nmetxtbx);
            this.Controls.Add(this.sbmtbtn);
            this.Controls.Add(this.accptchckbx);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Form2";
            this.Text = "Registration Form";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.CheckBox accptchckbx;
        private System.Windows.Forms.Button sbmtbtn;
        private System.Windows.Forms.TextBox usrnmetxtbx;
        private System.Windows.Forms.TextBox dobtxtbx;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.RadioButton mlerdbtn;
        private System.Windows.Forms.RadioButton fmlerdbtn;
        private System.Windows.Forms.TextBox emailidtxtbx;
        private System.Windows.Forms.TextBox addrstxtbx;
        private System.Windows.Forms.Label label9;
        public System.Windows.Forms.CheckBox ntchckbx;
        public System.Windows.Forms.CheckBox cchkbx;
        public System.Windows.Forms.CheckBox cpluschckbx;
        public System.Windows.Forms.TextBox nmetxtbx;
    }
}