﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Reflection;
using System.Resources;

namespace onlineexam
{
    public partial class Form5 : Form
    {
        public Form5()
        {
            InitializeComponent();
        }
        ResourceManager omr = new ResourceManager("onlineexam.Properties.Resources", Assembly.GetExecutingAssembly());
        Properties.Settings ha = new Properties.Settings();

        

        private void Form5_Load(object sender, EventArgs e)
        {
            

            if (ha.count == 4)
            {
                label3.Text = omr.GetString("cplabel1");
                label5.Text = omr.GetString("cplabel2");
                label7.Text = omr.GetString("cplabel3");
                label9.Text = omr.GetString("cplabel4");

                if (label3.Text == omr.GetString("cplabel1") && label5.Text == omr.GetString("cplabel2") && label7.Text == omr.GetString("cplabel3") && label9.Text == omr.GetString("cplabel4"))
                {
                    cpq1r1.Text = omr.GetString("cpq1ra1");
                    cpq1r2.Text = omr.GetString("cpq1ra2");
                    cpq1r3.Text = omr.GetString("cpq1ra3");
                    cpq1r4.Text = omr.GetString("cpq1ra4");

                    cpq2r1.Text = omr.GetString("cpq2ra1");
                    cpq2r2.Text = omr.GetString("cpq2ra2");
                    cpq2r3.Text = omr.GetString("cpq2ra3");
                    cpq2r4.Text = omr.GetString("cpq2ra4");

                    cpq3r1.Text = omr.GetString("cpq3ra1");
                    cpq3r2.Text = omr.GetString("cpq3ra2");
                    cpq3r3.Text = omr.GetString("cpq3ra3");
                    cpq3r4.Text = omr.GetString("cpq3ra4");

                    cpq4r1.Text = omr.GetString("cpq4ra1");
                    cpq4r2.Text = omr.GetString("cpq4ra2");
                    cpq4r3.Text = omr.GetString("cpq4ra3");
                    cpq4r4.Text = omr.GetString("cpq4ra4");
                }
                else
                {
                    MessageBox.Show("Error", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }

            else if (ha.count == 3)
            {
                label3.Text = omr.GetString("cplabel3");
                label5.Text = omr.GetString("cplabel1");
                label7.Text = omr.GetString("cplabel4");
                label9.Text = omr.GetString("cplabel2");

                if (label3.Text == omr.GetString("cplabel3") && label5.Text == omr.GetString("cplabel1") && label7.Text == omr.GetString("cplabel4") && label9.Text == omr.GetString("cplabel2"))
                {
                    cpq1r1.Text = omr.GetString("cpq3ra1");
                    cpq1r2.Text = omr.GetString("cpq3ra2");
                    cpq1r3.Text = omr.GetString("cpq3ra3");
                    cpq1r4.Text = omr.GetString("cpq3ra4");

                    cpq2r1.Text = omr.GetString("cpq1ra1");
                    cpq2r2.Text = omr.GetString("cpq1ra2");
                    cpq2r3.Text = omr.GetString("cpq1ra3");
                    cpq2r4.Text = omr.GetString("cpq1ra4");

                    cpq3r1.Text = omr.GetString("cpq4ra1");
                    cpq3r2.Text = omr.GetString("cpq4ra2");
                    cpq3r3.Text = omr.GetString("cpq4ra3");
                    cpq3r4.Text = omr.GetString("cpq4ra4");

                    cpq4r1.Text = omr.GetString("cpq2ra1");
                    cpq4r2.Text = omr.GetString("cpq2ra2");
                    cpq4r3.Text = omr.GetString("cpq2ra3");
                    cpq4r4.Text = omr.GetString("cpq2ra4");
                }
                else
                {
                    MessageBox.Show("Error", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else if (ha.count == 2)
            {
                label3.Text = omr.GetString("cplabel2");
                label5.Text = omr.GetString("cplabel4");
                label7.Text = omr.GetString("cplabel3");
                label9.Text = omr.GetString("cplabel1");

                if (label3.Text == omr.GetString("cplabel2") && label5.Text == omr.GetString("cplabel4") && label7.Text == omr.GetString("cplabel3") && label9.Text == omr.GetString("cplabel1"))
                {
                    cpq1r1.Text = omr.GetString("cpq2ra1");
                    cpq1r2.Text = omr.GetString("cpq2ra2");
                    cpq1r3.Text = omr.GetString("cpq2ra3");
                    cpq1r4.Text = omr.GetString("cpq2ra4");

                    cpq2r1.Text = omr.GetString("cpq4ra1");
                    cpq2r2.Text = omr.GetString("cpq4ra2");
                    cpq2r3.Text = omr.GetString("cpq4ra3");
                    cpq2r4.Text = omr.GetString("cpq4ra4");

                    cpq3r1.Text = omr.GetString("cpq3ra1");
                    cpq3r2.Text = omr.GetString("cpq3ra2");
                    cpq3r3.Text = omr.GetString("cpq3ra3");
                    cpq3r4.Text = omr.GetString("cpq3ra4");

                    cpq4r1.Text = omr.GetString("cpq1ra1");
                    cpq4r2.Text = omr.GetString("cpq1ra2");
                    cpq4r3.Text = omr.GetString("cpq1ra3");
                    cpq4r4.Text = omr.GetString("cpq1ra4");
                }
                else
                {
                    MessageBox.Show("Error", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else if (ha.count == 1)
            {
                label3.Text = omr.GetString("cplabel4");
                label5.Text = omr.GetString("cplabel3");
                label7.Text = omr.GetString("cplabel2");
                label9.Text = omr.GetString("cplabel1");

                if (label3.Text == omr.GetString("cplabel4") && label5.Text == omr.GetString("cplabel3") && label7.Text == omr.GetString("cplabel2") && label9.Text == omr.GetString("cplabel1"))
                {
                    cpq1r1.Text = omr.GetString("cpq4ra1");
                    cpq1r2.Text = omr.GetString("cpq4ra2");
                    cpq1r3.Text = omr.GetString("cpq4ra3");
                    cpq1r4.Text = omr.GetString("cpq4ra4");

                    cpq2r1.Text = omr.GetString("cpq3ra1");
                    cpq2r2.Text = omr.GetString("cpq3ra2");
                    cpq2r3.Text = omr.GetString("cpq3ra3");
                    cpq2r4.Text = omr.GetString("cpq3ra4");

                    cpq3r1.Text = omr.GetString("cpq2ra1");
                    cpq3r2.Text = omr.GetString("cpq2ra2");
                    cpq3r3.Text = omr.GetString("cpq2ra3");
                    cpq3r4.Text = omr.GetString("cpq2ra4");

                    cpq4r1.Text = omr.GetString("cpq1ra1");
                    cpq4r2.Text = omr.GetString("cpq1ra2");
                    cpq4r3.Text = omr.GetString("cpq1ra3");
                    cpq4r4.Text = omr.GetString("cpq1ra4");
                }
                else
                {
                    MessageBox.Show("Error", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }

            else
            {
                label3.Text = omr.GetString("cplabel3");
                label5.Text = omr.GetString("cplabel4");
                label7.Text = omr.GetString("cplabel1");
                label9.Text = omr.GetString("cplabel2");

                if (label3.Text == omr.GetString("cplabel3") && label5.Text == omr.GetString("cplabel4") && label7.Text == omr.GetString("cplabel1") && label9.Text == omr.GetString("cplabel2"))
                {
                    cpq1r1.Text = omr.GetString("cpq3ra1");
                    cpq1r2.Text = omr.GetString("cpq3ra2");
                    cpq1r3.Text = omr.GetString("cpq3ra3");
                    cpq1r4.Text = omr.GetString("cpq3ra4");

                    cpq2r1.Text = omr.GetString("cpq4ra1");
                    cpq2r2.Text = omr.GetString("cpq4ra2");
                    cpq2r3.Text = omr.GetString("cpq4ra3");
                    cpq2r4.Text = omr.GetString("cpq4ra4");

                    cpq3r1.Text = omr.GetString("cpq1ra1");
                    cpq3r2.Text = omr.GetString("cpq1ra2");
                    cpq3r3.Text = omr.GetString("cpq1ra3");
                    cpq3r4.Text = omr.GetString("cpq1ra4");

                    cpq4r1.Text = omr.GetString("cpq2ra1");
                    cpq4r2.Text = omr.GetString("cpq2ra2");
                    cpq4r3.Text = omr.GetString("cpq2ra3");
                    cpq4r4.Text = omr.GetString("cpq2ra4");
                }
                else
                {
                    MessageBox.Show("Error", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }



        }

        private void button1_Click(object sender, EventArgs e)
        {
           

            this.Hide();
            Form6 frm6 = new Form6();
            frm6.resltnme.Text = textBox6.Text;
            if (h5.Checked == true)
            {
                frm6.ntans1.Checked = true;
            }
            else
            {
                frm6.ntans1.Checked = false;
            }
            if (h6.Checked == true)
            {
                frm6.ntans2.Checked = true;
            }
            else
            {
                frm6.ntans2.Checked = false;
            }
            if (h7.Checked == true)
            {
                frm6.ntans3.Checked = true;
            }
            else
            {
                frm6.ntans3.Checked = false;
            }
            if (h8.Checked == true)
            {
                frm6.ntans4.Checked = true;
            }
            else
            {
                frm6.ntans4.Checked = false;
            }

            if (h9.Checked == true)
            {
                frm6.cans1.Checked = true;
            }
            else
            {
                frm6.cans1.Checked = false;
            }
            if (h10.Checked == true)
            {
                frm6.cans2.Checked = true;
            }
            else
            {
                frm6.cans2.Checked = false;
            }
            if (h11.Checked == true)
            {
                frm6.cans3.Checked = true;
            }
            else
            {
                frm6.cans3.Checked = false;
            }
            if (h12.Checked == true)
            {
                frm6.cans4.Checked = true;
            }
            else
            {
                frm6.cans4.Checked = false;
            }

            if (ha.count == 4)
            {

                if (cpq1r3.Checked == true)
                {
                    frm6.cpans1.Checked = true;
                }
                else
                {
                    frm6.cpans2.Checked = false;
                }
                if (cpq2r1.Checked == true)
                {
                    frm6.cpans2.Checked = true;
                }
                else
                {
                    frm6.cpans2.Checked = false;
                }
                if (cpq3r3.Checked == true)
                {
                    frm6.cpans3.Checked = true;
                }
                else
                {
                    frm6.cpans3.Checked = false;
                }
                if (cpq4r2.Checked == true)
                {
                    frm6.cpans4.Checked = true;
                }
                else
                {
                    frm6.cpans4.Checked = false;
                }
                frm6.ShowDialog();
            }

            else if (ha.count == 3)
            {
                if (cpq1r3.Checked == true)
                {
                    frm6.cpans1.Checked = true;
                }
                else
                {
                    frm6.cpans2.Checked = false;
                }
                if (cpq2r3.Checked == true)
                {
                    frm6.cpans2.Checked = true;
                }
                else
                {
                    frm6.cpans2.Checked = false;
                }
                if (cpq3r2.Checked == true)
                {
                    frm6.cpans3.Checked = true;
                }
                else
                {
                    frm6.cpans3.Checked = false;
                }
                if (cpq4r1.Checked == true)
                {
                    frm6.cpans4.Checked = true;
                }
                else
                {
                    frm6.cpans4.Checked = false;
                }
                frm6.ShowDialog();
            }
            else if (ha.count == 2)
            {
                if (cpq1r1.Checked == true)
                {
                    frm6.cpans1.Checked = true;
                }
                else
                {
                    frm6.cpans2.Checked = false;
                }
                if (cpq2r2.Checked == true)
                {
                    frm6.cpans2.Checked = true;
                }
                else
                {
                    frm6.cpans2.Checked = false;
                }
                if (cpq3r3.Checked == true)
                {
                    frm6.cpans3.Checked = true;
                }
                else
                {
                    frm6.cpans3.Checked = false;
                }
                if (cpq4r3.Checked == true)
                {
                    frm6.cpans4.Checked = true;
                }
                else
                {
                    frm6.cpans4.Checked = false;
                }
                frm6.ShowDialog();
            }
            else if (ha.count == 1)
            {
                if (cpq1r2.Checked == true)
                {
                    frm6.cpans1.Checked = true;
                }
                else
                {
                    frm6.cpans2.Checked = false;
                }
                if (cpq2r3.Checked == true)
                {
                    frm6.cpans2.Checked = true;
                }
                else
                {
                    frm6.cpans2.Checked = false;
                }
                if (cpq3r1.Checked == true)
                {
                    frm6.cpans3.Checked = true;
                }
                else
                {
                    frm6.cpans3.Checked = false;
                }
                if (cpq4r3.Checked == true)
                {
                    frm6.cpans4.Checked = true;
                }
                else
                {
                    frm6.cpans4.Checked = false;
                }
                frm6.ShowDialog();
            }
            else
            {
                if (cpq1r3.Checked == true)
                {
                    frm6.cpans1.Checked = true;
                }
                else
                {
                    frm6.cpans2.Checked = false;
                }
                if (cpq2r2.Checked == true)
                {
                    frm6.cpans2.Checked = true;
                }
                else
                {
                    frm6.cpans2.Checked = false;
                }
                if (cpq3r3.Checked == true)
                {
                    frm6.cpans3.Checked = true;
                }
                else
                {
                    frm6.cpans3.Checked = false;
                }
                if (cpq4r1.Checked == true)
                {
                    frm6.cpans4.Checked = true;
                }
                else
                {
                    frm6.cpans4.Checked = false;
                }
                ha.count = ha.count + 3; 
                frm6.ShowDialog();
            }

        }

       

        
    }
}
