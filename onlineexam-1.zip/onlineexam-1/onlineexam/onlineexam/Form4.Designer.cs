﻿namespace onlineexam
{
    partial class Form4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.panel4 = new System.Windows.Forms.Panel();
            this.cq4r4 = new System.Windows.Forms.RadioButton();
            this.cq4r3 = new System.Windows.Forms.RadioButton();
            this.cq4r2 = new System.Windows.Forms.RadioButton();
            this.cq4r1 = new System.Windows.Forms.RadioButton();
            this.cq2r4 = new System.Windows.Forms.RadioButton();
            this.cq2r3 = new System.Windows.Forms.RadioButton();
            this.cq2r2 = new System.Windows.Forms.RadioButton();
            this.cq3r4 = new System.Windows.Forms.RadioButton();
            this.cq1r2 = new System.Windows.Forms.RadioButton();
            this.cq3r3 = new System.Windows.Forms.RadioButton();
            this.cq3r2 = new System.Windows.Forms.RadioButton();
            this.cq3r1 = new System.Windows.Forms.RadioButton();
            this.panel3 = new System.Windows.Forms.Panel();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.cq1r4 = new System.Windows.Forms.RadioButton();
            this.cq1r3 = new System.Windows.Forms.RadioButton();
            this.cq1r1 = new System.Windows.Forms.RadioButton();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.cq2r1 = new System.Windows.Forms.RadioButton();
            this.button1 = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.checkBox5 = new System.Windows.Forms.CheckBox();
            this.h1 = new System.Windows.Forms.CheckBox();
            this.h2 = new System.Windows.Forms.CheckBox();
            this.h3 = new System.Windows.Forms.CheckBox();
            this.h4 = new System.Windows.Forms.CheckBox();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.panel4.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // label9
            // 
            this.label9.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(56, 533);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(735, 40);
            this.label9.TabIndex = 23;
            this.label9.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label8
            // 
            this.label8.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(30, 540);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(34, 27);
            this.label8.TabIndex = 22;
            this.label8.Text = "4.";
            this.label8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.cq4r4);
            this.panel4.Controls.Add(this.cq4r3);
            this.panel4.Controls.Add(this.cq4r2);
            this.panel4.Controls.Add(this.cq4r1);
            this.panel4.Location = new System.Drawing.Point(60, 586);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(254, 98);
            this.panel4.TabIndex = 19;
            // 
            // cq4r4
            // 
            this.cq4r4.AutoSize = true;
            this.cq4r4.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cq4r4.Location = new System.Drawing.Point(4, 76);
            this.cq4r4.Name = "cq4r4";
            this.cq4r4.Size = new System.Drawing.Size(14, 13);
            this.cq4r4.TabIndex = 3;
            this.cq4r4.TabStop = true;
            this.cq4r4.UseVisualStyleBackColor = true;
            // 
            // cq4r3
            // 
            this.cq4r3.AutoSize = true;
            this.cq4r3.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cq4r3.Location = new System.Drawing.Point(4, 52);
            this.cq4r3.Name = "cq4r3";
            this.cq4r3.Size = new System.Drawing.Size(14, 13);
            this.cq4r3.TabIndex = 2;
            this.cq4r3.TabStop = true;
            this.cq4r3.UseVisualStyleBackColor = true;
            // 
            // cq4r2
            // 
            this.cq4r2.AutoSize = true;
            this.cq4r2.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cq4r2.Location = new System.Drawing.Point(4, 28);
            this.cq4r2.Name = "cq4r2";
            this.cq4r2.Size = new System.Drawing.Size(14, 13);
            this.cq4r2.TabIndex = 1;
            this.cq4r2.TabStop = true;
            this.cq4r2.UseVisualStyleBackColor = true;
            // 
            // cq4r1
            // 
            this.cq4r1.AutoSize = true;
            this.cq4r1.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cq4r1.Location = new System.Drawing.Point(4, 4);
            this.cq4r1.Name = "cq4r1";
            this.cq4r1.Size = new System.Drawing.Size(14, 13);
            this.cq4r1.TabIndex = 0;
            this.cq4r1.TabStop = true;
            this.cq4r1.UseVisualStyleBackColor = true;
            // 
            // cq2r4
            // 
            this.cq2r4.AutoSize = true;
            this.cq2r4.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cq2r4.Location = new System.Drawing.Point(4, 76);
            this.cq2r4.Name = "cq2r4";
            this.cq2r4.Size = new System.Drawing.Size(14, 13);
            this.cq2r4.TabIndex = 3;
            this.cq2r4.TabStop = true;
            this.cq2r4.UseVisualStyleBackColor = true;
            // 
            // cq2r3
            // 
            this.cq2r3.AutoSize = true;
            this.cq2r3.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cq2r3.Location = new System.Drawing.Point(4, 52);
            this.cq2r3.Name = "cq2r3";
            this.cq2r3.Size = new System.Drawing.Size(14, 13);
            this.cq2r3.TabIndex = 2;
            this.cq2r3.TabStop = true;
            this.cq2r3.UseVisualStyleBackColor = true;
            // 
            // cq2r2
            // 
            this.cq2r2.AutoSize = true;
            this.cq2r2.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cq2r2.Location = new System.Drawing.Point(4, 28);
            this.cq2r2.Name = "cq2r2";
            this.cq2r2.Size = new System.Drawing.Size(14, 13);
            this.cq2r2.TabIndex = 1;
            this.cq2r2.TabStop = true;
            this.cq2r2.UseVisualStyleBackColor = true;
            // 
            // cq3r4
            // 
            this.cq3r4.AutoSize = true;
            this.cq3r4.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cq3r4.Location = new System.Drawing.Point(4, 76);
            this.cq3r4.Name = "cq3r4";
            this.cq3r4.Size = new System.Drawing.Size(14, 13);
            this.cq3r4.TabIndex = 3;
            this.cq3r4.TabStop = true;
            this.cq3r4.UseVisualStyleBackColor = true;
            // 
            // cq1r2
            // 
            this.cq1r2.AutoSize = true;
            this.cq1r2.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cq1r2.Location = new System.Drawing.Point(4, 28);
            this.cq1r2.Name = "cq1r2";
            this.cq1r2.Size = new System.Drawing.Size(14, 13);
            this.cq1r2.TabIndex = 1;
            this.cq1r2.UseVisualStyleBackColor = true;
            // 
            // cq3r3
            // 
            this.cq3r3.AutoSize = true;
            this.cq3r3.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cq3r3.Location = new System.Drawing.Point(4, 52);
            this.cq3r3.Name = "cq3r3";
            this.cq3r3.Size = new System.Drawing.Size(14, 13);
            this.cq3r3.TabIndex = 2;
            this.cq3r3.TabStop = true;
            this.cq3r3.UseVisualStyleBackColor = true;
            // 
            // cq3r2
            // 
            this.cq3r2.AutoSize = true;
            this.cq3r2.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cq3r2.Location = new System.Drawing.Point(4, 28);
            this.cq3r2.Name = "cq3r2";
            this.cq3r2.Size = new System.Drawing.Size(14, 13);
            this.cq3r2.TabIndex = 1;
            this.cq3r2.TabStop = true;
            this.cq3r2.UseVisualStyleBackColor = true;
            // 
            // cq3r1
            // 
            this.cq3r1.AutoSize = true;
            this.cq3r1.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cq3r1.Location = new System.Drawing.Point(4, 4);
            this.cq3r1.Name = "cq3r1";
            this.cq3r1.Size = new System.Drawing.Size(14, 13);
            this.cq3r1.TabIndex = 0;
            this.cq3r1.TabStop = true;
            this.cq3r1.UseVisualStyleBackColor = true;
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.cq3r4);
            this.panel3.Controls.Add(this.cq3r3);
            this.panel3.Controls.Add(this.cq3r2);
            this.panel3.Controls.Add(this.cq3r1);
            this.panel3.Location = new System.Drawing.Point(60, 430);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(254, 98);
            this.panel3.TabIndex = 17;
            // 
            // label7
            // 
            this.label7.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(56, 393);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(735, 40);
            this.label7.TabIndex = 21;
            this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label6
            // 
            this.label6.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(30, 400);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(34, 27);
            this.label6.TabIndex = 20;
            this.label6.Text = "3.";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.cq1r4);
            this.panel1.Controls.Add(this.cq1r3);
            this.panel1.Controls.Add(this.cq1r2);
            this.panel1.Controls.Add(this.cq1r1);
            this.panel1.Location = new System.Drawing.Point(60, 132);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(254, 98);
            this.panel1.TabIndex = 14;
            // 
            // cq1r4
            // 
            this.cq1r4.AutoSize = true;
            this.cq1r4.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cq1r4.Location = new System.Drawing.Point(4, 76);
            this.cq1r4.Name = "cq1r4";
            this.cq1r4.Size = new System.Drawing.Size(14, 13);
            this.cq1r4.TabIndex = 3;
            this.cq1r4.UseVisualStyleBackColor = true;
            // 
            // cq1r3
            // 
            this.cq1r3.AutoSize = true;
            this.cq1r3.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cq1r3.Location = new System.Drawing.Point(4, 52);
            this.cq1r3.Name = "cq1r3";
            this.cq1r3.Size = new System.Drawing.Size(14, 13);
            this.cq1r3.TabIndex = 2;
            this.cq1r3.UseVisualStyleBackColor = true;
            // 
            // cq1r1
            // 
            this.cq1r1.AutoSize = true;
            this.cq1r1.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cq1r1.Location = new System.Drawing.Point(4, 4);
            this.cq1r1.Name = "cq1r1";
            this.cq1r1.Size = new System.Drawing.Size(14, 13);
            this.cq1r1.TabIndex = 0;
            this.cq1r1.UseVisualStyleBackColor = true;
            // 
            // label3
            // 
            this.label3.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(56, 76);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(735, 52);
            this.label3.TabIndex = 13;
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label2
            // 
            this.label2.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(30, 89);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(34, 27);
            this.label2.TabIndex = 12;
            this.label2.Text = "1.";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("Times New Roman", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(352, 20);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(214, 30);
            this.label1.TabIndex = 11;
            this.label1.Text = "C QUESTIONS";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // cq2r1
            // 
            this.cq2r1.AutoSize = true;
            this.cq2r1.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cq2r1.Location = new System.Drawing.Point(4, 4);
            this.cq2r1.Name = "cq2r1";
            this.cq2r1.Size = new System.Drawing.Size(14, 13);
            this.cq2r1.TabIndex = 0;
            this.cq2r1.TabStop = true;
            this.cq2r1.UseVisualStyleBackColor = true;
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(434, 689);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(96, 39);
            this.button1.TabIndex = 24;
            this.button1.Text = "Next";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.cq2r4);
            this.panel2.Controls.Add(this.cq2r3);
            this.panel2.Controls.Add(this.cq2r2);
            this.panel2.Controls.Add(this.cq2r1);
            this.panel2.Location = new System.Drawing.Point(60, 283);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(254, 98);
            this.panel2.TabIndex = 16;
            // 
            // label5
            // 
            this.label5.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(56, 240);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(735, 40);
            this.label5.TabIndex = 18;
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label4
            // 
            this.label4.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(30, 247);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(34, 27);
            this.label4.TabIndex = 15;
            this.label4.Text = "2.";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // checkBox5
            // 
            this.checkBox5.AutoSize = true;
            this.checkBox5.Location = new System.Drawing.Point(845, 20);
            this.checkBox5.Name = "checkBox5";
            this.checkBox5.Size = new System.Drawing.Size(15, 14);
            this.checkBox5.TabIndex = 25;
            this.checkBox5.UseVisualStyleBackColor = true;
            this.checkBox5.Visible = false;
            // 
            // h1
            // 
            this.h1.AutoSize = true;
            this.h1.Location = new System.Drawing.Point(824, 140);
            this.h1.Name = "h1";
            this.h1.Size = new System.Drawing.Size(80, 17);
            this.h1.TabIndex = 26;
            this.h1.Text = "checkBox1";
            this.h1.UseVisualStyleBackColor = true;
            this.h1.Visible = false;
            // 
            // h2
            // 
            this.h2.AutoSize = true;
            this.h2.Location = new System.Drawing.Point(824, 163);
            this.h2.Name = "h2";
            this.h2.Size = new System.Drawing.Size(80, 17);
            this.h2.TabIndex = 27;
            this.h2.Text = "checkBox2";
            this.h2.UseVisualStyleBackColor = true;
            this.h2.Visible = false;
            // 
            // h3
            // 
            this.h3.AutoSize = true;
            this.h3.Location = new System.Drawing.Point(824, 187);
            this.h3.Name = "h3";
            this.h3.Size = new System.Drawing.Size(80, 17);
            this.h3.TabIndex = 28;
            this.h3.Text = "checkBox3";
            this.h3.UseVisualStyleBackColor = true;
            this.h3.Visible = false;
            // 
            // h4
            // 
            this.h4.AutoSize = true;
            this.h4.Location = new System.Drawing.Point(824, 212);
            this.h4.Name = "h4";
            this.h4.Size = new System.Drawing.Size(80, 17);
            this.h4.TabIndex = 29;
            this.h4.Text = "checkBox4";
            this.h4.UseVisualStyleBackColor = true;
            this.h4.Visible = false;
            // 
            // textBox5
            // 
            this.textBox5.BackColor = System.Drawing.Color.LightSteelBlue;
            this.textBox5.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox5.Location = new System.Drawing.Point(720, 335);
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(204, 13);
            this.textBox5.TabIndex = 30;
            this.textBox5.Visible = false;
            // 
            // Form4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.LightSteelBlue;
            this.ClientSize = new System.Drawing.Size(1003, 763);
            this.Controls.Add(this.textBox5);
            this.Controls.Add(this.h4);
            this.Controls.Add(this.h3);
            this.Controls.Add(this.h2);
            this.Controls.Add(this.h1);
            this.Controls.Add(this.checkBox5);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Name = "Form4";
            this.Text = "C questions";
            this.Load += new System.EventHandler(this.Form4_Load);
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.RadioButton cq4r4;
        private System.Windows.Forms.RadioButton cq4r3;
        private System.Windows.Forms.RadioButton cq4r2;
        private System.Windows.Forms.RadioButton cq4r1;
        private System.Windows.Forms.RadioButton cq2r4;
        private System.Windows.Forms.RadioButton cq2r3;
        private System.Windows.Forms.RadioButton cq2r2;
        private System.Windows.Forms.RadioButton cq3r4;
        private System.Windows.Forms.RadioButton cq1r2;
        private System.Windows.Forms.RadioButton cq3r3;
        private System.Windows.Forms.RadioButton cq3r2;
        private System.Windows.Forms.RadioButton cq3r1;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.RadioButton cq1r4;
        private System.Windows.Forms.RadioButton cq1r3;
        private System.Windows.Forms.RadioButton cq1r1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.RadioButton cq2r1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        public System.Windows.Forms.CheckBox checkBox5;
        public System.Windows.Forms.CheckBox h1;
        public System.Windows.Forms.CheckBox h2;
        public System.Windows.Forms.CheckBox h3;
        public System.Windows.Forms.CheckBox h4;
        public System.Windows.Forms.TextBox textBox5;
    }
}