﻿namespace onlineexam
{
    partial class Form5
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.cpq1r4 = new System.Windows.Forms.RadioButton();
            this.cpq1r3 = new System.Windows.Forms.RadioButton();
            this.cpq3r4 = new System.Windows.Forms.RadioButton();
            this.label9 = new System.Windows.Forms.Label();
            this.cpq1r1 = new System.Windows.Forms.RadioButton();
            this.cpq3r3 = new System.Windows.Forms.RadioButton();
            this.cpq3r2 = new System.Windows.Forms.RadioButton();
            this.label6 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.cpq1r2 = new System.Windows.Forms.RadioButton();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.cpq2r1 = new System.Windows.Forms.RadioButton();
            this.label1 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.cpq2r4 = new System.Windows.Forms.RadioButton();
            this.cpq2r3 = new System.Windows.Forms.RadioButton();
            this.cpq2r2 = new System.Windows.Forms.RadioButton();
            this.label5 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.cpq4r3 = new System.Windows.Forms.RadioButton();
            this.label8 = new System.Windows.Forms.Label();
            this.cpq4r4 = new System.Windows.Forms.RadioButton();
            this.panel4 = new System.Windows.Forms.Panel();
            this.cpq4r2 = new System.Windows.Forms.RadioButton();
            this.cpq4r1 = new System.Windows.Forms.RadioButton();
            this.panel3 = new System.Windows.Forms.Panel();
            this.cpq3r1 = new System.Windows.Forms.RadioButton();
            this.label4 = new System.Windows.Forms.Label();
            this.h5 = new System.Windows.Forms.CheckBox();
            this.h6 = new System.Windows.Forms.CheckBox();
            this.h7 = new System.Windows.Forms.CheckBox();
            this.h8 = new System.Windows.Forms.CheckBox();
            this.h12 = new System.Windows.Forms.CheckBox();
            this.h11 = new System.Windows.Forms.CheckBox();
            this.h10 = new System.Windows.Forms.CheckBox();
            this.h9 = new System.Windows.Forms.CheckBox();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel3.SuspendLayout();
            this.SuspendLayout();
            // 
            // cpq1r4
            // 
            this.cpq1r4.AutoSize = true;
            this.cpq1r4.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cpq1r4.Location = new System.Drawing.Point(4, 76);
            this.cpq1r4.Name = "cpq1r4";
            this.cpq1r4.Size = new System.Drawing.Size(14, 13);
            this.cpq1r4.TabIndex = 3;
            this.cpq1r4.UseVisualStyleBackColor = true;
            // 
            // cpq1r3
            // 
            this.cpq1r3.AutoSize = true;
            this.cpq1r3.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cpq1r3.Location = new System.Drawing.Point(4, 52);
            this.cpq1r3.Name = "cpq1r3";
            this.cpq1r3.Size = new System.Drawing.Size(14, 13);
            this.cpq1r3.TabIndex = 2;
            this.cpq1r3.UseVisualStyleBackColor = true;
            // 
            // cpq3r4
            // 
            this.cpq3r4.AutoSize = true;
            this.cpq3r4.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cpq3r4.Location = new System.Drawing.Point(4, 76);
            this.cpq3r4.Name = "cpq3r4";
            this.cpq3r4.Size = new System.Drawing.Size(14, 13);
            this.cpq3r4.TabIndex = 3;
            this.cpq3r4.TabStop = true;
            this.cpq3r4.UseVisualStyleBackColor = true;
            // 
            // label9
            // 
            this.label9.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(50, 541);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(735, 40);
            this.label9.TabIndex = 37;
            this.label9.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // cpq1r1
            // 
            this.cpq1r1.AutoSize = true;
            this.cpq1r1.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cpq1r1.Location = new System.Drawing.Point(4, 4);
            this.cpq1r1.Name = "cpq1r1";
            this.cpq1r1.Size = new System.Drawing.Size(14, 13);
            this.cpq1r1.TabIndex = 0;
            this.cpq1r1.UseVisualStyleBackColor = true;
            // 
            // cpq3r3
            // 
            this.cpq3r3.AutoSize = true;
            this.cpq3r3.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cpq3r3.Location = new System.Drawing.Point(4, 52);
            this.cpq3r3.Name = "cpq3r3";
            this.cpq3r3.Size = new System.Drawing.Size(14, 13);
            this.cpq3r3.TabIndex = 2;
            this.cpq3r3.TabStop = true;
            this.cpq3r3.UseVisualStyleBackColor = true;
            // 
            // cpq3r2
            // 
            this.cpq3r2.AutoSize = true;
            this.cpq3r2.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cpq3r2.Location = new System.Drawing.Point(4, 28);
            this.cpq3r2.Name = "cpq3r2";
            this.cpq3r2.Size = new System.Drawing.Size(14, 13);
            this.cpq3r2.TabIndex = 1;
            this.cpq3r2.TabStop = true;
            this.cpq3r2.UseVisualStyleBackColor = true;
            // 
            // label6
            // 
            this.label6.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(24, 401);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(34, 27);
            this.label6.TabIndex = 34;
            this.label6.Text = "3.";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.cpq1r4);
            this.panel1.Controls.Add(this.cpq1r3);
            this.panel1.Controls.Add(this.cpq1r2);
            this.panel1.Controls.Add(this.cpq1r1);
            this.panel1.Location = new System.Drawing.Point(54, 133);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(254, 98);
            this.panel1.TabIndex = 28;
            // 
            // cpq1r2
            // 
            this.cpq1r2.AutoSize = true;
            this.cpq1r2.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cpq1r2.Location = new System.Drawing.Point(4, 28);
            this.cpq1r2.Name = "cpq1r2";
            this.cpq1r2.Size = new System.Drawing.Size(14, 13);
            this.cpq1r2.TabIndex = 1;
            this.cpq1r2.UseVisualStyleBackColor = true;
            // 
            // label3
            // 
            this.label3.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(54, 77);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(735, 52);
            this.label3.TabIndex = 27;
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label2
            // 
            this.label2.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(24, 90);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(34, 27);
            this.label2.TabIndex = 26;
            this.label2.Text = "1.";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // cpq2r1
            // 
            this.cpq2r1.AutoSize = true;
            this.cpq2r1.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cpq2r1.Location = new System.Drawing.Point(4, 4);
            this.cpq2r1.Name = "cpq2r1";
            this.cpq2r1.Size = new System.Drawing.Size(14, 13);
            this.cpq2r1.TabIndex = 0;
            this.cpq2r1.TabStop = true;
            this.cpq2r1.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("Times New Roman", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(390, 21);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(214, 30);
            this.label1.TabIndex = 25;
            this.label1.Text = "C ++ QUESTIONS";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(463, 691);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(96, 39);
            this.button1.TabIndex = 38;
            this.button1.Text = "Next";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.cpq2r4);
            this.panel2.Controls.Add(this.cpq2r3);
            this.panel2.Controls.Add(this.cpq2r2);
            this.panel2.Controls.Add(this.cpq2r1);
            this.panel2.Location = new System.Drawing.Point(58, 293);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(254, 98);
            this.panel2.TabIndex = 30;
            // 
            // cpq2r4
            // 
            this.cpq2r4.AutoSize = true;
            this.cpq2r4.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cpq2r4.Location = new System.Drawing.Point(4, 76);
            this.cpq2r4.Name = "cpq2r4";
            this.cpq2r4.Size = new System.Drawing.Size(14, 13);
            this.cpq2r4.TabIndex = 3;
            this.cpq2r4.TabStop = true;
            this.cpq2r4.UseVisualStyleBackColor = true;
            // 
            // cpq2r3
            // 
            this.cpq2r3.AutoSize = true;
            this.cpq2r3.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cpq2r3.Location = new System.Drawing.Point(4, 52);
            this.cpq2r3.Name = "cpq2r3";
            this.cpq2r3.Size = new System.Drawing.Size(14, 13);
            this.cpq2r3.TabIndex = 2;
            this.cpq2r3.TabStop = true;
            this.cpq2r3.UseVisualStyleBackColor = true;
            // 
            // cpq2r2
            // 
            this.cpq2r2.AutoSize = true;
            this.cpq2r2.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cpq2r2.Location = new System.Drawing.Point(4, 28);
            this.cpq2r2.Name = "cpq2r2";
            this.cpq2r2.Size = new System.Drawing.Size(14, 13);
            this.cpq2r2.TabIndex = 1;
            this.cpq2r2.TabStop = true;
            this.cpq2r2.UseVisualStyleBackColor = true;
            // 
            // label5
            // 
            this.label5.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(54, 241);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(735, 40);
            this.label5.TabIndex = 32;
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label7
            // 
            this.label7.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(54, 393);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(735, 40);
            this.label7.TabIndex = 35;
            this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // cpq4r3
            // 
            this.cpq4r3.AutoSize = true;
            this.cpq4r3.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cpq4r3.Location = new System.Drawing.Point(4, 52);
            this.cpq4r3.Name = "cpq4r3";
            this.cpq4r3.Size = new System.Drawing.Size(14, 13);
            this.cpq4r3.TabIndex = 2;
            this.cpq4r3.TabStop = true;
            this.cpq4r3.UseVisualStyleBackColor = true;
            // 
            // label8
            // 
            this.label8.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(24, 548);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(34, 27);
            this.label8.TabIndex = 36;
            this.label8.Text = "4.";
            this.label8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // cpq4r4
            // 
            this.cpq4r4.AutoSize = true;
            this.cpq4r4.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cpq4r4.Location = new System.Drawing.Point(4, 76);
            this.cpq4r4.Name = "cpq4r4";
            this.cpq4r4.Size = new System.Drawing.Size(14, 13);
            this.cpq4r4.TabIndex = 3;
            this.cpq4r4.TabStop = true;
            this.cpq4r4.UseVisualStyleBackColor = true;
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.cpq4r4);
            this.panel4.Controls.Add(this.cpq4r3);
            this.panel4.Controls.Add(this.cpq4r2);
            this.panel4.Controls.Add(this.cpq4r1);
            this.panel4.Location = new System.Drawing.Point(54, 587);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(254, 98);
            this.panel4.TabIndex = 33;
            // 
            // cpq4r2
            // 
            this.cpq4r2.AutoSize = true;
            this.cpq4r2.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cpq4r2.Location = new System.Drawing.Point(4, 28);
            this.cpq4r2.Name = "cpq4r2";
            this.cpq4r2.Size = new System.Drawing.Size(14, 13);
            this.cpq4r2.TabIndex = 1;
            this.cpq4r2.TabStop = true;
            this.cpq4r2.UseVisualStyleBackColor = true;
            // 
            // cpq4r1
            // 
            this.cpq4r1.AutoSize = true;
            this.cpq4r1.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cpq4r1.Location = new System.Drawing.Point(4, 4);
            this.cpq4r1.Name = "cpq4r1";
            this.cpq4r1.Size = new System.Drawing.Size(14, 13);
            this.cpq4r1.TabIndex = 0;
            this.cpq4r1.TabStop = true;
            this.cpq4r1.UseVisualStyleBackColor = true;
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.cpq3r4);
            this.panel3.Controls.Add(this.cpq3r3);
            this.panel3.Controls.Add(this.cpq3r2);
            this.panel3.Controls.Add(this.cpq3r1);
            this.panel3.Location = new System.Drawing.Point(54, 436);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(254, 98);
            this.panel3.TabIndex = 31;
            // 
            // cpq3r1
            // 
            this.cpq3r1.AutoSize = true;
            this.cpq3r1.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cpq3r1.Location = new System.Drawing.Point(4, 4);
            this.cpq3r1.Name = "cpq3r1";
            this.cpq3r1.Size = new System.Drawing.Size(14, 13);
            this.cpq3r1.TabIndex = 0;
            this.cpq3r1.TabStop = true;
            this.cpq3r1.UseVisualStyleBackColor = true;
            // 
            // label4
            // 
            this.label4.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(24, 248);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(34, 27);
            this.label4.TabIndex = 29;
            this.label4.Text = "2.";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // h5
            // 
            this.h5.AutoSize = true;
            this.h5.Location = new System.Drawing.Point(826, 209);
            this.h5.Name = "h5";
            this.h5.Size = new System.Drawing.Size(80, 17);
            this.h5.TabIndex = 39;
            this.h5.Text = "checkBox1";
            this.h5.UseVisualStyleBackColor = true;
            this.h5.Visible = false;
            // 
            // h6
            // 
            this.h6.AutoSize = true;
            this.h6.Location = new System.Drawing.Point(826, 233);
            this.h6.Name = "h6";
            this.h6.Size = new System.Drawing.Size(80, 17);
            this.h6.TabIndex = 40;
            this.h6.Text = "checkBox2";
            this.h6.UseVisualStyleBackColor = true;
            this.h6.Visible = false;
            // 
            // h7
            // 
            this.h7.AutoSize = true;
            this.h7.Location = new System.Drawing.Point(826, 257);
            this.h7.Name = "h7";
            this.h7.Size = new System.Drawing.Size(80, 17);
            this.h7.TabIndex = 41;
            this.h7.Text = "checkBox3";
            this.h7.UseVisualStyleBackColor = true;
            this.h7.Visible = false;
            // 
            // h8
            // 
            this.h8.AutoSize = true;
            this.h8.Location = new System.Drawing.Point(826, 281);
            this.h8.Name = "h8";
            this.h8.Size = new System.Drawing.Size(80, 17);
            this.h8.TabIndex = 42;
            this.h8.Text = "checkBox4";
            this.h8.UseVisualStyleBackColor = true;
            this.h8.Visible = false;
            // 
            // h12
            // 
            this.h12.AutoSize = true;
            this.h12.Location = new System.Drawing.Point(826, 393);
            this.h12.Name = "h12";
            this.h12.Size = new System.Drawing.Size(80, 17);
            this.h12.TabIndex = 46;
            this.h12.Text = "checkBox5";
            this.h12.UseVisualStyleBackColor = true;
            this.h12.Visible = false;
            // 
            // h11
            // 
            this.h11.AutoSize = true;
            this.h11.Location = new System.Drawing.Point(826, 369);
            this.h11.Name = "h11";
            this.h11.Size = new System.Drawing.Size(80, 17);
            this.h11.TabIndex = 45;
            this.h11.Text = "checkBox6";
            this.h11.UseVisualStyleBackColor = true;
            this.h11.Visible = false;
            // 
            // h10
            // 
            this.h10.AutoSize = true;
            this.h10.Location = new System.Drawing.Point(826, 345);
            this.h10.Name = "h10";
            this.h10.Size = new System.Drawing.Size(80, 17);
            this.h10.TabIndex = 44;
            this.h10.Text = "checkBox7";
            this.h10.UseVisualStyleBackColor = true;
            this.h10.Visible = false;
            // 
            // h9
            // 
            this.h9.AutoSize = true;
            this.h9.Location = new System.Drawing.Point(826, 321);
            this.h9.Name = "h9";
            this.h9.Size = new System.Drawing.Size(80, 17);
            this.h9.TabIndex = 43;
            this.h9.Text = "checkBox8";
            this.h9.UseVisualStyleBackColor = true;
            this.h9.Visible = false;
            // 
            // textBox6
            // 
            this.textBox6.BackColor = System.Drawing.Color.LightSteelBlue;
            this.textBox6.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox6.Location = new System.Drawing.Point(684, 90);
            this.textBox6.Name = "textBox6";
            this.textBox6.Size = new System.Drawing.Size(243, 13);
            this.textBox6.TabIndex = 47;
            this.textBox6.Visible = false;
            // 
            // Form5
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.LightSteelBlue;
            this.ClientSize = new System.Drawing.Size(1002, 741);
            this.Controls.Add(this.textBox6);
            this.Controls.Add(this.h12);
            this.Controls.Add(this.h11);
            this.Controls.Add(this.h10);
            this.Controls.Add(this.h9);
            this.Controls.Add(this.h8);
            this.Controls.Add(this.h7);
            this.Controls.Add(this.h6);
            this.Controls.Add(this.h5);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.label4);
            this.Name = "Form5";
            this.Text = "C++ Questions";
            this.Load += new System.EventHandler(this.Form5_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.RadioButton cpq1r4;
        private System.Windows.Forms.RadioButton cpq1r3;
        private System.Windows.Forms.RadioButton cpq3r4;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.RadioButton cpq1r1;
        private System.Windows.Forms.RadioButton cpq3r3;
        private System.Windows.Forms.RadioButton cpq3r2;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.RadioButton cpq1r2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.RadioButton cpq2r1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.RadioButton cpq2r4;
        private System.Windows.Forms.RadioButton cpq2r3;
        private System.Windows.Forms.RadioButton cpq2r2;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.RadioButton cpq4r3;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.RadioButton cpq4r4;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.RadioButton cpq4r2;
        private System.Windows.Forms.RadioButton cpq4r1;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.RadioButton cpq3r1;
        private System.Windows.Forms.Label label4;
        public System.Windows.Forms.CheckBox h5;
        public System.Windows.Forms.CheckBox h6;
        public System.Windows.Forms.CheckBox h7;
        public System.Windows.Forms.CheckBox h8;
        public System.Windows.Forms.CheckBox h12;
        public System.Windows.Forms.CheckBox h11;
        public System.Windows.Forms.CheckBox h10;
        public System.Windows.Forms.CheckBox h9;
        public System.Windows.Forms.TextBox textBox6;
    }
}