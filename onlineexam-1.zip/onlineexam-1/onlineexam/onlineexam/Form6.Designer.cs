﻿namespace onlineexam
{
    partial class Form6
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.ntans1 = new System.Windows.Forms.CheckBox();
            this.ntans2 = new System.Windows.Forms.CheckBox();
            this.ntans3 = new System.Windows.Forms.CheckBox();
            this.ntans4 = new System.Windows.Forms.CheckBox();
            this.label3 = new System.Windows.Forms.Label();
            this.cans4 = new System.Windows.Forms.CheckBox();
            this.cans3 = new System.Windows.Forms.CheckBox();
            this.cans2 = new System.Windows.Forms.CheckBox();
            this.cans1 = new System.Windows.Forms.CheckBox();
            this.label4 = new System.Windows.Forms.Label();
            this.cpans4 = new System.Windows.Forms.CheckBox();
            this.cpans3 = new System.Windows.Forms.CheckBox();
            this.cpans2 = new System.Windows.Forms.CheckBox();
            this.cpans1 = new System.Windows.Forms.CheckBox();
            this.resltnme = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("Times New Roman", 18F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(422, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(249, 40);
            this.label1.TabIndex = 0;
            this.label1.Text = "Result";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label2
            // 
            this.label2.Font = new System.Drawing.Font("Times New Roman", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(504, 137);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(100, 23);
            this.label2.TabIndex = 1;
            this.label2.Text = ".NET ";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // ntans1
            // 
            this.ntans1.AutoSize = true;
            this.ntans1.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ntans1.Location = new System.Drawing.Point(113, 178);
            this.ntans1.Name = "ntans1";
            this.ntans1.Size = new System.Drawing.Size(36, 23);
            this.ntans1.TabIndex = 2;
            this.ntans1.Text = "1";
            this.ntans1.UseVisualStyleBackColor = true;
            // 
            // ntans2
            // 
            this.ntans2.AutoSize = true;
            this.ntans2.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ntans2.Location = new System.Drawing.Point(381, 178);
            this.ntans2.Name = "ntans2";
            this.ntans2.Size = new System.Drawing.Size(36, 23);
            this.ntans2.TabIndex = 3;
            this.ntans2.Text = "2";
            this.ntans2.UseVisualStyleBackColor = true;
            // 
            // ntans3
            // 
            this.ntans3.AutoSize = true;
            this.ntans3.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ntans3.Location = new System.Drawing.Point(638, 178);
            this.ntans3.Name = "ntans3";
            this.ntans3.Size = new System.Drawing.Size(36, 23);
            this.ntans3.TabIndex = 4;
            this.ntans3.Text = "3";
            this.ntans3.UseVisualStyleBackColor = true;
            // 
            // ntans4
            // 
            this.ntans4.AutoSize = true;
            this.ntans4.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ntans4.Location = new System.Drawing.Point(910, 178);
            this.ntans4.Name = "ntans4";
            this.ntans4.Size = new System.Drawing.Size(36, 23);
            this.ntans4.TabIndex = 5;
            this.ntans4.Text = "4";
            this.ntans4.UseVisualStyleBackColor = true;
            // 
            // label3
            // 
            this.label3.Font = new System.Drawing.Font("Times New Roman", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(504, 241);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(100, 38);
            this.label3.TabIndex = 6;
            this.label3.Text = "C";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // cans4
            // 
            this.cans4.AutoSize = true;
            this.cans4.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cans4.Location = new System.Drawing.Point(910, 305);
            this.cans4.Name = "cans4";
            this.cans4.Size = new System.Drawing.Size(36, 23);
            this.cans4.TabIndex = 10;
            this.cans4.Text = "4";
            this.cans4.UseVisualStyleBackColor = true;
            // 
            // cans3
            // 
            this.cans3.AutoSize = true;
            this.cans3.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cans3.Location = new System.Drawing.Point(638, 305);
            this.cans3.Name = "cans3";
            this.cans3.Size = new System.Drawing.Size(36, 23);
            this.cans3.TabIndex = 9;
            this.cans3.Text = "3";
            this.cans3.UseVisualStyleBackColor = true;
            // 
            // cans2
            // 
            this.cans2.AutoSize = true;
            this.cans2.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cans2.Location = new System.Drawing.Point(381, 305);
            this.cans2.Name = "cans2";
            this.cans2.Size = new System.Drawing.Size(36, 23);
            this.cans2.TabIndex = 8;
            this.cans2.Text = "2";
            this.cans2.UseVisualStyleBackColor = true;
            // 
            // cans1
            // 
            this.cans1.AutoSize = true;
            this.cans1.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cans1.Location = new System.Drawing.Point(113, 305);
            this.cans1.Name = "cans1";
            this.cans1.Size = new System.Drawing.Size(36, 23);
            this.cans1.TabIndex = 7;
            this.cans1.Text = "1";
            this.cans1.UseVisualStyleBackColor = true;
            // 
            // label4
            // 
            this.label4.Font = new System.Drawing.Font("Times New Roman", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(504, 376);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(100, 38);
            this.label4.TabIndex = 11;
            this.label4.Text = "C ++";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // cpans4
            // 
            this.cpans4.AutoSize = true;
            this.cpans4.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cpans4.Location = new System.Drawing.Point(910, 438);
            this.cpans4.Name = "cpans4";
            this.cpans4.Size = new System.Drawing.Size(36, 23);
            this.cpans4.TabIndex = 15;
            this.cpans4.Text = "4";
            this.cpans4.UseVisualStyleBackColor = true;
            // 
            // cpans3
            // 
            this.cpans3.AutoSize = true;
            this.cpans3.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cpans3.Location = new System.Drawing.Point(638, 438);
            this.cpans3.Name = "cpans3";
            this.cpans3.Size = new System.Drawing.Size(36, 23);
            this.cpans3.TabIndex = 14;
            this.cpans3.Text = "3";
            this.cpans3.UseVisualStyleBackColor = true;
            // 
            // cpans2
            // 
            this.cpans2.AutoSize = true;
            this.cpans2.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cpans2.Location = new System.Drawing.Point(381, 438);
            this.cpans2.Name = "cpans2";
            this.cpans2.Size = new System.Drawing.Size(36, 23);
            this.cpans2.TabIndex = 13;
            this.cpans2.Text = "2";
            this.cpans2.UseVisualStyleBackColor = true;
            // 
            // cpans1
            // 
            this.cpans1.AutoSize = true;
            this.cpans1.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cpans1.Location = new System.Drawing.Point(113, 438);
            this.cpans1.Name = "cpans1";
            this.cpans1.Size = new System.Drawing.Size(36, 23);
            this.cpans1.TabIndex = 12;
            this.cpans1.Text = "1";
            this.cpans1.UseVisualStyleBackColor = true;
            // 
            // resltnme
            // 
            this.resltnme.Font = new System.Drawing.Font("Lucida Calligraphy", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.resltnme.Location = new System.Drawing.Point(427, 71);
            this.resltnme.Name = "resltnme";
            this.resltnme.Size = new System.Drawing.Size(277, 33);
            this.resltnme.TabIndex = 16;
            this.resltnme.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // Form6
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.LightSteelBlue;
            this.ClientSize = new System.Drawing.Size(1192, 569);
            this.Controls.Add(this.resltnme);
            this.Controls.Add(this.cpans4);
            this.Controls.Add(this.cpans3);
            this.Controls.Add(this.cpans2);
            this.Controls.Add(this.cpans1);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.cans4);
            this.Controls.Add(this.cans3);
            this.Controls.Add(this.cans2);
            this.Controls.Add(this.cans1);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.ntans4);
            this.Controls.Add(this.ntans3);
            this.Controls.Add(this.ntans2);
            this.Controls.Add(this.ntans1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Form6";
            this.Text = "Result Form";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        public System.Windows.Forms.CheckBox ntans1;
        public System.Windows.Forms.CheckBox ntans2;
        public System.Windows.Forms.CheckBox ntans3;
        public System.Windows.Forms.CheckBox ntans4;
        public System.Windows.Forms.CheckBox cans4;
        public System.Windows.Forms.CheckBox cans3;
        public System.Windows.Forms.CheckBox cans2;
        public System.Windows.Forms.CheckBox cans1;
        public System.Windows.Forms.CheckBox cpans4;
        public System.Windows.Forms.CheckBox cpans3;
        public System.Windows.Forms.CheckBox cpans2;
        public System.Windows.Forms.CheckBox cpans1;
        public System.Windows.Forms.TextBox resltnme;
    }
}