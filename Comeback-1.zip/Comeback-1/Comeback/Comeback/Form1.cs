﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Comeback
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        int aple = 10, bana = 5, gosebry = 3, grps = 30, grngrps = 35, guva = 9, mngo = 8, msmbi = 15, orng = 6, watrmeln = 52, pomegrte = 21, i=0;

        private void txtbxprdct1_TextChanged(object sender, EventArgs e)
        {
            if (txtbxprdct1.Text == "Apple" || txtbxprdct1.Text == "APPLE" || txtbxprdct1.Text == "apple")
            {
                txtbxprice1.Text = aple.ToString();
            }
            else if (txtbxprdct1.Text == "Banana" || txtbxprdct1.Text == "BANANA" || txtbxprdct1.Text == "banana")
            {
                txtbxprice1.Text = bana.ToString();
            }
            else if (txtbxprdct1.Text == "Gooseberry" || txtbxprdct1.Text == "GOOSEBERRY" || txtbxprdct1.Text == "gooseberry")
            {
                txtbxprice1.Text = gosebry.ToString();
            }
            else if (txtbxprdct1.Text == "Grapes" || txtbxprdct1.Text == "GRAPES" || txtbxprdct1.Text == "grapes")
            {
                txtbxprice1.Text = grps.ToString();
            }
            else if (txtbxprdct1.Text == "Green Grapes" || txtbxprdct1.Text == "GREEN GRAPES" || txtbxprdct1.Text == "green grapes")
            {
                txtbxprice1.Text = grngrps.ToString();
            }
            else if (txtbxprdct1.Text == "Guava" || txtbxprdct1.Text == "GUAVA" || txtbxprdct1.Text == "guava")
            {
                txtbxprice1.Text = guva.ToString();
            }
            else if (txtbxprdct1.Text == "Mango" || txtbxprdct1.Text == "MANGO" || txtbxprdct1.Text == "mango")
            {
                txtbxprice1.Text = mngo.ToString();
            }
            else if (txtbxprdct1.Text == "Mosambi" || txtbxprdct1.Text == "MOSAMBI" || txtbxprdct1.Text == "mosambi")
            {
                txtbxprice1.Text = msmbi.ToString();
            }
            else if (txtbxprdct1.Text == "Orange" || txtbxprdct1.Text == "ORANGE" || txtbxprdct1.Text == "orange")
            {
                txtbxprice1.Text = orng.ToString();
            }
            else if (txtbxprdct1.Text == "Watermelon" || txtbxprdct1.Text == "WATERMELON" || txtbxprdct1.Text == "watermelon")
            {
                txtbxprice1.Text = watrmeln.ToString();
            }
            else if (txtbxprdct1.Text == "Pomegrante" || txtbxprdct1.Text == "POMEGRANTE" || txtbxprdct1.Text == "pomegrante")
            {
                txtbxprice1.Text = pomegrte.ToString();
            }
        }

        private void txtbxprdct2_TextChanged(object sender, EventArgs e)
        {
            if (txtbxprdct2.Text == "Apple" || txtbxprdct2.Text == "APPLE" || txtbxprdct2.Text == "apple")
            {
                txtbxprice2.Text = aple.ToString();
            }
            else if (txtbxprdct2.Text == "Banana" || txtbxprdct2.Text == "BANANA" || txtbxprdct2.Text == "banana")
            {
                txtbxprice2.Text = bana.ToString();
            }
            else if (txtbxprdct2.Text == "Gooseberry" || txtbxprdct2.Text == "GOOSEBERRY" || txtbxprdct2.Text == "gooseberry")
            {
                txtbxprice2.Text = gosebry.ToString();
            }
            else if (txtbxprdct2.Text == "Grapes" || txtbxprdct2.Text == "GRAPES" || txtbxprdct2.Text == "grapes")
            {
                txtbxprice2.Text = grps.ToString();
            }
            else if (txtbxprdct2.Text == "Green Grapes" || txtbxprdct2.Text == "GREEN GRAPES" || txtbxprdct2.Text == "green grapes")
            {
                txtbxprice2.Text = grngrps.ToString();
            }
            else if (txtbxprdct2.Text == "Guava" || txtbxprdct2.Text == "GUAVA" || txtbxprdct2.Text == "guava")
            {
                txtbxprice2.Text = guva.ToString();
            }
            else if (txtbxprdct2.Text == "Mango" || txtbxprdct2.Text == "MANGO" || txtbxprdct2.Text == "mango")
            {
                txtbxprice2.Text = mngo.ToString();
            }
            else if (txtbxprdct2.Text == "Mosambi" || txtbxprdct2.Text == "MOSAMBI" || txtbxprdct2.Text == "mosambi")
            {
                txtbxprice2.Text = msmbi.ToString();
            }
            else if (txtbxprdct2.Text == "Orange" || txtbxprdct2.Text == "ORANGE" || txtbxprdct2.Text == "orange")
            {
                txtbxprice2.Text = orng.ToString();
            }
            else if (txtbxprdct2.Text == "Watermelon" || txtbxprdct2.Text == "WATERMELON" || txtbxprdct2.Text == "watermelon")
            {
                txtbxprice2.Text = watrmeln.ToString();
            }
            else if (txtbxprdct2.Text == "Pomegrante" || txtbxprdct2.Text == "POMEGRANTE" || txtbxprdct2.Text == "pomegrante")
            {
                txtbxprice2.Text = pomegrte.ToString();
            }
        }

        private void txtbxprdct3_TextChanged(object sender, EventArgs e)
        {
            if (txtbxprdct3.Text == "Apple" || txtbxprdct3.Text == "APPLE" || txtbxprdct3.Text == "apple")
            {
                txtbxprice3.Text = aple.ToString();
            }
            else if (txtbxprdct3.Text == "Banana" || txtbxprdct3.Text == "BANANA" || txtbxprdct3.Text == "banana")
            {
                txtbxprice3.Text = bana.ToString();
            }
            else if (txtbxprdct3.Text == "Gooseberry" || txtbxprdct3.Text == "GOOSEBERRY" || txtbxprdct3.Text == "gooseberry")
            {
                txtbxprice3.Text = gosebry.ToString();
            }
            else if (txtbxprdct3.Text == "Grapes" || txtbxprdct3.Text == "GRAPES" || txtbxprdct3.Text == "grapes")
            {
                txtbxprice3.Text = grps.ToString();
            }
            else if (txtbxprdct3.Text == "Green Grapes" || txtbxprdct3.Text == "GREEN GRAPES" || txtbxprdct3.Text == "green grapes")
            {
                txtbxprice3.Text = grngrps.ToString();
            }
            else if (txtbxprdct3.Text == "Guava" || txtbxprdct3.Text == "GUAVA" || txtbxprdct3.Text == "guava")
            {
                txtbxprice3.Text = guva.ToString();
            }
            else if (txtbxprdct3.Text == "Mango" || txtbxprdct3.Text == "MANGO" || txtbxprdct3.Text == "mango")
            {
                txtbxprice3.Text = mngo.ToString();
            }
            else if (txtbxprdct3.Text == "Mosambi" || txtbxprdct3.Text == "MOSAMBI" || txtbxprdct3.Text == "mosambi")
            {
                txtbxprice3.Text = msmbi.ToString();
            }
            else if (txtbxprdct3.Text == "Orange" || txtbxprdct3.Text == "ORANGE" || txtbxprdct3.Text == "orange")
            {
                txtbxprice3.Text = orng.ToString();
            }
            else if (txtbxprdct3.Text == "Watermelon" || txtbxprdct3.Text == "WATERMELON" || txtbxprdct3.Text == "watermelon")
            {
                txtbxprice3.Text = watrmeln.ToString();
            }
            else if (txtbxprdct3.Text == "Pomegrante" || txtbxprdct3.Text == "POMEGRANTE" || txtbxprdct3.Text == "pomegrante")
            {
                txtbxprice3.Text = pomegrte.ToString();
            }
        }

        private void txtbxprdct4_TextChanged(object sender, EventArgs e)
        {
            if (txtbxprdct4.Text == "Apple" || txtbxprdct4.Text == "APPLE" || txtbxprdct4.Text == "apple")
            {
                txtbxprice4.Text = aple.ToString();
            }
            else if (txtbxprdct4.Text == "Banana" || txtbxprdct4.Text == "BANANA" || txtbxprdct4.Text == "banana")
            {
                txtbxprice4.Text = bana.ToString();
            }
            else if (txtbxprdct4.Text == "Gooseberry" || txtbxprdct4.Text == "GOOSEBERRY" || txtbxprdct4.Text == "gooseberry")
            {
                txtbxprice4.Text = gosebry.ToString();
            }
            else if (txtbxprdct4.Text == "Grapes" || txtbxprdct4.Text == "GRAPES" || txtbxprdct4.Text == "grapes")
            {
                txtbxprice4.Text = grps.ToString();
            }
            else if (txtbxprdct4.Text == "Green Grapes" || txtbxprdct4.Text == "GREEN GRAPES" || txtbxprdct4.Text == "green grapes")
            {
                txtbxprice4.Text = grngrps.ToString();
            }
            else if (txtbxprdct4.Text == "Guava" || txtbxprdct4.Text == "GUAVA" || txtbxprdct4.Text == "guava")
            {
                txtbxprice4.Text = guva.ToString();
            }
            else if (txtbxprdct4.Text == "Mango" || txtbxprdct4.Text == "MANGO" || txtbxprdct4.Text == "mango")
            {
                txtbxprice4.Text = mngo.ToString();
            }
            else if (txtbxprdct4.Text == "Mosambi" || txtbxprdct4.Text == "MOSAMBI" || txtbxprdct4.Text == "mosambi")
            {
                txtbxprice4.Text = msmbi.ToString();
            }
            else if (txtbxprdct4.Text == "Orange" || txtbxprdct4.Text == "ORANGE" || txtbxprdct4.Text == "orange")
            {
                txtbxprice4.Text = orng.ToString();
            }
            else if (txtbxprdct4.Text == "Watermelon" || txtbxprdct4.Text == "WATERMELON" || txtbxprdct4.Text == "watermelon")
            {
                txtbxprice4.Text = watrmeln.ToString();
            }
            else if (txtbxprdct4.Text == "Pomegrante" || txtbxprdct4.Text == "POMEGRANTE" || txtbxprdct4.Text == "pomegrante")
            {
                txtbxprice4.Text = pomegrte.ToString();
            }
        }

        private void txtbxprdct5_TextChanged(object sender, EventArgs e)
        {
            if (txtbxprdct5.Text == "Apple" || txtbxprdct5.Text == "APPLE" || txtbxprdct5.Text == "apple")
            {
                txtbxprice5.Text = aple.ToString();
            }
            else if (txtbxprdct5.Text == "Banana" || txtbxprdct5.Text == "BANANA" || txtbxprdct5.Text == "banana")
            {
                txtbxprice5.Text = bana.ToString();
            }
            else if (txtbxprdct5.Text == "Gooseberry" || txtbxprdct5.Text == "GOOSEBERRY" || txtbxprdct5.Text == "gooseberry")
            {
                txtbxprice5.Text = gosebry.ToString();
            }
            else if (txtbxprdct5.Text == "Grapes" || txtbxprdct5.Text == "GRAPES" || txtbxprdct5.Text == "grapes")
            {
                txtbxprice5.Text = grps.ToString();
            }
            else if (txtbxprdct5.Text == "Green Grapes" || txtbxprdct5.Text == "GREEN GRAPES" || txtbxprdct5.Text == "green grapes")
            {
                txtbxprice5.Text = grngrps.ToString();
            }
            else if (txtbxprdct5.Text == "Guava" || txtbxprdct5.Text == "GUAVA" || txtbxprdct5.Text == "guava")
            {
                txtbxprice5.Text = guva.ToString();
            }
            else if (txtbxprdct5.Text == "Mango" || txtbxprdct5.Text == "MANGO" || txtbxprdct5.Text == "mango")
            {
                txtbxprice5.Text = mngo.ToString();
            }
            else if (txtbxprdct5.Text == "Mosambi" || txtbxprdct5.Text == "MOSAMBI" || txtbxprdct5.Text == "mosambi")
            {
                txtbxprice5.Text = msmbi.ToString();
            }
            else if (txtbxprdct5.Text == "Orange" || txtbxprdct5.Text == "ORANGE" || txtbxprdct5.Text == "orange")
            {
                txtbxprice5.Text = orng.ToString();
            }
            else if (txtbxprdct5.Text == "Watermelon" || txtbxprdct5.Text == "WATERMELON" || txtbxprdct5.Text == "watermelon")
            {
                txtbxprice5.Text = watrmeln.ToString();
            }
            else if (txtbxprdct5.Text == "Pomegrante" || txtbxprdct5.Text == "POMEGRANTE" || txtbxprdct5.Text == "pomegrante")
            {
                txtbxprice5.Text = pomegrte.ToString();
            }
        }

        private void txtbxprdct6_TextChanged(object sender, EventArgs e)
        {
            if (txtbxprdct6.Text == "Apple" || txtbxprdct6.Text == "APPLE" || txtbxprdct6.Text == "apple")
            {
                txtbxprice6.Text = aple.ToString();
            }
            else if (txtbxprdct6.Text == "Banana" || txtbxprdct6.Text == "BANANA" || txtbxprdct6.Text == "banana")
            {
                txtbxprice6.Text = bana.ToString();
            }
            else if (txtbxprdct6.Text == "Gooseberry" || txtbxprdct6.Text == "GOOSEBERRY" || txtbxprdct6.Text == "gooseberry")
            {
                txtbxprice6.Text = gosebry.ToString();
            }
            else if (txtbxprdct6.Text == "Grapes" || txtbxprdct6.Text == "GRAPES" || txtbxprdct6.Text == "grapes")
            {
                txtbxprice6.Text = grps.ToString();
            }
            else if (txtbxprdct6.Text == "Green Grapes" || txtbxprdct6.Text == "GREEN GRAPES" || txtbxprdct6.Text == "green grapes")
            {
                txtbxprice6.Text = grngrps.ToString();
            }
            else if (txtbxprdct6.Text == "Guava" || txtbxprdct6.Text == "GUAVA" || txtbxprdct6.Text == "guava")
            {
                txtbxprice6.Text = guva.ToString();
            }
            else if (txtbxprdct6.Text == "Mango" || txtbxprdct6.Text == "MANGO" || txtbxprdct6.Text == "mango")
            {
                txtbxprice6.Text = mngo.ToString();
            }
            else if (txtbxprdct6.Text == "Mosambi" || txtbxprdct6.Text == "MOSAMBI" || txtbxprdct6.Text == "mosambi")
            {
                txtbxprice6.Text = msmbi.ToString();
            }
            else if (txtbxprdct6.Text == "Orange" || txtbxprdct6.Text == "ORANGE" || txtbxprdct6.Text == "orange")
            {
                txtbxprice6.Text = orng.ToString();
            }
            else if (txtbxprdct6.Text == "Watermelon" || txtbxprdct6.Text == "WATERMELON" || txtbxprdct6.Text == "watermelon")
            {
                txtbxprice6.Text = watrmeln.ToString();
            }
            else if (txtbxprdct6.Text == "Pomegrante" || txtbxprdct6.Text == "POMEGRANTE" || txtbxprdct6.Text == "pomegrante")
            {
                txtbxprice6.Text = pomegrte.ToString();
            }
        }

        private void txtbxprdct7_TextChanged(object sender, EventArgs e)
        {
            if (txtbxprdct7.Text == "Apple" || txtbxprdct7.Text == "APPLE" || txtbxprdct7.Text == "apple")
            {
                txtbxprice7.Text = aple.ToString();
            }
            else if (txtbxprdct7.Text == "Banana" || txtbxprdct7.Text == "BANANA" || txtbxprdct7.Text == "banana")
            {
                txtbxprice7.Text = bana.ToString();
            }
            else if (txtbxprdct7.Text == "Gooseberry" || txtbxprdct7.Text == "GOOSEBERRY" || txtbxprdct7.Text == "gooseberry")
            {
                txtbxprice7.Text = gosebry.ToString();
            }
            else if (txtbxprdct7.Text == "Grapes" || txtbxprdct7.Text == "GRAPES" || txtbxprdct7.Text == "grapes")
            {
                txtbxprice7.Text = grps.ToString();
            }
            else if (txtbxprdct7.Text == "Green Grapes" || txtbxprdct7.Text == "GREEN GRAPES" || txtbxprdct7.Text == "green grapes")
            {
                txtbxprice7.Text = grngrps.ToString();
            }
            else if (txtbxprdct7.Text == "Guava" || txtbxprdct7.Text == "GUAVA" || txtbxprdct7.Text == "guava")
            {
                txtbxprice7.Text = guva.ToString();
            }
            else if (txtbxprdct7.Text == "Mango" || txtbxprdct7.Text == "MANGO" || txtbxprdct7.Text == "mango")
            {
                txtbxprice7.Text = mngo.ToString();
            }
            else if (txtbxprdct7.Text == "Mosambi" || txtbxprdct7.Text == "MOSAMBI" || txtbxprdct7.Text == "mosambi")
            {
                txtbxprice7.Text = msmbi.ToString();
            }
            else if (txtbxprdct7.Text == "Orange" || txtbxprdct7.Text == "ORANGE" || txtbxprdct7.Text == "orange")
            {
                txtbxprice7.Text = orng.ToString();
            }
            else if (txtbxprdct7.Text == "Watermelon" || txtbxprdct7.Text == "WATERMELON" || txtbxprdct7.Text == "watermelon")
            {
                txtbxprice7.Text = watrmeln.ToString();
            }
            else if (txtbxprdct7.Text == "Pomegrante" || txtbxprdct7.Text == "POMEGRANTE" || txtbxprdct7.Text == "pomegrante")
            {
                txtbxprice7.Text = pomegrte.ToString();
            }
        }

        private void txtbxprdct8_TextChanged(object sender, EventArgs e)
        {
            if (txtbxprdct8.Text == "Apple" || txtbxprdct8.Text == "APPLE" || txtbxprdct8.Text == "apple")
            {
                txtbxprice8.Text = aple.ToString();
            }
            else if (txtbxprdct8.Text == "Banana" || txtbxprdct8.Text == "BANANA" || txtbxprdct8.Text == "banana")
            {
                txtbxprice8.Text = bana.ToString();
            }
            else if (txtbxprdct8.Text == "Gooseberry" || txtbxprdct8.Text == "GOOSEBERRY" || txtbxprdct8.Text == "gooseberry")
            {
                txtbxprice8.Text = gosebry.ToString();
            }
            else if (txtbxprdct8.Text == "Grapes" || txtbxprdct8.Text == "GRAPES" || txtbxprdct8.Text == "grapes")
            {
                txtbxprice8.Text = grps.ToString();
            }
            else if (txtbxprdct8.Text == "Green Grapes" || txtbxprdct8.Text == "GREEN GRAPES" || txtbxprdct8.Text == "green grapes")
            {
                txtbxprice8.Text = grngrps.ToString();
            }
            else if (txtbxprdct8.Text == "Guava" || txtbxprdct8.Text == "GUAVA" || txtbxprdct8.Text == "guava")
            {
                txtbxprice8.Text = guva.ToString();
            }
            else if (txtbxprdct8.Text == "Mango" || txtbxprdct8.Text == "MANGO" || txtbxprdct8.Text == "mango")
            {
                txtbxprice8.Text = mngo.ToString();
            }
            else if (txtbxprdct8.Text == "Mosambi" || txtbxprdct8.Text == "MOSAMBI" || txtbxprdct8.Text == "mosambi")
            {
                txtbxprice8.Text = msmbi.ToString();
            }
            else if (txtbxprdct8.Text == "Orange" || txtbxprdct8.Text == "ORANGE" || txtbxprdct8.Text == "orange")
            {
                txtbxprice8.Text = orng.ToString();
            }
            else if (txtbxprdct8.Text == "Watermelon" || txtbxprdct8.Text == "WATERMELON" || txtbxprdct8.Text == "watermelon")
            {
                txtbxprice8.Text = watrmeln.ToString();
            }
            else if (txtbxprdct8.Text == "Pomegrante" || txtbxprdct8.Text == "POMEGRANTE" || txtbxprdct8.Text == "pomegrante")
            {
                txtbxprice8.Text = pomegrte.ToString();
            }
        }

        private void txtbxprdct9_TextChanged(object sender, EventArgs e)
        {
            if (txtbxprdct9.Text == "Apple" || txtbxprdct9.Text == "APPLE" || txtbxprdct9.Text == "apple")
            {
                txtbxprice9.Text = aple.ToString();
            }
            else if (txtbxprdct9.Text == "Banana" || txtbxprdct9.Text == "BANANA" || txtbxprdct9.Text == "banana")
            {
                txtbxprice9.Text = bana.ToString();
            }
            else if (txtbxprdct9.Text == "Gooseberry" || txtbxprdct9.Text == "GOOSEBERRY" || txtbxprdct9.Text == "gooseberry")
            {
                txtbxprice9.Text = gosebry.ToString();
            }
            else if (txtbxprdct9.Text == "Grapes" || txtbxprdct9.Text == "GRAPES" || txtbxprdct9.Text == "grapes")
            {
                txtbxprice9.Text = grps.ToString();
            }
            else if (txtbxprdct9.Text == "Green Grapes" || txtbxprdct9.Text == "GREEN GRAPES" || txtbxprdct9.Text == "green grapes")
            {
                txtbxprice9.Text = grngrps.ToString();
            }
            else if (txtbxprdct9.Text == "Guava" || txtbxprdct9.Text == "GUAVA" || txtbxprdct9.Text == "guava")
            {
                txtbxprice9.Text = guva.ToString();
            }
            else if (txtbxprdct9.Text == "Mango" || txtbxprdct9.Text == "MANGO" || txtbxprdct9.Text == "mango")
            {
                txtbxprice9.Text = mngo.ToString();
            }
            else if (txtbxprdct9.Text == "Mosambi" || txtbxprdct9.Text == "MOSAMBI" || txtbxprdct9.Text == "mosambi")
            {
                txtbxprice9.Text = msmbi.ToString();
            }
            else if (txtbxprdct9.Text == "Orange" || txtbxprdct9.Text == "ORANGE" || txtbxprdct9.Text == "orange")
            {
                txtbxprice9.Text = orng.ToString();
            }
            else if (txtbxprdct9.Text == "Watermelon" || txtbxprdct9.Text == "WATERMELON" || txtbxprdct9.Text == "watermelon")
            {
                txtbxprice9.Text = watrmeln.ToString();
            }
            else if (txtbxprdct9.Text == "Pomegrante" || txtbxprdct9.Text == "POMEGRANTE" || txtbxprdct9.Text == "pomegrante")
            {
                txtbxprice9.Text = pomegrte.ToString();
            }
        }

        private void txtbxqty1_TextChanged(object sender, EventArgs e)
        {
            if (txtbxqty1.Text == "")
            {
                txtbxqty1.Text = i.ToString();
            }
            else
            {
                txtbxamt1.Text = (Convert.ToDecimal(txtbxprice1.Text) * Convert.ToDecimal(txtbxqty1.Text)).ToString();
                txtbxtotal.Text = (Convert.ToInt32(txtbxamt1.Text)).ToString();
                txtbxnetamnt.Text = (Convert.ToDecimal(txtbxtotal.Text)).ToString();
            }
        }

        private void txtbxqty2_TextChanged(object sender, EventArgs e)
        {
            if (txtbxqty2.Text == "")
            {
                txtbxqty2.Text = i.ToString();
            }
            else
            {
                txtbxamt2.Text = (Convert.ToDecimal(txtbxprice2.Text) * Convert.ToDecimal(txtbxqty2.Text)).ToString();
                txtbxtotal.Text = (Convert.ToInt32(txtbxamt1.Text) + Convert.ToInt32(txtbxamt2.Text)).ToString();
                txtbxnetamnt.Text = (Convert.ToDecimal(txtbxtotal.Text)).ToString();
            }
        }

        private void txtbxqty3_TextChanged(object sender, EventArgs e)
        {
            if (txtbxqty3.Text == "")
            {
                txtbxqty3.Text = i.ToString();
            }
            else
            {
                txtbxamt3.Text = (Convert.ToDecimal(txtbxprice3.Text) * Convert.ToDecimal(txtbxqty3.Text)).ToString();
                txtbxtotal.Text = (Convert.ToInt32(txtbxamt1.Text) + Convert.ToInt32(txtbxamt2.Text) + Convert.ToInt32(txtbxamt3.Text)).ToString();
                txtbxnetamnt.Text = (Convert.ToDecimal(txtbxtotal.Text)).ToString();
            }
        }

        private void txtbxqty4_TextChanged(object sender, EventArgs e)
        {
            if (txtbxqty4.Text == "")
            {
                txtbxqty4.Text = i.ToString();
            }
            else
            {
                txtbxamt4.Text = (Convert.ToDecimal(txtbxprice4.Text) * Convert.ToDecimal(txtbxqty4.Text)).ToString();
                txtbxtotal.Text = (Convert.ToInt32(txtbxamt1.Text) + Convert.ToInt32(txtbxamt2.Text) + Convert.ToInt32(txtbxamt3.Text) + Convert.ToInt32(txtbxamt4.Text)).ToString();
                txtbxnetamnt.Text = (Convert.ToDecimal(txtbxtotal.Text)).ToString();
            }
        }

        private void txtbxqty5_TextChanged(object sender, EventArgs e)
        {
            if (txtbxqty5.Text == "")
            {
                txtbxqty5.Text = i.ToString();
            }
            else
            {
                txtbxamt5.Text = (Convert.ToDecimal(txtbxprice5.Text) * Convert.ToDecimal(txtbxqty5.Text)).ToString();
                txtbxtotal.Text = (Convert.ToInt32(txtbxamt1.Text) + Convert.ToInt32(txtbxamt2.Text) + Convert.ToInt32(txtbxamt3.Text) + Convert.ToInt32(txtbxamt4.Text) + Convert.ToInt32(txtbxamt5.Text)).ToString();
                txtbxnetamnt.Text = (Convert.ToDecimal(txtbxtotal.Text)).ToString();
            }
        }

        private void txtbxqty6_TextChanged(object sender, EventArgs e)
        {
            if (txtbxqty6.Text == "")
            {
                txtbxqty6.Text = i.ToString();
            }
            else
            {
                txtbxamt6.Text = (Convert.ToDecimal(txtbxprice6.Text) * Convert.ToDecimal(txtbxqty6.Text)).ToString();
                txtbxtotal.Text = (Convert.ToInt32(txtbxamt1.Text) + Convert.ToInt32(txtbxamt2.Text) + Convert.ToInt32(txtbxamt3.Text) + Convert.ToInt32(txtbxamt4.Text) + Convert.ToInt32(txtbxamt5.Text) +
                                   Convert.ToInt32(txtbxamt6.Text)).ToString();
                txtbxnetamnt.Text = (Convert.ToDecimal(txtbxtotal.Text)).ToString();
            }
        }

        private void txtbxqty7_TextChanged(object sender, EventArgs e)
        {
            if (txtbxqty7.Text == "")
            {
                txtbxqty7.Text = i.ToString();
            }
            else
            {
                txtbxamt7.Text = (Convert.ToDecimal(txtbxprice7.Text) * Convert.ToDecimal(txtbxqty7.Text)).ToString();
                txtbxtotal.Text = (Convert.ToInt32(txtbxamt1.Text) + Convert.ToInt32(txtbxamt2.Text) + Convert.ToInt32(txtbxamt3.Text) + Convert.ToInt32(txtbxamt4.Text) + Convert.ToInt32(txtbxamt5.Text) +
                                   Convert.ToInt32(txtbxamt6.Text) + Convert.ToInt32(txtbxamt7.Text)).ToString();
                txtbxnetamnt.Text = (Convert.ToDecimal(txtbxtotal.Text)).ToString();
            }
        }

        private void txtbxqty8_TextChanged(object sender, EventArgs e)
        {
            if (txtbxqty8.Text == "")
            {
                txtbxqty8.Text = i.ToString();
            }
            else
            {
                txtbxamt8.Text = (Convert.ToDecimal(txtbxprice8.Text) * Convert.ToDecimal(txtbxqty8.Text)).ToString();
                txtbxtotal.Text = (Convert.ToInt32(txtbxamt1.Text) + Convert.ToInt32(txtbxamt2.Text) + Convert.ToInt32(txtbxamt3.Text) + Convert.ToInt32(txtbxamt4.Text) + Convert.ToInt32(txtbxamt5.Text) +
                                   Convert.ToInt32(txtbxamt6.Text) + Convert.ToInt32(txtbxamt7.Text) + Convert.ToInt32(txtbxamt8.Text)).ToString();
                txtbxnetamnt.Text = (Convert.ToDecimal(txtbxtotal.Text)).ToString();
            }

        }

        private void txtbxqty9_TextChanged(object sender, EventArgs e)
        {
            if (txtbxqty9.Text == "")
            {
                txtbxqty9.Text = i.ToString();
            }
            else
            {
                txtbxamt9.Text = (Convert.ToDecimal(txtbxprice9.Text) * Convert.ToDecimal(txtbxqty9.Text)).ToString();
                txtbxtotal.Text = (Convert.ToInt32(txtbxamt1.Text) + Convert.ToInt32(txtbxamt2.Text) + Convert.ToInt32(txtbxamt3.Text) + Convert.ToInt32(txtbxamt4.Text) + Convert.ToInt32(txtbxamt5.Text) +
                                   Convert.ToInt32(txtbxamt6.Text) + Convert.ToInt32(txtbxamt7.Text) + Convert.ToInt32(txtbxamt8.Text) + Convert.ToInt32(txtbxamt9.Text)).ToString();
                txtbxnetamnt.Text = (Convert.ToDecimal(txtbxtotal.Text)).ToString();
            }
        }

        private void txtbxdiscnt1_TextChanged(object sender, EventArgs e)
        {
            if (txtbxdiscnt1.Text == "")
            {
                txtbxdiscnt1.Text = i.ToString();
            }
            else
            {
                txtbxdiscnt2.Text = ((Convert.ToDecimal(txtbxdiscnt1.Text)/100) * Convert.ToDecimal(txtbxtotal.Text)).ToString();
                txtbxnetamnt.Text = (Convert.ToDecimal(txtbxtotal.Text) - Convert.ToDecimal(txtbxdiscnt2.Text)).ToString();
            }
        }

    }
}
