﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;

namespace Notepad
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        
        private void newToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Rchtxtbx_notepad.Text == "")
            {
                Rchtxtbx_notepad.Text = "";
            }
            else
            {
                
                DialogResult dr = new DialogResult();
                dr = MessageBox.Show("Do you want to save changes to Untitled?", "Notepad", MessageBoxButtons.YesNoCancel,MessageBoxIcon.Asterisk, MessageBoxDefaultButton.Button1);
                if (dr == DialogResult.Yes)
                {
                    if (this.Text == "Notepad")
                    {
                        saveFileDialog1.Filter = "Text files(*.txt)|*.txt|All files(*.*)|*.*";
                        saveFileDialog1.ShowDialog();
                        if (saveFileDialog1.FileName == "")
                        {
                            saveFileDialog1.Dispose();
                        }
                        else
                        {

                            TextWriter tw;
                            tw = File.CreateText(saveFileDialog1.FileName);
                            tw.WriteLine(Rchtxtbx_notepad.Text);
                            tw.Dispose();
                            Rchtxtbx_notepad.Text = "";
                            this.Text = "NotePad";
                        }
                    }
                    else
                    {
                        TextWriter tw1;
                        tw1 = File.CreateText(this.Text);
                        tw1.WriteLine(Rchtxtbx_notepad.Text);
                        tw1.Dispose();
                        Rchtxtbx_notepad.Text = "";
                        this.Text = "NotePad";
                    }
                }
                else if (dr == DialogResult.No)
                {
                    Rchtxtbx_notepad.Text = "";
                    this.Text = "Notepad";

                }
                else
                {
                }
               
               
            }
        }

        private void openToolStripMenuItem_Click(object sender, EventArgs e)
        {
            openFileDialog1.Filter = "Textfiles(*.txt)|*.txt|All Files(*.*)|*.*";
            openFileDialog1.ShowDialog();
            TextReader tr;
            tr = File.OpenText(openFileDialog1.FileName);
            this.Text = openFileDialog1.FileName;
            Rchtxtbx_notepad.Text = tr.ReadToEnd();

            tr.Dispose();
        }

        private void saveToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (this.Text == "Notepad")
            {
                saveFileDialog1.Filter = "Text files(*.txt)|*.txt|All files(*.*)|*.*";
                saveFileDialog1.ShowDialog();
                if (saveFileDialog1.FileName == "")
                {
                    saveFileDialog1.Dispose();
                }
                else
                {
                    TextWriter tw;
                    tw = File.CreateText(saveFileDialog1.FileName);
                    this.Text = saveFileDialog1.FileName;
                    tw.WriteLine(Rchtxtbx_notepad.Text);
                    tw.Dispose();
                }
               
            }
            else
            {
                TextWriter tw1;
                tw1 = File.CreateText(this.Text);
                tw1.WriteLine(Rchtxtbx_notepad.Text);
                tw1.Dispose();
            }

        }

        private void saveToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            saveFileDialog1.Filter = "Text files(*.txt)|*.txt|All files(*.*)|*.*";
            saveFileDialog1.ShowDialog();
            if (saveFileDialog1.FileName == "")
            {
                saveFileDialog1.Dispose();
            }
            else
            {
                TextWriter tw;
                tw = File.CreateText(saveFileDialog1.FileName);
                this.Text = saveFileDialog1.FileName;
                tw.WriteLine(Rchtxtbx_notepad.Text);
                tw.Dispose();
            }
        }

        private void printToolStripMenuItem_Click(object sender, EventArgs e)
        {
            printDialog1.ShowDialog();
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Rchtxtbx_notepad.Text == "")
            {
                this.Close();
            }
            else
            {
                DialogResult dr = new DialogResult();
                dr = MessageBox.Show("Do you want to save changes to Untitled?", "Notepad", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Asterisk, MessageBoxDefaultButton.Button1);
                if (dr == DialogResult.Yes)
                {
                    if (this.Text == "Notepad")
                    {
                        saveFileDialog1.Filter = "Text files(*.txt)|*.txt|All files(*.*)|*.*";
                        saveFileDialog1.ShowDialog();
                        if (saveFileDialog1.FileName == "")
                        {
                            saveFileDialog1.Dispose();
                        }
                        else
                        {
                            TextWriter tw;
                            tw = File.CreateText(saveFileDialog1.FileName);
                            tw.WriteLine(Rchtxtbx_notepad.Text);
                            tw.Dispose();
                            Rchtxtbx_notepad.Text = "";
                            this.Text = "NotePad";
                        }
                    }
                    else
                    {
                        TextWriter tw1;
                        tw1 = File.CreateText(this.Text);
                        tw1.WriteLine(Rchtxtbx_notepad.Text);
                        tw1.Dispose();
                        Rchtxtbx_notepad.Text = "";
                        this.Text = "NotePad";
                    }
                }
                else if (dr == DialogResult.No)
                {
                    Rchtxtbx_notepad.Text = "";
                    this.Text = "Notepad";
                    this.Close();

                }
                else
                {
                }
            }
            
        }

        private void Form1_FormClosed(object sender, FormClosedEventArgs e)
        {
            if (Rchtxtbx_notepad.Text == "")
            {
                Form1 frm1 = new Form1();
                frm1.Close();
            }
            else
            {
                DialogResult dr = new DialogResult();
                dr = MessageBox.Show("Do you want to save changes to Untitled?", "Notepad", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Asterisk, MessageBoxDefaultButton.Button1);
                if (dr == DialogResult.Yes)
                {
                    if (this.Text == "Notepad")
                    {
                        saveFileDialog1.Filter = "Text files(*.txt)|*.txt|All files(*.*)|*.*";
                        saveFileDialog1.ShowDialog();
                        if (saveFileDialog1.FileName == "")
                        {
                            saveFileDialog1.Dispose();
                        }
                        else
                        {
                            TextWriter tw;
                            tw = File.CreateText(saveFileDialog1.FileName);
                            tw.WriteLine(Rchtxtbx_notepad.Text);
                            tw.Dispose();
                            Rchtxtbx_notepad.Text = "";
                            this.Text = "NotePad";
                        }
                    }
                    else
                    {
                        TextWriter tw1;
                        tw1 = File.CreateText(this.Text);
                        tw1.WriteLine(Rchtxtbx_notepad.Text);
                        tw1.Dispose();
                        Rchtxtbx_notepad.Text = "";
                        this.Text = "NotePad";
                    }
                }
                else if (dr == DialogResult.No)
                {
                    Rchtxtbx_notepad.Text = "";
                    this.Text = "Notepad";
                    this.Close();

                }
                else
                {
                }
            }
        }

        private void undoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            
            Rchtxtbx_notepad.Undo();
        }

        private void cutToolStripMenuItem_Click(object sender, EventArgs e)
        {
                Rchtxtbx_notepad.Cut();
                pasteToolStripMenuItem.Enabled = true;
        }

        private void copyToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Rchtxtbx_notepad.Copy();
            pasteToolStripMenuItem.Enabled = true;
        }

        private void pasteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Rchtxtbx_notepad.Paste();

        }

        private void deleteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Rchtxtbx_notepad.SelectedText != "")
            {
                string s1 = Rchtxtbx_notepad.SelectedText;
                Rchtxtbx_notepad.Text = Rchtxtbx_notepad.Text.Replace(s1, "");
            }
          
        }
        private void editToolStripMenuItem_Click(object sender, EventArgs e)
        {
            copyToolStripMenuItem.Enabled = Rchtxtbx_notepad.SelectionLength > 0;
            cutToolStripMenuItem.Enabled = Rchtxtbx_notepad.SelectionLength > 0;
            deleteToolStripMenuItem.Enabled = Rchtxtbx_notepad.SelectionLength > 0;
            if (Rchtxtbx_notepad.Text == "")
            {
                findToolStripMenuItem.Enabled = false;
                findNextToolStripMenuItem.Enabled = false;
                undoToolStripMenuItem.Enabled = false;
            }
            else
            {
                findToolStripMenuItem.Enabled = true;
                findNextToolStripMenuItem.Enabled = true;
                undoToolStripMenuItem.Enabled = true;
            }

        }

        private void findToolStripMenuItem_Click(object sender, EventArgs e)
        {
            panel1.Visible = true;

            
        }

        private void Rchtxtbx_notepad_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void selectAllToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Rchtxtbx_notepad.SelectAll();
        }

        private void timeDateToolStripMenuItem_Click(object sender, EventArgs e)
        {

            Rchtxtbx_notepad.AppendText(DateTime.Now.ToString());
        }

        private void fontToolStripMenuItem_Click(object sender, EventArgs e)
        {
            fontDialog1.ShowDialog();
            Rchtxtbx_notepad.Font = fontDialog1.Font;
        }

        private void button1_Click(object sender, EventArgs e)
        {
           
            
            if (Rchtxtbx_notepad.Text.Contains(textBox1.Text) == true)
            {
                string s = textBox1.Text;
                int i = textBox1.Text.Count();
                int k = Rchtxtbx_notepad.Text.Count();
                string[] s2 = Rchtxtbx_notepad.Text.Split(' ');
                int l1 = s2.Count();
                
                    foreach(string s1 in s2)
                    {
                        if (radioButton1.Checked == true)
                        {
                            int j = Rchtxtbx_notepad.Text.IndexOf(s);

                            if (s1.Contains(s) == true)
                            {

                                Rchtxtbx_notepad.Select(j, i);
                                Rchtxtbx_notepad.SelectionColor = Color.Blue;
                            }
                        }
                        else
                        {
                            int j = Rchtxtbx_notepad.Text.LastIndexOf(s);

                            if (s1.Contains(s) == true)
                            {

                                Rchtxtbx_notepad.Select(j, i);
                                Rchtxtbx_notepad.SelectionColor = Color.Blue;
                            }
                        }
               }
                
            }
            else
            {
                MessageBox.Show("Cannot find '" + textBox1.Text + "'.", "Notepad", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            Rchtxtbx_notepad.ForeColor = Color.Black;
            if (textBox1.Text == "")
            {
                button1.Enabled = false;
               
            }
            else
            {
                button1.Enabled = true;
                
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            panel1.Hide();
            Rchtxtbx_notepad.SelectionColor = Color.Black;
          
        }

        private void wordWrapToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Rchtxtbx_notepad.Multiline = true;
        }

        private void formatToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Rchtxtbx_notepad.Text == "")
            {
                wordWrapToolStripMenuItem.Enabled = false;
            }
            else
            {
                wordWrapToolStripMenuItem.Enabled = true;
            }
        }

        private void findNextToolStripMenuItem_Click(object sender, EventArgs e)
        {
            panel1.Visible = true;
        }

        private void replaceToolStripMenuItem_Click(object sender, EventArgs e)
        {
            panel1.Visible = true;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (Rchtxtbx_notepad.SelectedText != "")
            {
                string s1 = Rchtxtbx_notepad.SelectedText;
                Rchtxtbx_notepad.Text = Rchtxtbx_notepad.Text.Replace(s1, textBox2.Text);
            }

            
        }

        

        


        
    }
}
