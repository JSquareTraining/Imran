﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;

namespace Web_Browser
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void toolStripButton6_Click(object sender, EventArgs e)
        {

            webBrowser1.Navigate(toolStripComboBox1.Text);
            TextWriter tw2;
            tw2 = File.AppendText(@"C:\Web Browser\History\History.txt");
            tw2.WriteLine(toolStripComboBox1.Text);
            tw2.Dispose();

        }

        private void webBrowser1_ProgressChanged(object sender, WebBrowserProgressChangedEventArgs e)
        {
            if (toolStripProgressBar1.Value < 100)
            {
                if (toolStripProgressBar1.Value <= 50)
                {
                    toolStripStatusLabel1.Text = "Connecting to " + toolStripComboBox1.Text;
                }
                else
                {
                    toolStripStatusLabel1.Text = "Transferring Data from " + toolStripComboBox1.Text;
                }
                toolStripProgressBar1.Value += 50;
            }
            else
            {
                toolStripProgressBar1.Value = 0;

            }
            
        }

        private void toolStripButton3_Click(object sender, EventArgs e)
        {
            webBrowser1.Refresh();
        }

        private void toolStripButton1_Click(object sender, EventArgs e)
        {
            webBrowser1.GoBack();
        }

        private void toolStripButton2_Click(object sender, EventArgs e)
        {
            webBrowser1.GoForward();
        }

        private void toolStripButton4_Click(object sender, EventArgs e)
        {
            webBrowser1.Stop();
        }

        private void toolStripButton5_Click(object sender, EventArgs e)
        {
            webBrowser1.Navigate("www.google.co.in");
            toolStripComboBox1.Text = "www.google.co.in";
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            webBrowser1.Navigate("www.google.co.in");
            toolStripComboBox1.Text = "www.google.co.in";
            statusBarToolStripMenuItem.Checked = true;
         
        }

        private void toolStripButton7_Click(object sender, EventArgs e)
        {
            if (Directory.Exists(@"C:\Web Browser") == true)
            {
                if (File.Exists(@"C:\Web Browser\Bookmarks\Bookmark.txt") == true)
                {
                    TextWriter tw1;
                    tw1 = File.AppendText(@"C:\Web Browser\Bookmarks\Bookmark.txt");
                    tw1.WriteLine(toolStripComboBox1.Text);
                    tw1.Dispose();
                }
            }
            else
            {
                Directory.CreateDirectory(@"C:\Web Browser");
                Directory.CreateDirectory(@"C:\Web Browser\Bookmarks");
                TextWriter tw;
                tw = File.CreateText(@"C:\Web Browser\Bookmarks\Bookmark.txt");
                tw.WriteLine(toolStripComboBox1.Text);
                tw.Dispose();
            }
        }

        private void toolStripButton8_Click(object sender, EventArgs e)
        {
            Form2 frm2 = new Form2();
            
            frm2.radioButton1.Checked = true;
            frm2.radioButton2.Checked = false;
            frm2.Show();
        }

        private void showHistoryToolStripMenuItem_Click(object sender, EventArgs e)
        {

            Form2 frm2 = new Form2();
            
            frm2.radioButton2.Checked = true;
            frm2.radioButton1.Checked = false;
           
            frm2.Show();
            
        }

        private void showBookmarksToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form2 frm2 = new Form2();
            
            frm2.radioButton2.Checked = false;
            frm2.radioButton1.Checked = true;
           
            frm2.Show();
        }

        private void newToolStripMenuItem_Click(object sender, EventArgs e)
        {
            toolStripComboBox1.Text = "about:blank";
            webBrowser1.Navigate("about:blank");
        }

        private void openToolStripMenuItem_Click(object sender, EventArgs e)
        {
            openFileDialog1.Filter = "HTML files(*.html)|*.html";
            openFileDialog1.ShowDialog();
            TextReader tr;
            if (openFileDialog1.FileName == "")
            {
                openFileDialog1.Dispose();
            }
            else
            {
                tr = File.OpenText(openFileDialog1.FileName);
                toolStripComboBox1.Text = openFileDialog1.FileName;
                webBrowser1.DocumentText = tr.ReadToEnd();
                tr.Dispose();
            }
        }

        private void saveToolStripMenuItem_Click(object sender, EventArgs e)
        {
            saveFileDialog1.Filter = "HTML files(*.html)|*.html";
            saveFileDialog1.ShowDialog();
            TextWriter tw;
            if (saveFileDialog1.FileName == "")
            {
                saveFileDialog1.Dispose();
            }
            else
            {
                tw = File.CreateText(saveFileDialog1.FileName);
                tw.Write(webBrowser1.DocumentText);
                tw.Dispose();
            }

        }

        private void printToolStripMenuItem_Click(object sender, EventArgs e)
        {
            printDialog1.ShowDialog();
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void backToolStripMenuItem_Click(object sender, EventArgs e)
        {
            webBrowser1.GoBack();
        }

        private void forwardToolStripMenuItem_Click(object sender, EventArgs e)
        {
            webBrowser1.GoForward();
        }

        private void statusBarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (statusBarToolStripMenuItem.Checked == true)
            {
                statusBarToolStripMenuItem.Checked = false;
                statusStrip1.Show();
              
            }
            if(statusBarToolStripMenuItem.Checked == false)
            {
                statusBarToolStripMenuItem.Checked = true;
                statusStrip1.Hide();
            }

        }

        

       

       
    }
}
