﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WindowsFormsApplication3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
      

        private void click1(object sender, EventArgs e)
        {
            if (oprtrlbl.Text == "")
            {
                Button txtbxnum1 = (Button)sender;
                txtbx1.Text = txtbx1.Text + txtbxnum1.Text;
            }
            else
            {
                Button txtbxnum1 = (Button)sender;
                txtbx2.Text = txtbx2.Text + txtbxnum1.Text;
            }

        }

        

        private void btneqls_Click(object sender, EventArgs e)
        {
            resltlbl.Text = btneqls.Text;

            if (oprtrlbl.Text == "+")
            {
                if (txtbx1.Text == "")
                {
                    txtbx1.Text = "0";
                }
                else if(txtbx2.Text == "")
                {
                    txtbx2.Text = "0";
                }
                
                else
                {
                    resltbx.Text = (Convert.ToDecimal(txtbx1.Text)+Convert.ToDecimal(txtbx2.Text)).ToString();
                }
            }
            else if (oprtrlbl.Text == "-")
            {
                if (txtbx1.Text == "")
                {
                    txtbx1.Text = "0";
                }
                else if (txtbx2.Text == "")
                {
                    txtbx2.Text = "0";
                }
               
                else
                {
                    resltbx.Text = (Convert.ToDecimal(txtbx1.Text) - Convert.ToDecimal(txtbx2.Text)).ToString();

                }
            }
            else if (oprtrlbl.Text == "*")
            {
                if (txtbx1.Text == "")
                {
                    txtbx1.Text = "0";
                }
                else if (txtbx2.Text == "")
                {
                    txtbx2.Text = "0";
                }
                
                else
                {
                    resltbx.Text = (Convert.ToDecimal(txtbx1.Text)*Convert.ToDecimal(txtbx2.Text)).ToString();

                }
            }
            else if (oprtrlbl.Text == "/")
            {
                if (txtbx1.Text == "")
                {
                    txtbx1.Text = "0";
                    resltbx.Text = "0";
                }
                else if (txtbx2.Text == "")
                {
                    txtbx2.Text = "0";
                    
                }
                else if (txtbx2.Text == "0")
                {
                    resltbx.Text = "Error";
                }
                else
                {
                    resltbx.Text = (Convert.ToDecimal(txtbx1.Text)/Convert.ToDecimal(txtbx2.Text)).ToString();
                }
            }
        }

        private void oprtrbtnclick(object sender, EventArgs e)
        {
            Button oprtrclick1 = (Button)sender;
            oprtrlbl.Text = oprtrclick1.Text;
        }

        private void btn_clear_Click(object sender, EventArgs e)
        {
            txtbx1.Clear();
            txtbx2.Clear();
            resltbx.Clear();
            oprtrlbl.Text = "";
            resltlbl.Text = "";
            
        }
        
    }
    }

