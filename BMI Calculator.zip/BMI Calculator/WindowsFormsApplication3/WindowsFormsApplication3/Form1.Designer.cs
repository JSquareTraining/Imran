﻿namespace WindowsFormsApplication3
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtbx1 = new System.Windows.Forms.TextBox();
            this.txtbx2 = new System.Windows.Forms.TextBox();
            this.btn7 = new System.Windows.Forms.Button();
            this.resltbx = new System.Windows.Forms.TextBox();
            this.btn8 = new System.Windows.Forms.Button();
            this.btn9 = new System.Windows.Forms.Button();
            this.btndiv = new System.Windows.Forms.Button();
            this.btn4 = new System.Windows.Forms.Button();
            this.btn5 = new System.Windows.Forms.Button();
            this.btn6 = new System.Windows.Forms.Button();
            this.btnmul = new System.Windows.Forms.Button();
            this.btn1 = new System.Windows.Forms.Button();
            this.btn2 = new System.Windows.Forms.Button();
            this.btn3 = new System.Windows.Forms.Button();
            this.btnsub = new System.Windows.Forms.Button();
            this.btndt = new System.Windows.Forms.Button();
            this.btn0 = new System.Windows.Forms.Button();
            this.btneqls = new System.Windows.Forms.Button();
            this.btnadd = new System.Windows.Forms.Button();
            this.oprtrlbl = new System.Windows.Forms.Label();
            this.resltlbl = new System.Windows.Forms.Label();
            this.btn_clear = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // txtbx1
            // 
            this.txtbx1.BackColor = System.Drawing.SystemColors.Window;
            this.txtbx1.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbx1.Location = new System.Drawing.Point(12, 26);
            this.txtbx1.Name = "txtbx1";
            this.txtbx1.ReadOnly = true;
            this.txtbx1.ShortcutsEnabled = false;
            this.txtbx1.Size = new System.Drawing.Size(128, 29);
            this.txtbx1.TabIndex = 0;
            this.txtbx1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtbx1.Click += new System.EventHandler(this.click1);
            // 
            // txtbx2
            // 
            this.txtbx2.BackColor = System.Drawing.Color.White;
            this.txtbx2.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbx2.Location = new System.Drawing.Point(199, 26);
            this.txtbx2.Name = "txtbx2";
            this.txtbx2.ReadOnly = true;
            this.txtbx2.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.txtbx2.Size = new System.Drawing.Size(123, 29);
            this.txtbx2.TabIndex = 1;
            this.txtbx2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // btn7
            // 
            this.btn7.BackColor = System.Drawing.Color.PaleGoldenrod;
            this.btn7.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn7.Location = new System.Drawing.Point(169, 87);
            this.btn7.Name = "btn7";
            this.btn7.Size = new System.Drawing.Size(47, 44);
            this.btn7.TabIndex = 2;
            this.btn7.Text = "7";
            this.btn7.UseVisualStyleBackColor = false;
            this.btn7.Click += new System.EventHandler(this.click1);
            // 
            // resltbx
            // 
            this.resltbx.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.resltbx.Location = new System.Drawing.Point(381, 26);
            this.resltbx.Name = "resltbx";
            this.resltbx.Size = new System.Drawing.Size(123, 29);
            this.resltbx.TabIndex = 3;
            this.resltbx.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // btn8
            // 
            this.btn8.BackColor = System.Drawing.Color.PaleGoldenrod;
            this.btn8.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn8.Location = new System.Drawing.Point(222, 87);
            this.btn8.Name = "btn8";
            this.btn8.Size = new System.Drawing.Size(47, 44);
            this.btn8.TabIndex = 4;
            this.btn8.Text = "8";
            this.btn8.UseVisualStyleBackColor = false;
            this.btn8.Click += new System.EventHandler(this.click1);
            // 
            // btn9
            // 
            this.btn9.BackColor = System.Drawing.Color.PaleGoldenrod;
            this.btn9.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn9.Location = new System.Drawing.Point(275, 87);
            this.btn9.Name = "btn9";
            this.btn9.Size = new System.Drawing.Size(47, 44);
            this.btn9.TabIndex = 5;
            this.btn9.Text = "9";
            this.btn9.UseVisualStyleBackColor = false;
            this.btn9.Click += new System.EventHandler(this.click1);
            // 
            // btndiv
            // 
            this.btndiv.BackColor = System.Drawing.Color.PaleGoldenrod;
            this.btndiv.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btndiv.Location = new System.Drawing.Point(328, 87);
            this.btndiv.Name = "btndiv";
            this.btndiv.Size = new System.Drawing.Size(47, 44);
            this.btndiv.TabIndex = 6;
            this.btndiv.Text = "/";
            this.btndiv.UseVisualStyleBackColor = false;
            this.btndiv.Click += new System.EventHandler(this.oprtrbtnclick);
            // 
            // btn4
            // 
            this.btn4.BackColor = System.Drawing.Color.PaleGoldenrod;
            this.btn4.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn4.Location = new System.Drawing.Point(169, 150);
            this.btn4.Name = "btn4";
            this.btn4.Size = new System.Drawing.Size(47, 44);
            this.btn4.TabIndex = 7;
            this.btn4.Text = "4";
            this.btn4.UseVisualStyleBackColor = false;
            this.btn4.Click += new System.EventHandler(this.click1);
            // 
            // btn5
            // 
            this.btn5.BackColor = System.Drawing.Color.PaleGoldenrod;
            this.btn5.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn5.Location = new System.Drawing.Point(222, 150);
            this.btn5.Name = "btn5";
            this.btn5.Size = new System.Drawing.Size(47, 44);
            this.btn5.TabIndex = 8;
            this.btn5.Text = "5";
            this.btn5.UseVisualStyleBackColor = false;
            this.btn5.Click += new System.EventHandler(this.click1);
            // 
            // btn6
            // 
            this.btn6.BackColor = System.Drawing.Color.PaleGoldenrod;
            this.btn6.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn6.Location = new System.Drawing.Point(275, 150);
            this.btn6.Name = "btn6";
            this.btn6.Size = new System.Drawing.Size(47, 44);
            this.btn6.TabIndex = 9;
            this.btn6.Text = "6";
            this.btn6.UseVisualStyleBackColor = false;
            this.btn6.Click += new System.EventHandler(this.click1);
            // 
            // btnmul
            // 
            this.btnmul.BackColor = System.Drawing.Color.PaleGoldenrod;
            this.btnmul.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnmul.Location = new System.Drawing.Point(328, 150);
            this.btnmul.Name = "btnmul";
            this.btnmul.Size = new System.Drawing.Size(47, 44);
            this.btnmul.TabIndex = 10;
            this.btnmul.Text = "*";
            this.btnmul.UseVisualStyleBackColor = false;
            this.btnmul.Click += new System.EventHandler(this.oprtrbtnclick);
            // 
            // btn1
            // 
            this.btn1.BackColor = System.Drawing.Color.PaleGoldenrod;
            this.btn1.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn1.Location = new System.Drawing.Point(169, 213);
            this.btn1.Name = "btn1";
            this.btn1.Size = new System.Drawing.Size(47, 44);
            this.btn1.TabIndex = 11;
            this.btn1.Text = "1";
            this.btn1.UseVisualStyleBackColor = false;
            this.btn1.Click += new System.EventHandler(this.click1);
            // 
            // btn2
            // 
            this.btn2.BackColor = System.Drawing.Color.PaleGoldenrod;
            this.btn2.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn2.Location = new System.Drawing.Point(222, 213);
            this.btn2.Name = "btn2";
            this.btn2.Size = new System.Drawing.Size(47, 44);
            this.btn2.TabIndex = 12;
            this.btn2.Text = "2";
            this.btn2.UseVisualStyleBackColor = false;
            this.btn2.Click += new System.EventHandler(this.click1);
            // 
            // btn3
            // 
            this.btn3.BackColor = System.Drawing.Color.PaleGoldenrod;
            this.btn3.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn3.Location = new System.Drawing.Point(275, 213);
            this.btn3.Name = "btn3";
            this.btn3.Size = new System.Drawing.Size(47, 44);
            this.btn3.TabIndex = 13;
            this.btn3.Text = "3";
            this.btn3.UseVisualStyleBackColor = false;
            this.btn3.Click += new System.EventHandler(this.click1);
            // 
            // btnsub
            // 
            this.btnsub.BackColor = System.Drawing.Color.PaleGoldenrod;
            this.btnsub.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnsub.Location = new System.Drawing.Point(328, 213);
            this.btnsub.Name = "btnsub";
            this.btnsub.Size = new System.Drawing.Size(47, 44);
            this.btnsub.TabIndex = 14;
            this.btnsub.Text = "-";
            this.btnsub.UseVisualStyleBackColor = false;
            this.btnsub.Click += new System.EventHandler(this.oprtrbtnclick);
            // 
            // btndt
            // 
            this.btndt.BackColor = System.Drawing.Color.PaleGoldenrod;
            this.btndt.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btndt.Location = new System.Drawing.Point(169, 274);
            this.btndt.Name = "btndt";
            this.btndt.Size = new System.Drawing.Size(47, 44);
            this.btndt.TabIndex = 15;
            this.btndt.Text = ".";
            this.btndt.UseVisualStyleBackColor = false;
            this.btndt.Click += new System.EventHandler(this.click1);
            // 
            // btn0
            // 
            this.btn0.BackColor = System.Drawing.Color.PaleGoldenrod;
            this.btn0.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn0.Location = new System.Drawing.Point(222, 274);
            this.btn0.Name = "btn0";
            this.btn0.Size = new System.Drawing.Size(47, 44);
            this.btn0.TabIndex = 16;
            this.btn0.Text = "0";
            this.btn0.UseVisualStyleBackColor = false;
            this.btn0.Click += new System.EventHandler(this.click1);
            // 
            // btneqls
            // 
            this.btneqls.BackColor = System.Drawing.Color.PaleGoldenrod;
            this.btneqls.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btneqls.Location = new System.Drawing.Point(275, 274);
            this.btneqls.Name = "btneqls";
            this.btneqls.Size = new System.Drawing.Size(47, 44);
            this.btneqls.TabIndex = 17;
            this.btneqls.Text = "=";
            this.btneqls.UseVisualStyleBackColor = false;
            this.btneqls.Click += new System.EventHandler(this.btneqls_Click);
            // 
            // btnadd
            // 
            this.btnadd.BackColor = System.Drawing.Color.PaleGoldenrod;
            this.btnadd.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnadd.Location = new System.Drawing.Point(328, 274);
            this.btnadd.Name = "btnadd";
            this.btnadd.Size = new System.Drawing.Size(47, 44);
            this.btnadd.TabIndex = 18;
            this.btnadd.Text = "+";
            this.btnadd.UseVisualStyleBackColor = false;
            this.btnadd.Click += new System.EventHandler(this.oprtrbtnclick);
            // 
            // oprtrlbl
            // 
            this.oprtrlbl.BackColor = System.Drawing.Color.LemonChiffon;
            this.oprtrlbl.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.oprtrlbl.Location = new System.Drawing.Point(146, 26);
            this.oprtrlbl.Name = "oprtrlbl";
            this.oprtrlbl.Size = new System.Drawing.Size(47, 29);
            this.oprtrlbl.TabIndex = 19;
            this.oprtrlbl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.oprtrlbl.Click += new System.EventHandler(this.oprtrbtnclick);
            // 
            // resltlbl
            // 
            this.resltlbl.BackColor = System.Drawing.Color.LemonChiffon;
            this.resltlbl.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.resltlbl.Location = new System.Drawing.Point(328, 26);
            this.resltlbl.Name = "resltlbl";
            this.resltlbl.Size = new System.Drawing.Size(47, 29);
            this.resltlbl.TabIndex = 20;
            this.resltlbl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btn_clear
            // 
            this.btn_clear.BackColor = System.Drawing.Color.PaleGoldenrod;
            this.btn_clear.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_clear.Location = new System.Drawing.Point(116, 87);
            this.btn_clear.Name = "btn_clear";
            this.btn_clear.Size = new System.Drawing.Size(47, 44);
            this.btn_clear.TabIndex = 21;
            this.btn_clear.Text = "C";
            this.btn_clear.UseVisualStyleBackColor = false;
            this.btn_clear.Click += new System.EventHandler(this.btn_clear_Click);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.PaleGoldenrod;
            this.button1.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(116, 150);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(47, 44);
            this.button1.TabIndex = 22;
            this.button1.Text = "M-";
            this.button1.UseVisualStyleBackColor = false;
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.PaleGoldenrod;
            this.button2.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.Location = new System.Drawing.Point(116, 213);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(47, 44);
            this.button2.TabIndex = 23;
            this.button2.Text = "M+";
            this.button2.UseVisualStyleBackColor = false;
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.PaleGoldenrod;
            this.button3.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3.Location = new System.Drawing.Point(116, 274);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(47, 44);
            this.button3.TabIndex = 24;
            this.button3.Text = "CE";
            this.button3.UseVisualStyleBackColor = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(516, 348);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.btn_clear);
            this.Controls.Add(this.resltlbl);
            this.Controls.Add(this.oprtrlbl);
            this.Controls.Add(this.btnadd);
            this.Controls.Add(this.btneqls);
            this.Controls.Add(this.btn0);
            this.Controls.Add(this.btndt);
            this.Controls.Add(this.btnsub);
            this.Controls.Add(this.btn3);
            this.Controls.Add(this.btn2);
            this.Controls.Add(this.btn1);
            this.Controls.Add(this.btnmul);
            this.Controls.Add(this.btn6);
            this.Controls.Add(this.btn5);
            this.Controls.Add(this.btn4);
            this.Controls.Add(this.btndiv);
            this.Controls.Add(this.btn9);
            this.Controls.Add(this.btn8);
            this.Controls.Add(this.resltbx);
            this.Controls.Add(this.btn7);
            this.Controls.Add(this.txtbx2);
            this.Controls.Add(this.txtbx1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Calculator";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtbx1;
        private System.Windows.Forms.TextBox txtbx2;
        private System.Windows.Forms.Button btn7;
        private System.Windows.Forms.TextBox resltbx;
        private System.Windows.Forms.Button btn8;
        private System.Windows.Forms.Button btn9;
        private System.Windows.Forms.Button btndiv;
        private System.Windows.Forms.Button btn4;
        private System.Windows.Forms.Button btn5;
        private System.Windows.Forms.Button btn6;
        private System.Windows.Forms.Button btnmul;
        private System.Windows.Forms.Button btn1;
        private System.Windows.Forms.Button btn2;
        private System.Windows.Forms.Button btn3;
        private System.Windows.Forms.Button btnsub;
        private System.Windows.Forms.Button btndt;
        private System.Windows.Forms.Button btn0;
        private System.Windows.Forms.Button btneqls;
        private System.Windows.Forms.Button btnadd;
        private System.Windows.Forms.Label oprtrlbl;
        private System.Windows.Forms.Label resltlbl;
        private System.Windows.Forms.Button btn_clear;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
    }
}

