﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;

namespace Gmail
{
    public partial class Form5 : Form
    {
        public Form5()
        {
            InitializeComponent();
        }
       
        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "" || textBox2.Text == "")
            {
                MessageBox.Show("Please fill the Receipient/Subject", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                string[] s = textBox1.Text.Split('@');
                string s1 = string.Format("{0}", s);
                string[] m = label5.Text.Split('@');
                string m1 = string.Format("{0}",m);
                if (Directory.Exists(@"C:\Gmail\" + s1) == true)
                {
                    TextWriter tw;
                    tw = File.CreateText(@"C:\Gmail\" + s1 + @"\Inbox\" + textBox2.Text + ".txt");
                    tw.WriteLine(richTextBox1.Text);
                    tw.Dispose();

                    TextWriter tw1;
                    tw1 = File.CreateText(@"C:\Gmail\" + m1 + @"\Sent Items\" + textBox2.Text + ".txt");
                    tw1.WriteLine(richTextBox1.Text);
                    tw1.Dispose();
                    DialogResult dr3 = new DialogResult();
                    dr3 = MessageBox.Show("Message Sent Successfully", "Gmail", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    if (dr3 == DialogResult.OK)
                    {
                        this.Close();
                    }
                }
                else
                {
                    MessageBox.Show("Invalid Email-id", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            fontDialog1.ShowDialog();
            richTextBox1.Font = fontDialog1.Font;
        }
    }
}
