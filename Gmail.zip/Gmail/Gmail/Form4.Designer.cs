﻿namespace Gmail
{
    partial class Form4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.lbl1 = new System.Windows.Forms.Label();
            this.chckbx1 = new System.Windows.Forms.CheckBox();
            this.chckbx2 = new System.Windows.Forms.CheckBox();
            this.lbl2 = new System.Windows.Forms.Label();
            this.chckbx4 = new System.Windows.Forms.CheckBox();
            this.lbl4 = new System.Windows.Forms.Label();
            this.chckbx3 = new System.Windows.Forms.CheckBox();
            this.lbl3 = new System.Windows.Forms.Label();
            this.chckbx6 = new System.Windows.Forms.CheckBox();
            this.lbl6 = new System.Windows.Forms.Label();
            this.chckbx5 = new System.Windows.Forms.CheckBox();
            this.lbl5 = new System.Windows.Forms.Label();
            this.lbl7 = new System.Windows.Forms.Label();
            this.lbl8 = new System.Windows.Forms.Label();
            this.lbl9 = new System.Windows.Forms.Label();
            this.lbl10 = new System.Windows.Forms.Label();
            this.lbl11 = new System.Windows.Forms.Label();
            this.lbl12 = new System.Windows.Forms.Label();
            this.lbl13 = new System.Windows.Forms.Label();
            this.lbl14 = new System.Windows.Forms.Label();
            this.lbl15 = new System.Windows.Forms.Label();
            this.lbl16 = new System.Windows.Forms.Label();
            this.lbl17 = new System.Windows.Forms.Label();
            this.lbl18 = new System.Windows.Forms.Label();
            this.chckbx7 = new System.Windows.Forms.CheckBox();
            this.chckbx8 = new System.Windows.Forms.CheckBox();
            this.chckbx9 = new System.Windows.Forms.CheckBox();
            this.chckbx10 = new System.Windows.Forms.CheckBox();
            this.chckbx11 = new System.Windows.Forms.CheckBox();
            this.chckbx12 = new System.Windows.Forms.CheckBox();
            this.chckbx13 = new System.Windows.Forms.CheckBox();
            this.chckbx14 = new System.Windows.Forms.CheckBox();
            this.chckbx15 = new System.Windows.Forms.CheckBox();
            this.chckbx16 = new System.Windows.Forms.CheckBox();
            this.chckbx17 = new System.Windows.Forms.CheckBox();
            this.chckbx18 = new System.Windows.Forms.CheckBox();
            this.label1 = new System.Windows.Forms.Label();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.deleteToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.contextMenuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // lbl1
            // 
            this.lbl1.BackColor = System.Drawing.Color.White;
            this.lbl1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl1.Dock = System.Windows.Forms.DockStyle.Top;
            this.lbl1.Location = new System.Drawing.Point(0, 0);
            this.lbl1.Name = "lbl1";
            this.lbl1.Size = new System.Drawing.Size(1114, 32);
            this.lbl1.TabIndex = 0;
            this.lbl1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl1.Click += new System.EventHandler(this.lbl1_Click);
            // 
            // chckbx1
            // 
            this.chckbx1.AutoSize = true;
            this.chckbx1.Location = new System.Drawing.Point(8, 8);
            this.chckbx1.Name = "chckbx1";
            this.chckbx1.Size = new System.Drawing.Size(15, 14);
            this.chckbx1.TabIndex = 1;
            this.chckbx1.UseVisualStyleBackColor = true;
            // 
            // chckbx2
            // 
            this.chckbx2.AutoSize = true;
            this.chckbx2.Location = new System.Drawing.Point(8, 42);
            this.chckbx2.Name = "chckbx2";
            this.chckbx2.Size = new System.Drawing.Size(15, 14);
            this.chckbx2.TabIndex = 3;
            this.chckbx2.UseVisualStyleBackColor = true;
            // 
            // lbl2
            // 
            this.lbl2.BackColor = System.Drawing.Color.White;
            this.lbl2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl2.Dock = System.Windows.Forms.DockStyle.Top;
            this.lbl2.Location = new System.Drawing.Point(0, 32);
            this.lbl2.Name = "lbl2";
            this.lbl2.Size = new System.Drawing.Size(1114, 32);
            this.lbl2.TabIndex = 2;
            this.lbl2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl2.Click += new System.EventHandler(this.lbl2_Click);
            // 
            // chckbx4
            // 
            this.chckbx4.AutoSize = true;
            this.chckbx4.Location = new System.Drawing.Point(8, 106);
            this.chckbx4.Name = "chckbx4";
            this.chckbx4.Size = new System.Drawing.Size(15, 14);
            this.chckbx4.TabIndex = 7;
            this.chckbx4.UseVisualStyleBackColor = true;
            // 
            // lbl4
            // 
            this.lbl4.BackColor = System.Drawing.Color.White;
            this.lbl4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl4.Dock = System.Windows.Forms.DockStyle.Top;
            this.lbl4.Location = new System.Drawing.Point(0, 96);
            this.lbl4.Name = "lbl4";
            this.lbl4.Size = new System.Drawing.Size(1114, 32);
            this.lbl4.TabIndex = 6;
            this.lbl4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl4.Click += new System.EventHandler(this.lbl4_Click);
            // 
            // chckbx3
            // 
            this.chckbx3.AutoSize = true;
            this.chckbx3.Location = new System.Drawing.Point(8, 74);
            this.chckbx3.Name = "chckbx3";
            this.chckbx3.Size = new System.Drawing.Size(15, 14);
            this.chckbx3.TabIndex = 5;
            this.chckbx3.UseVisualStyleBackColor = true;
            // 
            // lbl3
            // 
            this.lbl3.BackColor = System.Drawing.Color.White;
            this.lbl3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl3.Dock = System.Windows.Forms.DockStyle.Top;
            this.lbl3.Location = new System.Drawing.Point(0, 64);
            this.lbl3.Name = "lbl3";
            this.lbl3.Size = new System.Drawing.Size(1114, 32);
            this.lbl3.TabIndex = 4;
            this.lbl3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl3.Click += new System.EventHandler(this.lbl3_Click);
            // 
            // chckbx6
            // 
            this.chckbx6.AutoSize = true;
            this.chckbx6.Location = new System.Drawing.Point(8, 170);
            this.chckbx6.Name = "chckbx6";
            this.chckbx6.Size = new System.Drawing.Size(15, 14);
            this.chckbx6.TabIndex = 11;
            this.chckbx6.UseVisualStyleBackColor = true;
            // 
            // lbl6
            // 
            this.lbl6.BackColor = System.Drawing.Color.White;
            this.lbl6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl6.Dock = System.Windows.Forms.DockStyle.Top;
            this.lbl6.Location = new System.Drawing.Point(0, 160);
            this.lbl6.Name = "lbl6";
            this.lbl6.Size = new System.Drawing.Size(1114, 32);
            this.lbl6.TabIndex = 10;
            this.lbl6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl6.Click += new System.EventHandler(this.lbl6_Click);
            // 
            // chckbx5
            // 
            this.chckbx5.AutoSize = true;
            this.chckbx5.Location = new System.Drawing.Point(8, 138);
            this.chckbx5.Name = "chckbx5";
            this.chckbx5.Size = new System.Drawing.Size(15, 14);
            this.chckbx5.TabIndex = 9;
            this.chckbx5.UseVisualStyleBackColor = true;
            // 
            // lbl5
            // 
            this.lbl5.BackColor = System.Drawing.Color.White;
            this.lbl5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl5.Dock = System.Windows.Forms.DockStyle.Top;
            this.lbl5.Location = new System.Drawing.Point(0, 128);
            this.lbl5.Name = "lbl5";
            this.lbl5.Size = new System.Drawing.Size(1114, 32);
            this.lbl5.TabIndex = 8;
            this.lbl5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl5.Click += new System.EventHandler(this.lbl5_Click);
            // 
            // lbl7
            // 
            this.lbl7.BackColor = System.Drawing.Color.White;
            this.lbl7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl7.Dock = System.Windows.Forms.DockStyle.Top;
            this.lbl7.Location = new System.Drawing.Point(0, 192);
            this.lbl7.Name = "lbl7";
            this.lbl7.Size = new System.Drawing.Size(1114, 32);
            this.lbl7.TabIndex = 12;
            this.lbl7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl7.Click += new System.EventHandler(this.lbl7_Click);
            // 
            // lbl8
            // 
            this.lbl8.BackColor = System.Drawing.Color.White;
            this.lbl8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl8.Dock = System.Windows.Forms.DockStyle.Top;
            this.lbl8.Location = new System.Drawing.Point(0, 224);
            this.lbl8.Name = "lbl8";
            this.lbl8.Size = new System.Drawing.Size(1114, 32);
            this.lbl8.TabIndex = 13;
            this.lbl8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl8.Click += new System.EventHandler(this.lbl8_Click);
            // 
            // lbl9
            // 
            this.lbl9.BackColor = System.Drawing.Color.White;
            this.lbl9.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl9.Dock = System.Windows.Forms.DockStyle.Top;
            this.lbl9.Location = new System.Drawing.Point(0, 256);
            this.lbl9.Name = "lbl9";
            this.lbl9.Size = new System.Drawing.Size(1114, 32);
            this.lbl9.TabIndex = 14;
            this.lbl9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl9.Click += new System.EventHandler(this.lbl9_Click);
            // 
            // lbl10
            // 
            this.lbl10.BackColor = System.Drawing.Color.White;
            this.lbl10.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl10.Dock = System.Windows.Forms.DockStyle.Top;
            this.lbl10.Location = new System.Drawing.Point(0, 288);
            this.lbl10.Name = "lbl10";
            this.lbl10.Size = new System.Drawing.Size(1114, 32);
            this.lbl10.TabIndex = 15;
            this.lbl10.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl10.Click += new System.EventHandler(this.lbl10_Click);
            // 
            // lbl11
            // 
            this.lbl11.BackColor = System.Drawing.Color.White;
            this.lbl11.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl11.Dock = System.Windows.Forms.DockStyle.Top;
            this.lbl11.Location = new System.Drawing.Point(0, 320);
            this.lbl11.Name = "lbl11";
            this.lbl11.Size = new System.Drawing.Size(1114, 32);
            this.lbl11.TabIndex = 16;
            this.lbl11.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl11.Click += new System.EventHandler(this.lbl11_Click);
            // 
            // lbl12
            // 
            this.lbl12.BackColor = System.Drawing.Color.White;
            this.lbl12.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl12.Dock = System.Windows.Forms.DockStyle.Top;
            this.lbl12.Location = new System.Drawing.Point(0, 352);
            this.lbl12.Name = "lbl12";
            this.lbl12.Size = new System.Drawing.Size(1114, 32);
            this.lbl12.TabIndex = 17;
            this.lbl12.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl12.Click += new System.EventHandler(this.lbl12_Click);
            // 
            // lbl13
            // 
            this.lbl13.BackColor = System.Drawing.Color.White;
            this.lbl13.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl13.Dock = System.Windows.Forms.DockStyle.Top;
            this.lbl13.Location = new System.Drawing.Point(0, 384);
            this.lbl13.Name = "lbl13";
            this.lbl13.Size = new System.Drawing.Size(1114, 32);
            this.lbl13.TabIndex = 18;
            this.lbl13.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl13.Click += new System.EventHandler(this.lbl13_Click);
            // 
            // lbl14
            // 
            this.lbl14.BackColor = System.Drawing.Color.White;
            this.lbl14.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl14.Dock = System.Windows.Forms.DockStyle.Top;
            this.lbl14.Location = new System.Drawing.Point(0, 416);
            this.lbl14.Name = "lbl14";
            this.lbl14.Size = new System.Drawing.Size(1114, 32);
            this.lbl14.TabIndex = 19;
            this.lbl14.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl14.Click += new System.EventHandler(this.lbl14_Click);
            // 
            // lbl15
            // 
            this.lbl15.BackColor = System.Drawing.Color.White;
            this.lbl15.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl15.Dock = System.Windows.Forms.DockStyle.Top;
            this.lbl15.Location = new System.Drawing.Point(0, 448);
            this.lbl15.Name = "lbl15";
            this.lbl15.Size = new System.Drawing.Size(1114, 32);
            this.lbl15.TabIndex = 20;
            this.lbl15.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl15.Click += new System.EventHandler(this.lbl15_Click);
            // 
            // lbl16
            // 
            this.lbl16.BackColor = System.Drawing.Color.White;
            this.lbl16.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl16.Dock = System.Windows.Forms.DockStyle.Top;
            this.lbl16.Location = new System.Drawing.Point(0, 480);
            this.lbl16.Name = "lbl16";
            this.lbl16.Size = new System.Drawing.Size(1114, 32);
            this.lbl16.TabIndex = 21;
            this.lbl16.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl16.Click += new System.EventHandler(this.lbl16_Click);
            // 
            // lbl17
            // 
            this.lbl17.BackColor = System.Drawing.Color.White;
            this.lbl17.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl17.Dock = System.Windows.Forms.DockStyle.Top;
            this.lbl17.Location = new System.Drawing.Point(0, 512);
            this.lbl17.Name = "lbl17";
            this.lbl17.Size = new System.Drawing.Size(1114, 32);
            this.lbl17.TabIndex = 22;
            this.lbl17.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl17.Click += new System.EventHandler(this.lbl17_Click);
            // 
            // lbl18
            // 
            this.lbl18.BackColor = System.Drawing.Color.White;
            this.lbl18.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl18.Dock = System.Windows.Forms.DockStyle.Top;
            this.lbl18.Location = new System.Drawing.Point(0, 544);
            this.lbl18.Name = "lbl18";
            this.lbl18.Size = new System.Drawing.Size(1114, 32);
            this.lbl18.TabIndex = 23;
            this.lbl18.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl18.Click += new System.EventHandler(this.lbl18_Click);
            // 
            // chckbx7
            // 
            this.chckbx7.AutoSize = true;
            this.chckbx7.Location = new System.Drawing.Point(8, 202);
            this.chckbx7.Name = "chckbx7";
            this.chckbx7.Size = new System.Drawing.Size(15, 14);
            this.chckbx7.TabIndex = 24;
            this.chckbx7.UseVisualStyleBackColor = true;
            // 
            // chckbx8
            // 
            this.chckbx8.AutoSize = true;
            this.chckbx8.Location = new System.Drawing.Point(8, 234);
            this.chckbx8.Name = "chckbx8";
            this.chckbx8.Size = new System.Drawing.Size(15, 14);
            this.chckbx8.TabIndex = 25;
            this.chckbx8.UseVisualStyleBackColor = true;
            // 
            // chckbx9
            // 
            this.chckbx9.AutoSize = true;
            this.chckbx9.Location = new System.Drawing.Point(8, 266);
            this.chckbx9.Name = "chckbx9";
            this.chckbx9.Size = new System.Drawing.Size(15, 14);
            this.chckbx9.TabIndex = 26;
            this.chckbx9.UseVisualStyleBackColor = true;
            // 
            // chckbx10
            // 
            this.chckbx10.AutoSize = true;
            this.chckbx10.Location = new System.Drawing.Point(8, 298);
            this.chckbx10.Name = "chckbx10";
            this.chckbx10.Size = new System.Drawing.Size(15, 14);
            this.chckbx10.TabIndex = 27;
            this.chckbx10.UseVisualStyleBackColor = true;
            // 
            // chckbx11
            // 
            this.chckbx11.AutoSize = true;
            this.chckbx11.Location = new System.Drawing.Point(8, 330);
            this.chckbx11.Name = "chckbx11";
            this.chckbx11.Size = new System.Drawing.Size(15, 14);
            this.chckbx11.TabIndex = 28;
            this.chckbx11.UseVisualStyleBackColor = true;
            // 
            // chckbx12
            // 
            this.chckbx12.AutoSize = true;
            this.chckbx12.Location = new System.Drawing.Point(8, 362);
            this.chckbx12.Name = "chckbx12";
            this.chckbx12.Size = new System.Drawing.Size(15, 14);
            this.chckbx12.TabIndex = 29;
            this.chckbx12.UseVisualStyleBackColor = true;
            // 
            // chckbx13
            // 
            this.chckbx13.AutoSize = true;
            this.chckbx13.Location = new System.Drawing.Point(8, 394);
            this.chckbx13.Name = "chckbx13";
            this.chckbx13.Size = new System.Drawing.Size(15, 14);
            this.chckbx13.TabIndex = 30;
            this.chckbx13.UseVisualStyleBackColor = true;
            // 
            // chckbx14
            // 
            this.chckbx14.AutoSize = true;
            this.chckbx14.Location = new System.Drawing.Point(8, 426);
            this.chckbx14.Name = "chckbx14";
            this.chckbx14.Size = new System.Drawing.Size(15, 14);
            this.chckbx14.TabIndex = 31;
            this.chckbx14.UseVisualStyleBackColor = true;
            // 
            // chckbx15
            // 
            this.chckbx15.AutoSize = true;
            this.chckbx15.Location = new System.Drawing.Point(8, 458);
            this.chckbx15.Name = "chckbx15";
            this.chckbx15.Size = new System.Drawing.Size(15, 14);
            this.chckbx15.TabIndex = 32;
            this.chckbx15.UseVisualStyleBackColor = true;
            // 
            // chckbx16
            // 
            this.chckbx16.AutoSize = true;
            this.chckbx16.Location = new System.Drawing.Point(8, 490);
            this.chckbx16.Name = "chckbx16";
            this.chckbx16.Size = new System.Drawing.Size(15, 14);
            this.chckbx16.TabIndex = 33;
            this.chckbx16.UseVisualStyleBackColor = true;
            // 
            // chckbx17
            // 
            this.chckbx17.AutoSize = true;
            this.chckbx17.Location = new System.Drawing.Point(8, 522);
            this.chckbx17.Name = "chckbx17";
            this.chckbx17.Size = new System.Drawing.Size(15, 14);
            this.chckbx17.TabIndex = 34;
            this.chckbx17.UseVisualStyleBackColor = true;
            // 
            // chckbx18
            // 
            this.chckbx18.AutoSize = true;
            this.chckbx18.Location = new System.Drawing.Point(8, 554);
            this.chckbx18.Name = "chckbx18";
            this.chckbx18.Size = new System.Drawing.Size(15, 14);
            this.chckbx18.TabIndex = 35;
            this.chckbx18.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(1048, 553);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(54, 19);
            this.label1.TabIndex = 36;
            this.label1.Text = "label1";
            this.label1.Visible = false;
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.deleteToolStripMenuItem});
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(108, 26);
            // 
            // deleteToolStripMenuItem
            // 
            this.deleteToolStripMenuItem.Name = "deleteToolStripMenuItem";
            this.deleteToolStripMenuItem.Size = new System.Drawing.Size(107, 22);
            this.deleteToolStripMenuItem.Text = "Delete";
            this.deleteToolStripMenuItem.Click += new System.EventHandler(this.deleteToolStripMenuItem_Click_1);
            // 
            // Form4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 19F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.ClientSize = new System.Drawing.Size(1114, 580);
            this.ContextMenuStrip = this.contextMenuStrip1;
            this.ControlBox = false;
            this.Controls.Add(this.label1);
            this.Controls.Add(this.chckbx18);
            this.Controls.Add(this.chckbx17);
            this.Controls.Add(this.chckbx16);
            this.Controls.Add(this.chckbx15);
            this.Controls.Add(this.chckbx14);
            this.Controls.Add(this.chckbx13);
            this.Controls.Add(this.chckbx12);
            this.Controls.Add(this.chckbx11);
            this.Controls.Add(this.chckbx10);
            this.Controls.Add(this.chckbx9);
            this.Controls.Add(this.chckbx8);
            this.Controls.Add(this.chckbx7);
            this.Controls.Add(this.lbl18);
            this.Controls.Add(this.lbl17);
            this.Controls.Add(this.lbl16);
            this.Controls.Add(this.lbl15);
            this.Controls.Add(this.lbl14);
            this.Controls.Add(this.lbl13);
            this.Controls.Add(this.lbl12);
            this.Controls.Add(this.lbl11);
            this.Controls.Add(this.lbl10);
            this.Controls.Add(this.lbl9);
            this.Controls.Add(this.lbl8);
            this.Controls.Add(this.lbl7);
            this.Controls.Add(this.chckbx6);
            this.Controls.Add(this.lbl6);
            this.Controls.Add(this.chckbx5);
            this.Controls.Add(this.lbl5);
            this.Controls.Add(this.chckbx4);
            this.Controls.Add(this.lbl4);
            this.Controls.Add(this.chckbx3);
            this.Controls.Add(this.lbl3);
            this.Controls.Add(this.chckbx2);
            this.Controls.Add(this.lbl2);
            this.Controls.Add(this.chckbx1);
            this.Controls.Add(this.lbl1);
            this.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.Name = "Form4";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Inbox";
            this.contextMenuStrip1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        public System.Windows.Forms.Label lbl1;
        public System.Windows.Forms.CheckBox chckbx1;
        public System.Windows.Forms.CheckBox chckbx2;
        public System.Windows.Forms.Label lbl2;
        public System.Windows.Forms.CheckBox chckbx4;
        public System.Windows.Forms.Label lbl4;
        public System.Windows.Forms.CheckBox chckbx3;
        public System.Windows.Forms.Label lbl3;
        public System.Windows.Forms.CheckBox chckbx6;
        public System.Windows.Forms.Label lbl6;
        public System.Windows.Forms.CheckBox chckbx5;
        public System.Windows.Forms.Label lbl5;
        public System.Windows.Forms.Label lbl7;
        public System.Windows.Forms.Label lbl8;
        public System.Windows.Forms.Label lbl9;
        public System.Windows.Forms.Label lbl10;
        public System.Windows.Forms.Label lbl11;
        public System.Windows.Forms.Label lbl12;
        public System.Windows.Forms.Label lbl13;
        public System.Windows.Forms.Label lbl14;
        public System.Windows.Forms.Label lbl15;
        public System.Windows.Forms.Label lbl16;
        public System.Windows.Forms.Label lbl17;
        public System.Windows.Forms.Label lbl18;
        public System.Windows.Forms.CheckBox chckbx7;
        public System.Windows.Forms.CheckBox chckbx8;
        public System.Windows.Forms.CheckBox chckbx9;
        public System.Windows.Forms.CheckBox chckbx10;
        public System.Windows.Forms.CheckBox chckbx11;
        public System.Windows.Forms.CheckBox chckbx12;
        public System.Windows.Forms.CheckBox chckbx13;
        public System.Windows.Forms.CheckBox chckbx14;
        public System.Windows.Forms.CheckBox chckbx15;
        public System.Windows.Forms.CheckBox chckbx16;
        public System.Windows.Forms.CheckBox chckbx17;
        public System.Windows.Forms.CheckBox chckbx18;
        public System.Windows.Forms.Label label1;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.ToolStripMenuItem deleteToolStripMenuItem;

    }
}