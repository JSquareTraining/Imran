﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;

namespace Gmail
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            textBox1.Text = "Email";
            textBox2.Text = "Password";
            textBox1.ForeColor = Color.Gray;
            textBox2.ForeColor = Color.Gray;
        }

        private void textBox1_Click(object sender, EventArgs e)
        {
            textBox1.Text = "";
            textBox1.ForeColor = Color.Black;
        }

        private void textBox2_Click(object sender, EventArgs e)
        {
            textBox2.Text = "";
            textBox2.ForeColor = Color.Black;
        }

        private void lbl_crtaccnt_MouseHover(object sender, EventArgs e)
        {
            lbl_crtaccnt.ForeColor = Color.Gray;
        }

        private void lbl_crtaccnt_MouseLeave(object sender, EventArgs e)
        {
            lbl_crtaccnt.ForeColor = Color.CornflowerBlue;
        }

        private void lbl_needhlp_MouseHover(object sender, EventArgs e)
        {
            lbl_needhlp.ForeColor = Color.Gray;
        }

        private void lbl_needhlp_MouseLeave(object sender, EventArgs e)
        {
            lbl_needhlp.ForeColor = Color.CornflowerBlue;
        }

        private void lbl_crtaccnt_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form2 frm2 = new Form2();
            frm2.Show();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "" || textBox1.Text == "Email" || textBox2.Text == "" || textBox2.Text == "Password")
            {
                label3.ForeColor = Color.Maroon;
                label3.Text = "Please enter the valid Email-id/Password";
            }
            else
            {
                if (File.Exists(@"C:\Gmail\" + textBox1.Text + @"\" + textBox1.Text + ".txt") == true)
                {
                    TextReader tr;
                    tr = File.OpenText(@"C:\Gmail\" + textBox1.Text + @"\" + textBox1.Text + ".txt");
                    tr.ReadLine();
                    tr.ReadLine();
                    string s = tr.ReadLine();
                    string[] s1 = s.Split('@');
                    string s2 = string.Format("{0}", s1);
                    if (textBox1.Text == s2 && textBox2.Text == tr.ReadLine())
                    {
                        Form3 frm3 = new Form3();
                        frm3.label1.Text = textBox1.Text + "@gmail.com";
                        frm3.Show();
                        this.Hide();
                    }
                    else
                    {
                        label3.ForeColor = Color.Maroon;
                        label3.Text = "Please enter the valid Email-id/Password";
                    }
                }
                else
                {
                    label3.ForeColor = Color.Maroon;
                    label3.Text = "Please enter the valid Email-id/Password";
                }
                
                
            }
        }

        private void Form1_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();
        }
    }
}
