﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Reflection;
using System.Resources;

namespace Offer_Letter
{
    public partial class Form1 : Form
    {

        int n = 0;
        string x = null;
        public Form1()
        {
            InitializeComponent();
        }
        Form2 frm2 = new Form2();
        Form3 frm3 = new Form3();
        Properties.Settings m = new Properties.Settings();
        private void button1_Click(object sender, EventArgs e)
        {
            m.fname = fnmetxtbx.Text;
            m.lname = lnmetxtbx.Text;
            m.address = addrstxtbx.Text;
            m.doj = dojtxtbx.Text;
            m.salary = slrytxtbx.Text;
            m.plceoj = plcejoingtxtbx.Text;
            m.prbtnperd = probtnperdtxtbx.Text;
            m.bnfts = bnftstxtbx.Text;
            m.desg = desgntxtbx.Text;
            frm2.label1.Text = fnmetxtbx.Text;
            frm2.label7.Text = lnmetxtbx.Text;
            frm2.label8.Text = desgntxtbx.Text;
           
            string[] a = {"One","Two","Three","Four","Five","Six","Seven","Eight","Nine","Ten",
                           "Eleven","Twelve","Thirteen","Fourteen","Fifteen","Sixteen",
                           "Seventeen","Eighteen","Ninteen"
                         };
            string[] b = { "Twenty","Thirty","Fourty","Fifty","Sixty","Seventy","Eighty","Ninety"
                         };
            
            x = "";
            n = int.Parse(slrytxtbx.Text);
            if(n <= 999999)
            {
                if (n > 99999 & n <= 999999)
                {
                    x += a[(n/100000) - 1] + "Lakh";
                    n = n % 100000;
                }
                x += "";
                if (n > 9999 & n <= 99999)
                {
                    x += b[(n / 10000) - 2] + "Thousand";
                    n = n % 10000;
                }

                x += "";
                if(n > 999 & n <= 9999)
                {
                    x += a[(n/1000) - 1] + "Thousand";
                    n = n % 1000;
                }
                x += "";
                if(n > 99 & n <= 999)
                {
                    x += a[(n/100) - 1]+ "Hundred";
                    n = n % 100;
                }
                x += "";
                if (n > 19 & n <= 99)
                {
                    x += b[(n/10) - 1];
                    n = n % 10;
                }
                 x += "";
                if(n > 0 & n <= 19)
                {
                    x += a[n - 1 ];
                }
              
            }
                else
            {
                MessageBox.Show("Number is out of range");
            }
            
            frm2.tdylbl.Text = (String.Format("{0:D}", DateTime.Now,","));
            StringBuilder omr = new StringBuilder();
            frm2.addresslbl.Text = omr.Append(String.Concat(rspcttxtbx.Text.Trim(), fnmetxtbx.Text.Trim(), lnmetxtbx.Text.Trim(),",")).ToString();
            omr.AppendLine();
            frm2.addresslbl.Text = omr.Append(addrstxtbx.Text).ToString();
            frm2.wlcmelbl.Text = String.Concat("Dear","  ", rspcttxtbx.Text.Trim(), fnmetxtbx.Text.Trim(), lnmetxtbx.Text.Trim(), ",");
            frm2.desglbl2.Text = String.Concat("With reference to your application and subsequent interview with us, we are pleased to appoint you as ", desgntxtbx.Text, " in our organization on the following terms and conditions.");
            frm2.dojlbl2.Text = String.Concat("You have joined us on", " ", dojtxtbx.Text.TrimStart());
            frm2.slrylbl2.Text = String.Concat("Your Annual Total Employment Cost to the company would be ", slrytxtbx.Text.TrimStart()," ", "(", x, " Only) the details of which is been given in the Annexure attached below.");
            frm2.plcelbl2.Text = String.Concat("Your Present place of work will be at ", plcejoingtxtbx.Text.ToLower(), ", but during the course of the service, you shall be liable to be posted / transferred anywhere to serve any of the Company's Projects or any other establishment in India or outside, at the sole discretion of the Management.");
            frm2.prbtnlbl2.Text = String.Concat("You will be on a Probation period for the ", probtnperdtxtbx.Text.Trim().ToLower(), " Months.Based on your performance your services will be confirmed with the company in written after ", probtnperdtxtbx.Text.Trim().ToLower()," Months");
            frm2.lvelbl2.Text = String.Concat("You will be ", bnftstxtbx.Text.Trim()," to the benefits of the Company’s Leave Rules on your confirmation in the Company’s Service.");
            frm2.lvelbl3.Text = String.Concat("During the period of your employment with the Company, you will devote ", tmewrktxtbx.Text.Trim(), " time to the work of the Company. Further, you will not take up any other employment or assignment or any office, honorary or for any consideration, in cash or in kind or otherwise, without the prior written permission of the Company.");
            
            frm2.ShowDialog();
        }
    }
}
