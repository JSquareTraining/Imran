﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Game1
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }
        Form2 frm2 = new Form2();
        Properties.Settings scr = new Properties.Settings();
       
        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "")
            {
                MessageBox.Show("Please Enter Your Name", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                this.Hide();
                scr.Name = textBox1.Text;
                frm2.nmetxtbx.Text = textBox1.Text;
                scr.Score = 0;
                scr.Save();
                frm2.ShowDialog();
                
                
            }
           

        }
    
    }
}
