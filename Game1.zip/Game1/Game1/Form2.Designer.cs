﻿namespace Game1
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.Nmelbl = new System.Windows.Forms.Label();
            this.nmetxtbx = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.scrtxtbx = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.clckstxtbx = new System.Windows.Forms.Label();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.newGameToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.helpToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.lbl16 = new System.Windows.Forms.Label();
            this.lbl17 = new System.Windows.Forms.Label();
            this.lbl18 = new System.Windows.Forms.Label();
            this.lbl19 = new System.Windows.Forms.Label();
            this.lbl20 = new System.Windows.Forms.Label();
            this.lbl21 = new System.Windows.Forms.Label();
            this.lbl22 = new System.Windows.Forms.Label();
            this.lbl23 = new System.Windows.Forms.Label();
            this.lbl24 = new System.Windows.Forms.Label();
            this.lbl25 = new System.Windows.Forms.Label();
            this.lbl26 = new System.Windows.Forms.Label();
            this.lbl27 = new System.Windows.Forms.Label();
            this.lbl28 = new System.Windows.Forms.Label();
            this.lbl3 = new System.Windows.Forms.Label();
            this.lbl4 = new System.Windows.Forms.Label();
            this.lbl5 = new System.Windows.Forms.Label();
            this.lbl6 = new System.Windows.Forms.Label();
            this.lbl7 = new System.Windows.Forms.Label();
            this.lbl8 = new System.Windows.Forms.Label();
            this.lbl9 = new System.Windows.Forms.Label();
            this.lbl10 = new System.Windows.Forms.Label();
            this.lbl11 = new System.Windows.Forms.Label();
            this.lbl12 = new System.Windows.Forms.Label();
            this.lbl13 = new System.Windows.Forms.Label();
            this.lbl14 = new System.Windows.Forms.Label();
            this.lbl15 = new System.Windows.Forms.Label();
            this.lbl1 = new System.Windows.Forms.Label();
            this.lbl2 = new System.Windows.Forms.Label();
            this.lbl46 = new System.Windows.Forms.Label();
            this.lbl47 = new System.Windows.Forms.Label();
            this.lbl48 = new System.Windows.Forms.Label();
            this.lbl49 = new System.Windows.Forms.Label();
            this.lbl50 = new System.Windows.Forms.Label();
            this.lbl51 = new System.Windows.Forms.Label();
            this.lbl52 = new System.Windows.Forms.Label();
            this.lbl53 = new System.Windows.Forms.Label();
            this.lbl54 = new System.Windows.Forms.Label();
            this.lbl55 = new System.Windows.Forms.Label();
            this.lbl56 = new System.Windows.Forms.Label();
            this.lbl57 = new System.Windows.Forms.Label();
            this.lbl58 = new System.Windows.Forms.Label();
            this.lbl33 = new System.Windows.Forms.Label();
            this.lbl34 = new System.Windows.Forms.Label();
            this.lbl35 = new System.Windows.Forms.Label();
            this.lbl36 = new System.Windows.Forms.Label();
            this.lbl37 = new System.Windows.Forms.Label();
            this.lbl38 = new System.Windows.Forms.Label();
            this.lbl39 = new System.Windows.Forms.Label();
            this.lbl40 = new System.Windows.Forms.Label();
            this.lbl41 = new System.Windows.Forms.Label();
            this.lbl42 = new System.Windows.Forms.Label();
            this.lbl43 = new System.Windows.Forms.Label();
            this.lbl44 = new System.Windows.Forms.Label();
            this.lbl45 = new System.Windows.Forms.Label();
            this.lbl31 = new System.Windows.Forms.Label();
            this.lbl32 = new System.Windows.Forms.Label();
            this.lbl76 = new System.Windows.Forms.Label();
            this.lbl77 = new System.Windows.Forms.Label();
            this.lbl78 = new System.Windows.Forms.Label();
            this.lbl79 = new System.Windows.Forms.Label();
            this.lbl80 = new System.Windows.Forms.Label();
            this.lbl81 = new System.Windows.Forms.Label();
            this.lbl82 = new System.Windows.Forms.Label();
            this.lbl83 = new System.Windows.Forms.Label();
            this.lbl84 = new System.Windows.Forms.Label();
            this.lbl85 = new System.Windows.Forms.Label();
            this.lbl86 = new System.Windows.Forms.Label();
            this.lbl87 = new System.Windows.Forms.Label();
            this.lbl88 = new System.Windows.Forms.Label();
            this.lbl63 = new System.Windows.Forms.Label();
            this.lbl64 = new System.Windows.Forms.Label();
            this.lbl65 = new System.Windows.Forms.Label();
            this.lbl66 = new System.Windows.Forms.Label();
            this.lbl67 = new System.Windows.Forms.Label();
            this.lbl68 = new System.Windows.Forms.Label();
            this.lbl69 = new System.Windows.Forms.Label();
            this.lbl70 = new System.Windows.Forms.Label();
            this.lbl71 = new System.Windows.Forms.Label();
            this.lbl72 = new System.Windows.Forms.Label();
            this.lbl73 = new System.Windows.Forms.Label();
            this.lbl74 = new System.Windows.Forms.Label();
            this.lbl75 = new System.Windows.Forms.Label();
            this.lbl61 = new System.Windows.Forms.Label();
            this.lbl62 = new System.Windows.Forms.Label();
            this.lbl106 = new System.Windows.Forms.Label();
            this.lbl107 = new System.Windows.Forms.Label();
            this.lbl108 = new System.Windows.Forms.Label();
            this.lbl109 = new System.Windows.Forms.Label();
            this.lbl110 = new System.Windows.Forms.Label();
            this.lbl111 = new System.Windows.Forms.Label();
            this.lbl112 = new System.Windows.Forms.Label();
            this.lbl113 = new System.Windows.Forms.Label();
            this.lbl114 = new System.Windows.Forms.Label();
            this.lbl115 = new System.Windows.Forms.Label();
            this.lbl116 = new System.Windows.Forms.Label();
            this.lbl117 = new System.Windows.Forms.Label();
            this.lbl118 = new System.Windows.Forms.Label();
            this.lbl93 = new System.Windows.Forms.Label();
            this.lbl94 = new System.Windows.Forms.Label();
            this.lbl95 = new System.Windows.Forms.Label();
            this.lbl96 = new System.Windows.Forms.Label();
            this.lbl97 = new System.Windows.Forms.Label();
            this.lbl98 = new System.Windows.Forms.Label();
            this.lbl99 = new System.Windows.Forms.Label();
            this.lbl100 = new System.Windows.Forms.Label();
            this.lbl101 = new System.Windows.Forms.Label();
            this.lbl102 = new System.Windows.Forms.Label();
            this.lbl103 = new System.Windows.Forms.Label();
            this.lbl104 = new System.Windows.Forms.Label();
            this.lbl105 = new System.Windows.Forms.Label();
            this.lbl91 = new System.Windows.Forms.Label();
            this.lbl92 = new System.Windows.Forms.Label();
            this.lbl136 = new System.Windows.Forms.Label();
            this.lbl137 = new System.Windows.Forms.Label();
            this.lbl138 = new System.Windows.Forms.Label();
            this.lbl139 = new System.Windows.Forms.Label();
            this.lbl140 = new System.Windows.Forms.Label();
            this.lbl141 = new System.Windows.Forms.Label();
            this.lbl142 = new System.Windows.Forms.Label();
            this.lbl143 = new System.Windows.Forms.Label();
            this.lbl144 = new System.Windows.Forms.Label();
            this.lbl145 = new System.Windows.Forms.Label();
            this.lbl146 = new System.Windows.Forms.Label();
            this.lbl147 = new System.Windows.Forms.Label();
            this.lbl148 = new System.Windows.Forms.Label();
            this.lbl123 = new System.Windows.Forms.Label();
            this.lbl124 = new System.Windows.Forms.Label();
            this.lbl125 = new System.Windows.Forms.Label();
            this.lbl126 = new System.Windows.Forms.Label();
            this.lbl127 = new System.Windows.Forms.Label();
            this.lbl128 = new System.Windows.Forms.Label();
            this.lbl129 = new System.Windows.Forms.Label();
            this.lbl130 = new System.Windows.Forms.Label();
            this.lbl131 = new System.Windows.Forms.Label();
            this.lbl132 = new System.Windows.Forms.Label();
            this.lbl133 = new System.Windows.Forms.Label();
            this.lbl134 = new System.Windows.Forms.Label();
            this.lbl135 = new System.Windows.Forms.Label();
            this.lbl121 = new System.Windows.Forms.Label();
            this.lbl29 = new System.Windows.Forms.Label();
            this.lbl122 = new System.Windows.Forms.Label();
            this.lbl30 = new System.Windows.Forms.Label();
            this.lbl59 = new System.Windows.Forms.Label();
            this.lbl60 = new System.Windows.Forms.Label();
            this.lbl89 = new System.Windows.Forms.Label();
            this.lbl90 = new System.Windows.Forms.Label();
            this.lbl119 = new System.Windows.Forms.Label();
            this.lbl120 = new System.Windows.Forms.Label();
            this.lbl149 = new System.Windows.Forms.Label();
            this.lbl150 = new System.Windows.Forms.Label();
            this.lbl166 = new System.Windows.Forms.Label();
            this.lbl167 = new System.Windows.Forms.Label();
            this.lbl168 = new System.Windows.Forms.Label();
            this.lbl169 = new System.Windows.Forms.Label();
            this.lbl170 = new System.Windows.Forms.Label();
            this.lbl171 = new System.Windows.Forms.Label();
            this.lbl172 = new System.Windows.Forms.Label();
            this.lbl173 = new System.Windows.Forms.Label();
            this.lbl174 = new System.Windows.Forms.Label();
            this.lbl175 = new System.Windows.Forms.Label();
            this.lbl176 = new System.Windows.Forms.Label();
            this.lbl177 = new System.Windows.Forms.Label();
            this.lbl178 = new System.Windows.Forms.Label();
            this.lbl153 = new System.Windows.Forms.Label();
            this.lbl154 = new System.Windows.Forms.Label();
            this.lbl155 = new System.Windows.Forms.Label();
            this.lbl156 = new System.Windows.Forms.Label();
            this.lbl157 = new System.Windows.Forms.Label();
            this.lbl158 = new System.Windows.Forms.Label();
            this.lbl159 = new System.Windows.Forms.Label();
            this.lbl160 = new System.Windows.Forms.Label();
            this.lbl161 = new System.Windows.Forms.Label();
            this.lbl162 = new System.Windows.Forms.Label();
            this.lbl163 = new System.Windows.Forms.Label();
            this.lbl164 = new System.Windows.Forms.Label();
            this.lbl165 = new System.Windows.Forms.Label();
            this.lbl151 = new System.Windows.Forms.Label();
            this.lbl152 = new System.Windows.Forms.Label();
            this.lbl196 = new System.Windows.Forms.Label();
            this.lbl197 = new System.Windows.Forms.Label();
            this.lbl198 = new System.Windows.Forms.Label();
            this.lbl199 = new System.Windows.Forms.Label();
            this.lbl200 = new System.Windows.Forms.Label();
            this.lbl201 = new System.Windows.Forms.Label();
            this.lbl202 = new System.Windows.Forms.Label();
            this.lbl203 = new System.Windows.Forms.Label();
            this.lbl204 = new System.Windows.Forms.Label();
            this.lbl205 = new System.Windows.Forms.Label();
            this.lbl206 = new System.Windows.Forms.Label();
            this.lbl207 = new System.Windows.Forms.Label();
            this.lbl208 = new System.Windows.Forms.Label();
            this.lbl183 = new System.Windows.Forms.Label();
            this.lbl184 = new System.Windows.Forms.Label();
            this.lbl185 = new System.Windows.Forms.Label();
            this.lbl186 = new System.Windows.Forms.Label();
            this.lbl187 = new System.Windows.Forms.Label();
            this.lbl188 = new System.Windows.Forms.Label();
            this.lbl189 = new System.Windows.Forms.Label();
            this.lbl190 = new System.Windows.Forms.Label();
            this.lbl191 = new System.Windows.Forms.Label();
            this.lbl192 = new System.Windows.Forms.Label();
            this.lbl193 = new System.Windows.Forms.Label();
            this.lbl194 = new System.Windows.Forms.Label();
            this.lbl195 = new System.Windows.Forms.Label();
            this.lbl181 = new System.Windows.Forms.Label();
            this.lbl182 = new System.Windows.Forms.Label();
            this.lbl226 = new System.Windows.Forms.Label();
            this.lbl227 = new System.Windows.Forms.Label();
            this.lbl228 = new System.Windows.Forms.Label();
            this.lbl229 = new System.Windows.Forms.Label();
            this.lbl230 = new System.Windows.Forms.Label();
            this.lbl231 = new System.Windows.Forms.Label();
            this.lbl232 = new System.Windows.Forms.Label();
            this.lbl233 = new System.Windows.Forms.Label();
            this.lbl234 = new System.Windows.Forms.Label();
            this.lbl235 = new System.Windows.Forms.Label();
            this.lbl236 = new System.Windows.Forms.Label();
            this.lbl237 = new System.Windows.Forms.Label();
            this.lbl238 = new System.Windows.Forms.Label();
            this.lbl213 = new System.Windows.Forms.Label();
            this.lbl214 = new System.Windows.Forms.Label();
            this.lbl215 = new System.Windows.Forms.Label();
            this.lbl216 = new System.Windows.Forms.Label();
            this.lbl217 = new System.Windows.Forms.Label();
            this.lbl218 = new System.Windows.Forms.Label();
            this.lbl219 = new System.Windows.Forms.Label();
            this.lbl220 = new System.Windows.Forms.Label();
            this.lbl221 = new System.Windows.Forms.Label();
            this.lbl222 = new System.Windows.Forms.Label();
            this.lbl223 = new System.Windows.Forms.Label();
            this.lbl224 = new System.Windows.Forms.Label();
            this.lbl225 = new System.Windows.Forms.Label();
            this.lbl211 = new System.Windows.Forms.Label();
            this.lbl212 = new System.Windows.Forms.Label();
            this.lbl256 = new System.Windows.Forms.Label();
            this.lbl257 = new System.Windows.Forms.Label();
            this.lbl258 = new System.Windows.Forms.Label();
            this.lbl259 = new System.Windows.Forms.Label();
            this.lbl260 = new System.Windows.Forms.Label();
            this.lbl261 = new System.Windows.Forms.Label();
            this.lbl262 = new System.Windows.Forms.Label();
            this.lbl263 = new System.Windows.Forms.Label();
            this.lbl264 = new System.Windows.Forms.Label();
            this.lbl265 = new System.Windows.Forms.Label();
            this.lbl266 = new System.Windows.Forms.Label();
            this.lbl267 = new System.Windows.Forms.Label();
            this.lbl268 = new System.Windows.Forms.Label();
            this.lbl243 = new System.Windows.Forms.Label();
            this.lbl244 = new System.Windows.Forms.Label();
            this.lbl245 = new System.Windows.Forms.Label();
            this.lbl246 = new System.Windows.Forms.Label();
            this.lbl247 = new System.Windows.Forms.Label();
            this.lbl248 = new System.Windows.Forms.Label();
            this.lbl249 = new System.Windows.Forms.Label();
            this.lbl250 = new System.Windows.Forms.Label();
            this.lbl251 = new System.Windows.Forms.Label();
            this.lbl252 = new System.Windows.Forms.Label();
            this.lbl253 = new System.Windows.Forms.Label();
            this.lbl254 = new System.Windows.Forms.Label();
            this.lbl255 = new System.Windows.Forms.Label();
            this.lbl241 = new System.Windows.Forms.Label();
            this.lbl242 = new System.Windows.Forms.Label();
            this.lbl286 = new System.Windows.Forms.Label();
            this.lbl287 = new System.Windows.Forms.Label();
            this.lbl288 = new System.Windows.Forms.Label();
            this.lbl289 = new System.Windows.Forms.Label();
            this.lbl290 = new System.Windows.Forms.Label();
            this.lbl291 = new System.Windows.Forms.Label();
            this.lbl292 = new System.Windows.Forms.Label();
            this.lbl293 = new System.Windows.Forms.Label();
            this.lbl294 = new System.Windows.Forms.Label();
            this.lbl295 = new System.Windows.Forms.Label();
            this.lbl296 = new System.Windows.Forms.Label();
            this.lbl297 = new System.Windows.Forms.Label();
            this.lbl298 = new System.Windows.Forms.Label();
            this.lbl273 = new System.Windows.Forms.Label();
            this.lbl274 = new System.Windows.Forms.Label();
            this.lbl275 = new System.Windows.Forms.Label();
            this.lbl276 = new System.Windows.Forms.Label();
            this.lbl277 = new System.Windows.Forms.Label();
            this.lbl278 = new System.Windows.Forms.Label();
            this.lbl279 = new System.Windows.Forms.Label();
            this.lbl280 = new System.Windows.Forms.Label();
            this.lbl281 = new System.Windows.Forms.Label();
            this.lbl282 = new System.Windows.Forms.Label();
            this.lbl283 = new System.Windows.Forms.Label();
            this.lbl284 = new System.Windows.Forms.Label();
            this.lbl285 = new System.Windows.Forms.Label();
            this.lbl271 = new System.Windows.Forms.Label();
            this.lbl272 = new System.Windows.Forms.Label();
            this.lbl179 = new System.Windows.Forms.Label();
            this.lbl180 = new System.Windows.Forms.Label();
            this.lbl209 = new System.Windows.Forms.Label();
            this.lbl210 = new System.Windows.Forms.Label();
            this.lbl239 = new System.Windows.Forms.Label();
            this.lbl240 = new System.Windows.Forms.Label();
            this.lbl269 = new System.Windows.Forms.Label();
            this.lbl270 = new System.Windows.Forms.Label();
            this.lbl299 = new System.Windows.Forms.Label();
            this.lbl300 = new System.Windows.Forms.Label();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // Nmelbl
            // 
            this.Nmelbl.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Nmelbl.Location = new System.Drawing.Point(545, 561);
            this.Nmelbl.Name = "Nmelbl";
            this.Nmelbl.Size = new System.Drawing.Size(100, 23);
            this.Nmelbl.TabIndex = 768;
            this.Nmelbl.Text = "Name";
            this.Nmelbl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // nmetxtbx
            // 
            this.nmetxtbx.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nmetxtbx.Location = new System.Drawing.Point(637, 558);
            this.nmetxtbx.Name = "nmetxtbx";
            this.nmetxtbx.ReadOnly = true;
            this.nmetxtbx.Size = new System.Drawing.Size(152, 29);
            this.nmetxtbx.TabIndex = 769;
            this.nmetxtbx.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label1
            // 
            this.label1.BackColor = System.Drawing.Color.Silver;
            this.label1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.label1.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.label1.Location = new System.Drawing.Point(0, 690);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(1354, 23);
            this.label1.TabIndex = 774;
            // 
            // label2
            // 
            this.label2.BackColor = System.Drawing.Color.Silver;
            this.label2.Location = new System.Drawing.Point(185, 690);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(35, 13);
            this.label2.TabIndex = 775;
            this.label2.Text = "Score";
            // 
            // scrtxtbx
            // 
            this.scrtxtbx.BackColor = System.Drawing.Color.Silver;
            this.scrtxtbx.Location = new System.Drawing.Point(226, 690);
            this.scrtxtbx.Name = "scrtxtbx";
            this.scrtxtbx.Size = new System.Drawing.Size(100, 13);
            this.scrtxtbx.TabIndex = 776;
            this.scrtxtbx.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Silver;
            this.label3.Location = new System.Drawing.Point(692, 691);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(35, 13);
            this.label3.TabIndex = 777;
            this.label3.Text = "Clicks";
            // 
            // clckstxtbx
            // 
            this.clckstxtbx.BackColor = System.Drawing.Color.Silver;
            this.clckstxtbx.Location = new System.Drawing.Point(767, 691);
            this.clckstxtbx.Name = "clckstxtbx";
            this.clckstxtbx.Size = new System.Drawing.Size(100, 12);
            this.clckstxtbx.TabIndex = 778;
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem,
            this.helpToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1354, 24);
            this.menuStrip1.TabIndex = 780;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // fileToolStripMenuItem
            // 
            this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.newGameToolStripMenuItem,
            this.exitToolStripMenuItem});
            this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            this.fileToolStripMenuItem.Size = new System.Drawing.Size(37, 20);
            this.fileToolStripMenuItem.Text = "File";
            // 
            // newGameToolStripMenuItem
            // 
            this.newGameToolStripMenuItem.Name = "newGameToolStripMenuItem";
            this.newGameToolStripMenuItem.Size = new System.Drawing.Size(132, 22);
            this.newGameToolStripMenuItem.Text = "New Game";
            // 
            // exitToolStripMenuItem
            // 
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.Size = new System.Drawing.Size(132, 22);
            this.exitToolStripMenuItem.Text = "Exit";
            // 
            // helpToolStripMenuItem
            // 
            this.helpToolStripMenuItem.Name = "helpToolStripMenuItem";
            this.helpToolStripMenuItem.Size = new System.Drawing.Size(44, 20);
            this.helpToolStripMenuItem.Text = "Help";
            // 
            // lbl16
            // 
            this.lbl16.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl16.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl16.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl16.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl16.Location = new System.Drawing.Point(681, 51);
            this.lbl16.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl16.Name = "lbl16";
            this.lbl16.Size = new System.Drawing.Size(45, 45);
            this.lbl16.TabIndex = 468;
            this.lbl16.Text = "?";
            this.lbl16.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl16.Click += new System.EventHandler(this.lbl16_Click);
            this.lbl16.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl16.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl17
            // 
            this.lbl17.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl17.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl17.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl17.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl17.Location = new System.Drawing.Point(725, 51);
            this.lbl17.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl17.Name = "lbl17";
            this.lbl17.Size = new System.Drawing.Size(45, 45);
            this.lbl17.TabIndex = 469;
            this.lbl17.Text = "?";
            this.lbl17.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl17.Click += new System.EventHandler(this.lbl17_Click);
            this.lbl17.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl17.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl18
            // 
            this.lbl18.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl18.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl18.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl18.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl18.Location = new System.Drawing.Point(769, 51);
            this.lbl18.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl18.Name = "lbl18";
            this.lbl18.Size = new System.Drawing.Size(45, 45);
            this.lbl18.TabIndex = 470;
            this.lbl18.Text = "?";
            this.lbl18.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl18.Click += new System.EventHandler(this.lbl18_Click);
            this.lbl18.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl18.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl19
            // 
            this.lbl19.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl19.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl19.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl19.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl19.Location = new System.Drawing.Point(813, 51);
            this.lbl19.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl19.Name = "lbl19";
            this.lbl19.Size = new System.Drawing.Size(45, 45);
            this.lbl19.TabIndex = 471;
            this.lbl19.Text = "?";
            this.lbl19.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl19.Click += new System.EventHandler(this.lbl19_Click);
            this.lbl19.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl19.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl20
            // 
            this.lbl20.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl20.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl20.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl20.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl20.Location = new System.Drawing.Point(857, 51);
            this.lbl20.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl20.Name = "lbl20";
            this.lbl20.Size = new System.Drawing.Size(45, 45);
            this.lbl20.TabIndex = 472;
            this.lbl20.Text = "?";
            this.lbl20.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl20.Click += new System.EventHandler(this.lbl20_Click);
            this.lbl20.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl20.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl21
            // 
            this.lbl21.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl21.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl21.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl21.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl21.Location = new System.Drawing.Point(901, 51);
            this.lbl21.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl21.Name = "lbl21";
            this.lbl21.Size = new System.Drawing.Size(45, 45);
            this.lbl21.TabIndex = 473;
            this.lbl21.Text = "?";
            this.lbl21.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl21.Click += new System.EventHandler(this.lbl21_Click);
            this.lbl21.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl21.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl22
            // 
            this.lbl22.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl22.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl22.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl22.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl22.Location = new System.Drawing.Point(945, 51);
            this.lbl22.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl22.Name = "lbl22";
            this.lbl22.Size = new System.Drawing.Size(45, 45);
            this.lbl22.TabIndex = 474;
            this.lbl22.Text = "?";
            this.lbl22.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl22.Click += new System.EventHandler(this.lbl22_Click);
            this.lbl22.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl22.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl23
            // 
            this.lbl23.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl23.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl23.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl23.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl23.Location = new System.Drawing.Point(989, 51);
            this.lbl23.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl23.Name = "lbl23";
            this.lbl23.Size = new System.Drawing.Size(45, 45);
            this.lbl23.TabIndex = 475;
            this.lbl23.Text = "?";
            this.lbl23.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl23.Click += new System.EventHandler(this.lbl23_Click);
            this.lbl23.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl23.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl24
            // 
            this.lbl24.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl24.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl24.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl24.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl24.Location = new System.Drawing.Point(1033, 51);
            this.lbl24.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl24.Name = "lbl24";
            this.lbl24.Size = new System.Drawing.Size(45, 45);
            this.lbl24.TabIndex = 476;
            this.lbl24.Text = "?";
            this.lbl24.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl24.Click += new System.EventHandler(this.lbl24_Click);
            this.lbl24.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl24.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl25
            // 
            this.lbl25.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl25.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl25.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl25.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl25.Location = new System.Drawing.Point(1077, 51);
            this.lbl25.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl25.Name = "lbl25";
            this.lbl25.Size = new System.Drawing.Size(45, 45);
            this.lbl25.TabIndex = 477;
            this.lbl25.Text = "?";
            this.lbl25.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl25.Click += new System.EventHandler(this.lbl25_Click);
            this.lbl25.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl25.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl26
            // 
            this.lbl26.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl26.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl26.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl26.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl26.Location = new System.Drawing.Point(1121, 51);
            this.lbl26.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl26.Name = "lbl26";
            this.lbl26.Size = new System.Drawing.Size(45, 45);
            this.lbl26.TabIndex = 478;
            this.lbl26.Text = "?";
            this.lbl26.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl26.Click += new System.EventHandler(this.lbl26_Click);
            this.lbl26.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl26.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl27
            // 
            this.lbl27.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl27.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl27.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl27.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl27.Location = new System.Drawing.Point(1165, 51);
            this.lbl27.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl27.Name = "lbl27";
            this.lbl27.Size = new System.Drawing.Size(45, 45);
            this.lbl27.TabIndex = 479;
            this.lbl27.Text = "?";
            this.lbl27.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl27.Click += new System.EventHandler(this.lbl27_Click);
            this.lbl27.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl27.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl28
            // 
            this.lbl28.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl28.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl28.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl28.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl28.Location = new System.Drawing.Point(1209, 51);
            this.lbl28.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl28.Name = "lbl28";
            this.lbl28.Size = new System.Drawing.Size(45, 45);
            this.lbl28.TabIndex = 480;
            this.lbl28.Text = "?";
            this.lbl28.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl28.Click += new System.EventHandler(this.lbl28_Click);
            this.lbl28.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl28.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl3
            // 
            this.lbl3.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl3.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl3.Location = new System.Drawing.Point(110, 51);
            this.lbl3.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl3.Name = "lbl3";
            this.lbl3.Size = new System.Drawing.Size(45, 45);
            this.lbl3.TabIndex = 495;
            this.lbl3.Text = "?";
            this.lbl3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl3.Click += new System.EventHandler(this.lbl3_Click);
            this.lbl3.MouseEnter += new System.EventHandler(this.lbl3_MouseEnter);
            // 
            // lbl4
            // 
            this.lbl4.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl4.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl4.Location = new System.Drawing.Point(154, 51);
            this.lbl4.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl4.Name = "lbl4";
            this.lbl4.Size = new System.Drawing.Size(45, 45);
            this.lbl4.TabIndex = 482;
            this.lbl4.Text = "?";
            this.lbl4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl4.Click += new System.EventHandler(this.lbl4_Click);
            this.lbl4.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl4.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl5
            // 
            this.lbl5.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl5.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl5.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl5.Location = new System.Drawing.Point(198, 51);
            this.lbl5.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl5.Name = "lbl5";
            this.lbl5.Size = new System.Drawing.Size(45, 45);
            this.lbl5.TabIndex = 483;
            this.lbl5.Text = "?";
            this.lbl5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl5.Click += new System.EventHandler(this.lbl5_Click);
            this.lbl5.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl5.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl6
            // 
            this.lbl6.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl6.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl6.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl6.Location = new System.Drawing.Point(242, 51);
            this.lbl6.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl6.Name = "lbl6";
            this.lbl6.Size = new System.Drawing.Size(45, 45);
            this.lbl6.TabIndex = 484;
            this.lbl6.Text = "?";
            this.lbl6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl6.Click += new System.EventHandler(this.lbl6_Click);
            this.lbl6.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl6.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl7
            // 
            this.lbl7.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl7.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl7.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl7.Location = new System.Drawing.Point(285, 51);
            this.lbl7.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl7.Name = "lbl7";
            this.lbl7.Size = new System.Drawing.Size(45, 45);
            this.lbl7.TabIndex = 485;
            this.lbl7.Text = "?";
            this.lbl7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl7.Click += new System.EventHandler(this.lbl7_Click);
            this.lbl7.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl7.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl8
            // 
            this.lbl8.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl8.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl8.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl8.Location = new System.Drawing.Point(329, 51);
            this.lbl8.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl8.Name = "lbl8";
            this.lbl8.Size = new System.Drawing.Size(45, 45);
            this.lbl8.TabIndex = 486;
            this.lbl8.Text = "?";
            this.lbl8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl8.Click += new System.EventHandler(this.lbl8_Click);
            this.lbl8.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl8.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl9
            // 
            this.lbl9.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl9.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl9.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl9.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl9.Location = new System.Drawing.Point(373, 51);
            this.lbl9.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl9.Name = "lbl9";
            this.lbl9.Size = new System.Drawing.Size(45, 45);
            this.lbl9.TabIndex = 487;
            this.lbl9.Text = "?";
            this.lbl9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl9.Click += new System.EventHandler(this.lbl9_Click);
            this.lbl9.MouseEnter += new System.EventHandler(this.lbl9_MouseEnter);
            // 
            // lbl10
            // 
            this.lbl10.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl10.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl10.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl10.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl10.Location = new System.Drawing.Point(417, 51);
            this.lbl10.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl10.Name = "lbl10";
            this.lbl10.Size = new System.Drawing.Size(45, 45);
            this.lbl10.TabIndex = 488;
            this.lbl10.Text = "?";
            this.lbl10.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl10.Click += new System.EventHandler(this.lbl10_Click);
            this.lbl10.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl10.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl11
            // 
            this.lbl11.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl11.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl11.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl11.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl11.Location = new System.Drawing.Point(461, 51);
            this.lbl11.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl11.Name = "lbl11";
            this.lbl11.Size = new System.Drawing.Size(45, 45);
            this.lbl11.TabIndex = 489;
            this.lbl11.Text = "?";
            this.lbl11.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl11.Click += new System.EventHandler(this.lbl11_Click);
            this.lbl11.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl11.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl12
            // 
            this.lbl12.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl12.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl12.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl12.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl12.Location = new System.Drawing.Point(505, 51);
            this.lbl12.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl12.Name = "lbl12";
            this.lbl12.Size = new System.Drawing.Size(45, 45);
            this.lbl12.TabIndex = 490;
            this.lbl12.Text = "?";
            this.lbl12.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl12.Click += new System.EventHandler(this.lbl12_Click);
            this.lbl12.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl12.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl13
            // 
            this.lbl13.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl13.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl13.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl13.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl13.Location = new System.Drawing.Point(549, 51);
            this.lbl13.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl13.Name = "lbl13";
            this.lbl13.Size = new System.Drawing.Size(45, 45);
            this.lbl13.TabIndex = 491;
            this.lbl13.Text = "?";
            this.lbl13.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl13.Click += new System.EventHandler(this.lbl13_Click);
            this.lbl13.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl13.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl14
            // 
            this.lbl14.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl14.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl14.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl14.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl14.Location = new System.Drawing.Point(593, 51);
            this.lbl14.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl14.Name = "lbl14";
            this.lbl14.Size = new System.Drawing.Size(45, 45);
            this.lbl14.TabIndex = 492;
            this.lbl14.Text = "?";
            this.lbl14.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl14.Click += new System.EventHandler(this.lbl14_Click);
            this.lbl14.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl14.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl15
            // 
            this.lbl15.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl15.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl15.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl15.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl15.Location = new System.Drawing.Point(637, 51);
            this.lbl15.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl15.Name = "lbl15";
            this.lbl15.Size = new System.Drawing.Size(45, 45);
            this.lbl15.TabIndex = 493;
            this.lbl15.Text = "?";
            this.lbl15.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl15.Click += new System.EventHandler(this.lbl15_Click);
            this.lbl15.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl15.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl1
            // 
            this.lbl1.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl1.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl1.Location = new System.Drawing.Point(23, 51);
            this.lbl1.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl1.Name = "lbl1";
            this.lbl1.Size = new System.Drawing.Size(45, 45);
            this.lbl1.TabIndex = 494;
            this.lbl1.Text = "?";
            this.lbl1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl1.Click += new System.EventHandler(this.lbl1_Click);
            this.lbl1.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl1.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl2
            // 
            this.lbl2.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl2.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl2.Location = new System.Drawing.Point(66, 51);
            this.lbl2.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl2.Name = "lbl2";
            this.lbl2.Size = new System.Drawing.Size(45, 45);
            this.lbl2.TabIndex = 495;
            this.lbl2.Text = "?";
            this.lbl2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl2.Click += new System.EventHandler(this.lbl2_Click);
            this.lbl2.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl2.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl46
            // 
            this.lbl46.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl46.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl46.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl46.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl46.Location = new System.Drawing.Point(681, 95);
            this.lbl46.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl46.Name = "lbl46";
            this.lbl46.Size = new System.Drawing.Size(45, 45);
            this.lbl46.TabIndex = 496;
            this.lbl46.Text = "?";
            this.lbl46.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl46.Click += new System.EventHandler(this.lbl46_Click);
            this.lbl46.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl46.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl47
            // 
            this.lbl47.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl47.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl47.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl47.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl47.Location = new System.Drawing.Point(725, 95);
            this.lbl47.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl47.Name = "lbl47";
            this.lbl47.Size = new System.Drawing.Size(45, 45);
            this.lbl47.TabIndex = 497;
            this.lbl47.Text = "?";
            this.lbl47.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl47.Click += new System.EventHandler(this.lbl47_Click);
            this.lbl47.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl47.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl48
            // 
            this.lbl48.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl48.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl48.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl48.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl48.Location = new System.Drawing.Point(769, 95);
            this.lbl48.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl48.Name = "lbl48";
            this.lbl48.Size = new System.Drawing.Size(45, 45);
            this.lbl48.TabIndex = 498;
            this.lbl48.Text = "?";
            this.lbl48.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl48.Click += new System.EventHandler(this.lbl48_Click);
            this.lbl48.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl48.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl49
            // 
            this.lbl49.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl49.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl49.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl49.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl49.Location = new System.Drawing.Point(813, 95);
            this.lbl49.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl49.Name = "lbl49";
            this.lbl49.Size = new System.Drawing.Size(45, 45);
            this.lbl49.TabIndex = 499;
            this.lbl49.Text = "?";
            this.lbl49.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl49.Click += new System.EventHandler(this.lbl49_Click);
            this.lbl49.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl49.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl50
            // 
            this.lbl50.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl50.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl50.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl50.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl50.Location = new System.Drawing.Point(857, 95);
            this.lbl50.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl50.Name = "lbl50";
            this.lbl50.Size = new System.Drawing.Size(45, 45);
            this.lbl50.TabIndex = 500;
            this.lbl50.Text = "?";
            this.lbl50.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl50.Click += new System.EventHandler(this.lbl50_Click);
            this.lbl50.MouseEnter += new System.EventHandler(this.lbl50_MouseEnter);
            // 
            // lbl51
            // 
            this.lbl51.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl51.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl51.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl51.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl51.Location = new System.Drawing.Point(901, 95);
            this.lbl51.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl51.Name = "lbl51";
            this.lbl51.Size = new System.Drawing.Size(45, 45);
            this.lbl51.TabIndex = 501;
            this.lbl51.Text = "?";
            this.lbl51.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl51.Click += new System.EventHandler(this.lbl51_Click);
            this.lbl51.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl51.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl52
            // 
            this.lbl52.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl52.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl52.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl52.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl52.Location = new System.Drawing.Point(945, 95);
            this.lbl52.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl52.Name = "lbl52";
            this.lbl52.Size = new System.Drawing.Size(45, 45);
            this.lbl52.TabIndex = 502;
            this.lbl52.Text = "?";
            this.lbl52.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl52.Click += new System.EventHandler(this.lbl52_Click);
            this.lbl52.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl52.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl53
            // 
            this.lbl53.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl53.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl53.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl53.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl53.Location = new System.Drawing.Point(989, 95);
            this.lbl53.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl53.Name = "lbl53";
            this.lbl53.Size = new System.Drawing.Size(45, 45);
            this.lbl53.TabIndex = 503;
            this.lbl53.Text = "?";
            this.lbl53.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl53.Click += new System.EventHandler(this.lbl53_Click);
            this.lbl53.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl53.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl54
            // 
            this.lbl54.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl54.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl54.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl54.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl54.Location = new System.Drawing.Point(1033, 95);
            this.lbl54.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl54.Name = "lbl54";
            this.lbl54.Size = new System.Drawing.Size(45, 45);
            this.lbl54.TabIndex = 504;
            this.lbl54.Text = "?";
            this.lbl54.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl54.Click += new System.EventHandler(this.lbl54_Click);
            this.lbl54.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl54.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl55
            // 
            this.lbl55.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl55.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl55.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl55.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl55.Location = new System.Drawing.Point(1077, 95);
            this.lbl55.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl55.Name = "lbl55";
            this.lbl55.Size = new System.Drawing.Size(45, 45);
            this.lbl55.TabIndex = 505;
            this.lbl55.Text = "?";
            this.lbl55.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl55.Click += new System.EventHandler(this.lbl55_Click);
            this.lbl55.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl55.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl56
            // 
            this.lbl56.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl56.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl56.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl56.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl56.Location = new System.Drawing.Point(1121, 95);
            this.lbl56.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl56.Name = "lbl56";
            this.lbl56.Size = new System.Drawing.Size(45, 45);
            this.lbl56.TabIndex = 506;
            this.lbl56.Text = "?";
            this.lbl56.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl56.Click += new System.EventHandler(this.lbl56_Click);
            this.lbl56.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl56.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl57
            // 
            this.lbl57.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl57.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl57.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl57.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl57.Location = new System.Drawing.Point(1165, 95);
            this.lbl57.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl57.Name = "lbl57";
            this.lbl57.Size = new System.Drawing.Size(45, 45);
            this.lbl57.TabIndex = 507;
            this.lbl57.Text = "?";
            this.lbl57.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl57.Click += new System.EventHandler(this.lbl57_Click);
            this.lbl57.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl57.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl58
            // 
            this.lbl58.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl58.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl58.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl58.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl58.Location = new System.Drawing.Point(1209, 95);
            this.lbl58.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl58.Name = "lbl58";
            this.lbl58.Size = new System.Drawing.Size(45, 45);
            this.lbl58.TabIndex = 508;
            this.lbl58.Text = "?";
            this.lbl58.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl58.Click += new System.EventHandler(this.lbl58_Click);
            this.lbl58.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl58.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl33
            // 
            this.lbl33.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl33.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl33.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl33.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl33.Location = new System.Drawing.Point(110, 95);
            this.lbl33.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl33.Name = "lbl33";
            this.lbl33.Size = new System.Drawing.Size(45, 45);
            this.lbl33.TabIndex = 509;
            this.lbl33.Text = "?";
            this.lbl33.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl33.Click += new System.EventHandler(this.lbl33_Click);
            this.lbl33.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl33.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl34
            // 
            this.lbl34.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl34.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl34.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl34.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl34.Location = new System.Drawing.Point(154, 95);
            this.lbl34.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl34.Name = "lbl34";
            this.lbl34.Size = new System.Drawing.Size(45, 45);
            this.lbl34.TabIndex = 510;
            this.lbl34.Text = "?";
            this.lbl34.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl34.Click += new System.EventHandler(this.lbl34_Click);
            this.lbl34.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl34.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl35
            // 
            this.lbl35.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl35.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl35.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl35.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl35.Location = new System.Drawing.Point(198, 95);
            this.lbl35.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl35.Name = "lbl35";
            this.lbl35.Size = new System.Drawing.Size(45, 45);
            this.lbl35.TabIndex = 511;
            this.lbl35.Text = "?";
            this.lbl35.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl35.Click += new System.EventHandler(this.lbl35_Click);
            this.lbl35.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl35.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl36
            // 
            this.lbl36.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl36.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl36.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl36.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl36.Location = new System.Drawing.Point(242, 95);
            this.lbl36.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl36.Name = "lbl36";
            this.lbl36.Size = new System.Drawing.Size(45, 45);
            this.lbl36.TabIndex = 512;
            this.lbl36.Text = "?";
            this.lbl36.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl36.Click += new System.EventHandler(this.lbl36_Click);
            this.lbl36.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl36.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl37
            // 
            this.lbl37.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl37.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl37.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl37.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl37.Location = new System.Drawing.Point(285, 95);
            this.lbl37.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl37.Name = "lbl37";
            this.lbl37.Size = new System.Drawing.Size(45, 45);
            this.lbl37.TabIndex = 513;
            this.lbl37.Text = "?";
            this.lbl37.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl37.Click += new System.EventHandler(this.lbl37_Click);
            this.lbl37.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl37.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl38
            // 
            this.lbl38.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl38.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl38.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl38.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl38.Location = new System.Drawing.Point(329, 95);
            this.lbl38.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl38.Name = "lbl38";
            this.lbl38.Size = new System.Drawing.Size(45, 45);
            this.lbl38.TabIndex = 514;
            this.lbl38.Text = "?";
            this.lbl38.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl38.Click += new System.EventHandler(this.lbl38_Click);
            this.lbl38.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl38.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl39
            // 
            this.lbl39.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl39.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl39.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl39.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl39.Location = new System.Drawing.Point(373, 95);
            this.lbl39.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl39.Name = "lbl39";
            this.lbl39.Size = new System.Drawing.Size(45, 45);
            this.lbl39.TabIndex = 515;
            this.lbl39.Text = "?";
            this.lbl39.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl39.Click += new System.EventHandler(this.lbl39_Click);
            this.lbl39.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl39.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl40
            // 
            this.lbl40.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl40.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl40.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl40.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl40.Location = new System.Drawing.Point(417, 95);
            this.lbl40.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl40.Name = "lbl40";
            this.lbl40.Size = new System.Drawing.Size(45, 45);
            this.lbl40.TabIndex = 516;
            this.lbl40.Text = "?";
            this.lbl40.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl40.Click += new System.EventHandler(this.lbl40_Click);
            this.lbl40.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl40.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl41
            // 
            this.lbl41.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl41.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl41.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl41.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl41.Location = new System.Drawing.Point(461, 95);
            this.lbl41.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl41.Name = "lbl41";
            this.lbl41.Size = new System.Drawing.Size(45, 45);
            this.lbl41.TabIndex = 517;
            this.lbl41.Text = "?";
            this.lbl41.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl41.Click += new System.EventHandler(this.lbl41_Click);
            this.lbl41.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl41.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl42
            // 
            this.lbl42.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl42.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl42.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl42.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl42.Location = new System.Drawing.Point(505, 95);
            this.lbl42.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl42.Name = "lbl42";
            this.lbl42.Size = new System.Drawing.Size(45, 45);
            this.lbl42.TabIndex = 518;
            this.lbl42.Text = "?";
            this.lbl42.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl42.Click += new System.EventHandler(this.lbl42_Click);
            this.lbl42.MouseEnter += new System.EventHandler(this.lbl42_MouseEnter);
            // 
            // lbl43
            // 
            this.lbl43.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl43.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl43.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl43.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl43.Location = new System.Drawing.Point(549, 95);
            this.lbl43.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl43.Name = "lbl43";
            this.lbl43.Size = new System.Drawing.Size(45, 45);
            this.lbl43.TabIndex = 519;
            this.lbl43.Text = "?";
            this.lbl43.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl43.Click += new System.EventHandler(this.lbl43_Click);
            this.lbl43.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl43.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl44
            // 
            this.lbl44.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl44.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl44.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl44.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl44.Location = new System.Drawing.Point(593, 95);
            this.lbl44.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl44.Name = "lbl44";
            this.lbl44.Size = new System.Drawing.Size(45, 45);
            this.lbl44.TabIndex = 520;
            this.lbl44.Text = "?";
            this.lbl44.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl44.Click += new System.EventHandler(this.lbl44_Click);
            this.lbl44.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl44.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl45
            // 
            this.lbl45.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl45.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl45.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl45.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl45.Location = new System.Drawing.Point(637, 95);
            this.lbl45.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl45.Name = "lbl45";
            this.lbl45.Size = new System.Drawing.Size(45, 45);
            this.lbl45.TabIndex = 521;
            this.lbl45.Text = "?";
            this.lbl45.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl45.Click += new System.EventHandler(this.lbl45_Click);
            this.lbl45.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl45.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl31
            // 
            this.lbl31.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl31.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl31.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl31.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl31.Location = new System.Drawing.Point(23, 95);
            this.lbl31.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl31.Name = "lbl31";
            this.lbl31.Size = new System.Drawing.Size(45, 45);
            this.lbl31.TabIndex = 522;
            this.lbl31.Text = "?";
            this.lbl31.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl31.Click += new System.EventHandler(this.lbl31_Click);
            this.lbl31.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl31.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl32
            // 
            this.lbl32.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl32.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl32.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl32.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl32.Location = new System.Drawing.Point(66, 95);
            this.lbl32.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl32.Name = "lbl32";
            this.lbl32.Size = new System.Drawing.Size(45, 45);
            this.lbl32.TabIndex = 523;
            this.lbl32.Text = "?";
            this.lbl32.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl32.Click += new System.EventHandler(this.lbl32_Click);
            this.lbl32.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl32.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl76
            // 
            this.lbl76.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl76.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl76.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl76.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl76.Location = new System.Drawing.Point(681, 139);
            this.lbl76.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl76.Name = "lbl76";
            this.lbl76.Size = new System.Drawing.Size(45, 45);
            this.lbl76.TabIndex = 524;
            this.lbl76.Text = "?";
            this.lbl76.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl76.Click += new System.EventHandler(this.lbl76_Click);
            this.lbl76.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl76.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl77
            // 
            this.lbl77.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl77.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl77.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl77.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl77.Location = new System.Drawing.Point(725, 139);
            this.lbl77.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl77.Name = "lbl77";
            this.lbl77.Size = new System.Drawing.Size(45, 45);
            this.lbl77.TabIndex = 525;
            this.lbl77.Text = "?";
            this.lbl77.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl77.Click += new System.EventHandler(this.lbl77_Click);
            this.lbl77.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl77.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl78
            // 
            this.lbl78.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl78.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl78.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl78.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl78.Location = new System.Drawing.Point(769, 139);
            this.lbl78.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl78.Name = "lbl78";
            this.lbl78.Size = new System.Drawing.Size(45, 45);
            this.lbl78.TabIndex = 526;
            this.lbl78.Text = "?";
            this.lbl78.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl78.Click += new System.EventHandler(this.lbl78_Click);
            this.lbl78.MouseEnter += new System.EventHandler(this.lbl78_MouseEnter);
            // 
            // lbl79
            // 
            this.lbl79.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl79.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl79.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl79.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl79.Location = new System.Drawing.Point(813, 139);
            this.lbl79.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl79.Name = "lbl79";
            this.lbl79.Size = new System.Drawing.Size(45, 45);
            this.lbl79.TabIndex = 527;
            this.lbl79.Text = "?";
            this.lbl79.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl79.Click += new System.EventHandler(this.lbl79_Click);
            this.lbl79.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl79.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl80
            // 
            this.lbl80.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl80.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl80.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl80.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl80.Location = new System.Drawing.Point(857, 139);
            this.lbl80.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl80.Name = "lbl80";
            this.lbl80.Size = new System.Drawing.Size(45, 45);
            this.lbl80.TabIndex = 528;
            this.lbl80.Text = "?";
            this.lbl80.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl80.Click += new System.EventHandler(this.lbl80_Click);
            this.lbl80.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl80.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl81
            // 
            this.lbl81.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl81.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl81.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl81.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl81.Location = new System.Drawing.Point(901, 139);
            this.lbl81.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl81.Name = "lbl81";
            this.lbl81.Size = new System.Drawing.Size(45, 45);
            this.lbl81.TabIndex = 529;
            this.lbl81.Text = "?";
            this.lbl81.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl81.Click += new System.EventHandler(this.lbl81_Click);
            this.lbl81.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl81.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl82
            // 
            this.lbl82.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl82.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl82.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl82.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl82.Location = new System.Drawing.Point(945, 139);
            this.lbl82.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl82.Name = "lbl82";
            this.lbl82.Size = new System.Drawing.Size(45, 45);
            this.lbl82.TabIndex = 530;
            this.lbl82.Text = "?";
            this.lbl82.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl82.Click += new System.EventHandler(this.lbl82_Click);
            this.lbl82.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl82.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl83
            // 
            this.lbl83.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl83.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl83.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl83.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl83.Location = new System.Drawing.Point(989, 139);
            this.lbl83.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl83.Name = "lbl83";
            this.lbl83.Size = new System.Drawing.Size(45, 45);
            this.lbl83.TabIndex = 531;
            this.lbl83.Text = "?";
            this.lbl83.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl83.Click += new System.EventHandler(this.lbl83_Click);
            this.lbl83.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl83.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl84
            // 
            this.lbl84.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl84.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl84.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl84.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl84.Location = new System.Drawing.Point(1033, 139);
            this.lbl84.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl84.Name = "lbl84";
            this.lbl84.Size = new System.Drawing.Size(45, 45);
            this.lbl84.TabIndex = 532;
            this.lbl84.Text = "?";
            this.lbl84.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl84.Click += new System.EventHandler(this.lbl84_Click);
            this.lbl84.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl84.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl85
            // 
            this.lbl85.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl85.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl85.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl85.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl85.Location = new System.Drawing.Point(1077, 139);
            this.lbl85.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl85.Name = "lbl85";
            this.lbl85.Size = new System.Drawing.Size(45, 45);
            this.lbl85.TabIndex = 533;
            this.lbl85.Text = "?";
            this.lbl85.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl85.Click += new System.EventHandler(this.lbl85_Click);
            this.lbl85.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl85.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl86
            // 
            this.lbl86.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl86.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl86.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl86.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl86.Location = new System.Drawing.Point(1121, 139);
            this.lbl86.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl86.Name = "lbl86";
            this.lbl86.Size = new System.Drawing.Size(45, 45);
            this.lbl86.TabIndex = 534;
            this.lbl86.Text = "?";
            this.lbl86.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl86.Click += new System.EventHandler(this.lbl86_Click);
            this.lbl86.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl86.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl87
            // 
            this.lbl87.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl87.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl87.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl87.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl87.Location = new System.Drawing.Point(1165, 139);
            this.lbl87.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl87.Name = "lbl87";
            this.lbl87.Size = new System.Drawing.Size(45, 45);
            this.lbl87.TabIndex = 535;
            this.lbl87.Text = "?";
            this.lbl87.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl87.Click += new System.EventHandler(this.lbl87_Click);
            this.lbl87.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl87.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl88
            // 
            this.lbl88.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl88.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl88.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl88.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl88.Location = new System.Drawing.Point(1209, 139);
            this.lbl88.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl88.Name = "lbl88";
            this.lbl88.Size = new System.Drawing.Size(45, 45);
            this.lbl88.TabIndex = 536;
            this.lbl88.Text = "?";
            this.lbl88.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl88.Click += new System.EventHandler(this.lbl88_Click);
            this.lbl88.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl88.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl63
            // 
            this.lbl63.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl63.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl63.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl63.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl63.Location = new System.Drawing.Point(110, 139);
            this.lbl63.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl63.Name = "lbl63";
            this.lbl63.Size = new System.Drawing.Size(45, 45);
            this.lbl63.TabIndex = 537;
            this.lbl63.Text = "?";
            this.lbl63.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl63.Click += new System.EventHandler(this.lbl63_Click);
            this.lbl63.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl63.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl64
            // 
            this.lbl64.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl64.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl64.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl64.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl64.Location = new System.Drawing.Point(154, 139);
            this.lbl64.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl64.Name = "lbl64";
            this.lbl64.Size = new System.Drawing.Size(45, 45);
            this.lbl64.TabIndex = 538;
            this.lbl64.Text = "?";
            this.lbl64.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl64.Click += new System.EventHandler(this.lbl64_Click);
            this.lbl64.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl64.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl65
            // 
            this.lbl65.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl65.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl65.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl65.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl65.Location = new System.Drawing.Point(198, 139);
            this.lbl65.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl65.Name = "lbl65";
            this.lbl65.Size = new System.Drawing.Size(45, 45);
            this.lbl65.TabIndex = 539;
            this.lbl65.Text = "?";
            this.lbl65.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl65.Click += new System.EventHandler(this.lbl65_Click);
            this.lbl65.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl65.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl66
            // 
            this.lbl66.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl66.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl66.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl66.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl66.Location = new System.Drawing.Point(242, 139);
            this.lbl66.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl66.Name = "lbl66";
            this.lbl66.Size = new System.Drawing.Size(45, 45);
            this.lbl66.TabIndex = 540;
            this.lbl66.Text = "?";
            this.lbl66.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl66.Click += new System.EventHandler(this.lbl66_Click);
            this.lbl66.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl66.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl67
            // 
            this.lbl67.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl67.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl67.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl67.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl67.Location = new System.Drawing.Point(285, 139);
            this.lbl67.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl67.Name = "lbl67";
            this.lbl67.Size = new System.Drawing.Size(45, 45);
            this.lbl67.TabIndex = 541;
            this.lbl67.Text = "?";
            this.lbl67.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl67.Click += new System.EventHandler(this.lbl67_Click);
            this.lbl67.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl67.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl68
            // 
            this.lbl68.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl68.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl68.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl68.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl68.Location = new System.Drawing.Point(329, 139);
            this.lbl68.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl68.Name = "lbl68";
            this.lbl68.Size = new System.Drawing.Size(45, 45);
            this.lbl68.TabIndex = 542;
            this.lbl68.Text = "?";
            this.lbl68.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl68.Click += new System.EventHandler(this.lbl68_Click);
            this.lbl68.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl68.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl69
            // 
            this.lbl69.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl69.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl69.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl69.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl69.Location = new System.Drawing.Point(373, 139);
            this.lbl69.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl69.Name = "lbl69";
            this.lbl69.Size = new System.Drawing.Size(45, 45);
            this.lbl69.TabIndex = 543;
            this.lbl69.Text = "?";
            this.lbl69.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl69.Click += new System.EventHandler(this.lbl69_Click);
            this.lbl69.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl69.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl70
            // 
            this.lbl70.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl70.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl70.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl70.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl70.Location = new System.Drawing.Point(417, 139);
            this.lbl70.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl70.Name = "lbl70";
            this.lbl70.Size = new System.Drawing.Size(45, 45);
            this.lbl70.TabIndex = 544;
            this.lbl70.Text = "?";
            this.lbl70.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl70.Click += new System.EventHandler(this.lbl70_Click);
            this.lbl70.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl70.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl71
            // 
            this.lbl71.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl71.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl71.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl71.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl71.Location = new System.Drawing.Point(461, 139);
            this.lbl71.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl71.Name = "lbl71";
            this.lbl71.Size = new System.Drawing.Size(45, 45);
            this.lbl71.TabIndex = 545;
            this.lbl71.Text = "?";
            this.lbl71.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl71.Click += new System.EventHandler(this.lbl71_Click);
            this.lbl71.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl71.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl72
            // 
            this.lbl72.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl72.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl72.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl72.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl72.Location = new System.Drawing.Point(505, 139);
            this.lbl72.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl72.Name = "lbl72";
            this.lbl72.Size = new System.Drawing.Size(45, 45);
            this.lbl72.TabIndex = 546;
            this.lbl72.Text = "?";
            this.lbl72.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl72.Click += new System.EventHandler(this.lbl72_Click);
            this.lbl72.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl72.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl73
            // 
            this.lbl73.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl73.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl73.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl73.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl73.Location = new System.Drawing.Point(549, 139);
            this.lbl73.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl73.Name = "lbl73";
            this.lbl73.Size = new System.Drawing.Size(45, 45);
            this.lbl73.TabIndex = 547;
            this.lbl73.Text = "?";
            this.lbl73.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl73.Click += new System.EventHandler(this.lbl73_Click);
            this.lbl73.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl73.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl74
            // 
            this.lbl74.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl74.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl74.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl74.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl74.Location = new System.Drawing.Point(593, 139);
            this.lbl74.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl74.Name = "lbl74";
            this.lbl74.Size = new System.Drawing.Size(45, 45);
            this.lbl74.TabIndex = 548;
            this.lbl74.Text = "?";
            this.lbl74.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl74.Click += new System.EventHandler(this.lbl74_Click);
            this.lbl74.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl74.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl75
            // 
            this.lbl75.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl75.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl75.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl75.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl75.Location = new System.Drawing.Point(637, 139);
            this.lbl75.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl75.Name = "lbl75";
            this.lbl75.Size = new System.Drawing.Size(45, 45);
            this.lbl75.TabIndex = 549;
            this.lbl75.Text = "?";
            this.lbl75.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl75.Click += new System.EventHandler(this.lbl75_Click);
            this.lbl75.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl75.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl61
            // 
            this.lbl61.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl61.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl61.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl61.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl61.Location = new System.Drawing.Point(23, 139);
            this.lbl61.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl61.Name = "lbl61";
            this.lbl61.Size = new System.Drawing.Size(45, 45);
            this.lbl61.TabIndex = 550;
            this.lbl61.Text = "?";
            this.lbl61.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl61.Click += new System.EventHandler(this.lbl61_Click);
            this.lbl61.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl61.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl62
            // 
            this.lbl62.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl62.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl62.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl62.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl62.Location = new System.Drawing.Point(66, 139);
            this.lbl62.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl62.Name = "lbl62";
            this.lbl62.Size = new System.Drawing.Size(45, 45);
            this.lbl62.TabIndex = 551;
            this.lbl62.Text = "?";
            this.lbl62.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl62.Click += new System.EventHandler(this.lbl62_Click);
            this.lbl62.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl62.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl106
            // 
            this.lbl106.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl106.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl106.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl106.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl106.Location = new System.Drawing.Point(681, 183);
            this.lbl106.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl106.Name = "lbl106";
            this.lbl106.Size = new System.Drawing.Size(45, 45);
            this.lbl106.TabIndex = 552;
            this.lbl106.Text = "?";
            this.lbl106.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl106.Click += new System.EventHandler(this.lbl106_Click);
            this.lbl106.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl106.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl107
            // 
            this.lbl107.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl107.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl107.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl107.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl107.Location = new System.Drawing.Point(725, 183);
            this.lbl107.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl107.Name = "lbl107";
            this.lbl107.Size = new System.Drawing.Size(45, 45);
            this.lbl107.TabIndex = 553;
            this.lbl107.Text = "?";
            this.lbl107.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl107.Click += new System.EventHandler(this.lbl107_Click);
            this.lbl107.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl107.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl108
            // 
            this.lbl108.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl108.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl108.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl108.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl108.Location = new System.Drawing.Point(769, 183);
            this.lbl108.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl108.Name = "lbl108";
            this.lbl108.Size = new System.Drawing.Size(45, 45);
            this.lbl108.TabIndex = 554;
            this.lbl108.Text = "?";
            this.lbl108.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl108.Click += new System.EventHandler(this.lbl108_Click);
            this.lbl108.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl108.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl109
            // 
            this.lbl109.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl109.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl109.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl109.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl109.Location = new System.Drawing.Point(813, 183);
            this.lbl109.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl109.Name = "lbl109";
            this.lbl109.Size = new System.Drawing.Size(45, 45);
            this.lbl109.TabIndex = 555;
            this.lbl109.Text = "?";
            this.lbl109.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl109.Click += new System.EventHandler(this.lbl109_Click);
            this.lbl109.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl109.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl110
            // 
            this.lbl110.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl110.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl110.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl110.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl110.Location = new System.Drawing.Point(857, 183);
            this.lbl110.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl110.Name = "lbl110";
            this.lbl110.Size = new System.Drawing.Size(45, 45);
            this.lbl110.TabIndex = 556;
            this.lbl110.Text = "?";
            this.lbl110.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl110.Click += new System.EventHandler(this.lbl110_Click);
            this.lbl110.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl110.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl111
            // 
            this.lbl111.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl111.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl111.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl111.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl111.Location = new System.Drawing.Point(901, 183);
            this.lbl111.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl111.Name = "lbl111";
            this.lbl111.Size = new System.Drawing.Size(45, 45);
            this.lbl111.TabIndex = 557;
            this.lbl111.Text = "?";
            this.lbl111.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl111.Click += new System.EventHandler(this.lbl111_Click);
            this.lbl111.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl111.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl112
            // 
            this.lbl112.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl112.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl112.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl112.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl112.Location = new System.Drawing.Point(945, 183);
            this.lbl112.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl112.Name = "lbl112";
            this.lbl112.Size = new System.Drawing.Size(45, 45);
            this.lbl112.TabIndex = 558;
            this.lbl112.Text = "?";
            this.lbl112.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl112.Click += new System.EventHandler(this.lbl112_Click);
            this.lbl112.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl112.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl113
            // 
            this.lbl113.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl113.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl113.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl113.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl113.Location = new System.Drawing.Point(989, 183);
            this.lbl113.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl113.Name = "lbl113";
            this.lbl113.Size = new System.Drawing.Size(45, 45);
            this.lbl113.TabIndex = 559;
            this.lbl113.Text = "?";
            this.lbl113.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl113.Click += new System.EventHandler(this.lbl113_Click);
            this.lbl113.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl113.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl114
            // 
            this.lbl114.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl114.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl114.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl114.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl114.Location = new System.Drawing.Point(1033, 183);
            this.lbl114.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl114.Name = "lbl114";
            this.lbl114.Size = new System.Drawing.Size(45, 45);
            this.lbl114.TabIndex = 560;
            this.lbl114.Text = "?";
            this.lbl114.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl114.Click += new System.EventHandler(this.lbl114_Click);
            this.lbl114.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl114.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl115
            // 
            this.lbl115.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl115.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl115.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl115.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl115.Location = new System.Drawing.Point(1077, 183);
            this.lbl115.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl115.Name = "lbl115";
            this.lbl115.Size = new System.Drawing.Size(45, 45);
            this.lbl115.TabIndex = 561;
            this.lbl115.Text = "?";
            this.lbl115.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl115.Click += new System.EventHandler(this.lbl115_Click);
            this.lbl115.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl115.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl116
            // 
            this.lbl116.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl116.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl116.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl116.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl116.Location = new System.Drawing.Point(1121, 183);
            this.lbl116.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl116.Name = "lbl116";
            this.lbl116.Size = new System.Drawing.Size(45, 45);
            this.lbl116.TabIndex = 562;
            this.lbl116.Text = "?";
            this.lbl116.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl116.Click += new System.EventHandler(this.lbl116_Click);
            this.lbl116.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl116.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl117
            // 
            this.lbl117.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl117.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl117.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl117.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl117.Location = new System.Drawing.Point(1165, 183);
            this.lbl117.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl117.Name = "lbl117";
            this.lbl117.Size = new System.Drawing.Size(45, 45);
            this.lbl117.TabIndex = 563;
            this.lbl117.Text = "?";
            this.lbl117.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl117.Click += new System.EventHandler(this.lbl117_Click);
            this.lbl117.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl117.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl118
            // 
            this.lbl118.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl118.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl118.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl118.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl118.Location = new System.Drawing.Point(1209, 183);
            this.lbl118.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl118.Name = "lbl118";
            this.lbl118.Size = new System.Drawing.Size(45, 45);
            this.lbl118.TabIndex = 564;
            this.lbl118.Text = "?";
            this.lbl118.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl118.Click += new System.EventHandler(this.lbl118_Click);
            this.lbl118.MouseEnter += new System.EventHandler(this.lbl118_MouseEnter);
            // 
            // lbl93
            // 
            this.lbl93.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl93.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl93.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl93.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl93.Location = new System.Drawing.Point(110, 183);
            this.lbl93.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl93.Name = "lbl93";
            this.lbl93.Size = new System.Drawing.Size(45, 45);
            this.lbl93.TabIndex = 565;
            this.lbl93.Text = "?";
            this.lbl93.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl93.Click += new System.EventHandler(this.lbl93_Click);
            this.lbl93.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl93.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl94
            // 
            this.lbl94.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl94.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl94.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl94.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl94.Location = new System.Drawing.Point(154, 183);
            this.lbl94.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl94.Name = "lbl94";
            this.lbl94.Size = new System.Drawing.Size(45, 45);
            this.lbl94.TabIndex = 566;
            this.lbl94.Text = "?";
            this.lbl94.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl94.Click += new System.EventHandler(this.lbl94_Click);
            this.lbl94.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl94.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl95
            // 
            this.lbl95.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl95.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl95.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl95.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl95.Location = new System.Drawing.Point(198, 183);
            this.lbl95.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl95.Name = "lbl95";
            this.lbl95.Size = new System.Drawing.Size(45, 45);
            this.lbl95.TabIndex = 567;
            this.lbl95.Text = "?";
            this.lbl95.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl95.Click += new System.EventHandler(this.lbl95_Click);
            this.lbl95.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl95.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl96
            // 
            this.lbl96.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl96.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl96.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl96.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl96.Location = new System.Drawing.Point(242, 183);
            this.lbl96.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl96.Name = "lbl96";
            this.lbl96.Size = new System.Drawing.Size(45, 45);
            this.lbl96.TabIndex = 568;
            this.lbl96.Text = "?";
            this.lbl96.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl96.Click += new System.EventHandler(this.lbl96_Click);
            this.lbl96.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl96.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl97
            // 
            this.lbl97.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl97.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl97.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl97.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl97.Location = new System.Drawing.Point(285, 183);
            this.lbl97.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl97.Name = "lbl97";
            this.lbl97.Size = new System.Drawing.Size(45, 45);
            this.lbl97.TabIndex = 569;
            this.lbl97.Text = "?";
            this.lbl97.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl97.Click += new System.EventHandler(this.lbl97_Click);
            this.lbl97.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl97.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl98
            // 
            this.lbl98.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl98.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl98.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl98.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl98.Location = new System.Drawing.Point(329, 183);
            this.lbl98.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl98.Name = "lbl98";
            this.lbl98.Size = new System.Drawing.Size(45, 45);
            this.lbl98.TabIndex = 570;
            this.lbl98.Text = "?";
            this.lbl98.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl98.Click += new System.EventHandler(this.lbl98_Click);
            this.lbl98.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl98.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl99
            // 
            this.lbl99.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl99.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl99.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl99.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl99.Location = new System.Drawing.Point(373, 183);
            this.lbl99.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl99.Name = "lbl99";
            this.lbl99.Size = new System.Drawing.Size(45, 45);
            this.lbl99.TabIndex = 571;
            this.lbl99.Text = "?";
            this.lbl99.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl99.Click += new System.EventHandler(this.lbl99_Click);
            this.lbl99.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl99.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl100
            // 
            this.lbl100.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl100.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl100.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl100.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl100.Location = new System.Drawing.Point(417, 183);
            this.lbl100.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl100.Name = "lbl100";
            this.lbl100.Size = new System.Drawing.Size(45, 45);
            this.lbl100.TabIndex = 572;
            this.lbl100.Text = "?";
            this.lbl100.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl100.Click += new System.EventHandler(this.lbl100_Click);
            this.lbl100.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl100.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl101
            // 
            this.lbl101.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl101.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl101.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl101.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl101.Location = new System.Drawing.Point(461, 183);
            this.lbl101.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl101.Name = "lbl101";
            this.lbl101.Size = new System.Drawing.Size(45, 45);
            this.lbl101.TabIndex = 573;
            this.lbl101.Text = "?";
            this.lbl101.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl101.Click += new System.EventHandler(this.lbl101_Click);
            this.lbl101.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl101.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl102
            // 
            this.lbl102.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl102.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl102.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl102.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl102.Location = new System.Drawing.Point(505, 183);
            this.lbl102.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl102.Name = "lbl102";
            this.lbl102.Size = new System.Drawing.Size(45, 45);
            this.lbl102.TabIndex = 574;
            this.lbl102.Text = "?";
            this.lbl102.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl102.Click += new System.EventHandler(this.lbl102_Click);
            this.lbl102.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl102.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl103
            // 
            this.lbl103.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl103.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl103.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl103.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl103.Location = new System.Drawing.Point(549, 183);
            this.lbl103.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl103.Name = "lbl103";
            this.lbl103.Size = new System.Drawing.Size(45, 45);
            this.lbl103.TabIndex = 575;
            this.lbl103.Text = "?";
            this.lbl103.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl103.Click += new System.EventHandler(this.lbl103_Click);
            this.lbl103.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl103.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl104
            // 
            this.lbl104.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl104.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl104.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl104.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl104.Location = new System.Drawing.Point(593, 183);
            this.lbl104.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl104.Name = "lbl104";
            this.lbl104.Size = new System.Drawing.Size(45, 45);
            this.lbl104.TabIndex = 576;
            this.lbl104.Text = "?";
            this.lbl104.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl104.Click += new System.EventHandler(this.lbl104_Click);
            this.lbl104.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl104.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl105
            // 
            this.lbl105.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl105.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl105.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl105.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl105.Location = new System.Drawing.Point(637, 183);
            this.lbl105.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl105.Name = "lbl105";
            this.lbl105.Size = new System.Drawing.Size(45, 45);
            this.lbl105.TabIndex = 577;
            this.lbl105.Text = "?";
            this.lbl105.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl105.Click += new System.EventHandler(this.lbl105_Click);
            this.lbl105.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl105.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl91
            // 
            this.lbl91.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl91.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl91.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl91.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl91.Location = new System.Drawing.Point(23, 183);
            this.lbl91.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl91.Name = "lbl91";
            this.lbl91.Size = new System.Drawing.Size(45, 45);
            this.lbl91.TabIndex = 578;
            this.lbl91.Text = "?";
            this.lbl91.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl91.Click += new System.EventHandler(this.lbl91_Click);
            this.lbl91.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl91.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl92
            // 
            this.lbl92.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl92.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl92.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl92.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl92.Location = new System.Drawing.Point(66, 183);
            this.lbl92.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl92.Name = "lbl92";
            this.lbl92.Size = new System.Drawing.Size(45, 45);
            this.lbl92.TabIndex = 579;
            this.lbl92.Text = "?";
            this.lbl92.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl92.Click += new System.EventHandler(this.lbl92_Click);
            this.lbl92.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl92.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl136
            // 
            this.lbl136.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl136.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl136.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl136.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl136.Location = new System.Drawing.Point(681, 227);
            this.lbl136.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl136.Name = "lbl136";
            this.lbl136.Size = new System.Drawing.Size(45, 45);
            this.lbl136.TabIndex = 580;
            this.lbl136.Text = "?";
            this.lbl136.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl136.Click += new System.EventHandler(this.lbl136_Click);
            this.lbl136.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl136.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl137
            // 
            this.lbl137.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl137.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl137.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl137.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl137.Location = new System.Drawing.Point(725, 227);
            this.lbl137.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl137.Name = "lbl137";
            this.lbl137.Size = new System.Drawing.Size(45, 45);
            this.lbl137.TabIndex = 581;
            this.lbl137.Text = "?";
            this.lbl137.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl137.Click += new System.EventHandler(this.lbl137_Click);
            this.lbl137.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl137.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl138
            // 
            this.lbl138.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl138.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl138.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl138.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl138.Location = new System.Drawing.Point(769, 227);
            this.lbl138.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl138.Name = "lbl138";
            this.lbl138.Size = new System.Drawing.Size(45, 45);
            this.lbl138.TabIndex = 582;
            this.lbl138.Text = "?";
            this.lbl138.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl138.Click += new System.EventHandler(this.lbl138_Click);
            this.lbl138.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl138.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl139
            // 
            this.lbl139.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl139.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl139.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl139.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl139.Location = new System.Drawing.Point(813, 227);
            this.lbl139.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl139.Name = "lbl139";
            this.lbl139.Size = new System.Drawing.Size(45, 45);
            this.lbl139.TabIndex = 583;
            this.lbl139.Text = "?";
            this.lbl139.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl139.Click += new System.EventHandler(this.lbl139_Click);
            this.lbl139.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl139.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl140
            // 
            this.lbl140.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl140.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl140.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl140.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl140.Location = new System.Drawing.Point(857, 227);
            this.lbl140.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl140.Name = "lbl140";
            this.lbl140.Size = new System.Drawing.Size(45, 45);
            this.lbl140.TabIndex = 584;
            this.lbl140.Text = "?";
            this.lbl140.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl140.Click += new System.EventHandler(this.lbl140_Click);
            this.lbl140.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl140.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl141
            // 
            this.lbl141.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl141.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl141.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl141.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl141.Location = new System.Drawing.Point(901, 227);
            this.lbl141.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl141.Name = "lbl141";
            this.lbl141.Size = new System.Drawing.Size(45, 45);
            this.lbl141.TabIndex = 585;
            this.lbl141.Text = "?";
            this.lbl141.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl141.Click += new System.EventHandler(this.lbl141_Click);
            this.lbl141.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl141.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl142
            // 
            this.lbl142.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl142.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl142.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl142.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl142.Location = new System.Drawing.Point(945, 227);
            this.lbl142.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl142.Name = "lbl142";
            this.lbl142.Size = new System.Drawing.Size(45, 45);
            this.lbl142.TabIndex = 586;
            this.lbl142.Text = "?";
            this.lbl142.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl142.Click += new System.EventHandler(this.lbl142_Click);
            this.lbl142.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl142.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl143
            // 
            this.lbl143.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl143.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl143.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl143.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl143.Location = new System.Drawing.Point(989, 227);
            this.lbl143.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl143.Name = "lbl143";
            this.lbl143.Size = new System.Drawing.Size(45, 45);
            this.lbl143.TabIndex = 587;
            this.lbl143.Text = "?";
            this.lbl143.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl143.Click += new System.EventHandler(this.lbl143_Click);
            this.lbl143.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl143.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl144
            // 
            this.lbl144.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl144.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl144.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl144.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl144.Location = new System.Drawing.Point(1033, 227);
            this.lbl144.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl144.Name = "lbl144";
            this.lbl144.Size = new System.Drawing.Size(45, 45);
            this.lbl144.TabIndex = 588;
            this.lbl144.Text = "?";
            this.lbl144.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl144.Click += new System.EventHandler(this.lbl144_Click);
            this.lbl144.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl144.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl145
            // 
            this.lbl145.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl145.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl145.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl145.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl145.Location = new System.Drawing.Point(1077, 227);
            this.lbl145.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl145.Name = "lbl145";
            this.lbl145.Size = new System.Drawing.Size(45, 45);
            this.lbl145.TabIndex = 589;
            this.lbl145.Text = "?";
            this.lbl145.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl145.Click += new System.EventHandler(this.lbl145_Click);
            this.lbl145.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl145.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl146
            // 
            this.lbl146.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl146.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl146.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl146.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl146.Location = new System.Drawing.Point(1121, 227);
            this.lbl146.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl146.Name = "lbl146";
            this.lbl146.Size = new System.Drawing.Size(45, 45);
            this.lbl146.TabIndex = 590;
            this.lbl146.Text = "?";
            this.lbl146.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl146.Click += new System.EventHandler(this.lbl146_Click);
            this.lbl146.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl146.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl147
            // 
            this.lbl147.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl147.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl147.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl147.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl147.Location = new System.Drawing.Point(1165, 227);
            this.lbl147.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl147.Name = "lbl147";
            this.lbl147.Size = new System.Drawing.Size(45, 45);
            this.lbl147.TabIndex = 591;
            this.lbl147.Text = "?";
            this.lbl147.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl147.Click += new System.EventHandler(this.lbl147_Click);
            this.lbl147.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl147.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl148
            // 
            this.lbl148.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl148.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl148.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl148.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl148.Location = new System.Drawing.Point(1209, 227);
            this.lbl148.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl148.Name = "lbl148";
            this.lbl148.Size = new System.Drawing.Size(45, 45);
            this.lbl148.TabIndex = 592;
            this.lbl148.Text = "?";
            this.lbl148.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl148.Click += new System.EventHandler(this.lbl148_Click);
            this.lbl148.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl148.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl123
            // 
            this.lbl123.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl123.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl123.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl123.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl123.Location = new System.Drawing.Point(110, 227);
            this.lbl123.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl123.Name = "lbl123";
            this.lbl123.Size = new System.Drawing.Size(45, 45);
            this.lbl123.TabIndex = 593;
            this.lbl123.Text = "?";
            this.lbl123.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl123.Click += new System.EventHandler(this.lbl123_Click);
            this.lbl123.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl123.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl124
            // 
            this.lbl124.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl124.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl124.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl124.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl124.Location = new System.Drawing.Point(154, 227);
            this.lbl124.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl124.Name = "lbl124";
            this.lbl124.Size = new System.Drawing.Size(45, 45);
            this.lbl124.TabIndex = 594;
            this.lbl124.Text = "?";
            this.lbl124.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl124.Click += new System.EventHandler(this.lbl124_Click);
            this.lbl124.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl124.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl125
            // 
            this.lbl125.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl125.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl125.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl125.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl125.Location = new System.Drawing.Point(198, 227);
            this.lbl125.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl125.Name = "lbl125";
            this.lbl125.Size = new System.Drawing.Size(45, 45);
            this.lbl125.TabIndex = 595;
            this.lbl125.Text = "?";
            this.lbl125.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl125.Click += new System.EventHandler(this.lbl125_Click);
            this.lbl125.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl125.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl126
            // 
            this.lbl126.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl126.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl126.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl126.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl126.Location = new System.Drawing.Point(242, 227);
            this.lbl126.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl126.Name = "lbl126";
            this.lbl126.Size = new System.Drawing.Size(45, 45);
            this.lbl126.TabIndex = 596;
            this.lbl126.Text = "?";
            this.lbl126.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl126.Click += new System.EventHandler(this.lbl126_Click);
            this.lbl126.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl126.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl127
            // 
            this.lbl127.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl127.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl127.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl127.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl127.Location = new System.Drawing.Point(285, 227);
            this.lbl127.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl127.Name = "lbl127";
            this.lbl127.Size = new System.Drawing.Size(45, 45);
            this.lbl127.TabIndex = 597;
            this.lbl127.Text = "?";
            this.lbl127.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl127.Click += new System.EventHandler(this.lbl127_Click);
            this.lbl127.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl127.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl128
            // 
            this.lbl128.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl128.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl128.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl128.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl128.Location = new System.Drawing.Point(329, 227);
            this.lbl128.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl128.Name = "lbl128";
            this.lbl128.Size = new System.Drawing.Size(45, 45);
            this.lbl128.TabIndex = 598;
            this.lbl128.Text = "?";
            this.lbl128.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl128.Click += new System.EventHandler(this.lbl128_Click);
            this.lbl128.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl128.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl129
            // 
            this.lbl129.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl129.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl129.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl129.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl129.Location = new System.Drawing.Point(373, 227);
            this.lbl129.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl129.Name = "lbl129";
            this.lbl129.Size = new System.Drawing.Size(45, 45);
            this.lbl129.TabIndex = 599;
            this.lbl129.Text = "?";
            this.lbl129.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl129.Click += new System.EventHandler(this.lbl129_Click);
            this.lbl129.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl129.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl130
            // 
            this.lbl130.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl130.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl130.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl130.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl130.Location = new System.Drawing.Point(417, 227);
            this.lbl130.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl130.Name = "lbl130";
            this.lbl130.Size = new System.Drawing.Size(45, 45);
            this.lbl130.TabIndex = 600;
            this.lbl130.Text = "?";
            this.lbl130.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl130.Click += new System.EventHandler(this.lbl130_Click);
            this.lbl130.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl130.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl131
            // 
            this.lbl131.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl131.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl131.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl131.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl131.Location = new System.Drawing.Point(461, 227);
            this.lbl131.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl131.Name = "lbl131";
            this.lbl131.Size = new System.Drawing.Size(45, 45);
            this.lbl131.TabIndex = 601;
            this.lbl131.Text = "?";
            this.lbl131.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl131.Click += new System.EventHandler(this.lbl131_Click);
            this.lbl131.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl131.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl132
            // 
            this.lbl132.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl132.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl132.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl132.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl132.Location = new System.Drawing.Point(505, 227);
            this.lbl132.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl132.Name = "lbl132";
            this.lbl132.Size = new System.Drawing.Size(45, 45);
            this.lbl132.TabIndex = 602;
            this.lbl132.Text = "?";
            this.lbl132.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl132.Click += new System.EventHandler(this.lbl132_Click);
            this.lbl132.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl132.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl133
            // 
            this.lbl133.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl133.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl133.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl133.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl133.Location = new System.Drawing.Point(549, 227);
            this.lbl133.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl133.Name = "lbl133";
            this.lbl133.Size = new System.Drawing.Size(45, 45);
            this.lbl133.TabIndex = 603;
            this.lbl133.Text = "?";
            this.lbl133.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl133.Click += new System.EventHandler(this.lbl133_Click);
            this.lbl133.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl133.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl134
            // 
            this.lbl134.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl134.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl134.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl134.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl134.Location = new System.Drawing.Point(593, 227);
            this.lbl134.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl134.Name = "lbl134";
            this.lbl134.Size = new System.Drawing.Size(45, 45);
            this.lbl134.TabIndex = 604;
            this.lbl134.Text = "?";
            this.lbl134.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl134.Click += new System.EventHandler(this.lbl134_Click);
            this.lbl134.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl134.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl135
            // 
            this.lbl135.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl135.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl135.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl135.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl135.Location = new System.Drawing.Point(637, 227);
            this.lbl135.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl135.Name = "lbl135";
            this.lbl135.Size = new System.Drawing.Size(45, 45);
            this.lbl135.TabIndex = 605;
            this.lbl135.Text = "?";
            this.lbl135.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl135.Click += new System.EventHandler(this.lbl135_Click);
            this.lbl135.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl135.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl121
            // 
            this.lbl121.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl121.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl121.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl121.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl121.Location = new System.Drawing.Point(23, 227);
            this.lbl121.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl121.Name = "lbl121";
            this.lbl121.Size = new System.Drawing.Size(45, 45);
            this.lbl121.TabIndex = 606;
            this.lbl121.Text = "?";
            this.lbl121.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl121.Click += new System.EventHandler(this.lbl121_Click);
            this.lbl121.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl121.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl29
            // 
            this.lbl29.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl29.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl29.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl29.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl29.Location = new System.Drawing.Point(1253, 51);
            this.lbl29.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl29.Name = "lbl29";
            this.lbl29.Size = new System.Drawing.Size(45, 45);
            this.lbl29.TabIndex = 608;
            this.lbl29.Text = "?";
            this.lbl29.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl29.Click += new System.EventHandler(this.lbl29_Click);
            this.lbl29.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl29.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl122
            // 
            this.lbl122.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl122.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl122.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl122.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl122.Location = new System.Drawing.Point(66, 227);
            this.lbl122.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl122.Name = "lbl122";
            this.lbl122.Size = new System.Drawing.Size(45, 45);
            this.lbl122.TabIndex = 607;
            this.lbl122.Text = "?";
            this.lbl122.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl122.Click += new System.EventHandler(this.lbl122_Click);
            this.lbl122.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl122.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl30
            // 
            this.lbl30.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl30.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl30.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl30.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl30.Location = new System.Drawing.Point(1297, 51);
            this.lbl30.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl30.Name = "lbl30";
            this.lbl30.Size = new System.Drawing.Size(45, 45);
            this.lbl30.TabIndex = 609;
            this.lbl30.Text = "?";
            this.lbl30.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl30.Click += new System.EventHandler(this.lbl30_Click);
            this.lbl30.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl30.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl59
            // 
            this.lbl59.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl59.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl59.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl59.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl59.Location = new System.Drawing.Point(1253, 95);
            this.lbl59.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl59.Name = "lbl59";
            this.lbl59.Size = new System.Drawing.Size(45, 45);
            this.lbl59.TabIndex = 610;
            this.lbl59.Text = "?";
            this.lbl59.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl59.Click += new System.EventHandler(this.lbl59_Click);
            this.lbl59.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl59.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl60
            // 
            this.lbl60.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl60.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl60.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl60.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl60.Location = new System.Drawing.Point(1297, 95);
            this.lbl60.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl60.Name = "lbl60";
            this.lbl60.Size = new System.Drawing.Size(45, 45);
            this.lbl60.TabIndex = 611;
            this.lbl60.Text = "?";
            this.lbl60.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl60.Click += new System.EventHandler(this.lbl60_Click);
            this.lbl60.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl60.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl89
            // 
            this.lbl89.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl89.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl89.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl89.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl89.Location = new System.Drawing.Point(1253, 139);
            this.lbl89.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl89.Name = "lbl89";
            this.lbl89.Size = new System.Drawing.Size(45, 45);
            this.lbl89.TabIndex = 612;
            this.lbl89.Text = "?";
            this.lbl89.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl89.Click += new System.EventHandler(this.lbl89_Click);
            this.lbl89.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl89.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl90
            // 
            this.lbl90.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl90.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl90.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl90.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl90.Location = new System.Drawing.Point(1297, 139);
            this.lbl90.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl90.Name = "lbl90";
            this.lbl90.Size = new System.Drawing.Size(45, 45);
            this.lbl90.TabIndex = 613;
            this.lbl90.Text = "?";
            this.lbl90.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl90.Click += new System.EventHandler(this.lbl90_Click);
            this.lbl90.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl90.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl119
            // 
            this.lbl119.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl119.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl119.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl119.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl119.Location = new System.Drawing.Point(1253, 183);
            this.lbl119.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl119.Name = "lbl119";
            this.lbl119.Size = new System.Drawing.Size(45, 45);
            this.lbl119.TabIndex = 614;
            this.lbl119.Text = "?";
            this.lbl119.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl119.Click += new System.EventHandler(this.lbl119_Click);
            this.lbl119.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl119.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl120
            // 
            this.lbl120.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl120.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl120.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl120.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl120.Location = new System.Drawing.Point(1297, 183);
            this.lbl120.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl120.Name = "lbl120";
            this.lbl120.Size = new System.Drawing.Size(45, 45);
            this.lbl120.TabIndex = 615;
            this.lbl120.Text = "?";
            this.lbl120.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl120.Click += new System.EventHandler(this.lbl120_Click);
            this.lbl120.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl120.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl149
            // 
            this.lbl149.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl149.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl149.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl149.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl149.Location = new System.Drawing.Point(1253, 227);
            this.lbl149.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl149.Name = "lbl149";
            this.lbl149.Size = new System.Drawing.Size(45, 45);
            this.lbl149.TabIndex = 616;
            this.lbl149.Text = "?";
            this.lbl149.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl149.Click += new System.EventHandler(this.lbl149_Click);
            this.lbl149.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl149.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl150
            // 
            this.lbl150.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl150.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl150.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl150.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl150.Location = new System.Drawing.Point(1297, 227);
            this.lbl150.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl150.Name = "lbl150";
            this.lbl150.Size = new System.Drawing.Size(45, 45);
            this.lbl150.TabIndex = 617;
            this.lbl150.Text = "?";
            this.lbl150.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl150.Click += new System.EventHandler(this.lbl150_Click);
            this.lbl150.MouseEnter += new System.EventHandler(this.lbl150_MouseEnter);
            // 
            // lbl166
            // 
            this.lbl166.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl166.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl166.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl166.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl166.Location = new System.Drawing.Point(681, 271);
            this.lbl166.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl166.Name = "lbl166";
            this.lbl166.Size = new System.Drawing.Size(45, 45);
            this.lbl166.TabIndex = 618;
            this.lbl166.Text = "?";
            this.lbl166.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl166.Click += new System.EventHandler(this.lbl166_Click);
            this.lbl166.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl166.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl167
            // 
            this.lbl167.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl167.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl167.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl167.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl167.Location = new System.Drawing.Point(725, 271);
            this.lbl167.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl167.Name = "lbl167";
            this.lbl167.Size = new System.Drawing.Size(45, 45);
            this.lbl167.TabIndex = 619;
            this.lbl167.Text = "?";
            this.lbl167.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl167.Click += new System.EventHandler(this.lbl167_Click);
            this.lbl167.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl167.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl168
            // 
            this.lbl168.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl168.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl168.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl168.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl168.Location = new System.Drawing.Point(769, 271);
            this.lbl168.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl168.Name = "lbl168";
            this.lbl168.Size = new System.Drawing.Size(45, 45);
            this.lbl168.TabIndex = 620;
            this.lbl168.Text = "?";
            this.lbl168.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl168.Click += new System.EventHandler(this.lbl168_Click);
            this.lbl168.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl168.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl169
            // 
            this.lbl169.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl169.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl169.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl169.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl169.Location = new System.Drawing.Point(813, 271);
            this.lbl169.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl169.Name = "lbl169";
            this.lbl169.Size = new System.Drawing.Size(45, 45);
            this.lbl169.TabIndex = 621;
            this.lbl169.Text = "?";
            this.lbl169.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl169.Click += new System.EventHandler(this.lbl169_Click);
            this.lbl169.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl169.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl170
            // 
            this.lbl170.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl170.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl170.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl170.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl170.Location = new System.Drawing.Point(857, 271);
            this.lbl170.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl170.Name = "lbl170";
            this.lbl170.Size = new System.Drawing.Size(45, 45);
            this.lbl170.TabIndex = 622;
            this.lbl170.Text = "?";
            this.lbl170.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl170.Click += new System.EventHandler(this.lbl170_Click);
            this.lbl170.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl170.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl171
            // 
            this.lbl171.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl171.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl171.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl171.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl171.Location = new System.Drawing.Point(901, 271);
            this.lbl171.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl171.Name = "lbl171";
            this.lbl171.Size = new System.Drawing.Size(45, 45);
            this.lbl171.TabIndex = 623;
            this.lbl171.Text = "?";
            this.lbl171.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl171.Click += new System.EventHandler(this.lbl171_Click);
            this.lbl171.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl171.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl172
            // 
            this.lbl172.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl172.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl172.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl172.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl172.Location = new System.Drawing.Point(945, 271);
            this.lbl172.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl172.Name = "lbl172";
            this.lbl172.Size = new System.Drawing.Size(45, 45);
            this.lbl172.TabIndex = 624;
            this.lbl172.Text = "?";
            this.lbl172.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl172.Click += new System.EventHandler(this.lbl172_Click);
            this.lbl172.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl172.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl173
            // 
            this.lbl173.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl173.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl173.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl173.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl173.Location = new System.Drawing.Point(989, 271);
            this.lbl173.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl173.Name = "lbl173";
            this.lbl173.Size = new System.Drawing.Size(45, 45);
            this.lbl173.TabIndex = 625;
            this.lbl173.Text = "?";
            this.lbl173.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl173.Click += new System.EventHandler(this.lbl173_Click);
            this.lbl173.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl173.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl174
            // 
            this.lbl174.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl174.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl174.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl174.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl174.Location = new System.Drawing.Point(1033, 271);
            this.lbl174.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl174.Name = "lbl174";
            this.lbl174.Size = new System.Drawing.Size(45, 45);
            this.lbl174.TabIndex = 626;
            this.lbl174.Text = "?";
            this.lbl174.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl174.Click += new System.EventHandler(this.lbl174_Click);
            this.lbl174.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl174.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl175
            // 
            this.lbl175.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl175.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl175.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl175.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl175.Location = new System.Drawing.Point(1077, 271);
            this.lbl175.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl175.Name = "lbl175";
            this.lbl175.Size = new System.Drawing.Size(45, 45);
            this.lbl175.TabIndex = 627;
            this.lbl175.Text = "?";
            this.lbl175.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl175.Click += new System.EventHandler(this.lbl175_Click);
            this.lbl175.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl175.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl176
            // 
            this.lbl176.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl176.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl176.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl176.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl176.Location = new System.Drawing.Point(1121, 271);
            this.lbl176.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl176.Name = "lbl176";
            this.lbl176.Size = new System.Drawing.Size(45, 45);
            this.lbl176.TabIndex = 628;
            this.lbl176.Text = "?";
            this.lbl176.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl176.Click += new System.EventHandler(this.lbl176_Click);
            this.lbl176.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl176.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl177
            // 
            this.lbl177.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl177.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl177.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl177.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl177.Location = new System.Drawing.Point(1165, 271);
            this.lbl177.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl177.Name = "lbl177";
            this.lbl177.Size = new System.Drawing.Size(45, 45);
            this.lbl177.TabIndex = 629;
            this.lbl177.Text = "?";
            this.lbl177.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl177.Click += new System.EventHandler(this.lbl177_Click);
            this.lbl177.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl177.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl178
            // 
            this.lbl178.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl178.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl178.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl178.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl178.Location = new System.Drawing.Point(1209, 271);
            this.lbl178.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl178.Name = "lbl178";
            this.lbl178.Size = new System.Drawing.Size(45, 45);
            this.lbl178.TabIndex = 630;
            this.lbl178.Text = "?";
            this.lbl178.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl178.Click += new System.EventHandler(this.lbl178_Click);
            this.lbl178.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl178.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl153
            // 
            this.lbl153.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl153.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl153.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl153.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl153.Location = new System.Drawing.Point(110, 271);
            this.lbl153.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl153.Name = "lbl153";
            this.lbl153.Size = new System.Drawing.Size(45, 45);
            this.lbl153.TabIndex = 631;
            this.lbl153.Text = "?";
            this.lbl153.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl153.Click += new System.EventHandler(this.lbl153_Click);
            this.lbl153.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl153.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl154
            // 
            this.lbl154.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl154.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl154.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl154.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl154.Location = new System.Drawing.Point(154, 271);
            this.lbl154.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl154.Name = "lbl154";
            this.lbl154.Size = new System.Drawing.Size(45, 45);
            this.lbl154.TabIndex = 632;
            this.lbl154.Text = "?";
            this.lbl154.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl154.Click += new System.EventHandler(this.lbl154_Click);
            this.lbl154.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl154.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl155
            // 
            this.lbl155.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl155.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl155.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl155.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl155.Location = new System.Drawing.Point(198, 271);
            this.lbl155.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl155.Name = "lbl155";
            this.lbl155.Size = new System.Drawing.Size(45, 45);
            this.lbl155.TabIndex = 633;
            this.lbl155.Text = "?";
            this.lbl155.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl155.Click += new System.EventHandler(this.lbl155_Click);
            this.lbl155.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl155.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl156
            // 
            this.lbl156.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl156.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl156.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl156.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl156.Location = new System.Drawing.Point(242, 271);
            this.lbl156.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl156.Name = "lbl156";
            this.lbl156.Size = new System.Drawing.Size(45, 45);
            this.lbl156.TabIndex = 634;
            this.lbl156.Text = "?";
            this.lbl156.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl156.Click += new System.EventHandler(this.lbl156_Click);
            this.lbl156.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl156.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl157
            // 
            this.lbl157.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl157.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl157.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl157.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl157.Location = new System.Drawing.Point(285, 271);
            this.lbl157.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl157.Name = "lbl157";
            this.lbl157.Size = new System.Drawing.Size(45, 45);
            this.lbl157.TabIndex = 635;
            this.lbl157.Text = "?";
            this.lbl157.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl157.Click += new System.EventHandler(this.lbl157_Click);
            this.lbl157.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl157.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl158
            // 
            this.lbl158.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl158.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl158.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl158.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl158.Location = new System.Drawing.Point(329, 271);
            this.lbl158.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl158.Name = "lbl158";
            this.lbl158.Size = new System.Drawing.Size(45, 45);
            this.lbl158.TabIndex = 636;
            this.lbl158.Text = "?";
            this.lbl158.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl158.Click += new System.EventHandler(this.lbl158_Click);
            this.lbl158.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl158.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl159
            // 
            this.lbl159.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl159.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl159.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl159.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl159.Location = new System.Drawing.Point(373, 271);
            this.lbl159.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl159.Name = "lbl159";
            this.lbl159.Size = new System.Drawing.Size(45, 45);
            this.lbl159.TabIndex = 637;
            this.lbl159.Text = "?";
            this.lbl159.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl159.Click += new System.EventHandler(this.lbl159_Click);
            this.lbl159.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl159.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl160
            // 
            this.lbl160.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl160.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl160.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl160.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl160.Location = new System.Drawing.Point(417, 271);
            this.lbl160.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl160.Name = "lbl160";
            this.lbl160.Size = new System.Drawing.Size(45, 45);
            this.lbl160.TabIndex = 638;
            this.lbl160.Text = "?";
            this.lbl160.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl160.Click += new System.EventHandler(this.lbl160_Click);
            this.lbl160.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl160.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl161
            // 
            this.lbl161.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl161.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl161.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl161.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl161.Location = new System.Drawing.Point(461, 271);
            this.lbl161.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl161.Name = "lbl161";
            this.lbl161.Size = new System.Drawing.Size(45, 45);
            this.lbl161.TabIndex = 639;
            this.lbl161.Text = "?";
            this.lbl161.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl161.Click += new System.EventHandler(this.lbl161_Click);
            this.lbl161.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl161.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl162
            // 
            this.lbl162.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl162.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl162.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl162.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl162.Location = new System.Drawing.Point(505, 271);
            this.lbl162.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl162.Name = "lbl162";
            this.lbl162.Size = new System.Drawing.Size(45, 45);
            this.lbl162.TabIndex = 640;
            this.lbl162.Text = "?";
            this.lbl162.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl162.Click += new System.EventHandler(this.lbl162_Click);
            this.lbl162.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl162.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl163
            // 
            this.lbl163.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl163.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl163.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl163.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl163.Location = new System.Drawing.Point(549, 271);
            this.lbl163.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl163.Name = "lbl163";
            this.lbl163.Size = new System.Drawing.Size(45, 45);
            this.lbl163.TabIndex = 641;
            this.lbl163.Text = "?";
            this.lbl163.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl163.Click += new System.EventHandler(this.lbl163_Click);
            this.lbl163.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl163.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl164
            // 
            this.lbl164.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl164.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl164.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl164.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl164.Location = new System.Drawing.Point(593, 271);
            this.lbl164.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl164.Name = "lbl164";
            this.lbl164.Size = new System.Drawing.Size(45, 45);
            this.lbl164.TabIndex = 642;
            this.lbl164.Text = "?";
            this.lbl164.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl164.Click += new System.EventHandler(this.lbl164_Click);
            this.lbl164.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl164.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl165
            // 
            this.lbl165.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl165.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl165.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl165.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl165.Location = new System.Drawing.Point(637, 271);
            this.lbl165.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl165.Name = "lbl165";
            this.lbl165.Size = new System.Drawing.Size(45, 45);
            this.lbl165.TabIndex = 643;
            this.lbl165.Text = "?";
            this.lbl165.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl165.Click += new System.EventHandler(this.lbl165_Click);
            this.lbl165.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl165.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl151
            // 
            this.lbl151.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl151.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl151.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl151.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl151.Location = new System.Drawing.Point(23, 271);
            this.lbl151.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl151.Name = "lbl151";
            this.lbl151.Size = new System.Drawing.Size(45, 45);
            this.lbl151.TabIndex = 644;
            this.lbl151.Text = "?";
            this.lbl151.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl151.Click += new System.EventHandler(this.lbl151_Click);
            this.lbl151.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl151.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl152
            // 
            this.lbl152.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl152.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl152.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl152.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl152.Location = new System.Drawing.Point(66, 271);
            this.lbl152.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl152.Name = "lbl152";
            this.lbl152.Size = new System.Drawing.Size(45, 45);
            this.lbl152.TabIndex = 645;
            this.lbl152.Text = "?";
            this.lbl152.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl152.Click += new System.EventHandler(this.lbl152_Click);
            this.lbl152.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl152.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl196
            // 
            this.lbl196.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl196.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl196.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl196.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl196.Location = new System.Drawing.Point(681, 315);
            this.lbl196.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl196.Name = "lbl196";
            this.lbl196.Size = new System.Drawing.Size(45, 45);
            this.lbl196.TabIndex = 646;
            this.lbl196.Text = "?";
            this.lbl196.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl196.Click += new System.EventHandler(this.lbl196_Click);
            this.lbl196.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl196.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl197
            // 
            this.lbl197.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl197.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl197.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl197.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl197.Location = new System.Drawing.Point(725, 315);
            this.lbl197.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl197.Name = "lbl197";
            this.lbl197.Size = new System.Drawing.Size(45, 45);
            this.lbl197.TabIndex = 647;
            this.lbl197.Text = "?";
            this.lbl197.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl197.Click += new System.EventHandler(this.lbl197_Click);
            this.lbl197.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl197.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl198
            // 
            this.lbl198.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl198.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl198.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl198.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl198.Location = new System.Drawing.Point(769, 315);
            this.lbl198.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl198.Name = "lbl198";
            this.lbl198.Size = new System.Drawing.Size(45, 45);
            this.lbl198.TabIndex = 648;
            this.lbl198.Text = "?";
            this.lbl198.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl198.Click += new System.EventHandler(this.lbl198_Click);
            this.lbl198.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl198.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl199
            // 
            this.lbl199.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl199.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl199.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl199.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl199.Location = new System.Drawing.Point(813, 315);
            this.lbl199.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl199.Name = "lbl199";
            this.lbl199.Size = new System.Drawing.Size(45, 45);
            this.lbl199.TabIndex = 649;
            this.lbl199.Text = "?";
            this.lbl199.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl199.Click += new System.EventHandler(this.lbl199_Click);
            this.lbl199.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl199.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl200
            // 
            this.lbl200.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl200.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl200.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl200.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl200.Location = new System.Drawing.Point(857, 315);
            this.lbl200.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl200.Name = "lbl200";
            this.lbl200.Size = new System.Drawing.Size(45, 45);
            this.lbl200.TabIndex = 650;
            this.lbl200.Text = "?";
            this.lbl200.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl200.Click += new System.EventHandler(this.lbl200_Click);
            this.lbl200.MouseEnter += new System.EventHandler(this.lbl200_MouseEnter);
            // 
            // lbl201
            // 
            this.lbl201.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl201.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl201.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl201.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl201.Location = new System.Drawing.Point(901, 315);
            this.lbl201.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl201.Name = "lbl201";
            this.lbl201.Size = new System.Drawing.Size(45, 45);
            this.lbl201.TabIndex = 651;
            this.lbl201.Text = "?";
            this.lbl201.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl201.Click += new System.EventHandler(this.lbl201_Click);
            this.lbl201.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl201.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl202
            // 
            this.lbl202.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl202.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl202.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl202.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl202.Location = new System.Drawing.Point(945, 315);
            this.lbl202.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl202.Name = "lbl202";
            this.lbl202.Size = new System.Drawing.Size(45, 45);
            this.lbl202.TabIndex = 652;
            this.lbl202.Text = "?";
            this.lbl202.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl202.Click += new System.EventHandler(this.lbl202_Click);
            this.lbl202.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl202.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl203
            // 
            this.lbl203.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl203.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl203.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl203.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl203.Location = new System.Drawing.Point(989, 315);
            this.lbl203.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl203.Name = "lbl203";
            this.lbl203.Size = new System.Drawing.Size(45, 45);
            this.lbl203.TabIndex = 653;
            this.lbl203.Text = "?";
            this.lbl203.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl203.Click += new System.EventHandler(this.lbl203_Click);
            this.lbl203.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl203.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl204
            // 
            this.lbl204.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl204.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl204.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl204.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl204.Location = new System.Drawing.Point(1033, 315);
            this.lbl204.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl204.Name = "lbl204";
            this.lbl204.Size = new System.Drawing.Size(45, 45);
            this.lbl204.TabIndex = 654;
            this.lbl204.Text = "?";
            this.lbl204.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl204.Click += new System.EventHandler(this.lbl204_Click);
            this.lbl204.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl204.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl205
            // 
            this.lbl205.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl205.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl205.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl205.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl205.Location = new System.Drawing.Point(1077, 315);
            this.lbl205.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl205.Name = "lbl205";
            this.lbl205.Size = new System.Drawing.Size(45, 45);
            this.lbl205.TabIndex = 655;
            this.lbl205.Text = "?";
            this.lbl205.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl205.Click += new System.EventHandler(this.lbl205_Click);
            this.lbl205.MouseEnter += new System.EventHandler(this.lbl205_MouseEnter);
            // 
            // lbl206
            // 
            this.lbl206.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl206.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl206.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl206.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl206.Location = new System.Drawing.Point(1121, 315);
            this.lbl206.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl206.Name = "lbl206";
            this.lbl206.Size = new System.Drawing.Size(45, 45);
            this.lbl206.TabIndex = 656;
            this.lbl206.Text = "?";
            this.lbl206.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl206.Click += new System.EventHandler(this.lbl206_Click);
            this.lbl206.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl206.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl207
            // 
            this.lbl207.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl207.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl207.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl207.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl207.Location = new System.Drawing.Point(1165, 315);
            this.lbl207.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl207.Name = "lbl207";
            this.lbl207.Size = new System.Drawing.Size(45, 45);
            this.lbl207.TabIndex = 657;
            this.lbl207.Text = "?";
            this.lbl207.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl207.Click += new System.EventHandler(this.lbl207_Click);
            this.lbl207.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl207.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl208
            // 
            this.lbl208.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl208.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl208.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl208.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl208.Location = new System.Drawing.Point(1209, 315);
            this.lbl208.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl208.Name = "lbl208";
            this.lbl208.Size = new System.Drawing.Size(45, 45);
            this.lbl208.TabIndex = 658;
            this.lbl208.Text = "?";
            this.lbl208.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl208.Click += new System.EventHandler(this.lbl208_Click);
            this.lbl208.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl208.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl183
            // 
            this.lbl183.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl183.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl183.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl183.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl183.Location = new System.Drawing.Point(110, 315);
            this.lbl183.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl183.Name = "lbl183";
            this.lbl183.Size = new System.Drawing.Size(45, 45);
            this.lbl183.TabIndex = 659;
            this.lbl183.Text = "?";
            this.lbl183.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl183.Click += new System.EventHandler(this.lbl183_Click);
            this.lbl183.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl183.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl184
            // 
            this.lbl184.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl184.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl184.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl184.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl184.Location = new System.Drawing.Point(154, 315);
            this.lbl184.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl184.Name = "lbl184";
            this.lbl184.Size = new System.Drawing.Size(45, 45);
            this.lbl184.TabIndex = 660;
            this.lbl184.Text = "?";
            this.lbl184.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl184.Click += new System.EventHandler(this.lbl184_Click);
            this.lbl184.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl184.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl185
            // 
            this.lbl185.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl185.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl185.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl185.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl185.Location = new System.Drawing.Point(198, 315);
            this.lbl185.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl185.Name = "lbl185";
            this.lbl185.Size = new System.Drawing.Size(45, 45);
            this.lbl185.TabIndex = 661;
            this.lbl185.Text = "?";
            this.lbl185.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl185.Click += new System.EventHandler(this.lbl185_Click);
            this.lbl185.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl185.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl186
            // 
            this.lbl186.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl186.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl186.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl186.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl186.Location = new System.Drawing.Point(242, 315);
            this.lbl186.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl186.Name = "lbl186";
            this.lbl186.Size = new System.Drawing.Size(45, 45);
            this.lbl186.TabIndex = 662;
            this.lbl186.Text = "?";
            this.lbl186.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl186.Click += new System.EventHandler(this.lbl186_Click);
            this.lbl186.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl186.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl187
            // 
            this.lbl187.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl187.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl187.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl187.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl187.Location = new System.Drawing.Point(285, 315);
            this.lbl187.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl187.Name = "lbl187";
            this.lbl187.Size = new System.Drawing.Size(45, 45);
            this.lbl187.TabIndex = 663;
            this.lbl187.Text = "?";
            this.lbl187.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl187.Click += new System.EventHandler(this.lbl187_Click);
            this.lbl187.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl187.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl188
            // 
            this.lbl188.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl188.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl188.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl188.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl188.Location = new System.Drawing.Point(329, 315);
            this.lbl188.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl188.Name = "lbl188";
            this.lbl188.Size = new System.Drawing.Size(45, 45);
            this.lbl188.TabIndex = 664;
            this.lbl188.Text = "?";
            this.lbl188.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl188.Click += new System.EventHandler(this.lbl188_Click);
            this.lbl188.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl188.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl189
            // 
            this.lbl189.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl189.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl189.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl189.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl189.Location = new System.Drawing.Point(373, 315);
            this.lbl189.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl189.Name = "lbl189";
            this.lbl189.Size = new System.Drawing.Size(45, 45);
            this.lbl189.TabIndex = 665;
            this.lbl189.Text = "?";
            this.lbl189.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl189.Click += new System.EventHandler(this.lbl189_Click);
            this.lbl189.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl189.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl190
            // 
            this.lbl190.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl190.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl190.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl190.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl190.Location = new System.Drawing.Point(417, 315);
            this.lbl190.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl190.Name = "lbl190";
            this.lbl190.Size = new System.Drawing.Size(45, 45);
            this.lbl190.TabIndex = 666;
            this.lbl190.Text = "?";
            this.lbl190.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl190.Click += new System.EventHandler(this.lbl190_Click);
            this.lbl190.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl190.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl191
            // 
            this.lbl191.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl191.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl191.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl191.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl191.Location = new System.Drawing.Point(461, 315);
            this.lbl191.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl191.Name = "lbl191";
            this.lbl191.Size = new System.Drawing.Size(45, 45);
            this.lbl191.TabIndex = 667;
            this.lbl191.Text = "?";
            this.lbl191.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl191.Click += new System.EventHandler(this.lbl191_Click);
            this.lbl191.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl191.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl192
            // 
            this.lbl192.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl192.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl192.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl192.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl192.Location = new System.Drawing.Point(505, 315);
            this.lbl192.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl192.Name = "lbl192";
            this.lbl192.Size = new System.Drawing.Size(45, 45);
            this.lbl192.TabIndex = 668;
            this.lbl192.Text = "?";
            this.lbl192.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl192.Click += new System.EventHandler(this.lbl192_Click);
            this.lbl192.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl192.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl193
            // 
            this.lbl193.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl193.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl193.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl193.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl193.Location = new System.Drawing.Point(549, 315);
            this.lbl193.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl193.Name = "lbl193";
            this.lbl193.Size = new System.Drawing.Size(45, 45);
            this.lbl193.TabIndex = 669;
            this.lbl193.Text = "?";
            this.lbl193.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl193.Click += new System.EventHandler(this.lbl193_Click);
            this.lbl193.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl193.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl194
            // 
            this.lbl194.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl194.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl194.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl194.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl194.Location = new System.Drawing.Point(593, 315);
            this.lbl194.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl194.Name = "lbl194";
            this.lbl194.Size = new System.Drawing.Size(45, 45);
            this.lbl194.TabIndex = 670;
            this.lbl194.Text = "?";
            this.lbl194.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl194.Click += new System.EventHandler(this.lbl194_Click);
            this.lbl194.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl194.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl195
            // 
            this.lbl195.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl195.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl195.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl195.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl195.Location = new System.Drawing.Point(637, 315);
            this.lbl195.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl195.Name = "lbl195";
            this.lbl195.Size = new System.Drawing.Size(45, 45);
            this.lbl195.TabIndex = 671;
            this.lbl195.Text = "?";
            this.lbl195.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl195.Click += new System.EventHandler(this.lbl195_Click);
            this.lbl195.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl195.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl181
            // 
            this.lbl181.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl181.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl181.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl181.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl181.Location = new System.Drawing.Point(23, 315);
            this.lbl181.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl181.Name = "lbl181";
            this.lbl181.Size = new System.Drawing.Size(45, 45);
            this.lbl181.TabIndex = 672;
            this.lbl181.Text = "?";
            this.lbl181.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl181.Click += new System.EventHandler(this.lbl181_Click);
            this.lbl181.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl181.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl182
            // 
            this.lbl182.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl182.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl182.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl182.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl182.Location = new System.Drawing.Point(66, 315);
            this.lbl182.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl182.Name = "lbl182";
            this.lbl182.Size = new System.Drawing.Size(45, 45);
            this.lbl182.TabIndex = 673;
            this.lbl182.Text = "?";
            this.lbl182.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl182.Click += new System.EventHandler(this.lbl182_Click);
            this.lbl182.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl182.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl226
            // 
            this.lbl226.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl226.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl226.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl226.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl226.Location = new System.Drawing.Point(681, 359);
            this.lbl226.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl226.Name = "lbl226";
            this.lbl226.Size = new System.Drawing.Size(45, 45);
            this.lbl226.TabIndex = 674;
            this.lbl226.Text = "?";
            this.lbl226.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl226.Click += new System.EventHandler(this.lbl226_Click);
            this.lbl226.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl226.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl227
            // 
            this.lbl227.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl227.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl227.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl227.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl227.Location = new System.Drawing.Point(725, 359);
            this.lbl227.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl227.Name = "lbl227";
            this.lbl227.Size = new System.Drawing.Size(45, 45);
            this.lbl227.TabIndex = 675;
            this.lbl227.Text = "?";
            this.lbl227.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl227.Click += new System.EventHandler(this.lbl227_Click);
            this.lbl227.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl227.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl228
            // 
            this.lbl228.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl228.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl228.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl228.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl228.Location = new System.Drawing.Point(769, 359);
            this.lbl228.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl228.Name = "lbl228";
            this.lbl228.Size = new System.Drawing.Size(45, 45);
            this.lbl228.TabIndex = 676;
            this.lbl228.Text = "?";
            this.lbl228.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl228.Click += new System.EventHandler(this.lbl228_Click);
            this.lbl228.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl228.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl229
            // 
            this.lbl229.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl229.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl229.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl229.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl229.Location = new System.Drawing.Point(813, 359);
            this.lbl229.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl229.Name = "lbl229";
            this.lbl229.Size = new System.Drawing.Size(45, 45);
            this.lbl229.TabIndex = 677;
            this.lbl229.Text = "?";
            this.lbl229.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl229.Click += new System.EventHandler(this.lbl229_Click);
            this.lbl229.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl229.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl230
            // 
            this.lbl230.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl230.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl230.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl230.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl230.Location = new System.Drawing.Point(857, 359);
            this.lbl230.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl230.Name = "lbl230";
            this.lbl230.Size = new System.Drawing.Size(45, 45);
            this.lbl230.TabIndex = 678;
            this.lbl230.Text = "?";
            this.lbl230.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl230.Click += new System.EventHandler(this.lbl230_Click);
            this.lbl230.MouseEnter += new System.EventHandler(this.lbl230_MouseEnter);
            // 
            // lbl231
            // 
            this.lbl231.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl231.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl231.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl231.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl231.Location = new System.Drawing.Point(901, 359);
            this.lbl231.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl231.Name = "lbl231";
            this.lbl231.Size = new System.Drawing.Size(45, 45);
            this.lbl231.TabIndex = 679;
            this.lbl231.Text = "?";
            this.lbl231.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl231.Click += new System.EventHandler(this.lbl231_Click);
            this.lbl231.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl231.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl232
            // 
            this.lbl232.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl232.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl232.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl232.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl232.Location = new System.Drawing.Point(945, 359);
            this.lbl232.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl232.Name = "lbl232";
            this.lbl232.Size = new System.Drawing.Size(45, 45);
            this.lbl232.TabIndex = 680;
            this.lbl232.Text = "?";
            this.lbl232.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl232.Click += new System.EventHandler(this.lbl232_Click);
            this.lbl232.MouseEnter += new System.EventHandler(this.lbl232_MouseEnter);
            // 
            // lbl233
            // 
            this.lbl233.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl233.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl233.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl233.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl233.Location = new System.Drawing.Point(989, 359);
            this.lbl233.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl233.Name = "lbl233";
            this.lbl233.Size = new System.Drawing.Size(45, 45);
            this.lbl233.TabIndex = 681;
            this.lbl233.Text = "?";
            this.lbl233.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl233.Click += new System.EventHandler(this.lbl233_Click);
            this.lbl233.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl233.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl234
            // 
            this.lbl234.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl234.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl234.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl234.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl234.Location = new System.Drawing.Point(1033, 359);
            this.lbl234.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl234.Name = "lbl234";
            this.lbl234.Size = new System.Drawing.Size(45, 45);
            this.lbl234.TabIndex = 682;
            this.lbl234.Text = "?";
            this.lbl234.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl234.Click += new System.EventHandler(this.lbl234_Click);
            this.lbl234.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl234.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl235
            // 
            this.lbl235.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl235.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl235.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl235.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl235.Location = new System.Drawing.Point(1077, 359);
            this.lbl235.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl235.Name = "lbl235";
            this.lbl235.Size = new System.Drawing.Size(45, 45);
            this.lbl235.TabIndex = 683;
            this.lbl235.Text = "?";
            this.lbl235.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl235.Click += new System.EventHandler(this.lbl235_Click);
            this.lbl235.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl235.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl236
            // 
            this.lbl236.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl236.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl236.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl236.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl236.Location = new System.Drawing.Point(1121, 359);
            this.lbl236.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl236.Name = "lbl236";
            this.lbl236.Size = new System.Drawing.Size(45, 45);
            this.lbl236.TabIndex = 684;
            this.lbl236.Text = "?";
            this.lbl236.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl236.Click += new System.EventHandler(this.lbl236_Click);
            this.lbl236.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl236.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl237
            // 
            this.lbl237.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl237.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl237.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl237.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl237.Location = new System.Drawing.Point(1165, 359);
            this.lbl237.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl237.Name = "lbl237";
            this.lbl237.Size = new System.Drawing.Size(45, 45);
            this.lbl237.TabIndex = 685;
            this.lbl237.Text = "?";
            this.lbl237.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl237.Click += new System.EventHandler(this.lbl237_Click);
            this.lbl237.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl237.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl238
            // 
            this.lbl238.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl238.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl238.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl238.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl238.Location = new System.Drawing.Point(1209, 359);
            this.lbl238.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl238.Name = "lbl238";
            this.lbl238.Size = new System.Drawing.Size(45, 45);
            this.lbl238.TabIndex = 686;
            this.lbl238.Text = "?";
            this.lbl238.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl238.Click += new System.EventHandler(this.lbl238_Click);
            this.lbl238.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl238.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl213
            // 
            this.lbl213.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl213.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl213.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl213.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl213.Location = new System.Drawing.Point(110, 359);
            this.lbl213.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl213.Name = "lbl213";
            this.lbl213.Size = new System.Drawing.Size(45, 45);
            this.lbl213.TabIndex = 687;
            this.lbl213.Text = "?";
            this.lbl213.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl213.Click += new System.EventHandler(this.lbl213_Click);
            this.lbl213.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl213.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl214
            // 
            this.lbl214.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl214.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl214.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl214.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl214.Location = new System.Drawing.Point(154, 359);
            this.lbl214.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl214.Name = "lbl214";
            this.lbl214.Size = new System.Drawing.Size(45, 45);
            this.lbl214.TabIndex = 688;
            this.lbl214.Text = "?";
            this.lbl214.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl214.Click += new System.EventHandler(this.lbl214_Click);
            this.lbl214.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl214.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl215
            // 
            this.lbl215.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl215.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl215.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl215.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl215.Location = new System.Drawing.Point(198, 359);
            this.lbl215.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl215.Name = "lbl215";
            this.lbl215.Size = new System.Drawing.Size(45, 45);
            this.lbl215.TabIndex = 689;
            this.lbl215.Text = "?";
            this.lbl215.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl215.Click += new System.EventHandler(this.lbl215_Click);
            this.lbl215.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl215.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl216
            // 
            this.lbl216.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl216.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl216.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl216.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl216.Location = new System.Drawing.Point(242, 359);
            this.lbl216.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl216.Name = "lbl216";
            this.lbl216.Size = new System.Drawing.Size(45, 45);
            this.lbl216.TabIndex = 690;
            this.lbl216.Text = "?";
            this.lbl216.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl216.Click += new System.EventHandler(this.lbl216_Click);
            this.lbl216.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl216.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl217
            // 
            this.lbl217.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl217.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl217.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl217.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl217.Location = new System.Drawing.Point(285, 359);
            this.lbl217.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl217.Name = "lbl217";
            this.lbl217.Size = new System.Drawing.Size(45, 45);
            this.lbl217.TabIndex = 691;
            this.lbl217.Text = "?";
            this.lbl217.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl217.Click += new System.EventHandler(this.lbl217_Click);
            this.lbl217.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl217.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl218
            // 
            this.lbl218.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl218.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl218.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl218.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl218.Location = new System.Drawing.Point(329, 359);
            this.lbl218.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl218.Name = "lbl218";
            this.lbl218.Size = new System.Drawing.Size(45, 45);
            this.lbl218.TabIndex = 692;
            this.lbl218.Text = "?";
            this.lbl218.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl218.Click += new System.EventHandler(this.lbl218_Click);
            this.lbl218.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl218.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl219
            // 
            this.lbl219.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl219.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl219.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl219.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl219.Location = new System.Drawing.Point(373, 359);
            this.lbl219.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl219.Name = "lbl219";
            this.lbl219.Size = new System.Drawing.Size(45, 45);
            this.lbl219.TabIndex = 693;
            this.lbl219.Text = "?";
            this.lbl219.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl219.Click += new System.EventHandler(this.lbl219_Click);
            this.lbl219.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl219.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl220
            // 
            this.lbl220.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl220.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl220.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl220.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl220.Location = new System.Drawing.Point(417, 359);
            this.lbl220.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl220.Name = "lbl220";
            this.lbl220.Size = new System.Drawing.Size(45, 45);
            this.lbl220.TabIndex = 694;
            this.lbl220.Text = "?";
            this.lbl220.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl220.Click += new System.EventHandler(this.lbl220_Click);
            this.lbl220.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl220.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl221
            // 
            this.lbl221.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl221.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl221.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl221.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl221.Location = new System.Drawing.Point(461, 359);
            this.lbl221.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl221.Name = "lbl221";
            this.lbl221.Size = new System.Drawing.Size(45, 45);
            this.lbl221.TabIndex = 695;
            this.lbl221.Text = "?";
            this.lbl221.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl221.Click += new System.EventHandler(this.lbl221_Click);
            this.lbl221.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl221.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl222
            // 
            this.lbl222.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl222.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl222.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl222.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl222.Location = new System.Drawing.Point(505, 359);
            this.lbl222.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl222.Name = "lbl222";
            this.lbl222.Size = new System.Drawing.Size(45, 45);
            this.lbl222.TabIndex = 696;
            this.lbl222.Text = "?";
            this.lbl222.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl222.Click += new System.EventHandler(this.lbl222_Click);
            this.lbl222.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl222.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl223
            // 
            this.lbl223.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl223.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl223.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl223.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl223.Location = new System.Drawing.Point(549, 359);
            this.lbl223.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl223.Name = "lbl223";
            this.lbl223.Size = new System.Drawing.Size(45, 45);
            this.lbl223.TabIndex = 697;
            this.lbl223.Text = "?";
            this.lbl223.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl223.Click += new System.EventHandler(this.lbl223_Click);
            this.lbl223.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl223.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl224
            // 
            this.lbl224.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl224.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl224.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl224.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl224.Location = new System.Drawing.Point(593, 359);
            this.lbl224.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl224.Name = "lbl224";
            this.lbl224.Size = new System.Drawing.Size(45, 45);
            this.lbl224.TabIndex = 698;
            this.lbl224.Text = "?";
            this.lbl224.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl224.Click += new System.EventHandler(this.lbl224_Click);
            this.lbl224.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl224.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl225
            // 
            this.lbl225.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl225.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl225.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl225.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl225.Location = new System.Drawing.Point(637, 359);
            this.lbl225.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl225.Name = "lbl225";
            this.lbl225.Size = new System.Drawing.Size(45, 45);
            this.lbl225.TabIndex = 699;
            this.lbl225.Text = "?";
            this.lbl225.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl225.Click += new System.EventHandler(this.lbl225_Click);
            this.lbl225.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl225.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl211
            // 
            this.lbl211.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl211.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl211.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl211.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl211.Location = new System.Drawing.Point(23, 359);
            this.lbl211.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl211.Name = "lbl211";
            this.lbl211.Size = new System.Drawing.Size(45, 45);
            this.lbl211.TabIndex = 700;
            this.lbl211.Text = "?";
            this.lbl211.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl211.Click += new System.EventHandler(this.lbl211_Click);
            this.lbl211.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl211.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl212
            // 
            this.lbl212.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl212.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl212.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl212.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl212.Location = new System.Drawing.Point(66, 359);
            this.lbl212.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl212.Name = "lbl212";
            this.lbl212.Size = new System.Drawing.Size(45, 45);
            this.lbl212.TabIndex = 701;
            this.lbl212.Text = "?";
            this.lbl212.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl212.Click += new System.EventHandler(this.lbl212_Click);
            this.lbl212.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl212.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl256
            // 
            this.lbl256.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl256.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl256.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl256.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl256.Location = new System.Drawing.Point(681, 403);
            this.lbl256.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl256.Name = "lbl256";
            this.lbl256.Size = new System.Drawing.Size(45, 45);
            this.lbl256.TabIndex = 702;
            this.lbl256.Text = "?";
            this.lbl256.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl256.Click += new System.EventHandler(this.lbl256_Click);
            this.lbl256.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl256.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl257
            // 
            this.lbl257.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl257.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl257.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl257.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl257.Location = new System.Drawing.Point(725, 403);
            this.lbl257.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl257.Name = "lbl257";
            this.lbl257.Size = new System.Drawing.Size(45, 45);
            this.lbl257.TabIndex = 703;
            this.lbl257.Text = "?";
            this.lbl257.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl257.Click += new System.EventHandler(this.lbl257_Click);
            this.lbl257.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl257.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl258
            // 
            this.lbl258.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl258.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl258.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl258.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl258.Location = new System.Drawing.Point(769, 403);
            this.lbl258.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl258.Name = "lbl258";
            this.lbl258.Size = new System.Drawing.Size(45, 45);
            this.lbl258.TabIndex = 704;
            this.lbl258.Text = "?";
            this.lbl258.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl258.Click += new System.EventHandler(this.lbl258_Click);
            this.lbl258.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl258.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl259
            // 
            this.lbl259.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl259.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl259.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl259.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl259.Location = new System.Drawing.Point(813, 403);
            this.lbl259.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl259.Name = "lbl259";
            this.lbl259.Size = new System.Drawing.Size(45, 45);
            this.lbl259.TabIndex = 705;
            this.lbl259.Text = "?";
            this.lbl259.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl259.Click += new System.EventHandler(this.lbl259_Click);
            this.lbl259.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl259.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl260
            // 
            this.lbl260.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl260.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl260.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl260.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl260.Location = new System.Drawing.Point(857, 403);
            this.lbl260.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl260.Name = "lbl260";
            this.lbl260.Size = new System.Drawing.Size(45, 45);
            this.lbl260.TabIndex = 706;
            this.lbl260.Text = "?";
            this.lbl260.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl260.Click += new System.EventHandler(this.lbl260_Click);
            this.lbl260.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl260.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl261
            // 
            this.lbl261.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl261.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl261.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl261.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl261.Location = new System.Drawing.Point(901, 403);
            this.lbl261.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl261.Name = "lbl261";
            this.lbl261.Size = new System.Drawing.Size(45, 45);
            this.lbl261.TabIndex = 707;
            this.lbl261.Text = "?";
            this.lbl261.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl261.Click += new System.EventHandler(this.lbl261_Click);
            this.lbl261.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl261.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl262
            // 
            this.lbl262.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl262.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl262.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl262.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl262.Location = new System.Drawing.Point(945, 403);
            this.lbl262.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl262.Name = "lbl262";
            this.lbl262.Size = new System.Drawing.Size(45, 45);
            this.lbl262.TabIndex = 708;
            this.lbl262.Text = "?";
            this.lbl262.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl262.Click += new System.EventHandler(this.lbl262_Click);
            this.lbl262.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl262.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl263
            // 
            this.lbl263.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl263.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl263.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl263.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl263.Location = new System.Drawing.Point(989, 403);
            this.lbl263.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl263.Name = "lbl263";
            this.lbl263.Size = new System.Drawing.Size(45, 45);
            this.lbl263.TabIndex = 709;
            this.lbl263.Text = "?";
            this.lbl263.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl263.Click += new System.EventHandler(this.lbl263_Click);
            this.lbl263.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl263.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl264
            // 
            this.lbl264.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl264.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl264.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl264.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl264.Location = new System.Drawing.Point(1033, 403);
            this.lbl264.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl264.Name = "lbl264";
            this.lbl264.Size = new System.Drawing.Size(45, 45);
            this.lbl264.TabIndex = 710;
            this.lbl264.Text = "?";
            this.lbl264.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl264.Click += new System.EventHandler(this.lbl264_Click);
            this.lbl264.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl264.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl265
            // 
            this.lbl265.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl265.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl265.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl265.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl265.Location = new System.Drawing.Point(1077, 403);
            this.lbl265.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl265.Name = "lbl265";
            this.lbl265.Size = new System.Drawing.Size(45, 45);
            this.lbl265.TabIndex = 711;
            this.lbl265.Text = "?";
            this.lbl265.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl265.Click += new System.EventHandler(this.lbl265_Click);
            this.lbl265.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl265.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl266
            // 
            this.lbl266.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl266.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl266.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl266.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl266.Location = new System.Drawing.Point(1121, 403);
            this.lbl266.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl266.Name = "lbl266";
            this.lbl266.Size = new System.Drawing.Size(45, 45);
            this.lbl266.TabIndex = 712;
            this.lbl266.Text = "?";
            this.lbl266.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl266.Click += new System.EventHandler(this.lbl266_Click);
            this.lbl266.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl266.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl267
            // 
            this.lbl267.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl267.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl267.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl267.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl267.Location = new System.Drawing.Point(1165, 403);
            this.lbl267.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl267.Name = "lbl267";
            this.lbl267.Size = new System.Drawing.Size(45, 45);
            this.lbl267.TabIndex = 713;
            this.lbl267.Text = "?";
            this.lbl267.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl267.Click += new System.EventHandler(this.lbl267_Click);
            this.lbl267.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl267.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl268
            // 
            this.lbl268.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl268.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl268.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl268.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl268.Location = new System.Drawing.Point(1209, 403);
            this.lbl268.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl268.Name = "lbl268";
            this.lbl268.Size = new System.Drawing.Size(45, 45);
            this.lbl268.TabIndex = 714;
            this.lbl268.Text = "?";
            this.lbl268.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl268.Click += new System.EventHandler(this.lbl268_Click);
            this.lbl268.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl268.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl243
            // 
            this.lbl243.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl243.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl243.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl243.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl243.Location = new System.Drawing.Point(110, 403);
            this.lbl243.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl243.Name = "lbl243";
            this.lbl243.Size = new System.Drawing.Size(45, 45);
            this.lbl243.TabIndex = 715;
            this.lbl243.Text = "?";
            this.lbl243.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl243.Click += new System.EventHandler(this.lbl243_Click);
            this.lbl243.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl243.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl244
            // 
            this.lbl244.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl244.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl244.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl244.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl244.Location = new System.Drawing.Point(154, 403);
            this.lbl244.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl244.Name = "lbl244";
            this.lbl244.Size = new System.Drawing.Size(45, 45);
            this.lbl244.TabIndex = 716;
            this.lbl244.Text = "?";
            this.lbl244.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl244.Click += new System.EventHandler(this.lbl244_Click);
            this.lbl244.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl244.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl245
            // 
            this.lbl245.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl245.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl245.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl245.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl245.Location = new System.Drawing.Point(198, 403);
            this.lbl245.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl245.Name = "lbl245";
            this.lbl245.Size = new System.Drawing.Size(45, 45);
            this.lbl245.TabIndex = 717;
            this.lbl245.Text = "?";
            this.lbl245.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl245.Click += new System.EventHandler(this.lbl245_Click);
            this.lbl245.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl245.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl246
            // 
            this.lbl246.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl246.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl246.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl246.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl246.Location = new System.Drawing.Point(242, 403);
            this.lbl246.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl246.Name = "lbl246";
            this.lbl246.Size = new System.Drawing.Size(45, 45);
            this.lbl246.TabIndex = 718;
            this.lbl246.Text = "?";
            this.lbl246.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl246.Click += new System.EventHandler(this.lbl246_Click);
            this.lbl246.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl246.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl247
            // 
            this.lbl247.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl247.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl247.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl247.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl247.Location = new System.Drawing.Point(285, 403);
            this.lbl247.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl247.Name = "lbl247";
            this.lbl247.Size = new System.Drawing.Size(45, 45);
            this.lbl247.TabIndex = 719;
            this.lbl247.Text = "?";
            this.lbl247.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl247.Click += new System.EventHandler(this.lbl247_Click);
            this.lbl247.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl247.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl248
            // 
            this.lbl248.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl248.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl248.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl248.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl248.Location = new System.Drawing.Point(329, 403);
            this.lbl248.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl248.Name = "lbl248";
            this.lbl248.Size = new System.Drawing.Size(45, 45);
            this.lbl248.TabIndex = 720;
            this.lbl248.Text = "?";
            this.lbl248.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl248.Click += new System.EventHandler(this.lbl248_Click);
            this.lbl248.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl248.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl249
            // 
            this.lbl249.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl249.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl249.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl249.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl249.Location = new System.Drawing.Point(373, 403);
            this.lbl249.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl249.Name = "lbl249";
            this.lbl249.Size = new System.Drawing.Size(45, 45);
            this.lbl249.TabIndex = 721;
            this.lbl249.Text = "?";
            this.lbl249.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl249.Click += new System.EventHandler(this.lbl249_Click);
            this.lbl249.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl249.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl250
            // 
            this.lbl250.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl250.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl250.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl250.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl250.Location = new System.Drawing.Point(417, 403);
            this.lbl250.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl250.Name = "lbl250";
            this.lbl250.Size = new System.Drawing.Size(45, 45);
            this.lbl250.TabIndex = 722;
            this.lbl250.Text = "?";
            this.lbl250.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl250.Click += new System.EventHandler(this.lbl250_Click);
            this.lbl250.MouseEnter += new System.EventHandler(this.lbl250_MouseEnter);
            // 
            // lbl251
            // 
            this.lbl251.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl251.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl251.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl251.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl251.Location = new System.Drawing.Point(461, 403);
            this.lbl251.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl251.Name = "lbl251";
            this.lbl251.Size = new System.Drawing.Size(45, 45);
            this.lbl251.TabIndex = 723;
            this.lbl251.Text = "?";
            this.lbl251.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl251.Click += new System.EventHandler(this.lbl251_Click);
            this.lbl251.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl251.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl252
            // 
            this.lbl252.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl252.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl252.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl252.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl252.Location = new System.Drawing.Point(505, 403);
            this.lbl252.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl252.Name = "lbl252";
            this.lbl252.Size = new System.Drawing.Size(45, 45);
            this.lbl252.TabIndex = 724;
            this.lbl252.Text = "?";
            this.lbl252.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl252.Click += new System.EventHandler(this.lbl252_Click);
            this.lbl252.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl252.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl253
            // 
            this.lbl253.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl253.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl253.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl253.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl253.Location = new System.Drawing.Point(549, 403);
            this.lbl253.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl253.Name = "lbl253";
            this.lbl253.Size = new System.Drawing.Size(45, 45);
            this.lbl253.TabIndex = 725;
            this.lbl253.Text = "?";
            this.lbl253.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl253.Click += new System.EventHandler(this.lbl253_Click);
            this.lbl253.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl253.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl254
            // 
            this.lbl254.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl254.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl254.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl254.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl254.Location = new System.Drawing.Point(593, 403);
            this.lbl254.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl254.Name = "lbl254";
            this.lbl254.Size = new System.Drawing.Size(45, 45);
            this.lbl254.TabIndex = 726;
            this.lbl254.Text = "?";
            this.lbl254.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl254.Click += new System.EventHandler(this.lbl254_Click);
            this.lbl254.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl254.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl255
            // 
            this.lbl255.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl255.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl255.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl255.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl255.Location = new System.Drawing.Point(637, 403);
            this.lbl255.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl255.Name = "lbl255";
            this.lbl255.Size = new System.Drawing.Size(45, 45);
            this.lbl255.TabIndex = 727;
            this.lbl255.Text = "?";
            this.lbl255.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl255.Click += new System.EventHandler(this.lbl255_Click);
            this.lbl255.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl255.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl241
            // 
            this.lbl241.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl241.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl241.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl241.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl241.Location = new System.Drawing.Point(23, 403);
            this.lbl241.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl241.Name = "lbl241";
            this.lbl241.Size = new System.Drawing.Size(45, 45);
            this.lbl241.TabIndex = 728;
            this.lbl241.Text = "?";
            this.lbl241.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl241.Click += new System.EventHandler(this.lbl241_Click);
            this.lbl241.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl241.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl242
            // 
            this.lbl242.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl242.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl242.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl242.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl242.Location = new System.Drawing.Point(66, 403);
            this.lbl242.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl242.Name = "lbl242";
            this.lbl242.Size = new System.Drawing.Size(45, 45);
            this.lbl242.TabIndex = 729;
            this.lbl242.Text = "?";
            this.lbl242.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl242.Click += new System.EventHandler(this.lbl242_Click);
            this.lbl242.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl242.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl286
            // 
            this.lbl286.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl286.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl286.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl286.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl286.Location = new System.Drawing.Point(681, 447);
            this.lbl286.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl286.Name = "lbl286";
            this.lbl286.Size = new System.Drawing.Size(45, 45);
            this.lbl286.TabIndex = 730;
            this.lbl286.Text = "?";
            this.lbl286.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl286.Click += new System.EventHandler(this.lbl286_Click);
            this.lbl286.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl286.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl287
            // 
            this.lbl287.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl287.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl287.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl287.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl287.Location = new System.Drawing.Point(725, 447);
            this.lbl287.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl287.Name = "lbl287";
            this.lbl287.Size = new System.Drawing.Size(45, 45);
            this.lbl287.TabIndex = 731;
            this.lbl287.Text = "?";
            this.lbl287.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl287.Click += new System.EventHandler(this.lbl287_Click);
            this.lbl287.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl287.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl288
            // 
            this.lbl288.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl288.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl288.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl288.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl288.Location = new System.Drawing.Point(769, 447);
            this.lbl288.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl288.Name = "lbl288";
            this.lbl288.Size = new System.Drawing.Size(45, 45);
            this.lbl288.TabIndex = 732;
            this.lbl288.Text = "?";
            this.lbl288.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl288.Click += new System.EventHandler(this.lbl288_Click);
            this.lbl288.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl288.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl289
            // 
            this.lbl289.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl289.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl289.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl289.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl289.Location = new System.Drawing.Point(813, 447);
            this.lbl289.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl289.Name = "lbl289";
            this.lbl289.Size = new System.Drawing.Size(45, 45);
            this.lbl289.TabIndex = 733;
            this.lbl289.Text = "?";
            this.lbl289.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl289.Click += new System.EventHandler(this.lbl289_Click);
            this.lbl289.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl289.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl290
            // 
            this.lbl290.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl290.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl290.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl290.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl290.Location = new System.Drawing.Point(857, 447);
            this.lbl290.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl290.Name = "lbl290";
            this.lbl290.Size = new System.Drawing.Size(45, 45);
            this.lbl290.TabIndex = 734;
            this.lbl290.Text = "?";
            this.lbl290.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl290.Click += new System.EventHandler(this.lbl290_Click);
            this.lbl290.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl290.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl291
            // 
            this.lbl291.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl291.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl291.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl291.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl291.Location = new System.Drawing.Point(901, 447);
            this.lbl291.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl291.Name = "lbl291";
            this.lbl291.Size = new System.Drawing.Size(45, 45);
            this.lbl291.TabIndex = 735;
            this.lbl291.Text = "?";
            this.lbl291.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl291.Click += new System.EventHandler(this.lbl291_Click);
            this.lbl291.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl291.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl292
            // 
            this.lbl292.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl292.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl292.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl292.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl292.Location = new System.Drawing.Point(945, 447);
            this.lbl292.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl292.Name = "lbl292";
            this.lbl292.Size = new System.Drawing.Size(45, 45);
            this.lbl292.TabIndex = 736;
            this.lbl292.Text = "?";
            this.lbl292.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl292.Click += new System.EventHandler(this.lbl292_Click);
            this.lbl292.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl292.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl293
            // 
            this.lbl293.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl293.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl293.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl293.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl293.Location = new System.Drawing.Point(989, 447);
            this.lbl293.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl293.Name = "lbl293";
            this.lbl293.Size = new System.Drawing.Size(45, 45);
            this.lbl293.TabIndex = 737;
            this.lbl293.Text = "?";
            this.lbl293.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl293.Click += new System.EventHandler(this.lbl293_Click);
            this.lbl293.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl293.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl294
            // 
            this.lbl294.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl294.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl294.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl294.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl294.Location = new System.Drawing.Point(1033, 447);
            this.lbl294.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl294.Name = "lbl294";
            this.lbl294.Size = new System.Drawing.Size(45, 45);
            this.lbl294.TabIndex = 738;
            this.lbl294.Text = "?";
            this.lbl294.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl294.Click += new System.EventHandler(this.lbl294_Click);
            this.lbl294.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl294.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl295
            // 
            this.lbl295.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl295.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl295.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl295.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl295.Location = new System.Drawing.Point(1077, 447);
            this.lbl295.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl295.Name = "lbl295";
            this.lbl295.Size = new System.Drawing.Size(45, 45);
            this.lbl295.TabIndex = 739;
            this.lbl295.Text = "?";
            this.lbl295.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl295.Click += new System.EventHandler(this.lbl295_Click);
            this.lbl295.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl295.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl296
            // 
            this.lbl296.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl296.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl296.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl296.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl296.Location = new System.Drawing.Point(1121, 447);
            this.lbl296.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl296.Name = "lbl296";
            this.lbl296.Size = new System.Drawing.Size(45, 45);
            this.lbl296.TabIndex = 740;
            this.lbl296.Text = "?";
            this.lbl296.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl296.Click += new System.EventHandler(this.lbl296_Click);
            this.lbl296.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl296.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl297
            // 
            this.lbl297.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl297.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl297.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl297.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl297.Location = new System.Drawing.Point(1165, 447);
            this.lbl297.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl297.Name = "lbl297";
            this.lbl297.Size = new System.Drawing.Size(45, 45);
            this.lbl297.TabIndex = 741;
            this.lbl297.Text = "?";
            this.lbl297.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl297.Click += new System.EventHandler(this.lbl297_Click);
            this.lbl297.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl297.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl298
            // 
            this.lbl298.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl298.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl298.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl298.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl298.Location = new System.Drawing.Point(1209, 447);
            this.lbl298.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl298.Name = "lbl298";
            this.lbl298.Size = new System.Drawing.Size(45, 45);
            this.lbl298.TabIndex = 742;
            this.lbl298.Text = "?";
            this.lbl298.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl298.Click += new System.EventHandler(this.lbl298_Click);
            this.lbl298.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl298.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl273
            // 
            this.lbl273.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl273.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl273.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl273.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl273.Location = new System.Drawing.Point(110, 447);
            this.lbl273.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl273.Name = "lbl273";
            this.lbl273.Size = new System.Drawing.Size(45, 45);
            this.lbl273.TabIndex = 743;
            this.lbl273.Text = "?";
            this.lbl273.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl273.Click += new System.EventHandler(this.lbl273_Click);
            this.lbl273.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl273.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl274
            // 
            this.lbl274.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl274.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl274.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl274.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl274.Location = new System.Drawing.Point(154, 447);
            this.lbl274.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl274.Name = "lbl274";
            this.lbl274.Size = new System.Drawing.Size(45, 45);
            this.lbl274.TabIndex = 744;
            this.lbl274.Text = "?";
            this.lbl274.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl274.Click += new System.EventHandler(this.lbl274_Click);
            this.lbl274.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl274.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl275
            // 
            this.lbl275.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl275.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl275.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl275.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl275.Location = new System.Drawing.Point(198, 447);
            this.lbl275.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl275.Name = "lbl275";
            this.lbl275.Size = new System.Drawing.Size(45, 45);
            this.lbl275.TabIndex = 745;
            this.lbl275.Text = "?";
            this.lbl275.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl275.Click += new System.EventHandler(this.lbl275_Click);
            this.lbl275.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl275.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl276
            // 
            this.lbl276.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl276.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl276.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl276.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl276.Location = new System.Drawing.Point(242, 447);
            this.lbl276.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl276.Name = "lbl276";
            this.lbl276.Size = new System.Drawing.Size(45, 45);
            this.lbl276.TabIndex = 746;
            this.lbl276.Text = "?";
            this.lbl276.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl276.Click += new System.EventHandler(this.lbl276_Click);
            this.lbl276.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl276.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl277
            // 
            this.lbl277.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl277.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl277.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl277.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl277.Location = new System.Drawing.Point(285, 447);
            this.lbl277.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl277.Name = "lbl277";
            this.lbl277.Size = new System.Drawing.Size(45, 45);
            this.lbl277.TabIndex = 747;
            this.lbl277.Text = "?";
            this.lbl277.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl277.Click += new System.EventHandler(this.lbl277_Click);
            this.lbl277.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl277.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl278
            // 
            this.lbl278.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl278.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl278.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl278.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl278.Location = new System.Drawing.Point(329, 447);
            this.lbl278.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl278.Name = "lbl278";
            this.lbl278.Size = new System.Drawing.Size(45, 45);
            this.lbl278.TabIndex = 748;
            this.lbl278.Text = "?";
            this.lbl278.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl278.Click += new System.EventHandler(this.lbl278_Click);
            this.lbl278.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl278.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl279
            // 
            this.lbl279.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl279.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl279.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl279.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl279.Location = new System.Drawing.Point(373, 447);
            this.lbl279.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl279.Name = "lbl279";
            this.lbl279.Size = new System.Drawing.Size(45, 45);
            this.lbl279.TabIndex = 749;
            this.lbl279.Text = "?";
            this.lbl279.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl279.Click += new System.EventHandler(this.lbl279_Click);
            this.lbl279.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl279.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl280
            // 
            this.lbl280.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl280.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl280.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl280.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl280.Location = new System.Drawing.Point(417, 447);
            this.lbl280.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl280.Name = "lbl280";
            this.lbl280.Size = new System.Drawing.Size(45, 45);
            this.lbl280.TabIndex = 750;
            this.lbl280.Text = "?";
            this.lbl280.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl280.Click += new System.EventHandler(this.lbl280_Click);
            this.lbl280.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl280.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl281
            // 
            this.lbl281.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl281.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl281.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl281.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl281.Location = new System.Drawing.Point(461, 447);
            this.lbl281.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl281.Name = "lbl281";
            this.lbl281.Size = new System.Drawing.Size(45, 45);
            this.lbl281.TabIndex = 751;
            this.lbl281.Text = "?";
            this.lbl281.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl281.Click += new System.EventHandler(this.lbl281_Click);
            this.lbl281.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl281.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl282
            // 
            this.lbl282.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl282.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl282.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl282.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl282.Location = new System.Drawing.Point(505, 447);
            this.lbl282.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl282.Name = "lbl282";
            this.lbl282.Size = new System.Drawing.Size(45, 45);
            this.lbl282.TabIndex = 752;
            this.lbl282.Text = "?";
            this.lbl282.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl282.Click += new System.EventHandler(this.lbl282_Click);
            this.lbl282.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl282.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl283
            // 
            this.lbl283.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl283.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl283.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl283.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl283.Location = new System.Drawing.Point(549, 447);
            this.lbl283.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl283.Name = "lbl283";
            this.lbl283.Size = new System.Drawing.Size(45, 45);
            this.lbl283.TabIndex = 753;
            this.lbl283.Text = "?";
            this.lbl283.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl283.Click += new System.EventHandler(this.lbl283_Click);
            this.lbl283.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl283.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl284
            // 
            this.lbl284.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl284.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl284.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl284.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl284.Location = new System.Drawing.Point(593, 447);
            this.lbl284.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl284.Name = "lbl284";
            this.lbl284.Size = new System.Drawing.Size(45, 45);
            this.lbl284.TabIndex = 754;
            this.lbl284.Text = "?";
            this.lbl284.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl284.Click += new System.EventHandler(this.lbl284_Click);
            this.lbl284.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl284.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl285
            // 
            this.lbl285.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl285.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl285.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl285.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl285.Location = new System.Drawing.Point(637, 447);
            this.lbl285.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl285.Name = "lbl285";
            this.lbl285.Size = new System.Drawing.Size(45, 45);
            this.lbl285.TabIndex = 755;
            this.lbl285.Text = "?";
            this.lbl285.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl285.Click += new System.EventHandler(this.lbl285_Click);
            this.lbl285.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl285.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl271
            // 
            this.lbl271.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl271.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl271.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl271.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl271.Location = new System.Drawing.Point(23, 447);
            this.lbl271.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl271.Name = "lbl271";
            this.lbl271.Size = new System.Drawing.Size(45, 45);
            this.lbl271.TabIndex = 756;
            this.lbl271.Text = "?";
            this.lbl271.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl271.Click += new System.EventHandler(this.lbl271_Click);
            this.lbl271.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl271.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl272
            // 
            this.lbl272.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl272.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl272.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl272.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl272.Location = new System.Drawing.Point(66, 447);
            this.lbl272.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl272.Name = "lbl272";
            this.lbl272.Size = new System.Drawing.Size(45, 45);
            this.lbl272.TabIndex = 757;
            this.lbl272.Text = "?";
            this.lbl272.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl272.Click += new System.EventHandler(this.lbl272_Click);
            this.lbl272.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl272.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl179
            // 
            this.lbl179.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl179.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl179.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl179.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl179.Location = new System.Drawing.Point(1253, 271);
            this.lbl179.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl179.Name = "lbl179";
            this.lbl179.Size = new System.Drawing.Size(45, 45);
            this.lbl179.TabIndex = 758;
            this.lbl179.Text = "?";
            this.lbl179.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl179.Click += new System.EventHandler(this.lbl179_Click);
            this.lbl179.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl179.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl180
            // 
            this.lbl180.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl180.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl180.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl180.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl180.Location = new System.Drawing.Point(1297, 271);
            this.lbl180.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl180.Name = "lbl180";
            this.lbl180.Size = new System.Drawing.Size(45, 45);
            this.lbl180.TabIndex = 759;
            this.lbl180.Text = "?";
            this.lbl180.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl180.Click += new System.EventHandler(this.lbl180_Click);
            this.lbl180.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl180.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl209
            // 
            this.lbl209.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl209.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl209.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl209.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl209.Location = new System.Drawing.Point(1253, 315);
            this.lbl209.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl209.Name = "lbl209";
            this.lbl209.Size = new System.Drawing.Size(45, 45);
            this.lbl209.TabIndex = 760;
            this.lbl209.Text = "?";
            this.lbl209.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl209.Click += new System.EventHandler(this.lbl209_Click);
            this.lbl209.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl209.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl210
            // 
            this.lbl210.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl210.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl210.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl210.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl210.Location = new System.Drawing.Point(1297, 315);
            this.lbl210.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl210.Name = "lbl210";
            this.lbl210.Size = new System.Drawing.Size(45, 45);
            this.lbl210.TabIndex = 761;
            this.lbl210.Text = "?";
            this.lbl210.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl210.Click += new System.EventHandler(this.lbl210_Click);
            this.lbl210.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl210.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl239
            // 
            this.lbl239.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl239.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl239.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl239.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl239.Location = new System.Drawing.Point(1253, 359);
            this.lbl239.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl239.Name = "lbl239";
            this.lbl239.Size = new System.Drawing.Size(45, 45);
            this.lbl239.TabIndex = 762;
            this.lbl239.Text = "?";
            this.lbl239.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl239.Click += new System.EventHandler(this.lbl239_Click);
            this.lbl239.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl239.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl240
            // 
            this.lbl240.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl240.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl240.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl240.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl240.Location = new System.Drawing.Point(1297, 359);
            this.lbl240.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl240.Name = "lbl240";
            this.lbl240.Size = new System.Drawing.Size(45, 45);
            this.lbl240.TabIndex = 763;
            this.lbl240.Text = "?";
            this.lbl240.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl240.Click += new System.EventHandler(this.lbl240_Click);
            this.lbl240.MouseEnter += new System.EventHandler(this.lbl240_MouseEnter);
            // 
            // lbl269
            // 
            this.lbl269.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl269.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl269.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl269.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl269.Location = new System.Drawing.Point(1253, 403);
            this.lbl269.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl269.Name = "lbl269";
            this.lbl269.Size = new System.Drawing.Size(45, 45);
            this.lbl269.TabIndex = 764;
            this.lbl269.Text = "?";
            this.lbl269.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl269.Click += new System.EventHandler(this.lbl269_Click);
            this.lbl269.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl269.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl270
            // 
            this.lbl270.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl270.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl270.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl270.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl270.Location = new System.Drawing.Point(1297, 403);
            this.lbl270.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl270.Name = "lbl270";
            this.lbl270.Size = new System.Drawing.Size(45, 45);
            this.lbl270.TabIndex = 765;
            this.lbl270.Text = "?";
            this.lbl270.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl270.Click += new System.EventHandler(this.lbl270_Click);
            this.lbl270.MouseEnter += new System.EventHandler(this.usrMouseEnter);
            this.lbl270.MouseLeave += new System.EventHandler(this.usrMouseLeave);
            // 
            // lbl299
            // 
            this.lbl299.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl299.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl299.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl299.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl299.Location = new System.Drawing.Point(1253, 447);
            this.lbl299.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl299.Name = "lbl299";
            this.lbl299.Size = new System.Drawing.Size(45, 45);
            this.lbl299.TabIndex = 766;
            this.lbl299.Text = "?";
            this.lbl299.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl299.Click += new System.EventHandler(this.lbl299_Click);
            this.lbl299.MouseEnter += new System.EventHandler(this.lbl299_MouseEnter);
            // 
            // lbl300
            // 
            this.lbl300.BackColor = System.Drawing.Color.MediumAquamarine;
            this.lbl300.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl300.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl300.Font = new System.Drawing.Font("Courier New", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl300.Location = new System.Drawing.Point(1297, 447);
            this.lbl300.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lbl300.Name = "lbl300";
            this.lbl300.Size = new System.Drawing.Size(45, 45);
            this.lbl300.TabIndex = 767;
            this.lbl300.Text = "?";
            this.lbl300.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl300.Click += new System.EventHandler(this.lbl300_Click);
            this.lbl300.MouseEnter += new System.EventHandler(this.lbl300_MouseEnter);
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Green;
            this.ClientSize = new System.Drawing.Size(1354, 713);
            this.Controls.Add(this.clckstxtbx);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.scrtxtbx);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.nmetxtbx);
            this.Controls.Add(this.Nmelbl);
            this.Controls.Add(this.lbl300);
            this.Controls.Add(this.lbl299);
            this.Controls.Add(this.lbl270);
            this.Controls.Add(this.lbl269);
            this.Controls.Add(this.lbl240);
            this.Controls.Add(this.lbl239);
            this.Controls.Add(this.lbl210);
            this.Controls.Add(this.lbl209);
            this.Controls.Add(this.lbl180);
            this.Controls.Add(this.lbl179);
            this.Controls.Add(this.lbl272);
            this.Controls.Add(this.lbl271);
            this.Controls.Add(this.lbl285);
            this.Controls.Add(this.lbl284);
            this.Controls.Add(this.lbl283);
            this.Controls.Add(this.lbl282);
            this.Controls.Add(this.lbl281);
            this.Controls.Add(this.lbl280);
            this.Controls.Add(this.lbl279);
            this.Controls.Add(this.lbl278);
            this.Controls.Add(this.lbl277);
            this.Controls.Add(this.lbl276);
            this.Controls.Add(this.lbl275);
            this.Controls.Add(this.lbl274);
            this.Controls.Add(this.lbl273);
            this.Controls.Add(this.lbl298);
            this.Controls.Add(this.lbl297);
            this.Controls.Add(this.lbl296);
            this.Controls.Add(this.lbl295);
            this.Controls.Add(this.lbl294);
            this.Controls.Add(this.lbl293);
            this.Controls.Add(this.lbl292);
            this.Controls.Add(this.lbl291);
            this.Controls.Add(this.lbl290);
            this.Controls.Add(this.lbl289);
            this.Controls.Add(this.lbl288);
            this.Controls.Add(this.lbl287);
            this.Controls.Add(this.lbl286);
            this.Controls.Add(this.lbl242);
            this.Controls.Add(this.lbl241);
            this.Controls.Add(this.lbl255);
            this.Controls.Add(this.lbl254);
            this.Controls.Add(this.lbl253);
            this.Controls.Add(this.lbl252);
            this.Controls.Add(this.lbl251);
            this.Controls.Add(this.lbl250);
            this.Controls.Add(this.lbl249);
            this.Controls.Add(this.lbl248);
            this.Controls.Add(this.lbl247);
            this.Controls.Add(this.lbl246);
            this.Controls.Add(this.lbl245);
            this.Controls.Add(this.lbl244);
            this.Controls.Add(this.lbl243);
            this.Controls.Add(this.lbl268);
            this.Controls.Add(this.lbl267);
            this.Controls.Add(this.lbl266);
            this.Controls.Add(this.lbl265);
            this.Controls.Add(this.lbl264);
            this.Controls.Add(this.lbl263);
            this.Controls.Add(this.lbl262);
            this.Controls.Add(this.lbl261);
            this.Controls.Add(this.lbl260);
            this.Controls.Add(this.lbl259);
            this.Controls.Add(this.lbl258);
            this.Controls.Add(this.lbl257);
            this.Controls.Add(this.lbl256);
            this.Controls.Add(this.lbl212);
            this.Controls.Add(this.lbl211);
            this.Controls.Add(this.lbl225);
            this.Controls.Add(this.lbl224);
            this.Controls.Add(this.lbl223);
            this.Controls.Add(this.lbl222);
            this.Controls.Add(this.lbl221);
            this.Controls.Add(this.lbl220);
            this.Controls.Add(this.lbl219);
            this.Controls.Add(this.lbl218);
            this.Controls.Add(this.lbl217);
            this.Controls.Add(this.lbl216);
            this.Controls.Add(this.lbl215);
            this.Controls.Add(this.lbl214);
            this.Controls.Add(this.lbl213);
            this.Controls.Add(this.lbl238);
            this.Controls.Add(this.lbl237);
            this.Controls.Add(this.lbl236);
            this.Controls.Add(this.lbl235);
            this.Controls.Add(this.lbl234);
            this.Controls.Add(this.lbl233);
            this.Controls.Add(this.lbl232);
            this.Controls.Add(this.lbl231);
            this.Controls.Add(this.lbl230);
            this.Controls.Add(this.lbl229);
            this.Controls.Add(this.lbl228);
            this.Controls.Add(this.lbl227);
            this.Controls.Add(this.lbl226);
            this.Controls.Add(this.lbl182);
            this.Controls.Add(this.lbl181);
            this.Controls.Add(this.lbl195);
            this.Controls.Add(this.lbl194);
            this.Controls.Add(this.lbl193);
            this.Controls.Add(this.lbl192);
            this.Controls.Add(this.lbl191);
            this.Controls.Add(this.lbl190);
            this.Controls.Add(this.lbl189);
            this.Controls.Add(this.lbl188);
            this.Controls.Add(this.lbl187);
            this.Controls.Add(this.lbl186);
            this.Controls.Add(this.lbl185);
            this.Controls.Add(this.lbl184);
            this.Controls.Add(this.lbl183);
            this.Controls.Add(this.lbl208);
            this.Controls.Add(this.lbl207);
            this.Controls.Add(this.lbl206);
            this.Controls.Add(this.lbl205);
            this.Controls.Add(this.lbl204);
            this.Controls.Add(this.lbl203);
            this.Controls.Add(this.lbl202);
            this.Controls.Add(this.lbl201);
            this.Controls.Add(this.lbl200);
            this.Controls.Add(this.lbl199);
            this.Controls.Add(this.lbl198);
            this.Controls.Add(this.lbl197);
            this.Controls.Add(this.lbl196);
            this.Controls.Add(this.lbl152);
            this.Controls.Add(this.lbl151);
            this.Controls.Add(this.lbl165);
            this.Controls.Add(this.lbl164);
            this.Controls.Add(this.lbl163);
            this.Controls.Add(this.lbl162);
            this.Controls.Add(this.lbl161);
            this.Controls.Add(this.lbl160);
            this.Controls.Add(this.lbl159);
            this.Controls.Add(this.lbl158);
            this.Controls.Add(this.lbl157);
            this.Controls.Add(this.lbl156);
            this.Controls.Add(this.lbl155);
            this.Controls.Add(this.lbl154);
            this.Controls.Add(this.lbl153);
            this.Controls.Add(this.lbl178);
            this.Controls.Add(this.lbl177);
            this.Controls.Add(this.lbl176);
            this.Controls.Add(this.lbl175);
            this.Controls.Add(this.lbl174);
            this.Controls.Add(this.lbl173);
            this.Controls.Add(this.lbl172);
            this.Controls.Add(this.lbl171);
            this.Controls.Add(this.lbl170);
            this.Controls.Add(this.lbl169);
            this.Controls.Add(this.lbl168);
            this.Controls.Add(this.lbl167);
            this.Controls.Add(this.lbl166);
            this.Controls.Add(this.lbl150);
            this.Controls.Add(this.lbl149);
            this.Controls.Add(this.lbl120);
            this.Controls.Add(this.lbl119);
            this.Controls.Add(this.lbl90);
            this.Controls.Add(this.lbl89);
            this.Controls.Add(this.lbl60);
            this.Controls.Add(this.lbl59);
            this.Controls.Add(this.lbl30);
            this.Controls.Add(this.lbl29);
            this.Controls.Add(this.lbl122);
            this.Controls.Add(this.lbl121);
            this.Controls.Add(this.lbl135);
            this.Controls.Add(this.lbl134);
            this.Controls.Add(this.lbl133);
            this.Controls.Add(this.lbl132);
            this.Controls.Add(this.lbl131);
            this.Controls.Add(this.lbl130);
            this.Controls.Add(this.lbl129);
            this.Controls.Add(this.lbl128);
            this.Controls.Add(this.lbl127);
            this.Controls.Add(this.lbl126);
            this.Controls.Add(this.lbl125);
            this.Controls.Add(this.lbl124);
            this.Controls.Add(this.lbl123);
            this.Controls.Add(this.lbl148);
            this.Controls.Add(this.lbl147);
            this.Controls.Add(this.lbl146);
            this.Controls.Add(this.lbl145);
            this.Controls.Add(this.lbl144);
            this.Controls.Add(this.lbl143);
            this.Controls.Add(this.lbl142);
            this.Controls.Add(this.lbl141);
            this.Controls.Add(this.lbl140);
            this.Controls.Add(this.lbl139);
            this.Controls.Add(this.lbl138);
            this.Controls.Add(this.lbl137);
            this.Controls.Add(this.lbl136);
            this.Controls.Add(this.lbl92);
            this.Controls.Add(this.lbl91);
            this.Controls.Add(this.lbl105);
            this.Controls.Add(this.lbl104);
            this.Controls.Add(this.lbl103);
            this.Controls.Add(this.lbl102);
            this.Controls.Add(this.lbl101);
            this.Controls.Add(this.lbl100);
            this.Controls.Add(this.lbl99);
            this.Controls.Add(this.lbl98);
            this.Controls.Add(this.lbl97);
            this.Controls.Add(this.lbl96);
            this.Controls.Add(this.lbl95);
            this.Controls.Add(this.lbl94);
            this.Controls.Add(this.lbl93);
            this.Controls.Add(this.lbl118);
            this.Controls.Add(this.lbl117);
            this.Controls.Add(this.lbl116);
            this.Controls.Add(this.lbl115);
            this.Controls.Add(this.lbl114);
            this.Controls.Add(this.lbl113);
            this.Controls.Add(this.lbl112);
            this.Controls.Add(this.lbl111);
            this.Controls.Add(this.lbl110);
            this.Controls.Add(this.lbl109);
            this.Controls.Add(this.lbl108);
            this.Controls.Add(this.lbl107);
            this.Controls.Add(this.lbl106);
            this.Controls.Add(this.lbl62);
            this.Controls.Add(this.lbl61);
            this.Controls.Add(this.lbl75);
            this.Controls.Add(this.lbl74);
            this.Controls.Add(this.lbl73);
            this.Controls.Add(this.lbl72);
            this.Controls.Add(this.lbl71);
            this.Controls.Add(this.lbl70);
            this.Controls.Add(this.lbl69);
            this.Controls.Add(this.lbl68);
            this.Controls.Add(this.lbl67);
            this.Controls.Add(this.lbl66);
            this.Controls.Add(this.lbl65);
            this.Controls.Add(this.lbl64);
            this.Controls.Add(this.lbl63);
            this.Controls.Add(this.lbl88);
            this.Controls.Add(this.lbl87);
            this.Controls.Add(this.lbl86);
            this.Controls.Add(this.lbl85);
            this.Controls.Add(this.lbl84);
            this.Controls.Add(this.lbl83);
            this.Controls.Add(this.lbl82);
            this.Controls.Add(this.lbl81);
            this.Controls.Add(this.lbl80);
            this.Controls.Add(this.lbl79);
            this.Controls.Add(this.lbl78);
            this.Controls.Add(this.lbl77);
            this.Controls.Add(this.lbl76);
            this.Controls.Add(this.lbl32);
            this.Controls.Add(this.lbl31);
            this.Controls.Add(this.lbl45);
            this.Controls.Add(this.lbl44);
            this.Controls.Add(this.lbl43);
            this.Controls.Add(this.lbl42);
            this.Controls.Add(this.lbl41);
            this.Controls.Add(this.lbl40);
            this.Controls.Add(this.lbl39);
            this.Controls.Add(this.lbl38);
            this.Controls.Add(this.lbl37);
            this.Controls.Add(this.lbl36);
            this.Controls.Add(this.lbl35);
            this.Controls.Add(this.lbl34);
            this.Controls.Add(this.lbl33);
            this.Controls.Add(this.lbl58);
            this.Controls.Add(this.lbl57);
            this.Controls.Add(this.lbl56);
            this.Controls.Add(this.lbl55);
            this.Controls.Add(this.lbl54);
            this.Controls.Add(this.lbl53);
            this.Controls.Add(this.lbl52);
            this.Controls.Add(this.lbl51);
            this.Controls.Add(this.lbl50);
            this.Controls.Add(this.lbl49);
            this.Controls.Add(this.lbl48);
            this.Controls.Add(this.lbl47);
            this.Controls.Add(this.lbl46);
            this.Controls.Add(this.lbl2);
            this.Controls.Add(this.lbl1);
            this.Controls.Add(this.lbl15);
            this.Controls.Add(this.lbl14);
            this.Controls.Add(this.lbl13);
            this.Controls.Add(this.lbl12);
            this.Controls.Add(this.lbl11);
            this.Controls.Add(this.lbl10);
            this.Controls.Add(this.lbl9);
            this.Controls.Add(this.lbl8);
            this.Controls.Add(this.lbl7);
            this.Controls.Add(this.lbl6);
            this.Controls.Add(this.lbl5);
            this.Controls.Add(this.lbl4);
            this.Controls.Add(this.lbl3);
            this.Controls.Add(this.lbl28);
            this.Controls.Add(this.lbl27);
            this.Controls.Add(this.lbl26);
            this.Controls.Add(this.lbl25);
            this.Controls.Add(this.lbl24);
            this.Controls.Add(this.lbl23);
            this.Controls.Add(this.lbl22);
            this.Controls.Add(this.lbl21);
            this.Controls.Add(this.lbl20);
            this.Controls.Add(this.lbl19);
            this.Controls.Add(this.lbl18);
            this.Controls.Add(this.lbl17);
            this.Controls.Add(this.lbl16);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form2";
            this.Text = "NUMBER\'S GAME";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.Form2_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label Nmelbl;
        public System.Windows.Forms.TextBox nmetxtbx;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label scrtxtbx;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label clckstxtbx;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem newGameToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem helpToolStripMenuItem;
        private System.Windows.Forms.Label lbl16;
        private System.Windows.Forms.Label lbl17;
        private System.Windows.Forms.Label lbl18;
        private System.Windows.Forms.Label lbl19;
        private System.Windows.Forms.Label lbl20;
        private System.Windows.Forms.Label lbl21;
        private System.Windows.Forms.Label lbl22;
        private System.Windows.Forms.Label lbl23;
        private System.Windows.Forms.Label lbl24;
        private System.Windows.Forms.Label lbl25;
        private System.Windows.Forms.Label lbl26;
        private System.Windows.Forms.Label lbl27;
        private System.Windows.Forms.Label lbl28;
        private System.Windows.Forms.Label lbl3;
        private System.Windows.Forms.Label lbl4;
        private System.Windows.Forms.Label lbl5;
        private System.Windows.Forms.Label lbl6;
        private System.Windows.Forms.Label lbl7;
        private System.Windows.Forms.Label lbl8;
        private System.Windows.Forms.Label lbl9;
        private System.Windows.Forms.Label lbl10;
        private System.Windows.Forms.Label lbl11;
        private System.Windows.Forms.Label lbl12;
        private System.Windows.Forms.Label lbl13;
        private System.Windows.Forms.Label lbl14;
        private System.Windows.Forms.Label lbl15;
        private System.Windows.Forms.Label lbl1;
        private System.Windows.Forms.Label lbl2;
        private System.Windows.Forms.Label lbl46;
        private System.Windows.Forms.Label lbl47;
        private System.Windows.Forms.Label lbl48;
        private System.Windows.Forms.Label lbl49;
        private System.Windows.Forms.Label lbl50;
        private System.Windows.Forms.Label lbl51;
        private System.Windows.Forms.Label lbl52;
        private System.Windows.Forms.Label lbl53;
        private System.Windows.Forms.Label lbl54;
        private System.Windows.Forms.Label lbl55;
        private System.Windows.Forms.Label lbl56;
        private System.Windows.Forms.Label lbl57;
        private System.Windows.Forms.Label lbl58;
        private System.Windows.Forms.Label lbl33;
        private System.Windows.Forms.Label lbl34;
        private System.Windows.Forms.Label lbl35;
        private System.Windows.Forms.Label lbl36;
        private System.Windows.Forms.Label lbl37;
        private System.Windows.Forms.Label lbl38;
        private System.Windows.Forms.Label lbl39;
        private System.Windows.Forms.Label lbl40;
        private System.Windows.Forms.Label lbl41;
        private System.Windows.Forms.Label lbl42;
        private System.Windows.Forms.Label lbl43;
        private System.Windows.Forms.Label lbl44;
        private System.Windows.Forms.Label lbl45;
        private System.Windows.Forms.Label lbl31;
        private System.Windows.Forms.Label lbl32;
        private System.Windows.Forms.Label lbl76;
        private System.Windows.Forms.Label lbl77;
        private System.Windows.Forms.Label lbl78;
        private System.Windows.Forms.Label lbl79;
        private System.Windows.Forms.Label lbl80;
        private System.Windows.Forms.Label lbl81;
        private System.Windows.Forms.Label lbl82;
        private System.Windows.Forms.Label lbl83;
        private System.Windows.Forms.Label lbl84;
        private System.Windows.Forms.Label lbl85;
        private System.Windows.Forms.Label lbl86;
        private System.Windows.Forms.Label lbl87;
        private System.Windows.Forms.Label lbl88;
        private System.Windows.Forms.Label lbl63;
        private System.Windows.Forms.Label lbl64;
        private System.Windows.Forms.Label lbl65;
        private System.Windows.Forms.Label lbl66;
        private System.Windows.Forms.Label lbl67;
        private System.Windows.Forms.Label lbl68;
        private System.Windows.Forms.Label lbl69;
        private System.Windows.Forms.Label lbl70;
        private System.Windows.Forms.Label lbl71;
        private System.Windows.Forms.Label lbl72;
        private System.Windows.Forms.Label lbl73;
        private System.Windows.Forms.Label lbl74;
        private System.Windows.Forms.Label lbl75;
        private System.Windows.Forms.Label lbl61;
        private System.Windows.Forms.Label lbl62;
        private System.Windows.Forms.Label lbl106;
        private System.Windows.Forms.Label lbl107;
        private System.Windows.Forms.Label lbl108;
        private System.Windows.Forms.Label lbl109;
        private System.Windows.Forms.Label lbl110;
        private System.Windows.Forms.Label lbl111;
        private System.Windows.Forms.Label lbl112;
        private System.Windows.Forms.Label lbl113;
        private System.Windows.Forms.Label lbl114;
        private System.Windows.Forms.Label lbl115;
        private System.Windows.Forms.Label lbl116;
        private System.Windows.Forms.Label lbl117;
        private System.Windows.Forms.Label lbl118;
        private System.Windows.Forms.Label lbl93;
        private System.Windows.Forms.Label lbl94;
        private System.Windows.Forms.Label lbl95;
        private System.Windows.Forms.Label lbl96;
        private System.Windows.Forms.Label lbl97;
        private System.Windows.Forms.Label lbl98;
        private System.Windows.Forms.Label lbl99;
        private System.Windows.Forms.Label lbl100;
        private System.Windows.Forms.Label lbl101;
        private System.Windows.Forms.Label lbl102;
        private System.Windows.Forms.Label lbl103;
        private System.Windows.Forms.Label lbl104;
        private System.Windows.Forms.Label lbl105;
        private System.Windows.Forms.Label lbl91;
        private System.Windows.Forms.Label lbl92;
        private System.Windows.Forms.Label lbl136;
        private System.Windows.Forms.Label lbl137;
        private System.Windows.Forms.Label lbl138;
        private System.Windows.Forms.Label lbl139;
        private System.Windows.Forms.Label lbl140;
        private System.Windows.Forms.Label lbl141;
        private System.Windows.Forms.Label lbl142;
        private System.Windows.Forms.Label lbl143;
        private System.Windows.Forms.Label lbl144;
        private System.Windows.Forms.Label lbl145;
        private System.Windows.Forms.Label lbl146;
        private System.Windows.Forms.Label lbl147;
        private System.Windows.Forms.Label lbl148;
        private System.Windows.Forms.Label lbl123;
        private System.Windows.Forms.Label lbl124;
        private System.Windows.Forms.Label lbl125;
        private System.Windows.Forms.Label lbl126;
        private System.Windows.Forms.Label lbl127;
        private System.Windows.Forms.Label lbl128;
        private System.Windows.Forms.Label lbl129;
        private System.Windows.Forms.Label lbl130;
        private System.Windows.Forms.Label lbl131;
        private System.Windows.Forms.Label lbl132;
        private System.Windows.Forms.Label lbl133;
        private System.Windows.Forms.Label lbl134;
        private System.Windows.Forms.Label lbl135;
        private System.Windows.Forms.Label lbl121;
        private System.Windows.Forms.Label lbl29;
        private System.Windows.Forms.Label lbl122;
        private System.Windows.Forms.Label lbl30;
        private System.Windows.Forms.Label lbl59;
        private System.Windows.Forms.Label lbl60;
        private System.Windows.Forms.Label lbl89;
        private System.Windows.Forms.Label lbl90;
        private System.Windows.Forms.Label lbl119;
        private System.Windows.Forms.Label lbl120;
        private System.Windows.Forms.Label lbl149;
        private System.Windows.Forms.Label lbl150;
        private System.Windows.Forms.Label lbl166;
        private System.Windows.Forms.Label lbl167;
        private System.Windows.Forms.Label lbl168;
        private System.Windows.Forms.Label lbl169;
        private System.Windows.Forms.Label lbl170;
        private System.Windows.Forms.Label lbl171;
        private System.Windows.Forms.Label lbl172;
        private System.Windows.Forms.Label lbl173;
        private System.Windows.Forms.Label lbl174;
        private System.Windows.Forms.Label lbl175;
        private System.Windows.Forms.Label lbl176;
        private System.Windows.Forms.Label lbl177;
        private System.Windows.Forms.Label lbl178;
        private System.Windows.Forms.Label lbl153;
        private System.Windows.Forms.Label lbl154;
        private System.Windows.Forms.Label lbl155;
        private System.Windows.Forms.Label lbl156;
        private System.Windows.Forms.Label lbl157;
        private System.Windows.Forms.Label lbl158;
        private System.Windows.Forms.Label lbl159;
        private System.Windows.Forms.Label lbl160;
        private System.Windows.Forms.Label lbl161;
        private System.Windows.Forms.Label lbl162;
        private System.Windows.Forms.Label lbl163;
        private System.Windows.Forms.Label lbl164;
        private System.Windows.Forms.Label lbl165;
        private System.Windows.Forms.Label lbl151;
        private System.Windows.Forms.Label lbl152;
        private System.Windows.Forms.Label lbl196;
        private System.Windows.Forms.Label lbl197;
        private System.Windows.Forms.Label lbl198;
        private System.Windows.Forms.Label lbl199;
        private System.Windows.Forms.Label lbl200;
        private System.Windows.Forms.Label lbl201;
        private System.Windows.Forms.Label lbl202;
        private System.Windows.Forms.Label lbl203;
        private System.Windows.Forms.Label lbl204;
        private System.Windows.Forms.Label lbl205;
        private System.Windows.Forms.Label lbl206;
        private System.Windows.Forms.Label lbl207;
        private System.Windows.Forms.Label lbl208;
        private System.Windows.Forms.Label lbl183;
        private System.Windows.Forms.Label lbl184;
        private System.Windows.Forms.Label lbl185;
        private System.Windows.Forms.Label lbl186;
        private System.Windows.Forms.Label lbl187;
        private System.Windows.Forms.Label lbl188;
        private System.Windows.Forms.Label lbl189;
        private System.Windows.Forms.Label lbl190;
        private System.Windows.Forms.Label lbl191;
        private System.Windows.Forms.Label lbl192;
        private System.Windows.Forms.Label lbl193;
        private System.Windows.Forms.Label lbl194;
        private System.Windows.Forms.Label lbl195;
        private System.Windows.Forms.Label lbl181;
        private System.Windows.Forms.Label lbl182;
        private System.Windows.Forms.Label lbl226;
        private System.Windows.Forms.Label lbl227;
        private System.Windows.Forms.Label lbl228;
        private System.Windows.Forms.Label lbl229;
        private System.Windows.Forms.Label lbl230;
        private System.Windows.Forms.Label lbl231;
        private System.Windows.Forms.Label lbl232;
        private System.Windows.Forms.Label lbl233;
        private System.Windows.Forms.Label lbl234;
        private System.Windows.Forms.Label lbl235;
        private System.Windows.Forms.Label lbl236;
        private System.Windows.Forms.Label lbl237;
        private System.Windows.Forms.Label lbl238;
        private System.Windows.Forms.Label lbl213;
        private System.Windows.Forms.Label lbl214;
        private System.Windows.Forms.Label lbl215;
        private System.Windows.Forms.Label lbl216;
        private System.Windows.Forms.Label lbl217;
        private System.Windows.Forms.Label lbl218;
        private System.Windows.Forms.Label lbl219;
        private System.Windows.Forms.Label lbl220;
        private System.Windows.Forms.Label lbl221;
        private System.Windows.Forms.Label lbl222;
        private System.Windows.Forms.Label lbl223;
        private System.Windows.Forms.Label lbl224;
        private System.Windows.Forms.Label lbl225;
        private System.Windows.Forms.Label lbl211;
        private System.Windows.Forms.Label lbl212;
        private System.Windows.Forms.Label lbl256;
        private System.Windows.Forms.Label lbl257;
        private System.Windows.Forms.Label lbl258;
        private System.Windows.Forms.Label lbl259;
        private System.Windows.Forms.Label lbl260;
        private System.Windows.Forms.Label lbl261;
        private System.Windows.Forms.Label lbl262;
        private System.Windows.Forms.Label lbl263;
        private System.Windows.Forms.Label lbl264;
        private System.Windows.Forms.Label lbl265;
        private System.Windows.Forms.Label lbl266;
        private System.Windows.Forms.Label lbl267;
        private System.Windows.Forms.Label lbl268;
        private System.Windows.Forms.Label lbl243;
        private System.Windows.Forms.Label lbl244;
        private System.Windows.Forms.Label lbl245;
        private System.Windows.Forms.Label lbl246;
        private System.Windows.Forms.Label lbl247;
        private System.Windows.Forms.Label lbl248;
        private System.Windows.Forms.Label lbl249;
        private System.Windows.Forms.Label lbl250;
        private System.Windows.Forms.Label lbl251;
        private System.Windows.Forms.Label lbl252;
        private System.Windows.Forms.Label lbl253;
        private System.Windows.Forms.Label lbl254;
        private System.Windows.Forms.Label lbl255;
        private System.Windows.Forms.Label lbl241;
        private System.Windows.Forms.Label lbl242;
        private System.Windows.Forms.Label lbl286;
        private System.Windows.Forms.Label lbl287;
        private System.Windows.Forms.Label lbl288;
        private System.Windows.Forms.Label lbl289;
        private System.Windows.Forms.Label lbl290;
        private System.Windows.Forms.Label lbl291;
        private System.Windows.Forms.Label lbl292;
        private System.Windows.Forms.Label lbl293;
        private System.Windows.Forms.Label lbl294;
        private System.Windows.Forms.Label lbl295;
        private System.Windows.Forms.Label lbl296;
        private System.Windows.Forms.Label lbl297;
        private System.Windows.Forms.Label lbl298;
        private System.Windows.Forms.Label lbl273;
        private System.Windows.Forms.Label lbl274;
        private System.Windows.Forms.Label lbl275;
        private System.Windows.Forms.Label lbl276;
        private System.Windows.Forms.Label lbl277;
        private System.Windows.Forms.Label lbl278;
        private System.Windows.Forms.Label lbl279;
        private System.Windows.Forms.Label lbl280;
        private System.Windows.Forms.Label lbl281;
        private System.Windows.Forms.Label lbl282;
        private System.Windows.Forms.Label lbl283;
        private System.Windows.Forms.Label lbl284;
        private System.Windows.Forms.Label lbl285;
        private System.Windows.Forms.Label lbl271;
        private System.Windows.Forms.Label lbl272;
        private System.Windows.Forms.Label lbl179;
        private System.Windows.Forms.Label lbl180;
        private System.Windows.Forms.Label lbl209;
        private System.Windows.Forms.Label lbl210;
        private System.Windows.Forms.Label lbl239;
        private System.Windows.Forms.Label lbl240;
        private System.Windows.Forms.Label lbl269;
        private System.Windows.Forms.Label lbl270;
        private System.Windows.Forms.Label lbl299;
        private System.Windows.Forms.Label lbl300;
        private System.Windows.Forms.Timer timer1;
    }
}