﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Game1
{
    public partial class Form5 : Form
    {
        public Form5()
        {
            InitializeComponent();
        }
   
        Properties.Settings scr = new Properties.Settings();
        

        private void button2_Click(object sender, EventArgs e)
        {
            scr.Highscore = Convert.ToInt32(label7.Text);
            this.Close();
        }
       
       
    }
}
