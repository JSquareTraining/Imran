﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Reflection;


namespace Game1
{
    public partial class Form2 : Form
    {
        Timer timer = new Timer();
        
        public Form2()
        {
            InitializeComponent();
            timer.Tick += new EventHandler(timer1_Tick);
            timer.Interval = (10) * (1000);
            timer.Enabled = true;
            timer.Start();
        }

       
        int click = 0;
        Properties.Settings scr = new Properties.Settings();
        Form4 frm4 = new Form4();
        Form5 frm5 = new Form5();
        
        private void lbl1_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl1.Hide();
                scr.Score = scr.Score + 4;
               
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {

                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();

            }
        }

        private void lbl2_Click(object sender, EventArgs e)
        {
            
            if (click < 100)
            {
               
                
                lbl2.Hide();
                MessageBox.Show("Fire in the Hole -2 Points", "Ha Ha", MessageBoxButtons.OK, MessageBoxIcon.Error);
                scr.Score = scr.Score - 2;
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl3_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                if (lbl1.Visible == true)
                {
                    MessageBox.Show("I am locked find out my pair to unlock me", "Oh!!!!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    click = click + 1;
                    scr.Clicks = click;
                    clckstxtbx.Text = scr.Clicks.ToString();
                }
                else
                {
                    lbl3.Hide();
                    scr.Score = scr.Score + 3;
                    scrtxtbx.Text = scr.Score.ToString();
                   
                    click = click + 1;
                    scr.Clicks = click;
                    clckstxtbx.Text = scr.Clicks.ToString();
                }
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl4_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl4.Hide();
                scr.Score = scr.Score + 1;
               
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl5_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl5.Hide();
                scr.Score = scr.Score + 1;
               
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl6_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl6.Hide();
                MessageBox.Show("Fire in the Hole -3 Points", "Ha Ha", MessageBoxButtons.OK, MessageBoxIcon.Error);
                scr.Score = scr.Score - 3;
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl7_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl7.Hide();
                scr.Score = scr.Score + 11;
               
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl8_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl8.Hide();
                scr.Score = scr.Score + 4;
                
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl9_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                if (lbl220.Visible == true)
                {
                    MessageBox.Show("I am locked find out my pair to unlock me", "Oh!!!!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    click = click + 1;
                    scr.Clicks = click;
                    clckstxtbx.Text = scr.Clicks.ToString();
                }
                else
                {
                    lbl9.Hide();
                    MessageBox.Show("You got 100 Points", "Success", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    scr.Score = scr.Score + 100;
                    scrtxtbx.Text = scr.Score.ToString();
                    click = click + 1;
                    scr.Clicks = click;
                    clckstxtbx.Text = scr.Clicks.ToString();
                }
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl10_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl10.Hide();
                MessageBox.Show("Fire in the Hole -4 Points", "Ha Ha", MessageBoxButtons.OK, MessageBoxIcon.Error);
                scr.Score = scr.Score - 4;
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }

        }

        private void lbl11_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl11.Hide();
                scr.Score = scr.Score + 8;
               
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }

        }

        private void lbl12_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl12.Hide();
                scr.Score = scr.Score + 1;
               
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl13_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl13.Hide();
                MessageBox.Show("Fire in the Hole -1 Points", "Ha Ha", MessageBoxButtons.OK, MessageBoxIcon.Error);
                scr.Score = scr.Score - 1;
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl14_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl14.Hide();
                scr.Score = scr.Score + 4;
               
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl15_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl15.Hide();
                MessageBox.Show("Fire in the Hole -3 Points", "Ha Ha Ha Ha Ha", MessageBoxButtons.OK, MessageBoxIcon.Error);
                scr.Score = scr.Score - 3;
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl16_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl16.Hide();
                scr.Score = scr.Score + 7;
               
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl17_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl17.Hide();
                scr.Score = scr.Score + 1;
                
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl18_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl18.Hide();
                MessageBox.Show("Fire in the Hole -1 Points", "Ha Ha Ha Ha Ha", MessageBoxButtons.OK, MessageBoxIcon.Error);
                scr.Score = scr.Score - 1;
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl19_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl19.Hide();
                scr.Score = scr.Score + 3;
               
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl20_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl20.Hide();
                scr.Score = scr.Score + 9;
               
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl21_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl21.Hide();
                MessageBox.Show("Fire in the Hole -7 Points", "Ha Ha Ha Ha Ha", MessageBoxButtons.OK, MessageBoxIcon.Error);
                scr.Score = scr.Score - 7;
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl22_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl22.Hide();
                scr.Score = scr.Score + 5;
                
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl23_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl23.Hide();
                scr.Score = scr.Score + 1;
               
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl24_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl24.Hide();
                MessageBox.Show("Fire in the Hole -1 Points", "Ha Ha Ha Ha Ha", MessageBoxButtons.OK, MessageBoxIcon.Error);
                scr.Score = scr.Score - 1;
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl25_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl25.Hide();
                scr.Score = scr.Score + 9;
              
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl26_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl26.Hide();
                scr.Score = scr.Score + 11;
                
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl27_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl27.Hide();
                scr.Score = scr.Score + 20;
               
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl28_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl28.Hide();
                scr.Score = scr.Score + 1;
               
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl29_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl29.Hide();
                MessageBox.Show("Fire in the Hole -2 Points", "Ha Ha Ha Ha Ha", MessageBoxButtons.OK, MessageBoxIcon.Error);
                scr.Score = scr.Score - 2;
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl30_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl30.Hide();
                MessageBox.Show("Fire in the Hole -4 Points", "Ha Ha Ha Ha Ha", MessageBoxButtons.OK, MessageBoxIcon.Error);
                scr.Score = scr.Score - 4;
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl31_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl31.Hide();
                scr.Score = scr.Score + 10;
               
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl32_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl32.Hide();
                scr.Score = scr.Score + 1;
               
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl33_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl33.Hide();
                MessageBox.Show("Fire in the Hole -5 Points", "Ha Ha Ha Ha Ha", MessageBoxButtons.OK, MessageBoxIcon.Error);
                scr.Score = scr.Score - 5;
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl34_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl34.Hide();
                scr.Score = scr.Score + 3;
               
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }

        }

        private void lbl35_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl35.Hide();
                scr.Score = scr.Score + 2;
                
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl36_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl36.Hide();
                MessageBox.Show("Fire in the Hole -2 Points", "Ha Ha Ha Ha Ha", MessageBoxButtons.OK, MessageBoxIcon.Error);
                scr.Score = scr.Score - 2;
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl37_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl37.Hide();
                scr.Score = scr.Score + 1;
                
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl38_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl38.Hide();
                scr.Score = scr.Score + 4;
               
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl39_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl39.Hide();
                scr.Score = scr.Score + 8;
                
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl40_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl40.Hide();
                scr.Score = scr.Score + 1;
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl41_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl41.Hide();
                MessageBox.Show("Fire in the Hole -2 Points", "Ha Ha Ha Ha Ha", MessageBoxButtons.OK, MessageBoxIcon.Error);
                scr.Score = scr.Score - 2;
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl42_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                if (lbl45.Visible == true)
                {
                    MessageBox.Show("I am locked find out my pair to unlock me", "Oh!!!!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    click = click + 1;
                    scr.Clicks = click;
                    clckstxtbx.Text = scr.Clicks.ToString();
                }
                else
                {
                    lbl42.Hide();
                    scr.Score = scr.Score + 2;
                    MessageBox.Show("You got 2 points", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    scrtxtbx.Text = scr.Score.ToString();
                    click = click + 1;
                    scr.Clicks = click;
                    clckstxtbx.Text = scr.Clicks.ToString();
                }
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl43_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl43.Hide();
                MessageBox.Show("Fire in the Hole -1 Points", "Ha Ha Ha Ha Ha", MessageBoxButtons.OK, MessageBoxIcon.Error);
                scr.Score = scr.Score - 1;
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl44_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl44.Hide();
                scr.Score = scr.Score + 4;
               
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl45_Click(object sender, EventArgs e)
        {

            if (click < 100)
            {
                lbl45.Hide();
                scr.Score = scr.Score + 20;
               
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl46_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl46.Hide();
                MessageBox.Show("Fire in the Hole -20 Points", "Ha Ha Ha Ha Ha", MessageBoxButtons.OK, MessageBoxIcon.Error);
                scr.Score = scr.Score - 20;
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();

            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl47_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl47.Hide();
                scr.Score = scr.Score + 3;
                
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl48_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl48.Hide();
                scr.Score = scr.Score + 2;
                
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl49_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl49.Hide();
                scr.Score = scr.Score + 1;
               
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl50_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                if (lbl75.Visible == true)
                {
                    MessageBox.Show("I am locked find out my pair to unlock me", "Oh!!!!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    click = click + 1;
                    scr.Clicks = click;
                    clckstxtbx.Text = scr.Clicks.ToString();
                }
                else
                {
                    lbl50.Hide();
                    scr.Score = scr.Score + 7;
                    MessageBox.Show("You got 7 points", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    scrtxtbx.Text = scr.Score.ToString();
                    click = click + 1;
                    scr.Clicks = click;
                    clckstxtbx.Text = scr.Clicks.ToString();
                }
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl51_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl51.Hide();
                MessageBox.Show("Fire in the Hole -3 Points", "Ha Ha Ha Ha Ha", MessageBoxButtons.OK, MessageBoxIcon.Error);
                scr.Score = scr.Score - 3;
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl52_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl52.Hide();
                scr.Score = scr.Score + 4;
                
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl53_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl53.Hide();
                MessageBox.Show("Fire in the Hole -2 Points", "Ha Ha Ha Ha Ha", MessageBoxButtons.OK, MessageBoxIcon.Error);
                scr.Score = scr.Score - 2;
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl54_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl54.Hide();
                MessageBox.Show("Fire in the Hole -1 Points", "Ha Ha Ha Ha Ha", MessageBoxButtons.OK, MessageBoxIcon.Error);
                scr.Score = scr.Score - 1;
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl55_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl55.Hide();
                MessageBox.Show("Fire in the Hole -1 Points", "Ha Ha Ha Ha Ha", MessageBoxButtons.OK, MessageBoxIcon.Error);
                scr.Score = scr.Score - 1;
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl56_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl56.Hide();
                MessageBox.Show("Fire in the Hole -3 Points", "Ha Ha Ha Ha Ha", MessageBoxButtons.OK, MessageBoxIcon.Error);
                scr.Score = scr.Score - 3;
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl57_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl57.Hide();
                MessageBox.Show("Fire in the Hole -30 Points", "Ha Ha Ha Ha Ha", MessageBoxButtons.OK, MessageBoxIcon.Error);
                scr.Score = scr.Score - 30;
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl58_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl58.Hide();
                scr.Score = scr.Score + 10;
               
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl59_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl59.Hide();
                scr.Score = scr.Score + 1;
               
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl60_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl60.Hide();
                scr.Score = scr.Score + 5;
              
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl61_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl61.Hide();
                scr.Score = scr.Score + 1;
                
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl62_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl62.Hide();
                scr.Score = scr.Score + 8;
               
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl63_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {

                lbl63.Hide();
                scr.Score = scr.Score + 4;
               
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl64_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl64.Hide();
                scr.Score = scr.Score + 1;
              
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl65_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl65.Hide();
                MessageBox.Show("Fire in the Hole -2 Points", "Ha Ha Ha Ha Ha", MessageBoxButtons.OK, MessageBoxIcon.Error);
                scr.Score = scr.Score - 2;
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl66_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl66.Hide();
                scr.Score = scr.Score + 2;
               
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl67_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl67.Hide();
                scr.Score = scr.Score + 3;
               
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl68_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl68.Hide();
                MessageBox.Show("Fire in the Hole -5 Points", "Ha Ha Ha Ha Ha", MessageBoxButtons.OK, MessageBoxIcon.Error);
                scr.Score = scr.Score - 5;
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl69_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl69.Hide();
                scr.Score = scr.Score + 1;
                
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl70_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl70.Hide();
                scr.Score = scr.Score + 10;
               
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl71_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {

                lbl71.Hide();
                MessageBox.Show("Fire in the Hole -4 Points", "Ha Ha Ha Ha Ha", MessageBoxButtons.OK, MessageBoxIcon.Error);
                scr.Score = scr.Score - 4;
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl72_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl72.Hide();
                MessageBox.Show("Fire in the Hole -2 Points", "Ha Ha Ha Ha Ha", MessageBoxButtons.OK, MessageBoxIcon.Error);
                scr.Score = scr.Score - 2;
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                } 
                scr.Save();
                this.Close();
            }
        }

        private void lbl73_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl73.Hide();
                scr.Score = scr.Score + 1;
               
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl74_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl74.Hide();
                scr.Score = scr.Score + 20;
                
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl75_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl75.Hide();
                scr.Score = scr.Score + 11;
                
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl76_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl76.Hide();
                scr.Score = scr.Score + 9;
                
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }

        }

        private void lbl77_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl77.Hide();
                MessageBox.Show("Fire in the Hole -1 Points", "Ha Ha Ha Ha Ha", MessageBoxButtons.OK, MessageBoxIcon.Error);
                scr.Score = scr.Score - 1;
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl78_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                if (lbl54.Visible == true)
                {
                    MessageBox.Show("I am locked find out my pair to unlock me", "Oh!!!!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    click = click + 1;
                    scr.Clicks = click;
                    clckstxtbx.Text = scr.Clicks.ToString();
                }
                else
                {
                    lbl78.Hide();
                    scr.Score = scr.Score + 1;
                    MessageBox.Show("You got 1 points", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    scrtxtbx.Text = scr.Score.ToString();
                    click = click + 1;
                    scr.Clicks = click;
                    clckstxtbx.Text = scr.Clicks.ToString();
                }
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl79_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl79.Hide();
                scr.Score = scr.Score + 5;
                
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl80_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl80.Hide();
                MessageBox.Show("Fire in the Hole -7 Points", "Ha Ha Ha Ha Ha", MessageBoxButtons.OK, MessageBoxIcon.Error);
                scr.Score = scr.Score - 7;
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl81_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl81.Hide();
                scr.Score = scr.Score + 9;
               
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl82_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl82.Hide();
                scr.Score = scr.Score + 3;
                
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl83_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl83.Hide();
                MessageBox.Show("Fire in the Hole -1 Points", "Ha Ha Ha Ha Ha", MessageBoxButtons.OK, MessageBoxIcon.Error);
                scr.Score = scr.Score - 1;
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl84_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl84.Hide();
                scr.Score = scr.Score + 1;
               
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl85_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl85.Hide();
                scr.Score = scr.Score + 7;
               
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl86_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl86.Hide();
                MessageBox.Show("Fire in the Hole -3 Points", "Ha Ha Ha Ha Ha", MessageBoxButtons.OK, MessageBoxIcon.Error);
                scr.Score = scr.Score - 3;
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl87_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl87.Hide();
                scr.Score = scr.Score + 4;
                
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl88_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl88.Hide();
                MessageBox.Show("Fire in the Hole -1 Points", "Ha Ha Ha Ha Ha", MessageBoxButtons.OK, MessageBoxIcon.Error);
                scr.Score = scr.Score - 1;
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl89_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl89.Hide();
                scr.Score = scr.Score + 1;
               
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl90_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl90.Hide();
                scr.Score = scr.Score + 8;
               
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl91_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl91.Hide();
                MessageBox.Show("Fire in the Hole -4 Points", "Ha Ha Ha Ha Ha", MessageBoxButtons.OK, MessageBoxIcon.Error);
                scr.Score = scr.Score - 4;
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl92_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl92.Hide();
                MessageBox.Show("Fire in the Hole -5 Points", "Ha Ha Ha Ha Ha", MessageBoxButtons.OK, MessageBoxIcon.Error);
                scr.Score = scr.Score - 5;
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl93_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl93.Hide();
                scr.Score = scr.Score + 4;
               
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl94_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl94.Hide();
                scr.Score = scr.Score + 11;
                
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl95_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl95.Hide();
                MessageBox.Show("Fire in the Hole -3 Points", "Ha Ha Ha Ha Ha", MessageBoxButtons.OK, MessageBoxIcon.Error);
                scr.Score = scr.Score - 3;
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl96_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl96.Hide();
                scr.Score = scr.Score + 1;
                
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl97_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl97.Hide();
                scr.Score = scr.Score + 1;
                
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl98_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl98.Hide();
                scr.Score = scr.Score + 3;
               
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl99_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl99.Hide();
                MessageBox.Show("Fire in the Hole -2 Points", "Ha Ha Ha Ha Ha", MessageBoxButtons.OK, MessageBoxIcon.Error);
                scr.Score = scr.Score - 2;
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl100_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl100.Hide();
                scr.Score = scr.Score + 4;
                
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl101_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl101.Hide();
                MessageBox.Show("Fire in the Hole -4 Points", "Ha Ha Ha Ha Ha", MessageBoxButtons.OK, MessageBoxIcon.Error);
                scr.Score = scr.Score - 4;
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl102_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl102.Hide();
                MessageBox.Show("Fire in the Hole -2 Points", "Ha Ha Ha Ha Ha", MessageBoxButtons.OK, MessageBoxIcon.Error);
                scr.Score = scr.Score - 2;
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl103_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl103.Hide();
                scr.Score = scr.Score + 1;
                
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl104_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl104.Hide();
                scr.Score = scr.Score + 20;
               
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl105_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl105.Hide();
                scr.Score = scr.Score + 11;
                
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl106_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl106.Hide();
                MessageBox.Show("Fire in the Hole -9 Points", "Ha Ha Ha Ha Ha", MessageBoxButtons.OK, MessageBoxIcon.Error);
                scr.Score = scr.Score - 9;
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl107_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl107.Hide();
                MessageBox.Show("Fire in the Hole -1 Points", "Ha Ha Ha Ha Ha", MessageBoxButtons.OK, MessageBoxIcon.Error);
                scr.Score = scr.Score - 1;
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl108_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl108.Hide();
                MessageBox.Show("Fire in the Hole -1 Points", "Ha Ha Ha Ha Ha", MessageBoxButtons.OK, MessageBoxIcon.Error);
                scr.Score = scr.Score - 1;
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl109_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl109.Hide();
                scr.Score = scr.Score + 5;
               
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl110_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl110.Hide();
                MessageBox.Show("Fire in the Hole -7 Points", "Ha Ha Ha Ha Ha", MessageBoxButtons.OK, MessageBoxIcon.Error);
                scr.Score = scr.Score - 7;
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl111_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl111.Hide();
                MessageBox.Show("Fire in the Hole -2 Points", "Ha Ha Ha Ha Ha", MessageBoxButtons.OK, MessageBoxIcon.Error);
                scr.Score = scr.Score - 2;
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl112_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl112.Hide();
                scr.Score = scr.Score + 2;
              
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl113_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl113.Hide();
                MessageBox.Show("Fire in the Hole -1 Points", "Ha Ha Ha Ha Ha", MessageBoxButtons.OK, MessageBoxIcon.Error);
                scr.Score = scr.Score - 1;
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl114_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl114.Hide();
                scr.Score = scr.Score + 4;
               
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl115_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl115.Hide();
                scr.Score = scr.Score + 20;
               
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl116_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl116.Hide();
                MessageBox.Show("Fire in the Hole -20 Points", "Ha Ha Ha Ha Ha", MessageBoxButtons.OK, MessageBoxIcon.Error);
                scr.Score = scr.Score - 20;
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl117_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl117.Hide();
                scr.Score = scr.Score + 3;
                
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl118_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                if (lbl7.Visible == true)
                {
                    MessageBox.Show("I am locked find out my pair to unlock me", "Oh!!!!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    click = click + 1;
                    scr.Clicks = click;
                    clckstxtbx.Text = scr.Clicks.ToString();
                }
                else
                {
                    lbl118.Hide();
                    scr.Score = scr.Score + 2;
                    MessageBox.Show("You got 2 points", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    scrtxtbx.Text = scr.Score.ToString();
                    click = click + 1;
                    scr.Clicks = click;
                    clckstxtbx.Text = scr.Clicks.ToString();
                }
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl119_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl119.Hide();
                scr.Score = scr.Score + 1;
                
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl120_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl120.Hide();
                scr.Score = scr.Score + 7;
                
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl121_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl121.Hide();
                scr.Score = scr.Score + 8;
                
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl122_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl122.Hide();
                scr.Score = scr.Score + 1;
                
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl123_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl123.Hide();
                MessageBox.Show("Fire in the Hole -1 Points", "Ha Ha Ha Ha Ha", MessageBoxButtons.OK, MessageBoxIcon.Error);
                scr.Score = scr.Score - 1;
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl124_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl124.Hide();
                scr.Score = scr.Score + 4;
               
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl125_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl125.Hide();
                MessageBox.Show("Fire in the Hole -3 Points", "Ha Ha Ha Ha Ha", MessageBoxButtons.OK, MessageBoxIcon.Error);
                scr.Score = scr.Score - 3;
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl126_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl126.Hide();
                scr.Score = scr.Score + 7;
                
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl127_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl127.Hide();
                scr.Score = scr.Score + 1;
                
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl128_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl128.Hide();
                MessageBox.Show("Fire in the Hole -1 Points", "Ha Ha Ha Ha Ha", MessageBoxButtons.OK, MessageBoxIcon.Error);
                scr.Score = scr.Score - 1;
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl129_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl129.Hide();
                scr.Score = scr.Score + 3;
               
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl130_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl130.Hide();
                scr.Score = scr.Score + 9;
                
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl131_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl131.Hide();
                scr.Score = scr.Score + 9;
                
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl132_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl132.Hide();
                scr.Score = scr.Score + 3;
                
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl133_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl133.Hide();
                MessageBox.Show("Fire in the Hole -1 Points", "Ha Ha Ha Ha Ha", MessageBoxButtons.OK, MessageBoxIcon.Error);
                scr.Score = scr.Score - 1;
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl134_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl134.Hide();
                scr.Score = scr.Score + 1;
                
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl135_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl135.Hide();
                scr.Score = scr.Score + 7;
               
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
                
            }
        }

        private void lbl136_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl136.Hide();
                MessageBox.Show("Fire in the Hole -3 Points", "Ha Ha Ha Ha Ha", MessageBoxButtons.OK, MessageBoxIcon.Error);
                scr.Score = scr.Score - 3;
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl137_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl137.Hide();
                scr.Score = scr.Score + 4;
                
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl138_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl138.Hide();
                MessageBox.Show("Fire in the Hole -1 Points", "Ha Ha Ha Ha Ha", MessageBoxButtons.OK, MessageBoxIcon.Error);
                scr.Score = scr.Score - 1;
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl139_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl139.Hide();
                scr.Score = scr.Score + 1;
                
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl140_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl140.Hide();
                scr.Score = scr.Score + 8;
                
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl141_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl141.Hide();
                scr.Score = scr.Score + 1;
               
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl142_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl142.Hide();
                scr.Score = scr.Score + 8;
                
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl143_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl143.Hide();
                scr.Score = scr.Score + 4;
               
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl144_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl144.Hide();
                scr.Score = scr.Score + 1;
               
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl145_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl145.Hide();
                MessageBox.Show("Fire in the Hole -2 Points", "Ha Ha Ha Ha Ha", MessageBoxButtons.OK, MessageBoxIcon.Error);
                scr.Score = scr.Score - 2;
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl146_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl146.Hide();
                scr.Score = scr.Score + 2;
                
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl147_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl147.Hide();
                scr.Score = scr.Score + 3;
                
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl148_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl148.Hide();
                MessageBox.Show("Fire in the Hole -5 Points", "Ha Ha Ha Ha Ha", MessageBoxButtons.OK, MessageBoxIcon.Error);
                scr.Score = scr.Score - 5;
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl149_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl149.Hide();
                scr.Score = scr.Score + 1;
               
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl150_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                if (lbl300.Visible == true)
                {
                    MessageBox.Show("I am locked find out my pair to unlock me", "Oh!!!!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    click = click + 1;
                    scr.Clicks = click;
                    clckstxtbx.Text = scr.Clicks.ToString();
                }
                else
                {
                    lbl150.Hide();
                    scr.Score = scr.Score + 10;
                    MessageBox.Show("You got 10 points", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    scrtxtbx.Text = scr.Score.ToString();
                    click = click + 1;
                    scr.Clicks = click;
                    clckstxtbx.Text = scr.Clicks.ToString();
                }
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl151_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl151.Hide();
                scr.Score = scr.Score + 10;
               
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl152_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl152.Hide();
                scr.Score = scr.Score + 1;
               
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl153_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl153.Hide();
                MessageBox.Show("Fire in the Hole -5 Points", "Ha Ha Ha Ha Ha", MessageBoxButtons.OK, MessageBoxIcon.Error);
                scr.Score = scr.Score - 5;
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl154_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl154.Hide();
                scr.Score = scr.Score + 3;
                
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl155_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl155.Hide();
                scr.Score = scr.Score + 2;
               
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl156_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl156.Hide();
                MessageBox.Show("Fire in the Hole -2 Points", "Ha Ha Ha Ha Ha", MessageBoxButtons.OK, MessageBoxIcon.Error);
                scr.Score = scr.Score - 2;
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl157_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl157.Hide();
                scr.Score = scr.Score + 1;
               
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl158_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl158.Hide();
                scr.Score = scr.Score + 4;
                
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl159_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl159.Hide();
                scr.Score = scr.Score + 8;
               
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
                
            }
        }

        private void lbl160_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl160.Hide();
                scr.Score = scr.Score + 1;
                
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl161_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl161.Hide();
                MessageBox.Show("Fire in the Hole -4 Points", "Ha Ha Ha Ha Ha", MessageBoxButtons.OK, MessageBoxIcon.Error);
                scr.Score = scr.Score - 4;
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl162_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl162.Hide();
                MessageBox.Show("Fire in the Hole -5 Points", "Ha Ha Ha Ha Ha", MessageBoxButtons.OK, MessageBoxIcon.Error);
                scr.Score = scr.Score - 5;
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl163_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl163.Hide();
                scr.Score = scr.Score + 4;
               
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl164_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl164.Hide();
                scr.Score = scr.Score + 11;
               
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl165_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl165.Hide();
                MessageBox.Show("Fire in the Hole -3 Points", "Ha Ha Ha Ha Ha", MessageBoxButtons.OK, MessageBoxIcon.Error);
                scr.Score = scr.Score - 3;
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl166_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl166.Hide();
                scr.Score = scr.Score + 1;
               
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl167_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl167.Hide();
                scr.Score = scr.Score + 1;
               
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl168_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl168.Hide();
                scr.Score = scr.Score + 3;
                
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl169_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl169.Hide();
                MessageBox.Show("Fire in the Hole -2 Points", "Ha Ha Ha Ha Ha", MessageBoxButtons.OK, MessageBoxIcon.Error);
                scr.Score = scr.Score - 2;
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();

            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl170_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl170.Hide();
                scr.Score = scr.Score + 4;
               
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl171_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl171.Hide();
                MessageBox.Show("Fire in the Hole -3 Points", "Ha Ha Ha Ha Ha", MessageBoxButtons.OK, MessageBoxIcon.Error);
                scr.Score = scr.Score - 3;
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl172_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl172.Hide();
                scr.Score = scr.Score + 4;
                
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl173_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl173.Hide();
                MessageBox.Show("Fire in the Hole -2 Points", "Ha Ha Ha Ha Ha", MessageBoxButtons.OK, MessageBoxIcon.Error);
                scr.Score = scr.Score - 2;
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl174_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl174.Hide();
                MessageBox.Show("Fire in the Hole -1 Points", "Ha Ha Ha Ha Ha", MessageBoxButtons.OK, MessageBoxIcon.Error);
                scr.Score = scr.Score - 1;
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl175_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl175.Hide();
                MessageBox.Show("Fire in the Hole -1 Points", "Ha Ha Ha Ha Ha", MessageBoxButtons.OK, MessageBoxIcon.Error);
                scr.Score = scr.Score - 1;
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl176_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl176.Hide();
                MessageBox.Show("Fire in the Hole -3 Points", "Ha Ha Ha Ha Ha", MessageBoxButtons.OK, MessageBoxIcon.Error);
                scr.Score = scr.Score - 3;
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl177_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl177.Hide();
                MessageBox.Show("Fire in the Hole -30 Points", "Ha Ha Ha Ha Ha", MessageBoxButtons.OK, MessageBoxIcon.Error);
                scr.Score = scr.Score - 30;
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl178_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl178.Hide();
                scr.Score = scr.Score + 10;
               
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl179_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl179.Hide();
                scr.Score = scr.Score + 1;
                
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl180_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl180.Hide();
                scr.Score = scr.Score + 5;
               
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl181_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl181.Hide();
                scr.Score = scr.Score + 4;
            
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl182_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl182.Hide();
                MessageBox.Show("Fire in the Hole -2 Points", "Ha Ha Ha Ha Ha", MessageBoxButtons.OK, MessageBoxIcon.Error);
                scr.Score = scr.Score - 2;
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl183_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl183.Hide();
                scr.Score = scr.Score + 3;
               
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl184_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl184.Hide();
                scr.Score = scr.Score + 1;
               
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl185_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl185.Hide();
                scr.Score = scr.Score + 1;
                
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl186_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl186.Hide();
                MessageBox.Show("Fire in the Hole -3 Points", "Ha Ha Ha Ha Ha", MessageBoxButtons.OK, MessageBoxIcon.Error);
                scr.Score = scr.Score - 3;
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl187_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl187.Hide();
                scr.Score = scr.Score + 11;
                
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl188_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl188.Hide();
                scr.Score = scr.Score + 4;
                
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl189_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl189.Hide();
                MessageBox.Show("Fire in the Hole -5 Points", "Ha Ha Ha Ha Ha", MessageBoxButtons.OK, MessageBoxIcon.Error);
                scr.Score = scr.Score - 5;
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl190_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl190.Hide();
                MessageBox.Show("Fire in the Hole -4 Points", "Ha Ha Ha Ha Ha", MessageBoxButtons.OK, MessageBoxIcon.Error);
                scr.Score = scr.Score - 4;
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl191_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl191.Hide();
                MessageBox.Show("Fire in the Hole -7 Points", "Ha Ha Ha Ha Ha", MessageBoxButtons.OK, MessageBoxIcon.Error);
                scr.Score = scr.Score - 7;
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl192_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl192.Hide();
                scr.Score = scr.Score + 5;
               
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl193_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl193.Hide();
                scr.Score = scr.Score + 1;
               
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl194_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl194.Hide();
                MessageBox.Show("Fire in the Hole -1 Points", "Ha Ha Ha Ha Ha", MessageBoxButtons.OK, MessageBoxIcon.Error);
                scr.Score = scr.Score - 1;
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl195_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl195.Hide();
                scr.Score = scr.Score + 9;
               
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl196_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl196.Hide();
                scr.Score = scr.Score + 11;
               
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl197_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl197.Hide();
                scr.Score = scr.Score + 20;
                
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl198_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl198.Hide();
                scr.Score = scr.Score + 1;
              
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl199_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl199.Hide();
                MessageBox.Show("Fire in the Hole -2 Points", "Ha Ha Ha Ha Ha", MessageBoxButtons.OK, MessageBoxIcon.Error);
                scr.Score = scr.Score - 2;
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl200_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                if (lbl100.Visible == true)
                {
                    MessageBox.Show("I am locked find out my pair to unlock me", "Oh!!!!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    click = click + 1;
                    scr.Clicks = click;
                    clckstxtbx.Text = scr.Clicks.ToString();
                }
                else
                {
                    lbl200.Hide();
                    MessageBox.Show("Fire in the Hole -4 Points", "Ha Ha Ha Ha Ha", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    scr.Score = scr.Score - 4;
                    scrtxtbx.Text = scr.Score.ToString();
                    click = click + 1;
                    scr.Clicks = click;
                    clckstxtbx.Text = scr.Clicks.ToString();
                }
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl201_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl201.Hide();
                MessageBox.Show("Fire in the Hole -3 Points", "Ha Ha Ha Ha Ha", MessageBoxButtons.OK, MessageBoxIcon.Error);
                scr.Score = scr.Score - 3;
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl202_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl202.Hide();
                scr.Score = scr.Score + 4;
                
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl203_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl203.Hide();
                MessageBox.Show("Fire in the Hole -2 Points", "Ha Ha Ha Ha Ha", MessageBoxButtons.OK, MessageBoxIcon.Error);
                scr.Score = scr.Score - 2;
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl204_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl204.Hide();
                MessageBox.Show("Fire in the Hole -1 Points", "Ha Ha Ha Ha Ha", MessageBoxButtons.OK, MessageBoxIcon.Error);
                scr.Score = scr.Score - 1;
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl205_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                if (lbl145.Visible == true)
                {
                    MessageBox.Show("I am locked find out my pair to unlock me", "Oh!!!!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    click = click + 1;
                    scr.Clicks = click;
                    clckstxtbx.Text = scr.Clicks.ToString();
                }
                else
                {
                    lbl205.Hide();
                    MessageBox.Show("Fire in the Hole -1 Points", "Ha Ha Ha Ha Ha", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    scr.Score = scr.Score - 1;
                    scrtxtbx.Text = scr.Score.ToString();
                    click = click + 1;
                    scr.Clicks = click;
                    clckstxtbx.Text = scr.Clicks.ToString();
                }
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
               
            }
        }

        private void lbl206_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl206.Hide();
                MessageBox.Show("Fire in the Hole -3 Points", "Ha Ha Ha Ha Ha", MessageBoxButtons.OK, MessageBoxIcon.Error);
                scr.Score = scr.Score - 3;
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl207_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl207.Hide();
                MessageBox.Show("Fire in the Hole -30 Points", "Ha Ha Ha Ha Ha", MessageBoxButtons.OK, MessageBoxIcon.Error);
                scr.Score = scr.Score - 30;
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl208_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl208.Hide();
                scr.Score = scr.Score + 10;
                
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl209_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl209.Hide();
                scr.Score = scr.Score + 1;
               
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl210_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl210.Hide();
                scr.Score = scr.Score + 5;
                
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl211_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl211.Hide();
                MessageBox.Show("Fire in the Hole -20 Points", "Ha Ha Ha Ha Ha", MessageBoxButtons.OK, MessageBoxIcon.Error);
                scr.Score = scr.Score - 20;
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl212_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl212.Hide();
                MessageBox.Show("Fire in the Hole -30 Points", "Ha Ha Ha Ha Ha", MessageBoxButtons.OK, MessageBoxIcon.Error);
                scr.Score = scr.Score - 30;
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl213_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl213.Hide();
                MessageBox.Show("Fire in the Hole -20 Points", "Ha Ha Ha Ha Ha", MessageBoxButtons.OK, MessageBoxIcon.Error);
                scr.Score = scr.Score - 20;
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl214_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl214.Hide();
                MessageBox.Show("Fire in the Hole -10 Points", "Ha Ha Ha Ha Ha", MessageBoxButtons.OK, MessageBoxIcon.Error);
                scr.Score = scr.Score - 10;
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl215_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl215.Hide();
                MessageBox.Show("Fire in the Hole -15 Points", "Ha Ha Ha Ha Ha", MessageBoxButtons.OK, MessageBoxIcon.Error);
                scr.Score = scr.Score - 15;
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl216_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl216.Hide();
                MessageBox.Show("Fire in the Hole -5 Points", "Ha Ha Ha Ha Ha", MessageBoxButtons.OK, MessageBoxIcon.Error);
                scr.Score = scr.Score - 5;
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl217_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl217.Hide();
                MessageBox.Show("Fire in the Hole -100 Points", "Ha Ha Ha Ha Ha", MessageBoxButtons.OK, MessageBoxIcon.Error);
                scr.Score = scr.Score - 100;
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl218_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl218.Hide();
                MessageBox.Show("Fire in the Hole -1 Points", "Ha Ha Ha Ha Ha", MessageBoxButtons.OK, MessageBoxIcon.Error);
                scr.Score = scr.Score - 1;
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl219_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl219.Hide();
                scr.Score = scr.Score + 15;
               
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl220_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl220.Hide();
                scr.Score = scr.Score + 40;
                
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl221_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl221.Hide();
                MessageBox.Show("Fire in the Hole -2 Points", "Ha Ha Ha Ha Ha", MessageBoxButtons.OK, MessageBoxIcon.Error);
                scr.Score = scr.Score - 2;
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl222_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl222.Hide();
                scr.Score = scr.Score + 2;
               
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl223_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl223.Hide();
                MessageBox.Show("Fire in the Hole -1 Points", "Ha Ha Ha Ha Ha", MessageBoxButtons.OK, MessageBoxIcon.Error);
                scr.Score = scr.Score - 1;
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl224_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl224.Hide();
                scr.Score = scr.Score + 4;
                
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl225_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl225.Hide();
                scr.Score = scr.Score + 20;
               
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl226_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl226.Hide();
                MessageBox.Show("Fire in the Hole -20 Points", "Ha Ha Ha Ha Ha", MessageBoxButtons.OK, MessageBoxIcon.Error);
                scr.Score = scr.Score - 20;
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl227_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl227.Hide();
                scr.Score = scr.Score + 3;
               
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl228_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl228.Hide();
                scr.Score = scr.Score + 2;
                
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl229_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl229.Hide();
                scr.Score = scr.Score + 1;
                
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl230_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                if (lbl180.Visible == true)
                {
                    MessageBox.Show("I am locked find out my pair to unlock me", "Oh!!!!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    click = click + 1;
                    scr.Clicks = click;
                    clckstxtbx.Text = scr.Clicks.ToString();
                }
                else
                {
                    lbl230.Hide();
                    MessageBox.Show("Fire in the Hole -50 Points", "Ha Ha Ha Ha Ha", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    scr.Score = scr.Score - 50;
                    scrtxtbx.Text = scr.Score.ToString();
                    click = click + 1;
                    scr.Clicks = click;
                    clckstxtbx.Text = scr.Clicks.ToString();
                }
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl231_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl231.Hide();
                scr.Score = scr.Score + 1;
               
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl232_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                if (lbl115.Visible == true)
                {
                    MessageBox.Show("I am locked find out my pair to unlock me", "Oh!!!!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    click = click + 1;
                    scr.Clicks = click;
                    clckstxtbx.Text = scr.Clicks.ToString();
                }
                else
                {
                    lbl232.Hide();
                    scr.Score = scr.Score + 8;
                    MessageBox.Show("You got 8 points", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    scrtxtbx.Text = scr.Score.ToString();
                    click = click + 1;
                    scr.Clicks = click;
                    clckstxtbx.Text = scr.Clicks.ToString();
                }
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl233_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl233.Hide();
                scr.Score = scr.Score + 4;
                
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl234_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl234.Hide();
                scr.Score = scr.Score + 1;
                
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl235_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl235.Hide();
                MessageBox.Show("Fire in the Hole -2 Points", "Ha Ha Ha Ha Ha", MessageBoxButtons.OK, MessageBoxIcon.Error);
                scr.Score = scr.Score - 2;
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl236_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl236.Hide();
                scr.Score = scr.Score + 2;
                
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl237_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl237.Hide();
                scr.Score = scr.Score + 3;
                
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl238_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl238.Hide();
                MessageBox.Show("Fire in the Hole -5 Points", "Ha Ha Ha Ha Ha", MessageBoxButtons.OK, MessageBoxIcon.Error);
                scr.Score = scr.Score - 5;
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl239_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl239.Hide();
                scr.Score = scr.Score + 1;
                
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl240_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                if (lbl127.Visible == true)
                {
                    MessageBox.Show("I am locked find out my pair to unlock me", "Oh!!!!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    click = click + 1;
                    scr.Clicks = click;
                    clckstxtbx.Text = scr.Clicks.ToString();
                }
                else
                {
                    lbl240.Hide();
                    scr.Score = scr.Score + 10;
                    MessageBox.Show("You got 10 points", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    scrtxtbx.Text = scr.Score.ToString();
                    click = click + 1;
                    scr.Clicks = click;
                    clckstxtbx.Text = scr.Clicks.ToString();
                }
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl241_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl241.Hide();
                scr.Score = scr.Score + 2;
                
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl242_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl242.Hide();
                scr.Score = scr.Score + 7;
               
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl243_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl243.Hide();
                MessageBox.Show("Fire in the Hole -4 Points", "Ha Ha Ha Ha Ha", MessageBoxButtons.OK, MessageBoxIcon.Error);
                scr.Score = scr.Score - 4;
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl244_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl244.Hide();
                MessageBox.Show("Fire in the Hole -2 Points", "Ha Ha Ha Ha Ha", MessageBoxButtons.OK, MessageBoxIcon.Error);
                scr.Score = scr.Score - 2;
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl245_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl245.Hide();
                MessageBox.Show("Fire in the Hole -8 Points", "Ha Ha Ha Ha Ha", MessageBoxButtons.OK, MessageBoxIcon.Error);
                scr.Score = scr.Score - 8;
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl246_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl246.Hide();
                scr.Score = scr.Score + 5;
                
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl247_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl247.Hide();
                scr.Score = scr.Score + 11;
               
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl248_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl248.Hide();
                MessageBox.Show("Fire in the Hole -12 Points", "Ha Ha Ha Ha Ha", MessageBoxButtons.OK, MessageBoxIcon.Error);
                scr.Score = scr.Score - 12;
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl249_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl249.Hide();
                MessageBox.Show("Fire in the Hole -14 Points", "Ha Ha Ha Ha Ha", MessageBoxButtons.OK, MessageBoxIcon.Error);
                scr.Score = scr.Score - 14;
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl250_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                if (lbl63.Visible == true)
                {
                    MessageBox.Show("I am locked find out my pair to unlock me", "Oh!!!!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    click = click + 1;
                    scr.Clicks = click;
                    clckstxtbx.Text = scr.Clicks.ToString();
                }
                else
                {
                    lbl250.Hide();
                    scr.Score = scr.Score + 3;
                    MessageBox.Show("You got 3 points", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    scrtxtbx.Text = scr.Score.ToString();
                    click = click + 1;
                    scr.Clicks = click;
                    clckstxtbx.Text = scr.Clicks.ToString();
                }
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl251_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl251.Hide();
                scr.Score = scr.Score + 11;
               
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl252_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl252.Hide();
                MessageBox.Show("Fire in the Hole -9 Points", "Ha Ha Ha Ha Ha", MessageBoxButtons.OK, MessageBoxIcon.Error);
                scr.Score = scr.Score - 9;
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl253_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl253.Hide();
                MessageBox.Show("Fire in the Hole -2 Points", "Ha Ha Ha Ha Ha", MessageBoxButtons.OK, MessageBoxIcon.Error);
                scr.Score = scr.Score - 2;
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl254_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl254.Hide();
                MessageBox.Show("Fire in the Hole -8 Points", "Ha Ha Ha Ha Ha", MessageBoxButtons.OK, MessageBoxIcon.Error);
                scr.Score = scr.Score - 8;
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl255_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl255.Hide();
                MessageBox.Show("Fire in the Hole -3 Points", "Ha Ha Ha Ha Ha", MessageBoxButtons.OK, MessageBoxIcon.Error);
                scr.Score = scr.Score - 3;
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl256_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl256.Hide();
                MessageBox.Show("Fire in the Hole -2 Points", "Ha Ha Ha Ha Ha", MessageBoxButtons.OK, MessageBoxIcon.Error);
                scr.Score = scr.Score - 2;
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl257_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl257.Hide();
                scr.Score = scr.Score + 1;
                
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl258_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl258.Hide();
                scr.Score = scr.Score + 1;
               
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl259_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl259.Hide();
                MessageBox.Show("Fire in the Hole -4 Points", "Ha Ha Ha Ha Ha", MessageBoxButtons.OK, MessageBoxIcon.Error);
                scr.Score = scr.Score - 4;
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl260_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl260.Hide();
                scr.Score = scr.Score + 5;
               
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl261_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl261.Hide();
                MessageBox.Show("Fire in the Hole -17 Points", "Ha Ha Ha Ha Ha", MessageBoxButtons.OK, MessageBoxIcon.Error);
                scr.Score = scr.Score - 17;
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl262_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl262.Hide();
                scr.Score = scr.Score + 15;
                
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl263_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl263.Hide();
                scr.Score = scr.Score + 4;
                
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl264_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl264.Hide();
                MessageBox.Show("Fire in the Hole -3 Points", "Ha Ha Ha Ha Ha", MessageBoxButtons.OK, MessageBoxIcon.Error);
                scr.Score = scr.Score - 3;
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl265_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl265.Hide();
                MessageBox.Show("Fire in the Hole -30 Points", "Ha Ha Ha Ha Ha", MessageBoxButtons.OK, MessageBoxIcon.Error);
                scr.Score = scr.Score - 30;
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl266_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl266.Hide();
                scr.Score = scr.Score + 2;
                
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl267_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl267.Hide();
                MessageBox.Show("Fire in the Hole -1 Points", "Ha Ha Ha Ha Ha", MessageBoxButtons.OK, MessageBoxIcon.Error);
                scr.Score = scr.Score - 1;
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl268_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl268.Hide();
                scr.Score = scr.Score + 5;
                
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl269_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl269.Hide();
                MessageBox.Show("Fire in the Hole -9 Points", "Ha Ha Ha Ha Ha", MessageBoxButtons.OK, MessageBoxIcon.Error);
                scr.Score = scr.Score - 9;
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl270_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl270.Hide();
                scr.Score = scr.Score + 10;
               
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl271_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl271.Hide();
                scr.Score = scr.Score + 12;
               
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl272_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl272.Hide();
                MessageBox.Show("Fire in the Hole -11 Points", "Ha Ha Ha Ha Ha", MessageBoxButtons.OK, MessageBoxIcon.Error);
                scr.Score = scr.Score - 11;
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl273_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl273.Hide();
                scr.Score = scr.Score + 2;
                
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl274_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl274.Hide();
                scr.Score = scr.Score + 1;
               
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl275_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl275.Hide();
                scr.Score = scr.Score + 4;
                
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl276_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl276.Hide();
                MessageBox.Show("Fire in the Hole -5 Points", "Ha Ha Ha Ha Ha", MessageBoxButtons.OK, MessageBoxIcon.Error);
                scr.Score = scr.Score - 5;
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl277_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl277.Hide();
                MessageBox.Show("Fire in the Hole -3 Points", "Ha Ha Ha Ha Ha", MessageBoxButtons.OK, MessageBoxIcon.Error);
                scr.Score = scr.Score - 3;
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl278_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl278.Hide();
                MessageBox.Show("Fire in the Hole -3 Points", "Ha Ha Ha Ha Ha", MessageBoxButtons.OK, MessageBoxIcon.Error);
                scr.Score = scr.Score - 3;
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl279_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl279.Hide();
                scr.Score = scr.Score + 2;
                
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl280_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl280.Hide();
                scr.Score = scr.Score + 3;
                
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl281_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl281.Hide();
                scr.Score = scr.Score + 3;
                
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl282_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl282.Hide();
                MessageBox.Show("Fire in the Hole -8 Points", "Ha Ha Ha Ha Ha", MessageBoxButtons.OK, MessageBoxIcon.Error);
                scr.Score = scr.Score - 8;
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl283_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl283.Hide();
                MessageBox.Show("Fire in the Hole -2 Points", "Ha Ha Ha Ha Ha", MessageBoxButtons.OK, MessageBoxIcon.Error);
                scr.Score = scr.Score - 2;
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl284_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl284.Hide();
                MessageBox.Show("Fire in the Hole -1 Points", "Ha Ha Ha Ha Ha", MessageBoxButtons.OK, MessageBoxIcon.Error);
                scr.Score = scr.Score - 1;
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl285_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl285.Hide();
                MessageBox.Show("Fire in the Hole -1 Points", "Ha Ha Ha Ha Ha", MessageBoxButtons.OK, MessageBoxIcon.Error);
                scr.Score = scr.Score - 1;
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl286_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl286.Hide();
                scr.Score = scr.Score + 7;
                
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl287_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl287.Hide();
                scr.Score = scr.Score + 20;
                
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl288_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl288.Hide();
                scr.Score = scr.Score + 6;
                
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl289_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl289.Hide();
                scr.Score = scr.Score + 5;
                
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl290_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl290.Hide();
                MessageBox.Show("Fire in the Hole -6 Points", "Ha Ha Ha Ha Ha", MessageBoxButtons.OK, MessageBoxIcon.Error);
                scr.Score = scr.Score - 6;
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl291_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl291.Hide();
                scr.Score = scr.Score + 1;
                
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl292_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl292.Hide();
                MessageBox.Show("Fire in the Hole -7 Points", "Ha Ha Ha Ha Ha", MessageBoxButtons.OK, MessageBoxIcon.Error);
                scr.Score = scr.Score - 7;
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl293_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl293.Hide();
                MessageBox.Show("Fire in the Hole -5 Points", "Ha Ha Ha Ha Ha", MessageBoxButtons.OK, MessageBoxIcon.Error);
                scr.Score = scr.Score - 5;
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl294_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl294.Hide();
                MessageBox.Show("Fire in the Hole -1 Points", "Ha Ha Ha Ha Ha", MessageBoxButtons.OK, MessageBoxIcon.Error);
                scr.Score = scr.Score - 1;
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl295_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl295.Hide();
                scr.Score = scr.Score + 1;
                
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl296_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl296.Hide();
                scr.Score = scr.Score + 11;
               
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl297_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl297.Hide();
                MessageBox.Show("Fire in the Hole -20 Points", "Ha Ha Ha Ha Ha", MessageBoxButtons.OK, MessageBoxIcon.Error);
                scr.Score = scr.Score - 20;
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl298_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                lbl298.Hide();
                scr.Score = scr.Score + 1;
               
                scrtxtbx.Text = scr.Score.ToString();
                click = click + 1;
                scr.Clicks = click;
                clckstxtbx.Text = scr.Clicks.ToString();
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl299_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                if (lbl130.Visible == true)
                {
                    MessageBox.Show("I am locked find out my pair to unlock me", "Oh!!!!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    click = click + 1;
                    scr.Clicks = click;
                    clckstxtbx.Text = scr.Clicks.ToString();
                }
                else
                {
                    lbl299.Hide();
                    MessageBox.Show("Fire in the Hole -2 Points", "Ha Ha Ha Ha Ha", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    scr.Score = scr.Score - 2;
                    scrtxtbx.Text = scr.Score.ToString();
                    click = click + 1;
                    scr.Clicks = click;
                    clckstxtbx.Text = scr.Clicks.ToString();
                }
            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }

        private void lbl300_Click(object sender, EventArgs e)
        {
            if (click < 100)
            {
                if (lbl200.Visible == true)
                {
                    MessageBox.Show("I am locked find out my pair to unlock me", "Oh!!!!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    click = click + 1;
                    scr.Clicks = click;
                    clckstxtbx.Text = scr.Clicks.ToString();
                }
                else
                {
                    lbl300.Hide();
                    MessageBox.Show("Fire in the Hole -4 Points", "Ha Ha Ha Ha Ha", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    scr.Score = scr.Score - 4;
                    scrtxtbx.Text = scr.Score.ToString();
                    click = click + 1;
                    scr.Clicks = click;
                    clckstxtbx.Text = scr.Clicks.ToString();
                }


            }
            else
            {
                if (scr.Score > scr.Highscore)
                {
                    scr.Highscore = scr.Score;
                    frm5.label3.Text = scr.Score.ToString();
                    frm5.label5.Text = scr.Clicks.ToString();
                    frm5.label7.Text = scr.Highscore.ToString();
                    frm5.ShowDialog();
                }
                else
                {
                    frm4.label3.Text = scr.Score.ToString();
                    frm4.label5.Text = scr.Clicks.ToString();
                    frm4.label7.Text = scr.Highscore.ToString();
                    frm4.ShowDialog();
                }
                scr.Save();
                this.Close();
            }
        }



        private void lbl3_MouseEnter(object sender, EventArgs e)
        {
            if (lbl1.Visible == false)
            {
                lbl3.ForeColor = Color.OrangeRed;
            }
            else
            {
                lbl3.ForeColor = Color.Black;
            }
        }



        private void lbl9_MouseEnter(object sender, EventArgs e)
        {
            if (lbl220.Visible == false)
            {
                lbl9.ForeColor = Color.OrangeRed;
            }
            else
            {
                lbl9.ForeColor = Color.Black;
            }
        }



        private void lbl42_MouseEnter(object sender, EventArgs e)
        {
            if (lbl45.Visible == false)
            {
                lbl42.ForeColor = Color.OrangeRed;
            }
            else
            {
                lbl42.ForeColor = Color.Black;
            }
        }



        private void lbl50_MouseEnter(object sender, EventArgs e)
        {
            if (lbl75.Visible == false)
            {
                lbl50.ForeColor = Color.OrangeRed;
            }
            else
            {
                lbl50.ForeColor = Color.Black;
            }
        }



        private void lbl118_MouseEnter(object sender, EventArgs e)
        {
            if (lbl7.Visible == false)
            {
                lbl118.ForeColor = Color.OrangeRed;
            }
            else
            {
                lbl118.ForeColor = Color.Black;
            }

        }
        private void usrMouseEnter(object sender, EventArgs e)
        {
            Label lb = (Label)sender;
            lb.ForeColor = Color.Orange;

        }

        private void usrMouseLeave(object sender, EventArgs e)
        {
            Label lb1 = (Label)sender;
            lb1.ForeColor = Color.Black;
        }

        private void lbl200_MouseEnter(object sender, EventArgs e)
        {
            if (lbl100.Visible == false)
            {
                lbl200.ForeColor = Color.OrangeRed;
            }
            else
            {
                lbl200.ForeColor = Color.Black;
            }
        }

        private void lbl300_MouseEnter(object sender, EventArgs e)
        {
            if (lbl200.Visible == false)
            {
                lbl300.ForeColor = Color.OrangeRed;
            }
            else
            {
                lbl300.ForeColor = Color.Black;
            }
        }

        private void lbl150_MouseEnter(object sender, EventArgs e)
        {
            if (lbl300.Visible == false)
            {
                lbl150.ForeColor = Color.OrangeRed;
            }
            else
            {
                lbl150.ForeColor = Color.Black;
            }
        }

        private void lbl78_MouseEnter(object sender, EventArgs e)
        {
            if (lbl54.Visible == false)
            {
                lbl78.ForeColor = Color.OrangeRed;
            }
            else
            {
                lbl78.ForeColor = Color.Black;
            }
        }

        private void lbl250_MouseEnter(object sender, EventArgs e)
        {
            if (lbl63.Visible == false)
            {
                lbl250.ForeColor = Color.OrangeRed;
            }
            else
            {
                lbl250.ForeColor = Color.Black;
            }
        }

        private void lbl232_MouseEnter(object sender, EventArgs e)
        {
            if (lbl115.Visible == false)
            {
                lbl232.ForeColor = Color.OrangeRed;
            }
            else
            {
                lbl232.ForeColor = Color.Black;
            }
        }

        private void lbl240_MouseEnter(object sender, EventArgs e)
        {
            if (lbl127.Visible == false)
            {
                lbl240.ForeColor = Color.OrangeRed;
            }
            else
            {
                lbl240.ForeColor = Color.Black;
            }
        }

        private void lbl299_MouseEnter(object sender, EventArgs e)
        {
            if (lbl130.Visible == false)
            {
                lbl299.ForeColor = Color.OrangeRed;
            }
            else
            {
                lbl299.ForeColor = Color.Black;
            }
        }

        private void lbl205_MouseEnter(object sender, EventArgs e)
        {
            if (lbl145.Visible == false)
            {
                lbl205.ForeColor = Color.OrangeRed;
            }
            else
            {
                lbl205.ForeColor = Color.Black;
            }
        }

        private void lbl230_MouseEnter(object sender, EventArgs e)
        {
            if (lbl180.Visible == false)
            {
                lbl230.ForeColor = Color.OrangeRed;
            }
            else
            {
                lbl230.ForeColor = Color.Black;
            }
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            if (scr.Count == 0)
            {
                lbl1.Location = lbl26.Location;
                lbl2.Location = lbl27.Location;
                lbl3.Location = lbl28.Location;
                lbl4.Location = lbl29.Location;
                lbl5.Location = lbl30.Location;
                lbl6.Location = lbl31.Location;
                lbl7.Location = lbl32.Location;
                lbl8.Location = lbl33.Location;
                lbl9.Location = lbl34.Location;
                lbl10.Location = lbl35.Location;
                lbl11.Location = lbl36.Location;
                lbl12.Location = lbl37.Location;
                lbl13.Location = lbl38.Location;
                lbl14.Location = lbl39.Location;
                lbl15.Location = lbl40.Location;
                lbl16.Location = lbl41.Location;
                lbl17.Location = lbl42.Location;
                lbl18.Location = lbl43.Location;
                lbl19.Location = lbl44.Location;
                lbl20.Location = lbl45.Location;
                lbl21.Location = lbl46.Location;
                lbl22.Location = lbl47.Location;
                lbl23.Location = lbl48.Location;
                lbl24.Location = lbl49.Location;
                lbl25.Location = lbl50.Location;

                lbl26.Location = new Point(23, 51);
                lbl27.Location = new Point(66, 51);
                lbl28.Location = new Point(110, 51);
                lbl29.Location = new Point(154, 51);
                lbl30.Location = new Point(198, 51);
                lbl31.Location = new Point(242, 51);
                lbl32.Location = new Point(285, 51);
                lbl33.Location = new Point(329, 51);
                lbl34.Location = new Point(373, 51);
                lbl35.Location = new Point(417, 51);
                lbl36.Location = new Point(461, 51);
                lbl37.Location = new Point(505, 51);
                lbl38.Location = new Point(549, 51);
                lbl39.Location = new Point(593, 51);
                lbl40.Location = new Point(637, 51);
                lbl41.Location = new Point(681, 51);
                lbl42.Location = new Point(725, 51);
                lbl43.Location = new Point(769, 51);
                lbl44.Location = new Point(813, 51);
                lbl45.Location = new Point(857, 51);
                lbl46.Location = new Point(901, 51);
                lbl47.Location = new Point(945, 51);
                lbl48.Location = new Point(989, 51);
                lbl49.Location = new Point(1033, 51);
                lbl50.Location = new Point(1077, 51);

                lbl51.Location = lbl82.Location;
                lbl52.Location = lbl83.Location;
                lbl53.Location = lbl84.Location;
                lbl54.Location = lbl85.Location;
                lbl55.Location = lbl86.Location;
                lbl56.Location = lbl87.Location;
                lbl57.Location = lbl88.Location;
                lbl58.Location = lbl89.Location;
                lbl59.Location = lbl90.Location;
                lbl60.Location = lbl91.Location;
                lbl61.Location = lbl92.Location;
                lbl62.Location = lbl93.Location;
                lbl63.Location = lbl94.Location;
                lbl64.Location = lbl95.Location;
                lbl65.Location = lbl96.Location;
                lbl66.Location = lbl97.Location;
                lbl67.Location = lbl98.Location;
                lbl68.Location = lbl99.Location;
                lbl69.Location = lbl100.Location;
                lbl70.Location = lbl101.Location;
                lbl71.Location = lbl102.Location;
                lbl72.Location = lbl103.Location;
                lbl73.Location = lbl104.Location;
                lbl74.Location = lbl105.Location;
                lbl75.Location = lbl106.Location;
                lbl76.Location = lbl107.Location;
                lbl77.Location = lbl108.Location;
                lbl78.Location = lbl109.Location;
                lbl79.Location = lbl110.Location;
                lbl80.Location = lbl111.Location;
                lbl81.Location = lbl112.Location;

                lbl82.Location = new Point(901, 95);
                lbl83.Location = new Point(945, 95);
                lbl84.Location = new Point(989, 95);
                lbl85.Location = new Point(1033, 95);
                lbl86.Location = new Point(1077, 95);
                lbl87.Location = new Point(1121, 95);
                lbl88.Location = new Point(1165, 95);
                lbl89.Location = new Point(1209, 95);
                lbl90.Location = new Point(1253, 95);
                lbl91.Location = new Point(1297, 95);
                lbl92.Location = new Point(23, 139);
                lbl93.Location = new Point(66, 139);
                lbl94.Location = new Point(110, 139);
                lbl95.Location = new Point(154, 139);
                lbl96.Location = new Point(198, 139);
                lbl97.Location = new Point(242, 139);
                lbl98.Location = new Point(285, 139);
                lbl99.Location = new Point(329, 139);
                lbl100.Location = new Point(373, 139);
                lbl101.Location = new Point(417, 139);
                lbl102.Location = new Point(461, 139);
                lbl103.Location = new Point(505, 139);
                lbl104.Location = new Point(549, 139);
                lbl105.Location = new Point(593, 139);
                lbl106.Location = new Point(637, 139);
                lbl107.Location = new Point(681, 139);
                lbl108.Location = new Point(725, 139);
                lbl109.Location = new Point(769, 139);
                lbl110.Location = new Point(813, 139);
                lbl111.Location = new Point(857, 139);
                lbl112.Location = new Point(901, 139);

                lbl113.Location = lbl145.Location;
                lbl114.Location = lbl146.Location;
                lbl115.Location = lbl147.Location;
                lbl116.Location = lbl148.Location;
                lbl117.Location = lbl149.Location;
                lbl118.Location = lbl150.Location;
                lbl119.Location = lbl151.Location;
                lbl120.Location = lbl152.Location;
                lbl121.Location = lbl153.Location;
                lbl122.Location = lbl154.Location;
                lbl123.Location = lbl155.Location;
                lbl124.Location = lbl156.Location;
                lbl125.Location = lbl157.Location;
                lbl126.Location = lbl158.Location;
                lbl127.Location = lbl159.Location;
                lbl128.Location = lbl160.Location;
                lbl129.Location = lbl161.Location;
                lbl130.Location = lbl162.Location;
                lbl131.Location = lbl163.Location;
                lbl132.Location = lbl164.Location;
                lbl133.Location = lbl165.Location;
                lbl134.Location = lbl166.Location;
                lbl135.Location = lbl167.Location;
                lbl136.Location = lbl168.Location;
                lbl137.Location = lbl169.Location;
                lbl138.Location = lbl170.Location;
                lbl139.Location = lbl171.Location;
                lbl140.Location = lbl172.Location;
                lbl141.Location = lbl173.Location;
                lbl142.Location = lbl174.Location;
                lbl143.Location = lbl175.Location;
                lbl144.Location = lbl176.Location;

                lbl145.Location = new Point(989, 183);
                lbl146.Location = new Point(1033, 183);
                lbl147.Location = new Point(1077, 183);
                lbl148.Location = new Point(1121, 183);
                lbl149.Location = new Point(1165, 183);
                lbl150.Location = new Point(1209, 183);
                lbl151.Location = new Point(1253, 183);
                lbl152.Location = new Point(1297, 183);
                lbl153.Location = new Point(23, 227);
                lbl154.Location = new Point(66, 227);
                lbl155.Location = new Point(110, 227);
                lbl156.Location = new Point(154, 227);
                lbl157.Location = new Point(198, 227);
                lbl158.Location = new Point(242, 227);
                lbl159.Location = new Point(285, 227);
                lbl160.Location = new Point(329, 227);
                lbl161.Location = new Point(373, 227);
                lbl162.Location = new Point(417, 227);
                lbl163.Location = new Point(461, 227);
                lbl164.Location = new Point(505, 227);
                lbl165.Location = new Point(549, 227);
                lbl166.Location = new Point(593, 227);
                lbl167.Location = new Point(637, 227);
                lbl168.Location = new Point(681, 227);
                lbl169.Location = new Point(725, 227);
                lbl170.Location = new Point(769, 227);
                lbl171.Location = new Point(813, 227);
                lbl172.Location = new Point(857, 227);
                lbl173.Location = new Point(901, 227);
                lbl174.Location = new Point(945, 227);
                lbl175.Location = new Point(989, 227);
                lbl176.Location = new Point(1033, 227);




                lbl177.Location = lbl209.Location;
                lbl178.Location = lbl210.Location;
                lbl179.Location = lbl211.Location;
                lbl180.Location = lbl212.Location;
                lbl181.Location = lbl213.Location;
                lbl182.Location = lbl214.Location;
                lbl183.Location = lbl215.Location;
                lbl184.Location = lbl216.Location;
                lbl185.Location = lbl217.Location;
                lbl186.Location = lbl218.Location;
                lbl187.Location = lbl219.Location;
                lbl188.Location = lbl220.Location;
                lbl189.Location = lbl221.Location;
                lbl190.Location = lbl222.Location;
                lbl191.Location = lbl223.Location;
                lbl192.Location = lbl224.Location;
                lbl193.Location = lbl225.Location;
                lbl194.Location = lbl226.Location;
                lbl195.Location = lbl227.Location;
                lbl196.Location = lbl228.Location;
                lbl197.Location = lbl229.Location;
                lbl198.Location = lbl230.Location;
                lbl199.Location = lbl231.Location;
                lbl200.Location = lbl232.Location;
                lbl201.Location = lbl233.Location;
                lbl202.Location = lbl234.Location;
                lbl203.Location = lbl235.Location;
                lbl204.Location = lbl236.Location;
                lbl205.Location = lbl237.Location;
                lbl206.Location = lbl238.Location;
                lbl207.Location = lbl239.Location;
                lbl208.Location = lbl240.Location;

                lbl209.Location = new Point(1165, 271);
                lbl210.Location = new Point(1209, 271);
                lbl211.Location = new Point(1253, 271);
                lbl212.Location = new Point(1297, 271);
                lbl213.Location = new Point(23, 315);
                lbl214.Location = new Point(66, 315);
                lbl215.Location = new Point(110, 315);
                lbl216.Location = new Point(154, 315);
                lbl217.Location = new Point(198, 315);
                lbl218.Location = new Point(242, 315);
                lbl219.Location = new Point(285, 315);
                lbl220.Location = new Point(329, 315);
                lbl221.Location = new Point(373, 315);
                lbl222.Location = new Point(417, 315);
                lbl223.Location = new Point(461, 315);
                lbl224.Location = new Point(505, 315);
                lbl225.Location = new Point(549, 315);
                lbl226.Location = new Point(593, 315);
                lbl227.Location = new Point(637, 315);
                lbl228.Location = new Point(681, 315);
                lbl229.Location = new Point(725, 315);
                lbl230.Location = new Point(769, 315);
                lbl231.Location = new Point(813, 315);
                lbl232.Location = new Point(857, 315);
                lbl233.Location = new Point(901, 315);
                lbl234.Location = new Point(945, 315);
                lbl235.Location = new Point(989, 315);
                lbl236.Location = new Point(1033, 315);
                lbl237.Location = new Point(1077, 315);
                lbl238.Location = new Point(1121, 315);
                lbl239.Location = new Point(1165, 315);
                lbl240.Location = new Point(1209, 315);



                lbl241.Location = lbl271.Location;
                lbl242.Location = lbl272.Location;
                lbl243.Location = lbl273.Location;
                lbl244.Location = lbl274.Location;
                lbl245.Location = lbl275.Location;
                lbl246.Location = lbl276.Location;
                lbl247.Location = lbl277.Location;
                lbl248.Location = lbl278.Location;
                lbl249.Location = lbl279.Location;
                lbl250.Location = lbl280.Location;
                lbl251.Location = lbl281.Location;
                lbl252.Location = lbl282.Location;
                lbl253.Location = lbl283.Location;
                lbl254.Location = lbl284.Location;
                lbl255.Location = lbl285.Location;
                lbl256.Location = lbl286.Location;
                lbl257.Location = lbl287.Location;
                lbl258.Location = lbl288.Location;
                lbl259.Location = lbl289.Location;
                lbl260.Location = lbl290.Location;
                lbl261.Location = lbl291.Location;
                lbl262.Location = lbl292.Location;
                lbl263.Location = lbl293.Location;
                lbl264.Location = lbl294.Location;
                lbl265.Location = lbl295.Location;
                lbl266.Location = lbl296.Location;
                lbl267.Location = lbl297.Location;
                lbl268.Location = lbl298.Location;
                lbl269.Location = lbl299.Location;
                lbl270.Location = lbl300.Location;

                lbl271.Location = new Point(23, 403);
                lbl272.Location = new Point(66, 403);
                lbl273.Location = new Point(110, 403);
                lbl274.Location = new Point(154, 403);
                lbl275.Location = new Point(198, 403);
                lbl276.Location = new Point(242, 403);
                lbl277.Location = new Point(285, 403);
                lbl278.Location = new Point(329, 403);
                lbl279.Location = new Point(373, 403);
                lbl280.Location = new Point(417, 403);
                lbl281.Location = new Point(461, 403);
                lbl282.Location = new Point(505, 403);
                lbl283.Location = new Point(549, 403);
                lbl284.Location = new Point(593, 403);
                lbl285.Location = new Point(637, 403);
                lbl286.Location = new Point(681, 403);
                lbl287.Location = new Point(725, 403);
                lbl288.Location = new Point(769, 403);
                lbl289.Location = new Point(813, 403);
                lbl290.Location = new Point(857, 403);
                lbl291.Location = new Point(901, 403);
                lbl292.Location = new Point(945, 403);
                lbl293.Location = new Point(989, 403);
                lbl294.Location = new Point(1033, 403);
                lbl295.Location = new Point(1077, 403);
                lbl296.Location = new Point(1121, 403);
                lbl297.Location = new Point(1165, 403);
                lbl298.Location = new Point(1209, 403);
                lbl299.Location = new Point(1253, 403);
                lbl300.Location = new Point(1297, 403);
                scr.Count = scr.Count + 1;
                scr.Save();
            }
            else
            {
                scr.Count = scr.Count - 1;
                scr.Save();
            }

        }

        private void timer1_Tick(object sender, EventArgs e)
        {
                Random random = new Random();
                var names = new List<Label> { lbl1,lbl2,lbl3,lbl4,lbl5,lbl6,lbl7,lbl8,lbl9,lbl10,lbl11,lbl12,lbl13,
                                              lbl13,lbl14,lbl15,lbl16,lbl17,lbl18,lbl19,lbl20,lbl21,lbl22,lbl23,lbl24,
                                              lbl25,lbl26,lbl27,lbl27,lbl28,lbl29,lbl30,lbl31,lbl32,lbl33,lbl34,lbl35,
                                              lbl36,lbl37,lbl38,lbl39,lbl40,lbl41,lbl42,lbl43,lbl44,lbl45,lbl46,lbl47,
                                              lbl48,lbl49,lbl50,lbl51,lbl52,lbl53,lbl54,lbl55,lbl56,lbl57,lbl58,lbl59,
                                              lbl60,lbl61,lbl62,lbl63,lbl64,lbl65,lbl66,lbl67,lbl68,lbl69,lbl70,lbl71,
                                              lbl72,lbl73,lbl74,lbl75,lbl76,lbl77,lbl78,lbl79,lbl80,lbl81,lbl82,lbl83,
                                              lbl84,lbl85,lbl86,lbl87,lbl88,lbl89,lbl90,lbl91,lbl92,lbl93,lbl94,lbl95,
                                              lbl96,lbl97,lbl98,lbl99,lbl100,lbl101,lbl102,lbl103,lbl104,lbl105,lbl106,
                                              lbl107,lbl108,lbl109,lbl110,lbl111,lbl112,lbl113,lbl114,lbl115,lbl116,lbl117,
                                              lbl118,lbl119,lbl120,lbl121,lbl122,lbl123,lbl124,lbl125,lbl126,lbl127,lbl128,
                                              lbl129,lbl130,lbl131,lbl132,lbl133,lbl134,lbl135,lbl136,lbl137,lbl138,lbl139,
                                              lbl140,lbl141,lbl142,lbl143,lbl144,lbl145,lbl146,lbl147,lbl148,lbl149,lbl150,
                                              lbl151,lbl152,lbl153,lbl154,lbl155,lbl156,lbl157,lbl158,lbl159,lbl160,lbl161,
                                              lbl162,lbl163,lbl164,lbl165,lbl166,lbl167,lbl168,lbl169,lbl170,lbl171,lbl172,
                                              lbl173,lbl174,lbl175,lbl176,lbl177,lbl178,lbl179,lbl180,lbl181,lbl182,lbl183,
                                              lbl184,lbl185,lbl186,lbl187,lbl188,lbl189,lbl190,lbl191,lbl192,lbl193,lbl194,
                                              lbl195,lbl196,lbl197,lbl198,lbl199,lbl200,lbl201,lbl202,lbl203,lbl204,lbl205,
                                              lbl206,lbl207,lbl208,lbl209,lbl210,lbl211,lbl212,lbl213,lbl214,lbl215,lbl216,
                                              lbl217,lbl218,lbl219,lbl220,lbl221,lbl222,lbl223,lbl224,lbl225,lbl226,lbl227,
                                              lbl228,lbl229,lbl230,lbl231,lbl232,lbl233,lbl234,lbl235,lbl236,lbl237,lbl238,
                                              lbl239,lbl240,lbl241,lbl242,lbl243,lbl244,lbl245,lbl246,lbl247,lbl248,lbl249,
                                              lbl250,lbl251,lbl252,lbl253,lbl254,lbl255,lbl256,lbl257,lbl258,lbl259,lbl260,
                                              lbl261,lbl262,lbl263,lbl264,lbl265,lbl266,lbl267,lbl268,lbl269,lbl270,lbl271,
                                              lbl272,lbl273,lbl274,lbl275,lbl276,lbl277,lbl278,lbl279,lbl280,lbl281,lbl282,
                                              lbl283,lbl284,lbl285,lbl286,lbl287,lbl288,lbl289,lbl290,lbl291,lbl292,lbl293,
                                              lbl294,lbl295,lbl296,lbl297,lbl298,lbl299,lbl300
                                            };
                int index = random.Next(names.Count);
                var name = names[index];
                names.RemoveAt(index);
                name.Hide();
                click = click + 1;
            }
            
         
           
    }
}
