﻿namespace TreeStructureProject
{
    partial class RegistrationForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_RegstrtnFrm = new System.Windows.Forms.Label();
            this.lbl_CustrId = new System.Windows.Forms.Label();
            this.txtbx_CustmrId = new System.Windows.Forms.TextBox();
            this.lbl_name = new System.Windows.Forms.Label();
            this.txtbx_nme = new System.Windows.Forms.TextBox();
            this.lbl_addrss = new System.Windows.Forms.Label();
            this.txtbx_addrss = new System.Windows.Forms.TextBox();
            this.lbl_cntctnmbr = new System.Windows.Forms.Label();
            this.txtbx_cntctnmbr = new System.Windows.Forms.TextBox();
            this.lbl_email = new System.Windows.Forms.Label();
            this.txtbx_email = new System.Windows.Forms.TextBox();
            this.lbl_refrnceId = new System.Windows.Forms.Label();
            this.btn_Rgstr = new System.Windows.Forms.Button();
            this.listbx_Registered = new System.Windows.Forms.ListBox();
            this.listbx_Structrd = new System.Windows.Forms.ListBox();
            this.btn_shw = new System.Windows.Forms.Button();
            this.cmbobx_refid = new System.Windows.Forms.ComboBox();
            this.SuspendLayout();
            // 
            // lbl_RegstrtnFrm
            // 
            this.lbl_RegstrtnFrm.Font = new System.Drawing.Font("Times New Roman", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_RegstrtnFrm.Location = new System.Drawing.Point(595, 19);
            this.lbl_RegstrtnFrm.Name = "lbl_RegstrtnFrm";
            this.lbl_RegstrtnFrm.Size = new System.Drawing.Size(193, 23);
            this.lbl_RegstrtnFrm.TabIndex = 0;
            this.lbl_RegstrtnFrm.Text = "Registration Form";
            this.lbl_RegstrtnFrm.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl_CustrId
            // 
            this.lbl_CustrId.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_CustrId.Location = new System.Drawing.Point(497, 79);
            this.lbl_CustrId.Name = "lbl_CustrId";
            this.lbl_CustrId.Size = new System.Drawing.Size(100, 23);
            this.lbl_CustrId.TabIndex = 1;
            this.lbl_CustrId.Text = "Customer Id";
            this.lbl_CustrId.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // txtbx_CustmrId
            // 
            this.txtbx_CustmrId.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbx_CustmrId.Location = new System.Drawing.Point(662, 76);
            this.txtbx_CustmrId.Name = "txtbx_CustmrId";
            this.txtbx_CustmrId.Size = new System.Drawing.Size(214, 26);
            this.txtbx_CustmrId.TabIndex = 2;
            // 
            // lbl_name
            // 
            this.lbl_name.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_name.Location = new System.Drawing.Point(497, 133);
            this.lbl_name.Name = "lbl_name";
            this.lbl_name.Size = new System.Drawing.Size(100, 23);
            this.lbl_name.TabIndex = 3;
            this.lbl_name.Text = "Name";
            this.lbl_name.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // txtbx_nme
            // 
            this.txtbx_nme.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbx_nme.Location = new System.Drawing.Point(662, 130);
            this.txtbx_nme.Name = "txtbx_nme";
            this.txtbx_nme.Size = new System.Drawing.Size(214, 26);
            this.txtbx_nme.TabIndex = 4;
            // 
            // lbl_addrss
            // 
            this.lbl_addrss.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_addrss.Location = new System.Drawing.Point(497, 192);
            this.lbl_addrss.Name = "lbl_addrss";
            this.lbl_addrss.Size = new System.Drawing.Size(100, 23);
            this.lbl_addrss.TabIndex = 5;
            this.lbl_addrss.Text = "Address";
            this.lbl_addrss.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // txtbx_addrss
            // 
            this.txtbx_addrss.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbx_addrss.Location = new System.Drawing.Point(662, 189);
            this.txtbx_addrss.Multiline = true;
            this.txtbx_addrss.Name = "txtbx_addrss";
            this.txtbx_addrss.Size = new System.Drawing.Size(214, 96);
            this.txtbx_addrss.TabIndex = 6;
            // 
            // lbl_cntctnmbr
            // 
            this.lbl_cntctnmbr.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_cntctnmbr.Location = new System.Drawing.Point(453, 321);
            this.lbl_cntctnmbr.Name = "lbl_cntctnmbr";
            this.lbl_cntctnmbr.Size = new System.Drawing.Size(144, 23);
            this.lbl_cntctnmbr.TabIndex = 7;
            this.lbl_cntctnmbr.Text = "Contact Number";
            this.lbl_cntctnmbr.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // txtbx_cntctnmbr
            // 
            this.txtbx_cntctnmbr.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbx_cntctnmbr.Location = new System.Drawing.Point(662, 318);
            this.txtbx_cntctnmbr.Name = "txtbx_cntctnmbr";
            this.txtbx_cntctnmbr.Size = new System.Drawing.Size(214, 26);
            this.txtbx_cntctnmbr.TabIndex = 8;
            // 
            // lbl_email
            // 
            this.lbl_email.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_email.Location = new System.Drawing.Point(453, 377);
            this.lbl_email.Name = "lbl_email";
            this.lbl_email.Size = new System.Drawing.Size(144, 23);
            this.lbl_email.TabIndex = 9;
            this.lbl_email.Text = "Email - Id";
            this.lbl_email.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // txtbx_email
            // 
            this.txtbx_email.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbx_email.Location = new System.Drawing.Point(662, 374);
            this.txtbx_email.Name = "txtbx_email";
            this.txtbx_email.Size = new System.Drawing.Size(214, 26);
            this.txtbx_email.TabIndex = 10;
            // 
            // lbl_refrnceId
            // 
            this.lbl_refrnceId.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_refrnceId.Location = new System.Drawing.Point(453, 434);
            this.lbl_refrnceId.Name = "lbl_refrnceId";
            this.lbl_refrnceId.Size = new System.Drawing.Size(144, 23);
            this.lbl_refrnceId.TabIndex = 12;
            this.lbl_refrnceId.Text = "Reference Id";
            this.lbl_refrnceId.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // btn_Rgstr
            // 
            this.btn_Rgstr.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Rgstr.Location = new System.Drawing.Point(650, 492);
            this.btn_Rgstr.Name = "btn_Rgstr";
            this.btn_Rgstr.Size = new System.Drawing.Size(80, 29);
            this.btn_Rgstr.TabIndex = 13;
            this.btn_Rgstr.Text = "Register";
            this.btn_Rgstr.UseVisualStyleBackColor = true;
            this.btn_Rgstr.Click += new System.EventHandler(this.btn_Rgstr_Click);
            // 
            // listbx_Registered
            // 
            this.listbx_Registered.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.listbx_Registered.FormattingEnabled = true;
            this.listbx_Registered.ItemHeight = 19;
            this.listbx_Registered.Location = new System.Drawing.Point(66, 492);
            this.listbx_Registered.Name = "listbx_Registered";
            this.listbx_Registered.Size = new System.Drawing.Size(200, 194);
            this.listbx_Registered.TabIndex = 14;
            // 
            // listbx_Structrd
            // 
            this.listbx_Structrd.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.listbx_Structrd.FormattingEnabled = true;
            this.listbx_Structrd.ItemHeight = 19;
            this.listbx_Structrd.Location = new System.Drawing.Point(1099, 492);
            this.listbx_Structrd.Name = "listbx_Structrd";
            this.listbx_Structrd.Size = new System.Drawing.Size(200, 194);
            this.listbx_Structrd.TabIndex = 15;
            // 
            // btn_shw
            // 
            this.btn_shw.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_shw.Location = new System.Drawing.Point(290, 576);
            this.btn_shw.Name = "btn_shw";
            this.btn_shw.Size = new System.Drawing.Size(75, 23);
            this.btn_shw.TabIndex = 16;
            this.btn_shw.Text = "Show ";
            this.btn_shw.UseVisualStyleBackColor = true;
            this.btn_shw.Click += new System.EventHandler(this.btn_shw_Click);
            // 
            // cmbobx_refid
            // 
            this.cmbobx_refid.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbobx_refid.FormattingEnabled = true;
            this.cmbobx_refid.Items.AddRange(new object[] {
            "0",
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10",
            "11",
            "12"});
            this.cmbobx_refid.Location = new System.Drawing.Point(662, 435);
            this.cmbobx_refid.Name = "cmbobx_refid";
            this.cmbobx_refid.Size = new System.Drawing.Size(214, 21);
            this.cmbobx_refid.TabIndex = 17;
            // 
            // RegistrationForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.ClientSize = new System.Drawing.Size(1362, 741);
            this.Controls.Add(this.cmbobx_refid);
            this.Controls.Add(this.btn_shw);
            this.Controls.Add(this.listbx_Structrd);
            this.Controls.Add(this.listbx_Registered);
            this.Controls.Add(this.btn_Rgstr);
            this.Controls.Add(this.lbl_refrnceId);
            this.Controls.Add(this.txtbx_email);
            this.Controls.Add(this.lbl_email);
            this.Controls.Add(this.txtbx_cntctnmbr);
            this.Controls.Add(this.lbl_cntctnmbr);
            this.Controls.Add(this.txtbx_addrss);
            this.Controls.Add(this.lbl_addrss);
            this.Controls.Add(this.txtbx_nme);
            this.Controls.Add(this.lbl_name);
            this.Controls.Add(this.txtbx_CustmrId);
            this.Controls.Add(this.lbl_CustrId);
            this.Controls.Add(this.lbl_RegstrtnFrm);
            this.Name = "RegistrationForm";
            this.Text = "RegistrationForm";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_RegstrtnFrm;
        private System.Windows.Forms.Label lbl_CustrId;
        private System.Windows.Forms.TextBox txtbx_CustmrId;
        private System.Windows.Forms.Label lbl_name;
        private System.Windows.Forms.TextBox txtbx_nme;
        private System.Windows.Forms.Label lbl_addrss;
        private System.Windows.Forms.TextBox txtbx_addrss;
        private System.Windows.Forms.Label lbl_cntctnmbr;
        private System.Windows.Forms.TextBox txtbx_cntctnmbr;
        private System.Windows.Forms.Label lbl_email;
        private System.Windows.Forms.TextBox txtbx_email;
        private System.Windows.Forms.Label lbl_refrnceId;
        private System.Windows.Forms.Button btn_Rgstr;
        private System.Windows.Forms.ListBox listbx_Registered;
        private System.Windows.Forms.ListBox listbx_Structrd;
        private System.Windows.Forms.Button btn_shw;
        private System.Windows.Forms.ComboBox cmbobx_refid;
    }
}

