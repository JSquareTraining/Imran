﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace passingdatabetweenforms
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        int count = 3;
        private void Regstrbtn_Click(object sender, EventArgs e)
        {
             Form2 frm2 = new Form2();
            Hide();
            frm2.ShowDialog();
        }
        private void Lgnbtn_Click(object sender, EventArgs e)
        {
            if (Usrnmetxtbx.Text == "" && Pswdtxtxbx.Text == "")
            {
                MessageBox.Show("Please enter the Username and Password", "Information", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else if (Usrnmetxtbx.Text == "")
            {
                MessageBox.Show("Please enter the Username", "Information", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else if (Pswdtxtxbx.Text == "")
            {
                MessageBox.Show("Please enter the Password", "Information", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else if (count != 0)
            {
                if (Usrnmetxtbx.Text == textBox1.Text && Pswdtxtxbx.Text == textBox2.Text)
                {
                    DialogResult ha = new DialogResult();
                    ha = MessageBox.Show("You Logged in Successfully", "Information", MessageBoxButtons.OK);
                    if (ha == DialogResult.OK)
                    {
                        this.Close();
                    }
                    else
                    {
                        this.Close();
                    }

                }

                else
                {
                    count--;
                    DialogResult ha1 = new DialogResult();
                    ha1 = MessageBox.Show("Please enter the correct Username/Password", "Information", MessageBoxButtons.OK);
                    if (ha1 == DialogResult.OK)
                    {
                        MessageBox.Show("You have only" + count + "Chances only", "Information", MessageBoxButtons.OK);
                    }
                    else
                    {
                        this.Close();
                    }
                }
            }
            else
            {
                this.Close();
            }
        }

        
    }
}
