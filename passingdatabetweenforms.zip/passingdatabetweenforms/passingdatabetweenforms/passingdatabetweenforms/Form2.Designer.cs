﻿namespace passingdatabetweenforms
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Pswdtxtxbx1 = new System.Windows.Forms.TextBox();
            this.Usrnmetxtbx1 = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.Regstrbtn1 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // Pswdtxtxbx1
            // 
            this.Pswdtxtxbx1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Pswdtxtxbx1.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Pswdtxtxbx1.Location = new System.Drawing.Point(272, 158);
            this.Pswdtxtxbx1.Name = "Pswdtxtxbx1";
            this.Pswdtxtxbx1.PasswordChar = '$';
            this.Pswdtxtxbx1.Size = new System.Drawing.Size(238, 26);
            this.Pswdtxtxbx1.TabIndex = 11;
            // 
            // Usrnmetxtbx1
            // 
            this.Usrnmetxtbx1.BackColor = System.Drawing.SystemColors.Window;
            this.Usrnmetxtbx1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Usrnmetxtbx1.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Usrnmetxtbx1.Location = new System.Drawing.Point(272, 93);
            this.Usrnmetxtbx1.Name = "Usrnmetxtbx1";
            this.Usrnmetxtbx1.Size = new System.Drawing.Size(238, 26);
            this.Usrnmetxtbx1.TabIndex = 10;
            // 
            // label2
            // 
            this.label2.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(99, 149);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(167, 38);
            this.label2.TabIndex = 9;
            this.label2.Text = "Password";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(99, 84);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(167, 38);
            this.label1.TabIndex = 8;
            this.label1.Text = "Username";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Regstrbtn1
            // 
            this.Regstrbtn1.BackColor = System.Drawing.Color.Honeydew;
            this.Regstrbtn1.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Regstrbtn1.Location = new System.Drawing.Point(249, 217);
            this.Regstrbtn1.Name = "Regstrbtn1";
            this.Regstrbtn1.Size = new System.Drawing.Size(111, 38);
            this.Regstrbtn1.TabIndex = 7;
            this.Regstrbtn1.Text = "Register";
            this.Regstrbtn1.UseVisualStyleBackColor = false;
            this.Regstrbtn1.Click += new System.EventHandler(this.Regstrbtn1_Click);
            // 
            // Form2
            // 
            this.AcceptButton = this.Regstrbtn1;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Moccasin;
            this.ClientSize = new System.Drawing.Size(608, 348);
            this.Controls.Add(this.Pswdtxtxbx1);
            this.Controls.Add(this.Usrnmetxtbx1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.Regstrbtn1);
            this.Name = "Form2";
            this.Text = "Registration Form";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        public System.Windows.Forms.TextBox Pswdtxtxbx1;
        public System.Windows.Forms.TextBox Usrnmetxtbx1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        public System.Windows.Forms.Button Regstrbtn1;
    }
}