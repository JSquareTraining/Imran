﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace passingdatabetweenforms
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void Regstrbtn1_Click(object sender, EventArgs e)
        {
            if (Usrnmetxtbx1.Text == "" && Pswdtxtxbx1.Text == "")
            {
                MessageBox.Show("Please enter the Username and Password", "Information", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else if(Usrnmetxtbx1.Text == "")
            {
                MessageBox.Show("Please enter the Username", "Information", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else if (Pswdtxtxbx1.Text == "")
            {
                MessageBox.Show("Please enter the Password", "Information", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                DialogResult ss = new DialogResult();
                ss = MessageBox.Show("You have Registered Successfully", "Information", MessageBoxButtons.OK);
                if (ss == DialogResult.OK)
                {
                    Form1 frm1 = new Form1();
                    frm1.textBox1.Text = Usrnmetxtbx1.Text;
                    frm1.textBox2.Text = Pswdtxtxbx1.Text;
                    Hide();
                    frm1.ShowDialog();
                }
                else
                {
                    this.Close();
                }
            }
        }
    }
}
